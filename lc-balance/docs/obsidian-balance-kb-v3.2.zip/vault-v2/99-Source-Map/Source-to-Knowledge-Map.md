---
knowledge_id: Source-to-Knowledge-Map
title: "源文件到知识映射"
domain: Balance
category: Traceability
snapshot_date: 2026-08-22
tags:
  - balance
  - traceability
  - source-map
---

# 源文件到知识映射

本页将每个已分析的源码/文档文件，映射到由其产出的业务规则笔记。当某个源文件发生变更时可用本页查找：该文件下列出的每一条规则都是需要重新核实是否过时的候选对象（本知识库沿用了代码仓库自身"保持测试与文档同步"的既定规则）。

**快照基准：** 本次分析所用的代码仓库副本没有 `.git` 历史记录，因此无法锁定到某个具体的 commit hash。上方的快照日期，以及每个文件自身的最后修改时间戳（在暂存时采集），是目前唯一可用的新鲜度信号；关于这一点及其他方法论上的注意事项，参见 [[Knowledge-Gaps|知识空白]]。

**覆盖范围：** 在 20 个萃取分组、约 180 个已分析文件中，共有 89 个不同的源码/文档文件被至少一条业务规则引用为证据。

## Angular UI — 交易构建器（Transaction Builder，27 个文件）

| 源文件 | 生成的规则 |
|---|---|
| `src/app/transaction-builder/account-entries-dialog.component.html` | [[EXPOSURE-RULE-012]] |
| `src/app/transaction-builder/account-entries-dialog.component.ts` | [[STATUS-RULE-026]] |
| `src/app/transaction-builder/balance-component.model.spec.ts` | [[STATUS-RULE-019]], [[STATUS-RULE-020]], [[STATUS-RULE-021]], [[STATUS-RULE-022]], [[STATUS-RULE-023]] |
| `src/app/transaction-builder/balance-component.model.ts` | [[MOVEMENT-RULE-017]], [[MOVEMENT-RULE-018]], [[STATUS-RULE-019]], [[STATUS-RULE-020]], [[STATUS-RULE-021]], [[STATUS-RULE-022]], [[STATUS-RULE-023]] |
| `src/app/transaction-builder/builder-fields.spec.ts` | [[MAKER-CHECKER-RULE-014]] |
| `src/app/transaction-builder/builder-fields.ts` | [[MAKER-CHECKER-RULE-014]], [[MAKER-CHECKER-RULE-024]], [[MOVEMENT-RULE-020]] |
| `src/app/transaction-builder/catalog-picker.service.ts` | [[MAKER-CHECKER-RULE-006]], [[MAKER-CHECKER-RULE-043]], [[MOVEMENT-RULE-036]] |
| `src/app/transaction-builder/checker-actions.service.spec.ts` | [[MAKER-CHECKER-RULE-031]], [[MAKER-CHECKER-RULE-032]], [[MAKER-CHECKER-RULE-033]], [[MAKER-CHECKER-RULE-034]], [[MAKER-CHECKER-RULE-035]] |
| `src/app/transaction-builder/checker-actions.service.ts` | [[MAKER-CHECKER-RULE-031]], [[MAKER-CHECKER-RULE-032]], [[MAKER-CHECKER-RULE-033]], [[MAKER-CHECKER-RULE-034]], [[MAKER-CHECKER-RULE-035]], [[MAKER-CHECKER-RULE-036]] |
| `src/app/transaction-builder/checker-panel.component.spec.ts` | [[MAKER-CHECKER-RULE-028]], [[MAKER-CHECKER-RULE-029]], [[MAKER-CHECKER-RULE-030]] |
| `src/app/transaction-builder/checker-panel.component.ts` | [[MAKER-CHECKER-RULE-028]], [[MAKER-CHECKER-RULE-029]], [[MAKER-CHECKER-RULE-030]] |
| `src/app/transaction-builder/document-arrival-hints.service.ts` | [[EXPOSURE-RULE-014]], [[MAKER-CHECKER-RULE-041]], [[MAKER-CHECKER-RULE-042]], [[STATUS-RULE-027]] |
| `src/app/transaction-builder/eligibility-rule.ts` | [[MAKER-CHECKER-RULE-020]] |
| `src/app/transaction-builder/function-policy.spec.ts` | [[MAKER-CHECKER-RULE-019]] |
| `src/app/transaction-builder/function-policy.ts` | [[MAKER-CHECKER-RULE-019]] |
| `src/app/transaction-builder/function-strategy.spec.ts` | [[MAKER-CHECKER-RULE-013]], [[MAKER-CHECKER-RULE-015]], [[MAKER-CHECKER-RULE-016]], [[MAKER-CHECKER-RULE-017]], [[MAKER-CHECKER-RULE-018]] |
| `src/app/transaction-builder/function-strategy.ts` | [[MAKER-CHECKER-RULE-013]], [[MAKER-CHECKER-RULE-014]], [[MAKER-CHECKER-RULE-015]], [[MAKER-CHECKER-RULE-016]], [[MAKER-CHECKER-RULE-017]], [[MAKER-CHECKER-RULE-018]], [[MOVEMENT-RULE-019]], [[MOVEMENT-RULE-024]] |
| `src/app/transaction-builder/inquire-events.service.spec.ts` | [[BALANCE-RULE-014]], [[MAKER-CHECKER-RULE-037]], [[MAKER-CHECKER-RULE-038]], [[STATUS-RULE-024]], [[STATUS-RULE-025]] |
| `src/app/transaction-builder/inquire-events.service.ts` | [[BALANCE-RULE-014]], [[MAKER-CHECKER-RULE-037]], [[MAKER-CHECKER-RULE-038]], [[MOVEMENT-RULE-030]], [[MOVEMENT-RULE-031]], [[MOVEMENT-RULE-032]], [[MOVEMENT-RULE-033]], [[MOVEMENT-RULE-034]], [[MOVEMENT-RULE-035]], [[STATUS-RULE-024]], [[STATUS-RULE-025]] |
| `src/app/transaction-builder/look-up-panel.service.ts` | [[MAKER-CHECKER-RULE-037]], [[MAKER-CHECKER-RULE-039]], [[MAKER-CHECKER-RULE-040]], [[STATUS-RULE-025]] |
| `src/app/transaction-builder/maker-panel.component.ts` | [[BALANCE-RULE-011]], [[BALANCE-RULE-012]], [[BALANCE-RULE-013]], [[MAKER-CHECKER-RULE-027]], [[MOVEMENT-RULE-022]], [[MOVEMENT-RULE-027]], [[MOVEMENT-RULE-029]] |
| `src/app/transaction-builder/maker-submit.service.spec.ts` | [[MAKER-CHECKER-RULE-025]], [[MAKER-CHECKER-RULE-026]] |
| `src/app/transaction-builder/maker-submit.service.ts` | [[MAKER-CHECKER-RULE-025]], [[MAKER-CHECKER-RULE-026]], [[MOVEMENT-RULE-022]], [[MOVEMENT-RULE-028]] |
| `src/app/transaction-builder/picker-selection.service.ts` | [[EXPOSURE-RULE-013]], [[MAKER-CHECKER-RULE-041]], [[MAKER-CHECKER-RULE-042]] |
| `src/app/transaction-builder/submit-rules.spec.ts` | [[MAKER-CHECKER-RULE-021]], [[MAKER-CHECKER-RULE-022]], [[MAKER-CHECKER-RULE-023]] |
| `src/app/transaction-builder/submit-rules.ts` | [[MAKER-CHECKER-RULE-021]], [[MAKER-CHECKER-RULE-022]], [[MAKER-CHECKER-RULE-023]], [[MAKER-CHECKER-RULE-024]], [[MOVEMENT-RULE-020]], [[MOVEMENT-RULE-023]], [[MOVEMENT-RULE-025]], [[MOVEMENT-RULE-026]], [[MOVEMENT-RULE-056]] |
| `src/app/transaction-builder/transaction-builder.component.ts` | [[MAKER-CHECKER-RULE-011]], [[MAKER-CHECKER-RULE-044]] |

## Backend 中台编排器（Express，Business Case 注册表）（5 个文件）

| 源文件 | 生成的规则 |
|---|---|
| `backend/data/businessCases.js` | [[EXPOSURE-RULE-015]], [[EXPOSURE-RULE-016]], [[MAKER-CHECKER-RULE-010]], [[MAKER-CHECKER-RULE-046]], [[MOVEMENT-RULE-007]], [[MOVEMENT-RULE-013]], [[MOVEMENT-RULE-021]], [[MOVEMENT-RULE-037]], [[MOVEMENT-RULE-038]], [[MOVEMENT-RULE-039]], [[MOVEMENT-RULE-040]], [[MOVEMENT-RULE-041]], [[MOVEMENT-RULE-060]], [[STATUS-RULE-005]], [[TOLERANCE-RULE-014]] |
| `backend/server.js` | [[MAKER-CHECKER-RULE-045]], [[MAKER-CHECKER-RULE-047]] |
| `backend/test/businessCases.test.js` | [[EXPOSURE-RULE-016]], [[MOVEMENT-RULE-007]], [[MOVEMENT-RULE-013]], [[MOVEMENT-RULE-038]], [[MOVEMENT-RULE-040]], [[MOVEMENT-RULE-041]] |
| `backend/test/runCase.test.js` | [[MAKER-CHECKER-RULE-045]], [[MAKER-CHECKER-RULE-047]] |
| `backend/test/server.test.js` | [[MAKER-CHECKER-RULE-010]], [[MAKER-CHECKER-RULE-045]], [[MAKER-CHECKER-RULE-046]], [[MAKER-CHECKER-RULE-047]], [[MOVEMENT-RULE-039]] |

## 现有设计文档／规格说明／映射工作簿（8 个文件）

| 源文件 | 生成的规则 |
|---|---|
| `analysis/Balance-Component-Business-Rule-Decisions-2026-08-21.md` | [[EXPOSURE-RULE-017]], [[TOLERANCE-RULE-014]] |
| `analysis/Balance-Component-Export-Case-11-Verification-2026-08-22.md` | [[STATUS-RULE-004]], [[STATUS-RULE-005]] |
| `analysis/Balance-Component-Export-Case-2-4-Tenor-Fix-Verification-2026-08-22.md` | [[TOLERANCE-RULE-014]] |
| `analysis/Balance-Component-Import-Case-12-Verification-2026-08-22.md` | [[STATUS-RULE-004]], [[STATUS-RULE-005]] |
| `analysis/Balance-Component-New-Test-Cases-Verification-2026-08-21.md` | [[STATUS-RULE-005]] |
| `analysis/Balance-Component-Test-Case-Proposal.md` | [[EXPOSURE-RULE-017]] |
| `analysis/Balance-Figures-Calculation-Logic.md` | [[BALANCE-RULE-001]], [[BALANCE-RULE-002]], [[BALANCE-RULE-003]], [[BALANCE-RULE-004]], [[BALANCE-RULE-007]], [[BALANCE-RULE-009]], [[BALANCE-RULE-010]] |
| `analysis/contingent-liability-ledger.html` | [[EXPOSURE-RULE-018]], [[EXPOSURE-RULE-019]], [[EXPOSURE-RULE-022]], [[EXPOSURE-RULE-024]], [[EXPOSURE-RULE-025]], [[MOVEMENT-RULE-056]], [[MOVEMENT-RULE-057]], [[MOVEMENT-RULE-058]], [[MOVEMENT-RULE-059]], [[MOVEMENT-RULE-060]], [[MOVEMENT-RULE-061]], [[MOVEMENT-RULE-062]], [[STATUS-RULE-030]] |

## 微服务 — API／校验／存储／基础设施（11 个文件）

| 源文件 | 生成的规则 |
|---|---|
| `microservices/balance-component/src/db/index.ts` | [[MAKER-CHECKER-RULE-056]] |
| `microservices/balance-component/src/db/migrations.ts` | [[STATUS-RULE-015]], [[STATUS-RULE-016]] |
| `microservices/balance-component/src/db/schema.ts` | [[BALANCE-RULE-008]], [[STATUS-RULE-010]], [[STATUS-RULE-011]], [[STATUS-RULE-015]], [[STATUS-RULE-017]], [[STATUS-RULE-030]] |
| `microservices/balance-component/src/errors.ts` | [[MAKER-CHECKER-RULE-008]], [[MAKER-CHECKER-RULE-012]] |
| `microservices/balance-component/src/money.ts` | [[TOLERANCE-RULE-009]], [[TOLERANCE-RULE-010]] |
| `microservices/balance-component/src/routes/balanceMovements.ts` | [[MAKER-CHECKER-RULE-004]], [[MAKER-CHECKER-RULE-009]] |
| `microservices/balance-component/src/service/balanceService.ts` | [[BALANCE-RULE-003]], [[BALANCE-RULE-004]], [[BALANCE-RULE-007]], [[BALANCE-RULE-008]], [[EXPOSURE-RULE-001]], [[EXPOSURE-RULE-003]], [[EXPOSURE-RULE-004]], [[EXPOSURE-RULE-005]], [[EXPOSURE-RULE-011]], [[MAKER-CHECKER-RULE-002]], [[MAKER-CHECKER-RULE-003]], [[MAKER-CHECKER-RULE-004]], [[MAKER-CHECKER-RULE-010]], [[MOVEMENT-RULE-002]], [[MOVEMENT-RULE-003]], [[MOVEMENT-RULE-004]], [[MOVEMENT-RULE-007]], [[MOVEMENT-RULE-009]], [[MOVEMENT-RULE-010]], [[MOVEMENT-RULE-011]], [[MOVEMENT-RULE-012]], [[MOVEMENT-RULE-013]], [[MOVEMENT-RULE-042]], [[MOVEMENT-RULE-053]], [[MOVEMENT-RULE-055]], [[STATUS-RULE-004]], [[STATUS-RULE-005]], [[STATUS-RULE-006]], [[STATUS-RULE-007]], [[STATUS-RULE-008]], [[STATUS-RULE-009]], [[STATUS-RULE-014]], [[STATUS-RULE-017]], [[STATUS-RULE-018]], [[TOLERANCE-RULE-014]] |
| `microservices/balance-component/src/store/balanceContractStore.ts` | [[MAKER-CHECKER-RULE-006]], [[MOVEMENT-RULE-014]], [[MOVEMENT-RULE-055]], [[STATUS-RULE-013]], [[STATUS-RULE-014]] |
| `microservices/balance-component/src/store/balanceMovementStore.ts` | [[MAKER-CHECKER-RULE-004]], [[MAKER-CHECKER-RULE-005]], [[MAKER-CHECKER-RULE-050]], [[STATUS-RULE-012]] |
| `microservices/balance-component/src/types.ts` | [[BALANCE-RULE-003]], [[STATUS-RULE-028]] |
| `microservices/balance-component/src/validation/requestSchema.ts` | [[MAKER-CHECKER-RULE-007]], [[TOLERANCE-RULE-010]] |

## 微服务 — 领域逻辑（9 个文件）

| 源文件 | 生成的规则 |
|---|---|
| `microservices/balance-component/src/domain/amendDecrease.ts` | [[MOVEMENT-RULE-006]], [[MOVEMENT-RULE-007]], [[MOVEMENT-RULE-008]], [[TOLERANCE-RULE-013]] |
| `microservices/balance-component/src/domain/balanceDerivation.ts` | [[BALANCE-RULE-001]], [[BALANCE-RULE-002]], [[BALANCE-RULE-004]], [[BALANCE-RULE-005]], [[BALANCE-RULE-006]], [[MOVEMENT-RULE-001]], [[MOVEMENT-RULE-055]] |
| `microservices/balance-component/src/domain/closeEligibility.ts` | [[STATUS-RULE-004]] |
| `microservices/balance-component/src/domain/contingentAccountEntry.ts` | [[EXPOSURE-RULE-007]], [[EXPOSURE-RULE-008]], [[EXPOSURE-RULE-009]], [[EXPOSURE-RULE-010]], [[EXPOSURE-RULE-027]] |
| `microservices/balance-component/src/domain/offBalanceExposure.ts` | [[BALANCE-RULE-009]], [[BALANCE-RULE-010]], [[EXPOSURE-RULE-001]], [[EXPOSURE-RULE-002]], [[EXPOSURE-RULE-003]], [[EXPOSURE-RULE-004]], [[EXPOSURE-RULE-005]], [[EXPOSURE-RULE-006]], [[EXPOSURE-RULE-010]], [[EXPOSURE-RULE-024]], [[TOLERANCE-RULE-008]] |
| `microservices/balance-component/src/domain/shgtRedeem.ts` | [[MOVEMENT-RULE-004]], [[MOVEMENT-RULE-005]], [[MOVEMENT-RULE-056]] |
| `microservices/balance-component/src/domain/statusTransition.ts` | [[MAKER-CHECKER-RULE-001]], [[STATUS-RULE-001]], [[STATUS-RULE-002]], [[STATUS-RULE-003]] |
| `microservices/balance-component/src/domain/tenorRouting.ts` | [[MOVEMENT-RULE-002]], [[MOVEMENT-RULE-003]] |
| `microservices/balance-component/src/domain/tolerance.ts` | [[TOLERANCE-RULE-001]], [[TOLERANCE-RULE-002]], [[TOLERANCE-RULE-003]], [[TOLERANCE-RULE-004]], [[TOLERANCE-RULE-005]], [[TOLERANCE-RULE-006]], [[TOLERANCE-RULE-007]] |

## 微服务 — 测试（14 个文件）

| 源文件 | 生成的规则 |
|---|---|
| `microservices/balance-component/test/unit/app.test.ts` | [[EXPOSURE-RULE-004]], [[MAKER-CHECKER-RULE-004]], [[MAKER-CHECKER-RULE-008]], [[MAKER-CHECKER-RULE-009]], [[MAKER-CHECKER-RULE-010]], [[MAKER-CHECKER-RULE-012]], [[MAKER-CHECKER-RULE-050]], [[STATUS-RULE-008]], [[STATUS-RULE-018]] |
| `microservices/balance-component/test/unit/db/checkAndForeignKeyConstraints.test.ts` | [[STATUS-RULE-015]], [[STATUS-RULE-016]] |
| `microservices/balance-component/test/unit/db/schema.test.ts` | [[MAKER-CHECKER-RULE-004]], [[MAKER-CHECKER-RULE-005]], [[MOVEMENT-RULE-014]], [[STATUS-RULE-010]], [[STATUS-RULE-011]], [[STATUS-RULE-012]], [[STATUS-RULE-014]] |
| `microservices/balance-component/test/unit/domain/balanceDerivation.test.ts` | [[BALANCE-RULE-001]], [[BALANCE-RULE-002]], [[BALANCE-RULE-005]], [[BALANCE-RULE-006]] |
| `microservices/balance-component/test/unit/domain/closeEligibility.test.ts` | [[STATUS-RULE-004]] |
| `microservices/balance-component/test/unit/domain/contingentAccountEntry.test.ts` | [[EXPOSURE-RULE-007]], [[EXPOSURE-RULE-008]], [[EXPOSURE-RULE-009]], [[EXPOSURE-RULE-010]] |
| `microservices/balance-component/test/unit/domain/offBalanceExposure.test.ts` | [[EXPOSURE-RULE-001]], [[EXPOSURE-RULE-002]], [[EXPOSURE-RULE-003]], [[EXPOSURE-RULE-004]], [[EXPOSURE-RULE-006]], [[EXPOSURE-RULE-010]], [[TOLERANCE-RULE-008]] |
| `microservices/balance-component/test/unit/domain/statusTransition.test.ts` | [[MAKER-CHECKER-RULE-001]], [[STATUS-RULE-001]], [[STATUS-RULE-002]], [[STATUS-RULE-003]] |
| `microservices/balance-component/test/unit/domain/tenorRouting.test.ts` | [[MOVEMENT-RULE-002]], [[MOVEMENT-RULE-003]] |
| `microservices/balance-component/test/unit/domain/tolerance.test.ts` | [[TOLERANCE-RULE-001]], [[TOLERANCE-RULE-002]], [[TOLERANCE-RULE-003]], [[TOLERANCE-RULE-004]], [[TOLERANCE-RULE-005]], [[TOLERANCE-RULE-006]], [[TOLERANCE-RULE-007]] |
| `microservices/balance-component/test/unit/errorsAndMoney.test.ts` | [[TOLERANCE-RULE-009]], [[TOLERANCE-RULE-010]] |
| `microservices/balance-component/test/unit/service/balanceService.test.ts` | [[STATUS-RULE-008]], [[STATUS-RULE-009]] |
| `microservices/balance-component/test/unit/service/closeFunction.test.ts` | [[EXPOSURE-RULE-011]], [[MAKER-CHECKER-RULE-002]], [[STATUS-RULE-004]], [[STATUS-RULE-005]], [[STATUS-RULE-006]], [[STATUS-RULE-007]] |
| `microservices/balance-component/test/unit/validation/requestSchema.test.ts` | [[MAKER-CHECKER-RULE-007]], [[TOLERANCE-RULE-010]] |

## OpenAPI 契约（2 个文件）

| 源文件 | 生成的规则 |
|---|---|
| `analysis/balance-component-api.yaml` | [[BALANCE-RULE-001]], [[BALANCE-RULE-002]], [[BALANCE-RULE-007]], [[EXPOSURE-RULE-026]], [[EXPOSURE-RULE-027]], [[MAKER-CHECKER-RULE-048]], [[MOVEMENT-RULE-042]], [[STATUS-RULE-005]], [[TOLERANCE-RULE-001]], [[TOLERANCE-RULE-010]] |
| `analysis/balance-component-channel-api.yaml` | [[MAKER-CHECKER-RULE-049]], [[MOVEMENT-RULE-043]] |

## 根目录（CLAUDE.md、质量／整改报告）（13 个文件）

| 源文件 | 生成的规则 |
|---|---|
| `Balance-Component-Test-Case-Proposal.md` | [[MAKER-CHECKER-RULE-057]] |
| `CLAUDE.md` | [[EXPOSURE-RULE-022]], [[EXPOSURE-RULE-029]] |
| `Quality-report-balance.md` | [[MAKER-CHECKER-RULE-057]] |
| `amountValidation.test.ts` | [[MOVEMENT-RULE-011]], [[MOVEMENT-RULE-013]] |
| `balance-component.model.spec.ts` | [[MOVEMENT-RULE-017]], [[MOVEMENT-RULE-018]] |
| `builder-fields.spec.ts` | [[MOVEMENT-RULE-020]] |
| `businessCases.test.js` | [[EXPOSURE-RULE-004]] |
| `contingent-liability-ledger.html` | [[EXPOSURE-RULE-020]] |
| `function-strategy.spec.ts` | [[MOVEMENT-RULE-019]], [[MOVEMENT-RULE-024]] |
| `inquire-events.service.spec.ts` | [[MOVEMENT-RULE-030]], [[MOVEMENT-RULE-031]], [[MOVEMENT-RULE-032]], [[MOVEMENT-RULE-033]], [[MOVEMENT-RULE-034]], [[MOVEMENT-RULE-035]] |
| `maker-submit.service.spec.ts` | [[MOVEMENT-RULE-028]] |
| `submit-rules.spec.ts` | [[MOVEMENT-RULE-020]], [[MOVEMENT-RULE-023]], [[MOVEMENT-RULE-025]], [[MOVEMENT-RULE-026]] |
| `test/unit/app.test.ts` | [[MOVEMENT-RULE-002]], [[MOVEMENT-RULE-003]], [[MOVEMENT-RULE-010]], [[MOVEMENT-RULE-015]], [[MOVEMENT-RULE-016]] |

