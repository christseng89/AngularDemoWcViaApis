---
knowledge_id: Balance-Traceability-Matrix
title: "余额可追溯性矩阵"
domain: Balance
category: Traceability
snapshot_date: 2026-08-22
tags:
  - balance
  - traceability
---

# 余额可追溯性矩阵

规则 -> 实现 -> 测试，覆盖全部 206 条业务规则。`—` 表示该规则的证据仅引用了实现代码、没有对应的测试文件。更完整的场景级细节参见 [[Test-Scenario-Index|测试场景索引]]，反向映射（源文件 -> 规则）参见 [[Source-to-Knowledge-Map|源文件到知识映射]]。

## BALANCE-RULE（14 条规则，其中 5 条有直接测试证据）

| 规则 | 状态 | 实现 | 测试 |
|---|---|---|---|
| [[BALANCE-RULE-001]] | ✅ | `microservices/balance-component/src/domain/balanceDerivation.ts:17-49 (MOVEMENT_DIRECTION), 65-68 (computeConfirmedBalance); analysis/balance-component-api.yaml:672-681` | `microservices/balance-component/test/unit/domain/balanceDerivation.test.ts:10-18` |
| [[BALANCE-RULE-002]] | ✅ | `microservices/balance-component/src/domain/balanceDerivation.ts:70-77; analysis/balance-component-api.yaml:672-681` | `microservices/balance-component/test/unit/domain/balanceDerivation.test.ts:26-33` |
| [[BALANCE-RULE-003]] | ✅ | `microservices/balance-component/src/service/balanceService.ts:640; microservices/balance-component/src/types.ts:323` | `—` |
| [[BALANCE-RULE-004]] | ✅ | `microservices/balance-component/src/domain/balanceDerivation.ts:79-99; microservices/balance-component/src/service/balanceService.ts:266,299,585` | `—` |
| [[BALANCE-RULE-005]] | ✅ | `microservices/balance-component/src/domain/balanceDerivation.ts:54-55,101-117` | `microservices/balance-component/test/unit/domain/balanceDerivation.test.ts:35-44` |
| [[BALANCE-RULE-006]] | ✅ | `microservices/balance-component/src/domain/balanceDerivation.ts:57-63,111-114` | `microservices/balance-component/test/unit/domain/balanceDerivation.test.ts:20-23` |
| [[BALANCE-RULE-007]] | ✅ | `microservices/balance-component/src/service/balanceService.ts:266-281,299-305,585-631 (assembleSnapshot, both formulas); analysis/balance-component-api.yaml:398-412,1662-1688` | `—` |
| [[BALANCE-RULE-008]] | ✅ | `microservices/balance-component/src/service/balanceService.ts:1430; microservices/balance-component/src/db/schema.ts:99` | `—` |
| [[BALANCE-RULE-009]] | ✅ | `microservices/balance-component/src/domain/offBalanceExposure.ts:48-71 (computeOffBalanceExposure); analysis/Balance-Figures-Calculation-Logic.md (Figures #8/#9, invariant note after §2 table)` | `—` |
| [[BALANCE-RULE-010]] | ✅ | `microservices/balance-component/src/domain/offBalanceExposure.ts:177-186,228-230,244-251; analysis/Balance-Figures-Calculation-Logic.md (Figures #6/#7, invariant note after §2 table)` | `—` |
| [[BALANCE-RULE-011]] | ✅ | `src/app/transaction-builder/maker-panel.component.ts:358-405` | `—` |
| [[BALANCE-RULE-012]] | ✅ | `src/app/transaction-builder/maker-panel.component.ts:774-808` | `—` |
| [[BALANCE-RULE-013]] | ✅ | `src/app/transaction-builder/maker-panel.component.ts:941-992` | `—` |
| [[BALANCE-RULE-014]] | ✅ | `src/app/transaction-builder/inquire-events.service.ts:144-173` | `src/app/transaction-builder/inquire-events.service.spec.ts:282-328 (Import lcAmount sum); src/app/transaction-builder/inquire-events.service.spec.ts:335-354 (Export signed AMEND sum)` |

## EXPOSURE-RULE（29 条规则，其中 16 条有直接测试证据）

| 规则 | 状态 | 实现 | 测试 |
|---|---|---|---|
| [[EXPOSURE-RULE-001]] | ✅ | `microservices/balance-component/src/domain/offBalanceExposure.ts:54-74 (verified read in full); microservices/balance-component/src/service/balanceService.ts:601-606 (assembleSnapshot's automatic businessEventId derivation, verified read)` | `microservices/balance-component/test/unit/domain/offBalanceExposure.test.ts:17-46 (file line count confirmed 298 lines total, range plausible)` |
| [[EXPOSURE-RULE-002]] | ✅ | `microservices/balance-component/src/domain/offBalanceExposure.ts:261-312 (verified read in full)` | `microservices/balance-component/test/unit/domain/offBalanceExposure.test.ts:82-172` |
| [[EXPOSURE-RULE-003]] | ✅ | `microservices/balance-component/src/domain/offBalanceExposure.ts:88-107 (verified read); microservices/balance-component/src/service/balanceService.ts:331-359 (checkNewShgtSufficiency, verified read: parent resolution, confirmed/pendingDecreaseTotal, existingShgtExposure, sequenced BEFORE contract creation per the registry dispatch at line 326)` | `microservices/balance-component/test/unit/domain/offBalanceExposure.test.ts:180-247` |
| [[EXPOSURE-RULE-004]] | ✅ | `microservices/balance-component/src/domain/offBalanceExposure.ts:191-218, 152-186 (verified read); microservices/balance-component/src/service/balanceService.ts:361-396 (checkNewPresentDocsSufficiency, verified read: confirms strict posture, no provisionallyConsumedIds derivation used here)` | `microservices/balance-component/test/unit/domain/offBalanceExposure.test.ts:250-297; microservices/balance-component/test/unit/app.test.ts:1490-1626 (E2E, Present Docs vs. parent Confirmation Available)` |
| [[EXPOSURE-RULE-005]] | ✅ | `microservices/balance-component/src/domain/offBalanceExposure.ts:130-186, 244-251 (verified read); microservices/balance-component/src/service/balanceService.ts:609-632 (assembleSnapshot's EPLC_CONFIRMATION block, verified read — confirms this is the ONLY call site using provisionallyConsumedIds) and :271-277 (checkDecreaseShapedSufficiency's own deliberately-strict EPLC_CONFIRMATION branch, verified read)` | `—` |
| [[EXPOSURE-RULE-006]] | ✅ | `microservices/balance-component/src/domain/offBalanceExposure.ts:152-186, 220-251 (verified read in full)` | `microservices/balance-component/test/unit/domain/offBalanceExposure.test.ts:50-57, 59-74` |
| [[EXPOSURE-RULE-007]] | ✅ | `microservices/balance-component/src/domain/contingentAccountEntry.ts:41-99, 101-117, 119-151 (verified read in full)` | `microservices/balance-component/test/unit/domain/contingentAccountEntry.test.ts:1-202` |
| [[EXPOSURE-RULE-008]] | ✅ | `microservices/balance-component/src/domain/contingentAccountEntry.ts:16-29, 89-99 (verified read)` | `microservices/balance-component/test/unit/domain/contingentAccountEntry.test.ts:167-182` |
| [[EXPOSURE-RULE-009]] | ✅ | `microservices/balance-component/src/domain/contingentAccountEntry.ts:129-151 (verified read)` | `microservices/balance-component/test/unit/domain/contingentAccountEntry.test.ts:112-153, 188-196` |
| [[EXPOSURE-RULE-010]] | ✅ | `microservices/balance-component/src/domain/contingentAccountEntry.ts:129-130 (verified read); microservices/balance-component/src/domain/offBalanceExposure.ts:65-73, 123-128 (verified read)` | `microservices/balance-component/test/unit/domain/contingentAccountEntry.test.ts:184-186; microservices/balance-component/test/unit/domain/offBalanceExposure.test.ts:43-46, 76-79` |
| [[EXPOSURE-RULE-011]] | ✅ | `microservices/balance-component/src/service/balanceService.ts:431-465 (verified read: evaluateContractCloseEligibility, confirms the RELEASED+!presentDocsConsumedAt check for EPLC_CONFIRMATION at the line matching the candidate's cited 448-458 range)` | `microservices/balance-component/test/unit/service/closeFunction.test.ts:365-399 (not directly re-read, but line-count/location plausible given the verified implementation)` |
| [[EXPOSURE-RULE-012]] | ✅ | `src/app/transaction-builder/account-entries-dialog.component.html:17-50` | `—` |
| [[EXPOSURE-RULE-013]] | ✅ | `src/app/transaction-builder/picker-selection.service.ts:90-131` | `—` |
| [[EXPOSURE-RULE-014]] | ✅ | `src/app/transaction-builder/document-arrival-hints.service.ts:161-192` | `—` |
| [[EXPOSURE-RULE-015]] | ✅ | `backend/data/businessCases.js:326-446` | `backend/data/businessCases.js:555-618 (import-case-6's own two matched pairs, verified via the case's own snapshot expectations)` |
| [[EXPOSURE-RULE-016]] | ✅ | `backend/data/businessCases.js:1364-1370,1610-1683,1685-1757` | `backend/test/businessCases.test.js:44-53 (every case's step list structurally validated, notes included)` |
| [[EXPOSURE-RULE-017]] | ✅ | `analysis/Balance-Component-Business-Rule-Decisions-2026-08-21.md:61-73` | `analysis/Balance-Component-Test-Case-Proposal.md:62` |
| [[EXPOSURE-RULE-018]] | ✅ | `analysis/contingent-liability-ledger.html .scope-box` | `—` |
| [[EXPOSURE-RULE-019]] | ✅ | `analysis/contingent-liability-ledger.html Folio 3/5 .callout (verified via grep, line 574: 'an Acceptance movement is tagged exposureNature = ACTUAL, not CONTINGENT')` | `—` |
| [[EXPOSURE-RULE-020]] | ✅ | `TF_Contingent_Liability_Lifecycle-en.txt (converted) — grep-verified §3.7 discussion of 'Classification note'/'Acceptances & DPU', consistent with content at lines 574, 642-643, 665, 668 of contingent-liability-ledger.html which directly cites this source document's rationale` | `TF_Balance_Component_Spec-en.txt §12 T6 (design-doc reference, not independently re-read this pass)` |
| [[EXPOSURE-RULE-021]] | ✅ | `TF_Contingent_Liability_Lifecycle-en.txt (converted), §4.4 'SG discharge — replacing the MIN() rule', grep-verified at line 899, with REDEEMABLE→RELEASED status transitions confirmed at lines 915, 930` | `TF_Balance_Component_Spec-en.txt §12 T3, T4 (not independently re-read this pass)` |
| [[EXPOSURE-RULE-022]] | ⚠️ | `TF_Contingent_Liability_Lifecycle-en.txt §4.4 (grep-verified, line 899); analysis/contingent-liability-ledger.html Notes item 3 (grep-verified, line 667, explicitly naming this as 'a confirmed, deliberate divergence... not an oversight')` | `—` |
| [[EXPOSURE-RULE-023]] | ✅ | `TF_Contingent_Liability_Lifecycle-en.txt §4.5, §10.2 (converted, grep-verified: 'The exposure rule — why the answer is re-weight, not net' at line 955, MAX formula at line 1001, worked example at lines 1025-1041)` | `TF_Balance_Component_Spec-en.txt §12 T5 (not independently re-read this pass)` |
| [[EXPOSURE-RULE-024]] | ✅ | `analysis/contingent-liability-ledger.html Folio 2 establish row, Notes item 7 (grep-verified, line 666); microservices/balance-component/src/domain/offBalanceExposure.ts:70-72 (verified: throw guard's own valid-set comment confirms only ISSUE/PARTIAL_REDEEM/FULL_REDEEM are ever valid for SHGT)` | `—` |
| [[EXPOSURE-RULE-025]] | ✅ | `analysis/contingent-liability-ledger.html Folio 5 release row, Notes item 13 (grep-verified, line 672: 'Held-to-maturity and pre-maturity discounting reverse the identical shadow-memo pair')` | `—` |
| [[EXPOSURE-RULE-026]] | ✅ | `analysis/balance-component-api.yaml lines 1240-1254, 1284-1291 (not independently re-read this pass); analysis/Balance-Component-DB-Design.txt §5.4 (not independently re-read this pass, but consistent with the independently-verified EPLC_EXAMINATION-null-entry code behavior)` | `—` |
| [[EXPOSURE-RULE-027]] | ✅ | `analysis/balance-component-api.yaml lines 210-231, 1298-1315, 1390-1397 (not independently re-read this pass); Balance-Component-DB-Design.txt §4.2.3, §6.2 (not independently re-read this pass)` | `—` |
| [[EXPOSURE-RULE-028]] | ✅ | `Balance-Component-DB-Design.txt §3 (lines 130-140), §4.1 (lines 171-173) — grep-verified in converted/Balance-Component-DB-Design.txt: 'parent_logical_contract_id）仍是應用層以業務鍵維護的邏輯關聯，資料庫 schema 本身並未對它建立 FOREIGN KEY 約束' at line 138-139, and the field description '業務鍵關聯，非 FK' at line 171` | `—` |
| [[EXPOSURE-RULE-029]] | ✅ | `Balance-Component-DB-Design.txt §2.5 (lines 106-117), §4.2.5 (lines 382-409) — not independently re-read this pass, but directly consistent with the independently-verified assembleSnapshot()/multiple-snapshot-column CLAUDE.md decision-log entries` | `—` |

## MAKER-CHECKER-RULE（57 条规则，其中 38 条有直接测试证据）

| 规则 | 状态 | 实现 | 测试 |
|---|---|---|---|
| [[MAKER-CHECKER-RULE-001]] | ✅ | `microservices/balance-component/src/domain/statusTransition.ts:1-38 (header comment + LEGAL_TRANSITIONS table)` | `microservices/balance-component/test/unit/domain/statusTransition.test.ts:16-18` |
| [[MAKER-CHECKER-RULE-002]] | ✅ | `microservices/balance-component/src/service/balanceService.ts:413-430` | `microservices/balance-component/test/unit/service/closeFunction.test.ts:438-486` |
| [[MAKER-CHECKER-RULE-003]] | ✅ | `microservices/balance-component/src/service/balanceService.ts:1271-1308` | `—` |
| [[MAKER-CHECKER-RULE-004]] | ✅ | `microservices/balance-component/src/service/balanceService.ts:992-993,1100-1102; microservices/balance-component/src/store/balanceMovementStore.ts:122-211` | `microservices/balance-component/test/unit/db/schema.test.ts:79-89; microservices/balance-component/test/unit/app.test.ts:87-102` |
| [[MAKER-CHECKER-RULE-005]] | ✅ | `microservices/balance-component/src/store/balanceMovementStore.ts:193-211` | `microservices/balance-component/test/unit/db/schema.test.ts:292-299` |
| [[MAKER-CHECKER-RULE-006]] | ✅ | `microservices/balance-component/src/store/balanceContractStore.ts:98-112,259-264; src/app/transaction-builder/catalog-picker.service.ts:89-128` | `—` |
| [[MAKER-CHECKER-RULE-007]] | ✅ | `microservices/balance-component/src/validation/requestSchema.ts:21-47` | `microservices/balance-component/test/unit/validation/requestSchema.test.ts:17-89` |
| [[MAKER-CHECKER-RULE-008]] | ✅ | `microservices/balance-component/src/errors.ts:48-61` | `microservices/balance-component/test/unit/app.test.ts:955-1062` |
| [[MAKER-CHECKER-RULE-009]] | ✅ | `microservices/balance-component/src/routes/balanceMovements.ts:11-23` | `microservices/balance-component/test/unit/app.test.ts:87-102` |
| [[MAKER-CHECKER-RULE-010]] | ✅ | `microservices/balance-component/src/service/balanceService.ts:1117-1156; backend/data/businessCases.js:123-134,297-302,435-439,640-645,1190-1191` | `microservices/balance-component/test/unit/app.test.ts:2737-2811; backend/test/server.test.js:100-137` |
| [[MAKER-CHECKER-RULE-011]] | ✅ | `src/app/transaction-builder/transaction-builder.component.ts:439-446` | `—` |
| [[MAKER-CHECKER-RULE-012]] | ✅ | `microservices/balance-component/src/errors.ts:58-61` | `microservices/balance-component/test/unit/app.test.ts:955-1062` |
| [[MAKER-CHECKER-RULE-013]] | ✅ | `src/app/transaction-builder/function-strategy.ts:60-183` | `src/app/transaction-builder/function-strategy.spec.ts:8-110` |
| [[MAKER-CHECKER-RULE-014]] | ✅ | `src/app/transaction-builder/function-strategy.ts:135-139,157-161; src/app/transaction-builder/builder-fields.ts:50-55,83-84` | `src/app/transaction-builder/builder-fields.spec.ts:142-166` |
| [[MAKER-CHECKER-RULE-015]] | ✅ | `src/app/transaction-builder/function-strategy.ts:42-52,118-149` | `src/app/transaction-builder/function-strategy.spec.ts:74-93` |
| [[MAKER-CHECKER-RULE-016]] | ✅ | `src/app/transaction-builder/function-strategy.ts:150-156` | `src/app/transaction-builder/function-strategy.spec.ts:96-101` |
| [[MAKER-CHECKER-RULE-017]] | ✅ | `src/app/transaction-builder/function-strategy.ts:226-248` | `src/app/transaction-builder/function-strategy.spec.ts:158-160` |
| [[MAKER-CHECKER-RULE-018]] | ✅ | `src/app/transaction-builder/function-strategy.ts:250-259` | `src/app/transaction-builder/function-strategy.spec.ts:165-174` |
| [[MAKER-CHECKER-RULE-019]] | ✅ | `src/app/transaction-builder/function-policy.ts:106-129` | `src/app/transaction-builder/function-policy.spec.ts:202-309` |
| [[MAKER-CHECKER-RULE-020]] | ✅ | `src/app/transaction-builder/eligibility-rule.ts:28-60` | `—` |
| [[MAKER-CHECKER-RULE-021]] | ✅ | `src/app/transaction-builder/submit-rules.ts:107-110` | `src/app/transaction-builder/submit-rules.spec.ts:236-269` |
| [[MAKER-CHECKER-RULE-022]] | ✅ | `src/app/transaction-builder/submit-rules.ts:111-115` | `src/app/transaction-builder/submit-rules.spec.ts:271-300` |
| [[MAKER-CHECKER-RULE-023]] | ✅ | `src/app/transaction-builder/submit-rules.ts:219-249` | `src/app/transaction-builder/submit-rules.spec.ts:652-742` |
| [[MAKER-CHECKER-RULE-024]] | ⚠️ | `src/app/transaction-builder/submit-rules.ts:100; src/app/transaction-builder/builder-fields.ts:60,139` | `—` |
| [[MAKER-CHECKER-RULE-025]] | ✅ | `src/app/transaction-builder/maker-submit.service.ts:87-150 (submitDocumentArrivalWithSg + rollbackArrivalSgRedeem)` | `src/app/transaction-builder/maker-submit.service.spec.ts:241-286` |
| [[MAKER-CHECKER-RULE-026]] | ✅ | `src/app/transaction-builder/maker-submit.service.ts:9-23,51-60` | `src/app/transaction-builder/maker-submit.service.spec.ts:413-433,477-492,494-512,530-543` |
| [[MAKER-CHECKER-RULE-027]] | ✅ | `src/app/transaction-builder/maker-panel.component.ts:1090-1119` | `—` |
| [[MAKER-CHECKER-RULE-028]] | ✅ | `src/app/transaction-builder/checker-panel.component.ts:264-293` | `src/app/transaction-builder/checker-panel.component.spec.ts:496-597` |
| [[MAKER-CHECKER-RULE-029]] | ✅ | `src/app/transaction-builder/checker-panel.component.ts:256-262,281` | `src/app/transaction-builder/checker-panel.component.spec.ts:599-619` |
| [[MAKER-CHECKER-RULE-030]] | ✅ | `src/app/transaction-builder/checker-panel.component.ts:147-230` | `src/app/transaction-builder/checker-panel.component.spec.ts:274-285,351-426` |
| [[MAKER-CHECKER-RULE-031]] | ✅ | `src/app/transaction-builder/checker-actions.service.ts:49-128` | `src/app/transaction-builder/checker-actions.service.spec.ts:62-407` |
| [[MAKER-CHECKER-RULE-032]] | ✅ | `src/app/transaction-builder/checker-actions.service.ts:233-296` | `src/app/transaction-builder/checker-actions.service.spec.ts:80-99,114-166,188-205,256-278,299-323` |
| [[MAKER-CHECKER-RULE-033]] | ✅ | `src/app/transaction-builder/checker-actions.service.ts:151-159` | `src/app/transaction-builder/checker-actions.service.spec.ts:409-437` |
| [[MAKER-CHECKER-RULE-034]] | ⚠️ | `src/app/transaction-builder/checker-actions.service.ts:50 (release's checkerId derivation), 138 (acknowledgeArrival's identical derivation), 151-159 (reject's hardcoded 'checker1'/'MANUAL_TEST_REJECT')` | `src/app/transaction-builder/checker-actions.service.spec.ts:409-437 (does not assert checkerId varies by createdBy for reject())` |
| [[MAKER-CHECKER-RULE-035]] | ✅ | `src/app/transaction-builder/checker-actions.service.ts:166-170` | `src/app/transaction-builder/checker-actions.service.spec.ts:439-464` |
| [[MAKER-CHECKER-RULE-036]] | ✅ | `src/app/transaction-builder/checker-actions.service.ts:166-223` | `—` |
| [[MAKER-CHECKER-RULE-037]] | ✅ | `src/app/transaction-builder/inquire-events.service.ts:350; src/app/transaction-builder/look-up-panel.service.ts:288,307` | `src/app/transaction-builder/inquire-events.service.spec.ts:142-197` |
| [[MAKER-CHECKER-RULE-038]] | ✅ | `src/app/transaction-builder/inquire-events.service.ts:102,116` | `src/app/transaction-builder/inquire-events.service.spec.ts:240-270` |
| [[MAKER-CHECKER-RULE-039]] | ✅ | `src/app/transaction-builder/look-up-panel.service.ts:200-211,281-289` | `—` |
| [[MAKER-CHECKER-RULE-040]] | ✅ | `src/app/transaction-builder/look-up-panel.service.ts:195-198` | `—` |
| [[MAKER-CHECKER-RULE-041]] | ✅ | `src/app/transaction-builder/picker-selection.service.ts:329-346; src/app/transaction-builder/document-arrival-hints.service.ts:52-88` | `—` |
| [[MAKER-CHECKER-RULE-042]] | ✅ | `src/app/transaction-builder/picker-selection.service.ts:355-410; src/app/transaction-builder/document-arrival-hints.service.ts:90-129` | `—` |
| [[MAKER-CHECKER-RULE-043]] | ✅ | `src/app/transaction-builder/catalog-picker.service.ts:89-128` | `—` |
| [[MAKER-CHECKER-RULE-044]] | ✅ | `src/app/transaction-builder/transaction-builder.component.ts:419-468` | `—` |
| [[MAKER-CHECKER-RULE-045]] | ✅ | `backend/server.js:48-62,109-124` | `backend/test/runCase.test.js:106-133; backend/test/server.test.js:186-206,215-234` |
| [[MAKER-CHECKER-RULE-046]] | ✅ | `backend/data/businessCases.js:123-134,297-302,435-439,640-645,1190-1191` | `backend/test/server.test.js:100-137` |
| [[MAKER-CHECKER-RULE-047]] | ✅ | `backend/server.js:109-124` | `backend/test/server.test.js:258-306; backend/test/runCase.test.js:135-153` |
| [[MAKER-CHECKER-RULE-048]] | ✅ | `analysis/balance-component-api.yaml:756-760,820-829 (idempotency); analysis/balance-component-api.yaml:187-190,762-768,835-839 (re-ISSUE)` | `—` |
| [[MAKER-CHECKER-RULE-049]] | ✅ | `analysis/balance-component-channel-api.yaml:53-66,755-802` | `—` |
| [[MAKER-CHECKER-RULE-050]] | ⚠️ | `TF_Balance_Component_Spec-en.txt §5.4, I15 (design doc, describes unimplemented scheme); TF_Balance_Component_Mapping-en.txt line 601 (I15), 635/643/650 (T23/T31/T38) (design doc, describes unimplemented scheme)` | `TF_Balance_Component_Spec-en.txt §12.1 T23, T31, T38 (design-doc-internal test scenarios, not automated tests against real code); microservices/balance-component/test/unit/app.test.ts:87-102 (real, passing test proving the actual silent-accept behavior)` |
| [[MAKER-CHECKER-RULE-051]] | ✅ | `analysis/Balance-Figures-Calculation-Logic.txt:348-397` | `—` |
| [[MAKER-CHECKER-RULE-052]] | ✅ | `analysis/Balance-Figures-Calculation-Logic.txt:422-438` | `—` |
| [[MAKER-CHECKER-RULE-053]] | ✅ | `Balance-Component-DB-Design.txt §2.3 (lines 83-91); Balance-Component-DB-Design.txt §4.2.6-4.2.7 (lines 416-417,430-432)` | `—` |
| [[MAKER-CHECKER-RULE-054]] | ✅ | `Balance-Component-DB-Design.txt §8.4 (lines 795-802); Balance-Component-DB-Design.txt §4.1.1 idx_contracts_naturalkey row (lines 215-216)` | `—` |
| [[MAKER-CHECKER-RULE-055]] | ✅ | `Balance-Component-DB-Design.txt §1.1 (lines 47-58); Balance-Component-DB-Design.txt §8.1 (lines 767-774)` | `Balance-Component-DB-Optimization-Analysis.txt §3 SQLite-cannot-fix table (lines 198-207); Balance-Component-DB-Optimization-Analysis.txt §4 item 5 (lines 229-230)` |
| [[MAKER-CHECKER-RULE-056]] | ✅ | `microservices/balance-component/src/db/index.ts:39` | `Balance-Component-DB-Optimization-Analysis.txt P0 section (lines 55-69) — describes a new direct test asserting this value` |
| [[MAKER-CHECKER-RULE-057]] | ✅ | `Quality-report-balance.md:273-320 (BAL-123)` | `Quality-report-balance.md:313-320; Balance-Component-Test-Case-Proposal.md:51` |

## MOVEMENT-RULE（62 条规则，其中 39 条有直接测试证据）

| 规则 | 状态 | 实现 | 测试 |
|---|---|---|---|
| [[MOVEMENT-RULE-001]] | ✅ | `microservices/balance-component/src/domain/balanceDerivation.ts:17-49,57-63` | `—` |
| [[MOVEMENT-RULE-002]] | ✅ | `microservices/balance-component/src/domain/tenorRouting.ts:34-41; microservices/balance-component/src/service/balanceService.ts:919-940 (call site)` | `microservices/balance-component/test/unit/domain/tenorRouting.test.ts:36-57; test/unit/app.test.ts:1174-1280` |
| [[MOVEMENT-RULE-003]] | ✅ | `microservices/balance-component/src/domain/tenorRouting.ts:43-50; microservices/balance-component/src/service/balanceService.ts:919-940` | `microservices/balance-component/test/unit/domain/tenorRouting.test.ts:9-34,59-70; test/unit/app.test.ts:1174-1280` |
| [[MOVEMENT-RULE-004]] | ✅ | `microservices/balance-component/src/domain/shgtRedeem.ts:1-40; microservices/balance-component/src/service/balanceService.ts:197-198,247` | `—` |
| [[MOVEMENT-RULE-005]] | ✅ | `microservices/balance-component/src/domain/shgtRedeem.ts:7-14` | `—` |
| [[MOVEMENT-RULE-006]] | ✅ | `microservices/balance-component/src/domain/amendDecrease.ts:39-62` | `—` |
| [[MOVEMENT-RULE-007]] | ✅ | `microservices/balance-component/src/domain/amendDecrease.ts:16-24; microservices/balance-component/src/service/balanceService.ts:179-186,241-243` | `backend/data/businessCases.js:2258-2315 (export-case-10, live-verified); backend/test/businessCases.test.js:80-83` |
| [[MOVEMENT-RULE-008]] | 🟡 | `microservices/balance-component/src/domain/amendDecrease.ts:1-14` | `—` |
| [[MOVEMENT-RULE-009]] | ✅ | `microservices/balance-component/src/service/balanceService.ts:871-892` | `—` |
| [[MOVEMENT-RULE-010]] | ✅ | `microservices/balance-component/src/service/balanceService.ts:999-1014` | `test/unit/app.test.ts:1064-1172` |
| [[MOVEMENT-RULE-011]] | ✅ | `microservices/balance-component/src/service/balanceService.ts:952-982 (assertValidAmount); microservices/balance-component/src/service/balanceService.ts:985-988 (createMovement call site)` | `amountValidation.test.ts:30-212` |
| [[MOVEMENT-RULE-012]] | ✅ | `microservices/balance-component/src/service/balanceService.ts:919-940` | `—` |
| [[MOVEMENT-RULE-013]] | ✅ | `microservices/balance-component/src/service/balanceService.ts:179-186; backend/data/businessCases.js:2260-2315` | `amountValidation.test.ts:136-166; backend/test/businessCases.test.js:80-83` |
| [[MOVEMENT-RULE-014]] | ✅ | `microservices/balance-component/src/store/balanceContractStore.ts:83-93,253-258` | `microservices/balance-component/test/unit/db/schema.test.ts:179-222` |
| [[MOVEMENT-RULE-015]] | ✅ | `—` | `test/unit/app.test.ts:1817-1885` |
| [[MOVEMENT-RULE-016]] | ✅ | `—` | `test/unit/app.test.ts:1800-1815; test/unit/app.test.ts:2416-2444` |
| [[MOVEMENT-RULE-017]] | ✅ | `src/app/transaction-builder/balance-component.model.ts:666-687` | `balance-component.model.spec.ts:683-718` |
| [[MOVEMENT-RULE-018]] | ✅ | `src/app/transaction-builder/balance-component.model.ts:582-588` | `balance-component.model.spec.ts:781-809` |
| [[MOVEMENT-RULE-019]] | ✅ | `src/app/transaction-builder/function-strategy.ts:19-20,93-97,146,220` | `function-strategy.spec.ts:42-45,123-126` |
| [[MOVEMENT-RULE-020]] | ✅ | `src/app/transaction-builder/submit-rules.ts:116-135; src/app/transaction-builder/builder-fields.ts:37-55,77-78,90-97` | `submit-rules.spec.ts:302-340; builder-fields.spec.ts:88-99` |
| [[MOVEMENT-RULE-021]] | ✅ | `backend/data/businessCases.js:396-412,571-618,708-737,893-923` | `backend/data/businessCases.js's own inline case labels state the formula explicitly at each site` |
| [[MOVEMENT-RULE-022]] | ✅ | `src/app/transaction-builder/maker-panel.component.ts:757-772; src/app/transaction-builder/maker-submit.service.ts:91-98` | `—` |
| [[MOVEMENT-RULE-023]] | ✅ | `src/app/transaction-builder/submit-rules.ts:136-148` | `submit-rules.spec.ts:342-382` |
| [[MOVEMENT-RULE-024]] | ✅ | `src/app/transaction-builder/function-strategy.ts:206-224` | `function-strategy.spec.ts:128-132` |
| [[MOVEMENT-RULE-025]] | ✅ | `src/app/transaction-builder/submit-rules.ts:61-77` | `submit-rules.spec.ts:556-606` |
| [[MOVEMENT-RULE-026]] | ✅ | `src/app/transaction-builder/submit-rules.ts:149-156,168-176` | `submit-rules.spec.ts:608-650` |
| [[MOVEMENT-RULE-027]] | ✅ | `src/app/transaction-builder/maker-panel.component.ts:354-356` | `—` |
| [[MOVEMENT-RULE-028]] | ✅ | `src/app/transaction-builder/maker-submit.service.ts:66-85` | `maker-submit.service.spec.ts:104-192` |
| [[MOVEMENT-RULE-029]] | ✅ | `src/app/transaction-builder/maker-panel.component.ts:484-499,846-881` | `—` |
| [[MOVEMENT-RULE-030]] | ✅ | `src/app/transaction-builder/inquire-events.service.ts:82-96` | `inquire-events.service.spec.ts:142-197,213-225,226-239` |
| [[MOVEMENT-RULE-031]] | ✅ | `src/app/transaction-builder/inquire-events.service.ts:90,93-94` | `inquire-events.service.spec.ts:180` |
| [[MOVEMENT-RULE-032]] | ✅ | `src/app/transaction-builder/inquire-events.service.ts:57-63` | `inquire-events.service.spec.ts:186,193` |
| [[MOVEMENT-RULE-033]] | ✅ | `src/app/transaction-builder/inquire-events.service.ts:519-548` | `inquire-events.service.spec.ts:773-846` |
| [[MOVEMENT-RULE-034]] | ✅ | `src/app/transaction-builder/inquire-events.service.ts:507-515` | `inquire-events.service.spec.ts:184-196,199-211` |
| [[MOVEMENT-RULE-035]] | ✅ | `src/app/transaction-builder/inquire-events.service.ts:552-566` | `inquire-events.service.spec.ts:847-902,886` |
| [[MOVEMENT-RULE-036]] | ✅ | `src/app/transaction-builder/catalog-picker.service.ts:89-128` | `—` |
| [[MOVEMENT-RULE-037]] | ✅ | `backend/data/businessCases.js:396-412,571-618,708-737,893-923` | `backend/data/businessCases.js's own inline case labels state the formula explicitly at each site` |
| [[MOVEMENT-RULE-038]] | ✅ | `backend/data/businessCases.js:743-768,939-975` | `backend/test/businessCases.test.js:105-138` |
| [[MOVEMENT-RULE-039]] | ✅ | `backend/data/businessCases.js:1902-1997` | `backend/test/server.test.js:159-184,208-234` |
| [[MOVEMENT-RULE-040]] | ✅ | `backend/data/businessCases.js:2258-2315` | `backend/test/businessCases.test.js:80-83` |
| [[MOVEMENT-RULE-041]] | ✅ | `backend/data/businessCases.js:448-489,2258-2315` | `backend/test/businessCases.test.js:39-42` |
| [[MOVEMENT-RULE-042]] | ✅ | `analysis/balance-component-api.yaml:1361; microservices/balance-component/src/service/balanceService.ts (movementTypeRegistry, closeShaped, tenorRouting checks)` | `—` |
| [[MOVEMENT-RULE-043]] | ✅ | `analysis/balance-component-channel-api.yaml:310-315,855-876` | `—` |
| [[MOVEMENT-RULE-044]] | ✅ | `TF_Contingent_Liability_Lifecycle-en.txt §5.1; TF_Balance_Component_Spec-en.txt I8` | `TF_Balance_Component_Spec-en.txt §12 T7` |
| [[MOVEMENT-RULE-045]] | ✅ | `TF_Contingent_Liability_Lifecycle-en.txt §3.9,§7.7; TF_Balance_Component_Spec-en.txt I12` | `TF_Balance_Component_Spec-en.txt §12 T2` |
| [[MOVEMENT-RULE-046]] | ✅ | `TF_Contingent_Liability_Lifecycle-en.txt §3.5` | `TF_Balance_Component_Spec-en.txt §12 T1` |
| [[MOVEMENT-RULE-047]] | ✅ | `TF_Contingent_Liability_Lifecycle-en.txt §3.4` | `TF_Balance_Component_Spec-en.txt §12 T17` |
| [[MOVEMENT-RULE-048]] | ✅ | `TF_Contingent_Liability_Lifecycle-en.txt §6` | `TF_Balance_Component_Spec-en.txt §12 T11` |
| [[MOVEMENT-RULE-049]] | ✅ | `TF_Contingent_Liability_Lifecycle-en.txt §6` | `TF_Balance_Component_Spec-en.txt §12 T10,T32; I11` |
| [[MOVEMENT-RULE-050]] | ✅ | `TF_Contingent_Liability_Lifecycle-en.txt §3.6` | `TF_Balance_Component_Spec-en.txt §12 T8,T9` |
| [[MOVEMENT-RULE-051]] | ✅ | `TF_Contingent_Liability_Lifecycle-en.txt §7.4b` | `TF_Balance_Component_Spec-en.txt §12 T12` |
| [[MOVEMENT-RULE-052]] | ✅ | `Balance-Figures-Calculation-Logic.txt lines 403-420` | `—` |
| [[MOVEMENT-RULE-053]] | ✅ | `microservices/balance-component/src/service/balanceService.ts:200-230 (closeShaped)` | `—` |
| [[MOVEMENT-RULE-054]] | ✅ | `TF_Balance_Component_Mapping-en.txt line 14 (README Rule #1); TF_Balance_Component_Mapping-en.txt lines 160-161,312-314` | `—` |
| [[MOVEMENT-RULE-055]] | ⚠️ | `microservices/balance-component/src/store/balanceContractStore.ts:219-294 (listVersions/markSuperseded definitions, unused); microservices/balance-component/src/service/balanceService.ts:1420 (only contractVersion usage, hardcoded to 1)` | `—` |
| [[MOVEMENT-RULE-056]] | ⚠️ | `analysis/contingent-liability-ledger.html Folio 2 table + Implementation Notes section (verified verbatim, footnote 8 text); src/app/transaction-builder/submit-rules.ts:116-135 (directly verified A9 lock in this pass)` | `—` |
| [[MOVEMENT-RULE-057]] | ✅ | `analysis/contingent-liability-ledger.html — Implementation Notes, 'Import Acceptance under Buyer's Usance is a further, related divergence' paragraph` | `—` |
| [[MOVEMENT-RULE-058]] | ✅ | `analysis/contingent-liability-ledger.html — Implementation Notes, 'Export tenor collapse (Sight/BU/SU -> Sight/Usance)' paragraph` | `—` |
| [[MOVEMENT-RULE-059]] | ✅ | `analysis/contingent-liability-ledger.html — Implementation Notes, 'Confirm LC Amendment has no direction sub-choice' paragraph` | `—` |
| [[MOVEMENT-RULE-060]] | ✅ | `analysis/contingent-liability-ledger.html — Implementation Notes, 'Usance Accept is the same compound action as Folio 5's own Create row' paragraph` | `backend/data/businessCases.js:1953-1963 (export-case-9's own accept/acceptance/reimbReceivable release sequence and snapshots, directly verified in this pass)` |
| [[MOVEMENT-RULE-061]] | ✅ | `analysis/contingent-liability-ledger.html — Implementation Notes, 'Amendment Decrease is gated on beneficiary consent' paragraph` | `—` |
| [[MOVEMENT-RULE-062]] | ✅ | `analysis/contingent-liability-ledger.html Folio 1 Release/Honour row, Notes item 3` | `—` |

## STATUS-RULE（30 条规则，其中 23 条有直接测试证据）

| 规则 | 状态 | 实现 | 测试 |
|---|---|---|---|
| [[STATUS-RULE-001]] | ✅ | `microservices/balance-component/src/domain/statusTransition.ts:23-29,45-53` | `microservices/balance-component/test/unit/domain/statusTransition.test.ts:5-14` |
| [[STATUS-RULE-002]] | ✅ | `microservices/balance-component/src/domain/statusTransition.ts:23-29` | `microservices/balance-component/test/unit/domain/statusTransition.test.ts:10-11,20-23` |
| [[STATUS-RULE-003]] | ✅ | `microservices/balance-component/src/domain/statusTransition.ts:23-29` | `microservices/balance-component/test/unit/domain/statusTransition.test.ts:21-25` |
| [[STATUS-RULE-004]] | ✅ | `microservices/balance-component/src/domain/closeEligibility.ts:47-64; microservices/balance-component/src/service/balanceService.ts:431-464 (evaluateContractCloseEligibility, whole-tree scan)` | `microservices/balance-component/test/unit/domain/closeEligibility.test.ts:14-59; microservices/balance-component/test/unit/service/closeFunction.test.ts:103-163 (whole-tree PENDING-event blocking)` |
| [[STATUS-RULE-005]] | ✅ | `microservices/balance-component/src/service/balanceService.ts:200-230 (closeShaped); microservices/balance-component/src/service/balanceService.ts:1159-1182 (release() re-check)` | `microservices/balance-component/test/unit/service/closeFunction.test.ts:165-222; backend/data/businessCases.js:1008-1024 (import-case-8)` |
| [[STATUS-RULE-006]] | ✅ | `microservices/balance-component/src/service/balanceService.ts:99,210-216,488-491` | `microservices/balance-component/test/unit/service/closeFunction.test.ts:285-316,476-479` |
| [[STATUS-RULE-007]] | ✅ | `microservices/balance-component/src/service/balanceService.ts:1259-1266` | `microservices/balance-component/test/unit/service/closeFunction.test.ts:47-72,257-283` |
| [[STATUS-RULE-008]] | ✅ | `microservices/balance-component/src/service/balanceService.ts:852-861 (assertRootIssueReleased); microservices/balance-component/src/service/balanceService.ts:894-900 (existing-contract call site)` | `microservices/balance-component/test/unit/service/balanceService.test.ts:644-782; microservices/balance-component/test/unit/app.test.ts:~2965-2980 (HTTP-level, references the same fix by name)` |
| [[STATUS-RULE-009]] | ✅ | `microservices/balance-component/src/service/balanceService.ts:1133-1146,1236-1257` | `microservices/balance-component/test/unit/service/balanceService.test.ts:813-990` |
| [[STATUS-RULE-010]] | ✅ | `microservices/balance-component/src/db/schema.ts:111-114` | `microservices/balance-component/test/unit/db/schema.test.ts:69-73` |
| [[STATUS-RULE-011]] | ✅ | `microservices/balance-component/src/db/schema.ts:107-109` | `microservices/balance-component/test/unit/db/schema.test.ts:74-77` |
| [[STATUS-RULE-012]] | ✅ | `microservices/balance-component/src/store/balanceMovementStore.ts:1-13,367-508` | `microservices/balance-component/test/unit/db/schema.test.ts:301-318` |
| [[STATUS-RULE-013]] | ✅ | `microservices/balance-component/src/store/balanceContractStore.ts:174-217` | `—` |
| [[STATUS-RULE-014]] | ⚠️ | `microservices/balance-component/src/service/balanceService.ts:1419-1420 (contractVersion hardcoded to 1); microservices/balance-component/src/store/balanceContractStore.ts:271-290 (markSuperseded, uncalled outside tests)` | `microservices/balance-component/test/unit/db/schema.test.ts:261-289 (the one and only caller of markSuperseded() in the repo)` |
| [[STATUS-RULE-015]] | ✅ | `microservices/balance-component/src/db/schema.ts:80-153; microservices/balance-component/src/db/migrations.ts:160-263` | `microservices/balance-component/test/unit/db/checkAndForeignKeyConstraints.test.ts:58-166` |
| [[STATUS-RULE-016]] | ✅ | `microservices/balance-component/src/db/migrations.ts:160-263` | `microservices/balance-component/test/unit/db/checkAndForeignKeyConstraints.test.ts:168-208` |
| [[STATUS-RULE-017]] | ✅ | `microservices/balance-component/src/db/schema.ts:19-35,57-74 (MOVEMENT_TYPE_VALUES + its own doc comment naming the registry as authority); microservices/balance-component/src/service/balanceService.ts:232-254 (buildMovementTypeRegistry's return table, keys match exactly)` | `—` |
| [[STATUS-RULE-018]] | ✅ | `microservices/balance-component/src/service/balanceService.ts (release()/reject()/cancel() delegate to applyStatusTransition())` | `microservices/balance-component/test/unit/app.test.ts (reject-already-released and cancel-already-released describe blocks)` |
| [[STATUS-RULE-019]] | ✅ | `src/app/transaction-builder/balance-component.model.ts:534-560 (isEarmarkFunction + displayStatus)` | `src/app/transaction-builder/balance-component.model.spec.ts:638-679` |
| [[STATUS-RULE-020]] | ✅ | `src/app/transaction-builder/balance-component.model.ts:539` | `src/app/transaction-builder/balance-component.model.spec.ts:664-678` |
| [[STATUS-RULE-021]] | ✅ | `src/app/transaction-builder/balance-component.model.ts:551-560 (displayStatus CLOSE branch); src/app/transaction-builder/balance-component.model.ts:613-631 (isCloseMovement + statusBadgeClass CLOSE branch)` | `src/app/transaction-builder/balance-component.model.spec.ts:811-845` |
| [[STATUS-RULE-022]] | ✅ | `src/app/transaction-builder/balance-component.model.ts:590-596` | `src/app/transaction-builder/balance-component.model.spec.ts:840-856` |
| [[STATUS-RULE-023]] | ✅ | `src/app/transaction-builder/balance-component.model.ts:650-663` | `src/app/transaction-builder/balance-component.model.spec.ts:858-895` |
| [[STATUS-RULE-024]] | ✅ | `src/app/transaction-builder/inquire-events.service.ts:402-404` | `src/app/transaction-builder/inquire-events.service.spec.ts:395-465` |
| [[STATUS-RULE-025]] | ✅ | `src/app/transaction-builder/inquire-events.service.ts:276-286; src/app/transaction-builder/look-up-panel.service.ts:136-145` | `src/app/transaction-builder/inquire-events.service.spec.ts:732-772` |
| [[STATUS-RULE-026]] | ✅ | `src/app/transaction-builder/account-entries-dialog.component.ts:43,50-57` | `—` |
| [[STATUS-RULE-027]] | ✅ | `src/app/transaction-builder/document-arrival-hints.service.ts:136-154` | `—` |
| [[STATUS-RULE-028]] | ⚠️ | `ContractStatus/MovementStatus unions in microservices/balance-component/src/types.ts:39,48 — no consent-related state exists` | `—` |
| [[STATUS-RULE-029]] | ⚠️ | `no corresponding implementation found in microservices/balance-component/src/` | `—` |
| [[STATUS-RULE-030]] | ✅ | `analysis/contingent-liability-ledger.html (Folio 1/Folio 4 residual rows, Notes item 4); microservices/balance-component/src/db/schema.ts:58-74 (MOVEMENT_TYPE_VALUES — no EXPIRE/CANCEL value)` | `—` |

## TOLERANCE-RULE（14 条规则，其中 11 条有直接测试证据）

| 规则 | 状态 | 实现 | 测试 |
|---|---|---|---|
| [[TOLERANCE-RULE-001]] | ✅ | `microservices/balance-component/src/domain/tolerance.ts:53-68 (function body, verified verbatim); analysis/balance-component-api.yaml:93-101 (v0.3.0 changelog, corroborating)` | `microservices/balance-component/test/unit/domain/tolerance.test.ts:4-11 (test.each ISSUE/AMEND_INCREASE/AMEND_DECREASE on IPLC_LC — verified content matches exactly)` |
| [[TOLERANCE-RULE-002]] | ✅ | `microservices/balance-component/src/domain/tolerance.ts:32; microservices/balance-component/src/domain/tolerance.ts:56-58` | `microservices/balance-component/test/unit/domain/tolerance.test.ts:44-47 (verified — SHGT/IPLC_ACCEPTANCE both tested unchanged)` |
| [[TOLERANCE-RULE-003]] | ✅ | `microservices/balance-component/src/domain/tolerance.ts:34-39; microservices/balance-component/src/domain/tolerance.ts:59-61` | `microservices/balance-component/test/unit/domain/tolerance.test.ts:22-25 (EPLC_CONFIRMATION HONOUR/ACCEPT); microservices/balance-component/test/unit/domain/tolerance.test.ts:27-29 (UTILIZE)` |
| [[TOLERANCE-RULE-004]] | ✅ | `microservices/balance-component/src/domain/tolerance.ts:19-26 (doc comment explicitly states the rationale); microservices/balance-component/src/domain/tolerance.ts:56-58 (instrumentType gate, checked before movementType)` | `microservices/balance-component/test/unit/domain/tolerance.test.ts:44-45 (SHGT ISSUE with tolerancePct='10' -> unchanged, verified)` |
| [[TOLERANCE-RULE-005]] | ✅ | `microservices/balance-component/src/domain/tolerance.ts:62-64` | `microservices/balance-component/test/unit/domain/tolerance.test.ts:35-38 (verified verbatim, both null and undefined cases)` |
| [[TOLERANCE-RULE-006]] | ✅ | `microservices/balance-component/src/domain/tolerance.ts:66-67` | `microservices/balance-component/test/unit/domain/tolerance.test.ts:40-42 (verified verbatim)` |
| [[TOLERANCE-RULE-007]] | ✅ | `microservices/balance-component/src/domain/tolerance.ts:32` | `microservices/balance-component/test/unit/domain/tolerance.test.ts:13-15 (verified verbatim)` |
| [[TOLERANCE-RULE-008]] | ✅ | `microservices/balance-component/src/domain/offBalanceExposure.ts:298 (verified: tightAvailableBalance = confirmedBalance.minus(pendingDecreaseTotal).minus(offBalanceExposure))` | `microservices/balance-component/test/unit/domain/offBalanceExposure.test.ts:146-178 (checkUtilizeSufficiency PENDING increase/decrease cases, verified); microservices/balance-component/test/unit/domain/offBalanceExposure.test.ts:225-248 (checkShgtIssueSufficiency PENDING increase/decrease cases, verified)` |
| [[TOLERANCE-RULE-009]] | ✅ | `microservices/balance-component/src/money.ts:12-36 (verified verbatim)` | `microservices/balance-component/test/unit/errorsAndMoney.test.ts:28-51 (verified verbatim, including the scale:4 edge case)` |
| [[TOLERANCE-RULE-010]] | ✅ | `microservices/balance-component/src/money.ts:44-107 (verified verbatim, including the deliberate 2dp-fallback-vs-skip departure from the sibling payment-component project); microservices/balance-component/src/validation/requestSchema.ts:19,43 (confirms wiring into the zod schema — resolves the 'presumably' uncertainty in one of the merged candidates)` | `microservices/balance-component/test/unit/errorsAndMoney.test.ts:53-108 (verified — full CURRENCY_MINOR_UNITS table test.each, case-insensitivity, describeAmountScaleViolation messages); microservices/balance-component/test/unit/validation/requestSchema.test.ts (cited by candidate, not independently re-read this pass)` |
| [[TOLERANCE-RULE-011]] | 🟡 | `converted/TF_Contingent_Liability_Lifecycle-en.txt:255-265 (verified content matches, incl. the recommended dual-field data model)` | `—` |
| [[TOLERANCE-RULE-012]] | 🟡 | `converted/TF_Contingent_Liability_Lifecycle-en.txt:1281-1282 (verified content matches)` | `—` |
| [[TOLERANCE-RULE-013]] | ✅ | `microservices/balance-component/src/domain/amendDecrease.ts:38-39 (verified directly: checkAmendDecreaseSufficiency compares params.ceilingAmount against params.tightAvailableBalance, not raw amount); analysis/Balance-Figures-Calculation-Logic.txt:66-85, 329-346 (design-doc corroboration, as originally cited)` | `—` |
| [[TOLERANCE-RULE-014]] | ✅ | `analysis/Balance-Component-Business-Rule-Decisions-2026-08-21.md (Decision 2 section, verified content matches); microservices/balance-component/src/service/balanceService.ts:131 (comment-only; independently confirmed no BUYERS_USANCE guard exists in tenorRouting.ts or balanceService.ts via grep)` | `analysis/Balance-Component-Export-Case-2-4-Tenor-Fix-Verification-2026-08-22.md:45-60 (cited by candidate)` |

