---
knowledge_id: angular-maker-panel-submit-orchestration-test-scenarios
title: "Angular Maker 面板 + Submit 编排 测试场景"
domain: Balance
category: Test Scenarios
snapshot_date: 2026-08-22
tags:
  - balance
  - test-scenario
---

# Angular Maker 面板 + Submit 编排 测试场景

从本主题范围的测试文件中提取了11个测试场景。这些场景所证明的规则详见 Angular Maker Panel + Submit Orchestration 与 [[Business-Rule-Index]]。

| 场景 | 前置条件（Given） | 触发操作（When） | 预期结果（Then） | 来源 |
|---|---|---|---|---|
| A3S ——两条分支均成功，secondary 携带 SG 赎回信息 | 已选择 A3S，一份 confirmedBalance 为 500 的 SG 已解析完成（arrivalSgSnapshot 已存在），输入的 Bill Amount 为 1000 | 调用 submit()，SG 赎回的 createMovement 与 LC UTILIZE 的 createMovement 均成功 | 结果为 'submitted'；result.movementId 即 LC UTILIZE 自身的 id（'da-1'）；secondary.arrivalSgRedeemMovementId 与 secondary.arrivalSgRedeemMovement 均引用该 SG 分支（'sg-redeem-1'）——*余额影响：* 创建了两笔 PENDING 动账，共享同一个 businessEventId——SG 赎回会临时性地减少 SG 的 Outstanding 容量；LC UTILIZE 会消耗 LC 的 Available/Tight 容量，并依据 matched-businessEventId 例外规则，与刚创建的 SG 赎回记录相互抵销。 | `maker-submit.service.spec.ts:201-219` |
| A3S ——SG 赎回本身失败，未创建任何记录 | 已选择 A3S，且有效的 SG 快照已就绪 | 第一次 createMovement 调用（SG 赎回）因 INSUFFICIENT_AVAILABLE_BALANCE 而失败 | 结果为 'failed'，报错信息包含 'Could not reserve the Shipping Guarantee redemption'；result 为 undefined；secondary 为 {}——*余额影响：* 完全没有创建任何动账——LC 与 SG 的余额均不受影响。 | `maker-submit.service.spec.ts:221-234` |
| A3S ——SG 成功但 LC UTILIZE 失败：自动回滚会取消已成为孤儿记录的 SG 赎回 | 已选择 A3S，且有效的 SG 快照已就绪 | SG 赎回的 createMovement 成功（movementId 为 sg-redeem-2），但随后 LC UTILIZE 的 createMovement 因 ILLEGAL_STATE_TRANSITION 而失败，且用于补偿的 api.cancel() 调用成功 | 结果为 'failed'，报错信息同时包含 'Document Arrival failed: ILLEGAL_STATE_TRANSITION' 与 'automatically cancelled'；result 为 undefined；secondary 为 {}；api.cancel 以 ('sg-redeem-2', 'maker1', 'AUTO_ROLLBACK_LC_LEG_FAILED') 被调用——*余额影响：* SG 赎回记录被创建后又立即被 CANCELLED——对 SG 的 Outstanding/Available 净影响为零；LC 余额不受影响（UTILIZE 从未持久化）。 | `maker-submit.service.spec.ts:241-263` |
| A3S ——SG 成功、LC 失败，且回滚取消本身也失败 | 已选择 A3S，且有效的 SG 快照已就绪 | SG 赎回成功（sg-redeem-3），LC UTILIZE 失败（ILLEGAL_STATE_TRANSITION），且用于补偿的 api.cancel() 调用也失败（NOT_FOUND） | 结果为 'failed'，报错信息同时包含 'Document Arrival failed: ILLEGAL_STATE_TRANSITION'、'automatically cancelling'、'NOT_FOUND'，以及成为孤儿记录的动账 id 'sg-redeem-3'；secondary 为 {}——*余额影响：* SG 赎回记录仍以孤儿形式停留在 PENDING 状态，继续占用 SG 的 Outstanding 容量——用户必须通过 A9 自身的 Checker 面板手动拒绝该记录。 | `maker-submit.service.spec.ts:265-286` |
| B4 Sight/HONOUR ——两条分支均成功 | 已选择 B4，movementType 为 HONOUR，已选定一份 Confirmation 合约 | Honour 的 createMovement 与 Due-From-Issuing-Bank CREATE 的 createMovement 均成功 | 结果为 'submitted'；result.movementId 即 Honour 响应中的 id（'honour-1'）；secondary.dueFromIssuingBankMovementId 为 'dfib-1'——*余额影响：* Confirmation 自身的 Present-Docs Earmark 被消耗（RELEASED/HONOUR 路径）；同时新建一份资产侧 EPLC_DUE_FROM_ISSUING_BANK 合约，用于追踪应收款。 | `maker-submit.service.spec.ts:296-313` |
| B4 Sight/HONOUR ——Honour 成功后，Due-From-Issuing-Bank 分支失败 | B4 HONOUR，已选定一份 Confirmation | Honour 的 createMovement 成功（honour-2），但 Due-From-Issuing-Bank CREATE 失败（ILLEGAL_STATE_TRANSITION） | 结果为 'failed'，报错信息包含 'Due from Issuing Bank asset failed to record'；result.movementId 仍然是 'honour-2'（未被清空）；secondary 为 {}——*余额影响：* Honour 动账仍然真实地保持 PENDING 状态（未被回滚）；资产侧的应收款记录则从未被创建——与 A3S 不同，此分支不存在自动回滚机制。 | `maker-submit.service.spec.ts:329-347` |
| B4 Usance/ACCEPT ——三条分支均成功 | 已选择 B4，movementType 为 ACCEPT，已选定一份 tenor 为 SELLERS_USANCE 的 Confirmation | Accept、随后的 Acceptance-liability CREATE、以及随后的 Reimbursement-Receivable CREATE 均依次成功 | 结果为 'submitted'；result.movementId 为 'accept-1'；secondary.acceptanceMovementId 为 'liability-1'；secondary.acceptanceReimbReceivableMovementId 为 'receivable-1'——*余额影响：* Confirmation 自身的 earmark 通过 ACCEPT 被消耗；同时新建一份 EPLC_ACCEPTANCE 负债合约和一份 EPLC_ACCEPTANCE_REIMB_RECEIVABLE 资产合约，二者共享同一个 businessEventId。 | `maker-submit.service.spec.ts:357-376` |
| B4 Usance/ACCEPT ——在 Accept 与 liability 均成功之后，Receivable CREATE 失败 | B4 ACCEPT，已选定一份 Confirmation | Accept 成功（accept-3），Acceptance-liability CREATE 成功（liability-3），Receivable CREATE 失败（ILLEGAL_STATE_TRANSITION） | 结果为 'failed'，报错信息包含 'Reimbursement Receivable asset failed to record'；result.movementId 为 'accept-3'；secondary.acceptanceMovementId 保留为 'liability-3'；secondary.acceptanceReimbReceivableMovementId 为 undefined——*余额影响：* Accept 与 Acceptance liability 这两笔动账都作为真实的 PENDING 记录持久化；仅缺少资产侧的 Receivable 记录——同样地，之前已完成的分支不会被自动回滚。 | `maker-submit.service.spec.ts:413-433` |
| B5 ——三条分支均成功（Settle + resolve + Reimburse） | 已选择 B5，instrumentType 为 EPLC_ACCEPTANCE，已选定一份 Acceptance 合约 | FULL_SETTLE 的 createMovement 成功，resolveContract 找到了匹配的 EPLC_ACCEPTANCE_REIMB_RECEIVABLE 合约，且 REIMBURSE 的 createMovement 成功 | 结果为 'submitted'；result.movementId 为 'settle-1'；secondary.matchedReceivableMovementId 为 'reimburse-1'——*余额影响：* Acceptance 负债被结清（消耗其自身的 Available Balance）；同时针对匹配到的 Reimbursement Receivable 合约创建其自身的 REIMBURSE 动账，二者共享同一个 businessEventId。 | `maker-submit.service.spec.ts:443-460` |
| B5 ——无法解析出匹配的 Reimbursement Receivable 合约 | 已选择 B5，且已选定一份 Acceptance 合约 | Settle 成功（settle-2），但针对 EPLC_ACCEPTANCE_REIMB_RECEIVABLE 的 resolveContract 失败（NOT_FOUND） | 结果为 'failed'，报错信息包含 'matching Reimbursement Receivable could not be found'；result.movementId 仍为 'settle-2'——*余额影响：* Settle 动账作为真实的 PENDING 记录持久化；由于目标合约无法找到，从未尝试创建 Reimburse 动账。 | `maker-submit.service.spec.ts:477-492` |
| 普通路径——单次调用的功能失败 | 已选择 A1（不适用任何组合型结构） | 唯一的一次 createMovement 调用因 REQUEST_VALIDATION_FAILED 而失败 | 结果为 'failed'，报错信息为 'REQUEST_VALIDATION_FAILED'；result 为 undefined——*余额影响：* 完全没有创建任何动账/合约。 | `maker-submit.service.spec.ts:530-542` |
