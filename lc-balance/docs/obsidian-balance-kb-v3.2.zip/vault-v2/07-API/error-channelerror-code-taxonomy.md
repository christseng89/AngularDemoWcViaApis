---
knowledge_id: error-channelerror-code-taxonomy
title: "Error / ChannelError 错误码分类体系"
domain: Balance
category: Domain Concept
status: CONFIRMED
source_repository: Balance Component (lc-balance)
last_verified_commit: "N/A — no .git history in the analyzed snapshot, see [[Source-to-Knowledge-Map]]"
snapshot_date: 2026-08-22
tags:
  - balance
  - domain-concept
---

# Error / ChannelError 错误码分类体系

微服务的 Error.code 包括：REQUEST_VALIDATION_FAILED（400）、INSUFFICIENT_AVAILABLE_BALANCE（409）、NATURAL_KEY_ALREADY_EXISTS（409）、CURRENCY_MISMATCH（409）、ILLEGAL_STATE_TRANSITION（409）、NOT_FOUND（404）、INTERNAL_ERROR（500，恒为固定的通用信息，真实详情仅记录在服务端日志）。ChannelError 原样透传相同的错误码分类体系（并未另行发明自己的一套），并额外附带一个可选的 partialSuccess 对象，用于说明多分腿调用中哪些成功、哪些失败。

## Source Evidence

- `balance-component-api.yaml lines 1735-1751 (Error schema)`
- `balance-component-channel-api.yaml lines 804-830 (ChannelError schema)`

## Related Knowledge

- [[Business-Rule-Index]]
- [[Balance Component Overview]]
