---
knowledge_id: checker-independent-search-auto-resolve-by-candidate-count
title: "Checker 独立搜索：按候选数量自动解析"
domain: Balance
category: Flow
snapshot_date: 2026-08-22
tags:
  - balance
  - flow
---

# Checker 独立搜索：按候选数量自动解析

searchCheckerLc() 在 Checker 的次要键（IB/SG Number）留空时的决策路径——浏览所输入 LC Number 下所有 ACTIVE 候选记录，而不是一开始就要求给出精确键值。

```mermaid
flowchart TD
  Start[searchCheckerLc called] --> Reset[Reset search state; emit movementPicked null]
  Reset --> HasFn{selectedFunction set?}
  HasFn -- No --> End1[No-op]
  HasFn -- Yes --> HasLc{checkerLcNumber typed?}
  HasLc -- No --> Err1[checkerSearchError: Type an LC Number to search]
  HasLc -- Yes --> SecReq{Function needs a secondary field?}
  SecReq -- No --> Resolve[resolveContract by natural key]
  SecReq -- Yes --> SecBlank{secondary ref typed?}
  SecBlank -- No --> Browse[searchCheckerCandidatesByLcOnly via catalog ACTIVE lcNumber]
  SecBlank -- Yes --> Resolve
  Resolve -->|success| LQ[loadCheckerQueue]
  Resolve -->|error| Err2[checkerSearchError from server message]
  Browse --> Count{candidate count}
  Count -- 0 --> Err3[checkerSearchError: No record found under this LC]
  Count -- 1 --> Auto[Auto-resolve contract, set checkerAutoPickedHint]
  Auto --> LQ
  Count -- ">1" --> Pick[checkerSecondaryCandidates populated for manual pick]
  Pick -->|onSelectSecondaryCandidate| Resolve2[resolveCheckerContract from already-fetched candidate]
  Resolve2 --> LQ
```

## Source Evidence

- `checker-panel.component.ts:139-230`

## Related Knowledge

- Angular Checker 面板 + Actions
- [[Business-Rule-Index]]
