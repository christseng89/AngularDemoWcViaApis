---
knowledge_id: makerpanelcomponent
title: "MakerPanelComponent"
domain: Balance
category: Domain Concept
status: CONFIRMED
source_repository: Balance Component (lc-balance)
last_verified_commit: "N/A — no .git history in the analyzed snapshot, see [[Source-to-Knowledge-Map]]"
snapshot_date: 2026-08-22
tags:
  - balance
  - domain-concept
---

# MakerPanelComponent

Angular 子组件（从原本 2,923 行的 God Component 中拆分出来），负责 Maker 一侧的表单：`model`、自然键（natural key）/搜索状态、`selectedContract`/`selectedContractSnapshot`/`selectedParent`、全部选取器（catalog/parent/IB-index，通过注入的 `CatalogPickerService` 实例）、7 个字段组成的 `compoundLegs` 状态，以及 Submit 编排。对外暴露 `contextChanged`/`syncRequested`/`openAccountEntries`/`deletePendingRequested` 等 output，使父组件 `TransactionBuilderComponent` 与同级的 `CheckerPanelComponent` 能够在不使用 `@ViewChild` 的情况下作出响应。当前 1,223 行，是这个子项目中最大的文件。

## Source Evidence

- `maker-panel.component.ts:1-13 (imports)`
- `src/app/transaction-builder/maker-panel.component.ts:123-204 (class/constructor)`

## Related Knowledge

- [[Business-Rule-Index]]
- [[Balance Component Overview]]
