---
knowledge_id: movementaction-applystatustransition-state-machine
title: "MovementAction / applyStatusTransition() 状态机"
domain: Balance
category: Domain Concept
status: CONFIRMED
source_repository: Balance Component (lc-balance)
last_verified_commit: "N/A — 本次分析快照中无 .git 历史记录，详见 [[Source-to-Knowledge-Map]]"
snapshot_date: 2026-08-22
tags:
  - balance
  - domain-concept
---

# MovementAction / applyStatusTransition() 状态机

statusTransition.ts 是一个纯函数（不涉及任何 I/O），接收 {currentStatus, action, createdBy, actingUser} 作为入参，返回新的 MovementStatus；当 LEGAL_TRANSITIONS[currentStatus][action] 为 undefined 时，则抛出 IllegalStateTransitionError。共有四种动作：RELEASE、REJECT、CANCEL、EDIT。createdBy/actingUser 仅作为审计元数据使用，并不用于资格校验——Maker 与 Checker 是否为同一人，明确不在该函数的处理范畴之内。

## Source Evidence

- `microservices/balance-component/src/domain/statusTransition.ts (full file)`
- `microservices/balance-component/test/unit/domain/statusTransition.test.ts line 16-18`

## Related Knowledge

- [[Business-Rule-Index]]
- [[Balance Component Overview]]
