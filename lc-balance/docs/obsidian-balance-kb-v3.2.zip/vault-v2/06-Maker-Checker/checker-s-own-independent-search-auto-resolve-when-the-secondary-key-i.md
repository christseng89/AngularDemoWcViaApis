---
knowledge_id: checker-s-own-independent-search-auto-resolve-when-the-secondary-key-i
title: "次要键未知时，Checker 自身独立搜索的自动解析"
domain: Balance
category: Domain Concept
status: CONFIRMED
source_repository: Balance Component (lc-balance)
last_verified_commit: "N/A — no .git history in the analyzed snapshot, see [[Source-to-Knowledge-Map]]"
snapshot_date: 2026-08-22
tags:
  - balance
  - domain-concept
---

# 次要键未知时，Checker 自身独立搜索的自动解析

当已输入 LC Number，但该功能所需的次要键（IB/SG Number）留空时，searchCheckerLc() 不再直接硬报错——而是委托给 searchCheckerCandidatesByLcOnly()，后者会通过 catalog() 浏览该 LC 下、属于该功能自身 instrumentType 的所有 ACTIVE 候选记录（精确匹配 lcNumber，与 Maker 自身选取器所用的约定一致）。零个候选记录才是真正的错误；恰好一个则自动解析（设置 checkerAutoPickedHint）并直接加载其队列；多于一个则展示一个供人工挑选的列表（checkerSecondaryCandidates），因为此时究竟指的是哪条记录确实存在歧义。

## Source Evidence

- `checker-panel.component.spec.ts:351-426`
- `checker-panel.component.ts:139-230`

## Related Knowledge

- [[Business-Rule-Index]]
- [[Balance Component Overview]]
