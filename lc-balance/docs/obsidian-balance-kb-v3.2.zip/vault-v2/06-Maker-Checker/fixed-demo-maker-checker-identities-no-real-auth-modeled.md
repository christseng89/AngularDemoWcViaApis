---
knowledge_id: fixed-demo-maker-checker-identities-no-real-auth-modeled
title: "固定的演示用 Maker/Checker 身份——未建模真实身份验证"
domain: Balance
category: Domain Concept
status: CONFIRMED
source_repository: Balance Component (lc-balance)
last_verified_commit: "N/A — 本次分析快照中无 .git 历史记录，详见 [[Source-to-Knowledge-Map]]"
snapshot_date: 2026-08-22
tags:
  - balance
  - domain-concept
---

# 固定的演示用 Maker/Checker 身份——未建模真实身份验证

所有 createMovement 请求固定使用 createdBy: 'maker1'；release/makerSubmit 步骤固定使用 releasedBy/makerSubmittedBy 为 'checker1'/'maker1'。本系统不强制验证 Maker 与 Checker 是否为不同的真实使用者，这属于范畴之外的银行外部授权政策问题。完整的范畴判断说明见 [[Balance Component Overview#范畴之外]] 的"范畴之外"小节，此处不重复展开。

## Source Evidence

- `backend/data/businessCases.js:38-46`

## Related Knowledge

- [[Business-Rule-Index]]
- [[Balance Component Overview]]
