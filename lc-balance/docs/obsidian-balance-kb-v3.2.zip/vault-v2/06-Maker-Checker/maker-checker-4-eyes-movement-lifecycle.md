---
knowledge_id: maker-checker-4-eyes-movement-lifecycle
title: "Maker/Checker（四眼原则）资金变动生命周期"
domain: Balance
category: Domain Concept
status: CONFIRMED
source_repository: Balance Component (lc-balance)
last_verified_commit: "N/A — 本次分析快照中无 .git 历史记录，详见 [[Source-to-Knowledge-Map]]"
snapshot_date: 2026-08-22
tags:
  - balance
  - domain-concept
---

# Maker/Checker（四眼原则）资金变动生命周期

一条 BalanceMovement 记录由 Maker 创建时状态为 PENDING，之后必须由 Checker（或对于 CANCEL/EDIT，由 Maker 本人对自己的记录）通过 RELEASE、REJECT、CANCEL 或 EDIT 之一进行处理——任何未出现在 LEGAL_TRANSITIONS 表中的状态迁移都会被判定为非法并直接抛出异常，而不是静默地不做任何操作。系统本身并不强制校验 Maker 与 Checker 是否为不同使用者，这一点留给银行自身的外部角色/权限策略去约束。

## Source Evidence

- `microservices/balance-component/src/domain/statusTransition.ts lines 1-16`
- `microservices/balance-component/test/unit/domain/statusTransition.test.ts line 16-18`

## Related Knowledge

- [[Business-Rule-Index]]
- [[Balance Component Overview]]
