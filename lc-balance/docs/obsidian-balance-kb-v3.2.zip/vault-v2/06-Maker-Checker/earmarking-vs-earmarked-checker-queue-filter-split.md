---
knowledge_id: earmarking-vs-earmarked-checker-queue-filter-split
title: "EARMARKING 与 EARMARKED 的 Checker Queue 过滤分流"
domain: Balance
category: Domain Concept
status: CONFIRMED
source_repository: Balance Component (lc-balance)
last_verified_commit: "N/A — no .git history in the analyzed snapshot, see [[Source-to-Knowledge-Map]]"
snapshot_date: 2026-08-22
tags:
  - balance
  - domain-concept
---

# EARMARKING 与 EARMARKED 的 Checker Queue 过滤分流

loadCheckerQueue() 针对同一个"PENDING + acknowledgedAt"事实，对 A3/A3S 与 A4 分别施加两种方向相反、按功能限定范围的过滤。A3/A3S（deferSettlement）会排除已经 acknowledgedAt 的 UTILIZE——因为一旦其自身的 Checker 已经确认过，再在 A3/A3S 画面上重复展示就毫无意义了，该记录会留待 A4/A6 之后在各自画面上终结。A4（releasesExistingMovementInPlace）则恰恰相反：会排除仍处于 EARMARKING（尚无 acknowledgedAt）的 UTILIZE，因为在 A3 的 Checker 确认之前，A4 的 Checker 根本没有任何可以合法 Release 的对象——这正是真正的 4-eyes。除此之外的其余所有功能都不受此分流影响。

## Source Evidence

- `checker-panel.component.spec.ts:496-597 (5 tests covering both directions)`
- `checker-panel.component.ts:232-264,279-285`

## Related Knowledge

- [[Business-Rule-Index]]
- [[Balance Component Overview]]
