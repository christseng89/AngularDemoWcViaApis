---
knowledge_id: MOVEMENT-RULE-020
title: "A9 SG 赎回仅限 Full Redeem，金额被硬锁定为该 SG 当前的可用余额（Available Balance）"
domain: Balance
category: Business Rule
status: CONFIRMED
source_repository: Balance Component (lc-balance)
last_verified_commit: "N/A — no .git history in the analyzed snapshot, see [[Source-to-Knowledge-Map]]"
snapshot_date: 2026-08-22
tags:
  - balance
  - movement
  - confirmed
---

# MOVEMENT-RULE-020 — A9 SG 赎回仅限 Full Redeem，金额被硬锁定为该 SG 当前的可用余额（Available Balance）

## Status
CONFIRMED

## Business Rule
经业务方确认（TF_Balance_Component_Mapping 规则 #1，『SG 的解除是基于金融工具本身的，而非基于金额的』）：A9 的 Amount 字段被完全禁用，其值来源于该 SG 当前的 Available Balance（而非 Confirmed Balance——Available 会扣减同一 SG 上任何已处于 PENDING 状态的赎回，避免对已预留的额度重复计算）；通过 Angular A9 界面已无法再触达 Partial Redeem。submit-rules.ts 会硬性拒绝任何与该值不完全一致的金额，并将 movementType 硬编码为 FULL_REDEEM，作为纵深防御的兜底。amountVsAvailableDerivation='REDEEM' 在注册表中被保留，纯粹是作为 A9 的身份标记（用于父级资格提示、历史 PARTIAL_REDEEM 的回显），而非实际生效的推导选择。该限制的作用范围明确仅限于 UI 层/Angular 参考客户端——微服务自身的 PARTIAL_REDEEM movementType 与 checkRedeemSufficiency() 对任何其他直接调用接口的调用方仍然开放（checkRedeemSufficiency() 只检查 amount <= availableBalance，完全没有 businessEventId/A3S 配对检查）——这是一个已披露、但并未真正封堵的权衡取舍。

## Conditions
selectedFunction.code === 'A9'（amountVsAvailableDerivation === 'REDEEM'）

## Result
Amount 字段被锁定/禁用为 Available Balance；提交的 movementType 被硬编码为 FULL_REDEEM；任何与该值不完全一致的金额都会被硬性拒绝

## Example
availableBalance=80000，输入金额 90000 或 50000 -> 拒绝；amount=80000 -> 通过，patch.movementType='FULL_REDEEM'。示例：SG G01 开立 10,000，A3S 已赎回 2,000（仍为 PENDING 状态）-> A9 的 Amount 自动填充为 8,000，而非 10,000

## Verification Note
已直接阅读 submit-rules.ts 中的 REDEEM 分支；与声明内容完全一致。已将来自 angular-function-catalog、design-docs-figures-mapping 与 quality-remediation-history 三个不同角度、描述同一锁定机制的 5 个近似重复候选条目（包括单独的『A9 锁定依据澄清：基于 Available Balance 而非 Confirmed Balance』候选条目——它并非独立规则，而是本规则依据的最终、权威表述）合并为这一条完整的综合条目。

## Source Evidence

实现:
- `src/app/transaction-builder/submit-rules.ts:116-135`
- `src/app/transaction-builder/builder-fields.ts:37-55,77-78,90-97`

测试:
- `submit-rules.spec.ts:302-340`
- `builder-fields.spec.ts:88-99`

## Related Knowledge
- [[BalanceMovement]]
- 金额字段锁定优先级链（builder-fields.ts）
- （TF Mapping）SG 的解除是基于金融工具本身的，而非基于金额的
- [[Business-Rule-Index]]
- [[Balance-Traceability-Matrix]]
