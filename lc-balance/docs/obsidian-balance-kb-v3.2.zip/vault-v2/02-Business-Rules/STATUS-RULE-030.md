---
knowledge_id: STATUS-RULE-030
title: "LC／保兑到期与撤销的余额冲正是一项已定义的需求，但没有对应已实现的 movementType"
domain: Balance
category: Business Rule
status: CONFIRMED
source_repository: Balance Component (lc-balance)
last_verified_commit: "N/A — no .git history in the analyzed snapshot, see [[Source-to-Knowledge-Map]]"
snapshot_date: 2026-08-22
tags:
  - balance
  - status
  - confirmed
---

# STATUS-RULE-030 — LC／保兑到期与撤销的余额冲正是一项已定义的需求，但没有对应已实现的 movementType

## 状态
CONFIRMED

## 业务规则
源头台账（ledger）规范认为，对每一个在范围内的产品（LC、保兑），未释放的剩余余额在到期或撤销时都需要一笔冲正分录（reversal entry）。Balance Component 中 IPLC_LC/EPLC_CONFIRMATION 实际的 movementType 集合并不包含 EXPIRE 或普通的 CANCEL movementType——Folio 1/Folio 4 中『释放（剩余）／到期／撤销』的记录行，仅仅记录了所需的借／贷（Dr/Cr）配对，而不是一个可调用的 Transaction Builder 功能。

## 条件
任何 ACTIVE 状态的 LC／保兑，其表外或有负债配对（contingent pair）在到期／撤销之前从未透过法律事件被完全释放，且也没有提交 Maker/Checker 的 CLOSE 操作。

## 结果
不存在任何自动的、由日期触发的功能来记录这笔所需的余额冲正。

## 示例
一份未被使用而失效的 LC，若存在剩余的 Confirmed Balance，并没有自动的 EXPIRE 功能来冲正其「未偿付跟单信用证（Documentary Credits Outstanding）／客户负债（Customers' Liability）」配对科目。

## 验证说明
直接确认了 movementType 清单（不含 EXPIRE/CANCEL）。相较原候选规则做了精修：A10/B6 CLOSE（于 2026-08-21 新增，晚于本台账文档撰写时间）现已提供一种由 Maker/Checker *触发* 的注销机制，在功能上与本文档所描述的余额冲正相似——但它并非由日期触发（没有自动的到期机制），也没有区分不同的『原因』跟踪（撤销、到期、自愿关闭均归为同一个 CLOSE movementType）。因此本文档的核心主张——不存在自动的、由日期触发的到期／撤销功能——至今仍然成立；只是『完全尚未实现』这一表述需要更新。

## 来源证据

实现：
- `analysis/contingent-liability-ledger.html (Folio 1/Folio 4 residual rows, Notes item 4)`
- `microservices/balance-component/src/db/schema.ts:58-74 (MOVEMENT_TYPE_VALUES — no EXPIRE/CANCEL value)`

测试：
- （未引用直接测试证据）

## 相关知识
- [[Close Eligibility]]
- [[Business-Rule-Index]]
- [[Balance-Traceability-Matrix]]
