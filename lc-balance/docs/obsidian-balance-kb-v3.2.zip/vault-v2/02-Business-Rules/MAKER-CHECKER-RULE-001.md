---
knowledge_id: MAKER-CHECKER-RULE-001
title: "Maker/Checker 同一人分离验证属于银行政策范畴，本状态机不做强制检查"
domain: Balance
category: Business Rule
status: CONFIRMED
source_repository: Balance Component (lc-balance)
last_verified_commit: "N/A — no .git history in the analyzed snapshot, see [[Source-to-Knowledge-Map]]"
snapshot_date: 2026-08-22
tags:
  - balance
  - maker-checker
  - confirmed
---

# MAKER-CHECKER-RULE-001 — Maker/Checker 同一人分离验证属于银行政策范畴，本状态机不做强制检查

## 状态
CONFIRMED

## 技术要点
applyStatusTransition() 仅将 createdBy 与 actingUser 当作审计元数据保存，从不对两者进行比较，也不会因为同一用户既是当初的 Maker、又是当前的操作者，就拒绝该操作。真正的四眼（4-eyes）职责分离，委托给发起银行自身的外部角色/权限/授权系统处理——该档案自身开头的注释已明确记载，这是一项蓄意的业务决策（2026-08-14）。

完整的范畴判断说明见 [[Balance Component Overview#范畴之外]] 的"范畴之外"小节，此处不重复展开。

## 来源证据

实现代码：
- `microservices/balance-component/src/domain/statusTransition.ts:1-38 (header comment + LEGAL_TRANSITIONS table)`

测试：
- `microservices/balance-component/test/unit/domain/statusTransition.test.ts:16-18`

## 相关知识
- [[Maker Checker Lifecycle]]
- Maker/Checker (4-eyes) movement lifecycle
- [[Business-Rule-Index]]
- [[Balance-Traceability-Matrix]]
