---
knowledge_id: Knowledge-Gaps
title: "Knowledge Gaps"
domain: Payment
category: Gap Log
snapshot_date: 2026-08-22
tags:
  - payment
  - gaps
  - conflicts
---

# Knowledge Gaps

Every item below was deliberately NOT asserted as a confirmed business rule, per this vault's evidence rule: **never convert an assumption into a fact.** Three kinds of entries are recorded here: rules whose evidence was judged insufficient to confirm (status UNCLEAR — no standalone rule file was created for these), domain-level conflicts between sources, and gaps surfaced during the adversarial verification pass. Rules that carried a CONFLICT status strong enough to still document as a rule (both sides described) got their own file in [[Business-Rule-Index]] and are cross-linked below; these entries add the narrative the rule file's YAML frontmatter can't hold.

## UNCLEAR rules (14)

### GAP-001 (API)

**Observed:**
The response shape `{ entries: [], summary: {}, rates: currentRates(), at }` hardcodes entries/summary as permanently empty literals for this specific endpoint — no code path assigns into either field for /api/fx/rates. Additional evidence found on verification: every OTHER calculator endpoint in server.js (A1 LC Issue, and the various B1-B5/A2-A4 handlers) independently builds its own populated `entries`/`summary` local variables and returns them in an identically-shaped `{entries, summary, ...}` envelope — strongly suggesting /api/fx/rates's empty literals are a copy-pasted leftover of that same file-wide response-shape convention, never filled in for this endpoint specifically, rather than a deliberately reserved contract field. Intent is still not documented anywhere in the file.

**Source:**
backend/server.js line 88: `app.get('/api/fx/rates', (_req, res) => { res.json({ entries: [], summary: {}, rates: currentRates(), at: new Date().toISOString() }); });`; backend/server.js: at least 8 other route handlers (e.g. lines 172-199, 274-293, 359-385, 429-443, 479-490, 531-542, 584-603, 657-753, 844-859) each build their own populated `entries`/`summary` locals in the same `{entries, summary, ...}` shape, confirming the envelope convention this endpoint's literals mimic but never populate

**Problem:**
Business intention cannot be determined from available evidence.

**Question:**
Re-read server.js in full via grep for entries/summary usage; confirmed line 88 is the sole reference for this endpoint and that no other code path feeds into it. Strengthened the note with the cross-endpoint pattern match (a new observation) but did not change status to CONFIRMED, since the file still contains no comment or test stating what these fields are FOR — only what likely explains their presence (copy-paste from the shared shape). Status remains UNCLEAR.

---

### GAP-008 (Accounting)

**Observed:**
The proposed Use Case 1 bridges cash margin/collateral through the same Suspense-Credit clearing account as Commission/Charges. The document itself flags this as needing a business call: some banks book cash margin as a direct Dr Customer / Cr Margin Deposit entry with no Charge Component/Suspense involvement at all.

**Source:**
PaymentComponentProposedUseCases-EN.docx.txt, Use Case 1 'Open items for review'; Cross-cutting Open Questions Summary item 3 (cited, not independently re-opened this pass)

**Problem:**
Business intention cannot be determined from available evidence.

**Question:**
Not independently re-verified this pass (proposed-use-case doc not re-opened), but the UNCLEAR status is appropriate on its face — it is explicitly an open business question per the source document's own framing, not a code-verifiable fact, so no downgrade/upgrade indicated.

---

### GAP-009 (Accounting)

**Observed:**
The proposed 'Acceptance'/'Repayment' sourceFunctionCode names for the two-step Usance IBL Takedown/Repayment flow need reconciliation against the already-registered iplc-payment-at-maturity case. It is unclear whether that existing case is the same real-world screen under a different name.

**Source:**
PaymentComponentProposedUseCases-EN.docx.txt, Use Case 2B 'Open items for review' (cited, not independently re-opened this pass)

**Problem:**
Business intention cannot be determined from available evidence.

**Question:**
Not independently re-verified this pass. UNCLEAR is the appropriate status per the source document's own framing — kept as-is.

---

### GAP-010 (Accounting)

**Observed:**
Use Case 5 swaps the account type in the README's confirmed IBL/EBL Repayment example from CUSTOMER to NOSTRO without independent accounting verification. Explicitly called 'the least-confirmed use case in the set' in the source document.

**Source:**
PaymentComponentProposedUseCases-EN.docx.txt, Use Case 5 'Open items for review' (cited, not independently re-opened this pass)

**Problem:**
Business intention cannot be determined from available evidence.

**Question:**
Not independently re-verified this pass. UNCLEAR is correct per the source's own explicit self-description. Kept as-is.

---

### GAP-033 (Classification)

**Observed:**
For all 4 RPFM GAP cases, the non-Nostro side of the leg pair is a sub-ledger/loan-participation account booked in a different business component than Payment Component; the registry author chose accountType 'INTERNAL' over 'SUSPENSE' as 'the more specific of the two... a judgment call, not itself business-confirmed, but classification-wise indistinguishable from SUSPENSE.' No test or downstream logic distinguishes INTERNAL vs SUSPENSE for these cases specifically, so whether INTERNAL is the correct real-world classification is left genuinely open by the source itself.

**Source:**
src/app/payment-component/business-case-registry.ts lines 210-234 (GAP_CASES header comment: 'a judgment call, not itself business-confirmed'); analysis/RPFM-PaymentComponent-Gap-Analysis.md line 24 (same judgment-call framing, independently corroborating)

**Problem:**
Business intention cannot be determined from available evidence.

**Question:**
Confirmed the exact doc comment in business-case-registry.ts (lines 210-234) and found independent corroboration in RPFM-PaymentComponent-Gap-Analysis.md line 24, which states the identical judgment-call framing verbatim. Status remains UNCLEAR as originally reported — this is exactly what the source itself flags as open, not resolved by additional evidence.

---

### GAP-034 (Classification)

**Observed:**
Both B4's settlementType='direct' branch and the entire B5 component compute a Foreign Bank Charges embed-or-separate-debit split, credit the beneficiary's CA net of charges, and charge a percentage-based fee (Settlement Commission in B4-direct vs. Collection Rate in B5) with its own minimum floor. It's not established from these files alone whether 'Direct to CA' in B4 represents settling a bill that WAS negotiated (B3) but never converted to an EBL advance, versus B5 representing a bill that was never negotiated at all (pure collection basis) — both plausible distinct trade-finance products, or an accidental duplication of the same flow under two component names. No file in this set states the distinguishing business trigger.

**Source:**
src/app/web-components/export/lc-settlement.element.ts lines 55-69 (_initCharges 'direct' branch: FBC + Settlement Commission + Bill Credit); src/app/web-components/export/lc-collection.element.ts lines 48-64 (_initCharges: FBC + Collection Fee + Bill Credit)

**Problem:**
Business intention cannot be determined from available evidence.

**Question:**
Read both cited code blocks directly — the structural similarity (FBC embed/separate logic, percentage fee, net Bill Credit) is confirmed as described, and no comment in either file states the business distinction between the two paths. Status remains UNCLEAR as originally reported — this is a genuine gap in the source, not resolvable from code alone.

---

### GAP-042 (FX)

**Observed:**
drRate's usage vs. drBuyRate is explicitly flagged 'not fully resolved' in the OAS itself. drBuyRate IS confirmed as the buy-or-sell rate selected by an amount threshold in legacy Debit_ExchangingRate() for IMCO specifically. crBuyRate's selection logic is explicitly 'not traced this pass'. sellRate is noted as distinct from drBuyRate in the source XSD schema but their relationship is 'not fully resolved'.

**Source:**
Payment_component.yaml / payment-instructions-post.yaml PaymentLegInput.drRate/drBuyRate/crBuyRate/sellRate doc comments (lines ~729-757 / ~777-805)

**Problem:**
Business intention cannot be determined from available evidence.

**Question:**
Confirmed directly by reading the OAS yaml text at those lines — it literally states 'specific selection logic not traced this pass' for crBuyRate and flags drRate-vs-drBuyRate as unresolved. Appropriately marked UNCLEAR; no change.

---

### GAP-043 (FX)

**Observed:**
Duplicate of 'leg-rate-fields-purpose-unresolved' above — same underlying gap, sourced from the Calculation Validation doc's own §12.3 rather than the OAS yaml's inline caveats. §8 traced drBuyRate's IMCO-specific threshold-based resolution, but no populating function for drRate, crBuyRate, or sellRate was found; this gap was carried over unresolved from an earlier document (Payment_Mapping_Functions.docx §10 R2).

**Source:**
analysis__Payment_Component_Calculation_Validation.docx.txt §12.3

**Problem:**
Business intention cannot be determined from available evidence.

**Question:**
Merged conceptually with 'leg-rate-fields-purpose-unresolved' (same gap, two source documents making the identical claim). Kept UNCLEAR — no code exists anywhere in the microservice that resolves these rate fields server-side (the service explicitly requires the caller to submit already-resolved rates per 'fx-rate-resolution-out-of-scope' in the cross-domain title list), so this is a genuine, still-open documentation gap, not resolvable from the codebase available to this review.

---

### GAP-050 (Other)

**Observed:**
SSSS_PaymentCredit.js:1429 has the RTGS assignment for RPFM Settle Participant's IDR branch commented out, while the equivalent branches in the other 3 RPFM functions (Process Grantor, Repay Grantor, Process Participant) are live/uncommented (Credit.js:1388-1401, 1402-1419, 1435-1447 vs. 1429). This reads as an unintentional latent source defect rather than a designed exception, but was not confirmed with the module owner — whether it needs a documented exception or a bug fix remains open. No OAS/schema change can resolve this either way; it requires source-code owner confirmation. Note: SSSS_PaymentCredit.js itself is not present in this repository — this is a business fact about a legacy source file, reported second-hand through the analysis documents (evidence priority tier 3, not tier 1 executable code).

**Source:**
analysis/Payment_Mapping_Functions.docx (converted .txt) line 55: '...SSSS_PaymentCredit.js:1429 has its RTGS assignment commented out for the IDR branch, while the equivalent branches in the other 3 RPFM functions are live.'; analysis/Payment_Mapping_Functions.docx (converted .txt) §10.4 R4, lines 71-72: full open-item writeup, 'This looks unintentional (a probable latent defect, not a designed exception)...'; analysis/Payment_Mapping_Functions.docx (converted .txt) line 195 (§7 table): 'Cr: NOSTRO (payfeeccy≠IDR); IDR branch has the RTGS assignment commented out (Credit.js:1429) — CPYT_CR_AC_TYPE is left at its prior value in that branch'; analysis/PaymentComponent-Microservice-FSD-zh.docx (converted .txt) Appendix C.1 table, line ~1025: '...SSSS_PaymentCredit.js:1429 的 IDR 分支中,RTGS 賦值程式碼被註解掉,與其餘 3 個 RPFM 函式的對應分支不一致。'

**Problem:**
Business intention cannot be determined from available evidence.

**Question:**
Re-opened both cited converted analysis files and confirmed all three citations verbatim (Payment_Mapping_Functions.docx.txt lines 55, 71-72, 195; PaymentComponent-Microservice-FSD-zh.docx.txt Appendix C.1 table row for Settle Participant). Content matches the candidate rule's statement exactly, including the 'commented out only for this one branch, live in the other 3' detail and the explicit 'requires module-owner confirmation, not an OAS matter' framing. Status correctly remains UNCLEAR — this is honestly an open question in the source documents themselves, not something these agents merely failed to resolve. No merge candidate found among the other 'Other' rules. No downgrade needed; evidence is solid tier-3 (design/analysis doc) support for a claim that is explicitly about legacy source code not present in this repo.

---

### GAP-051 (Other)

**Observed:**
payInstrFlag (F=Sight, A=Acceptance/Deferred, derived from CPYT_C_SDA_FLAG=='Sight' else 'A' per SSSS_PaymentInstruction.js:72-77) was added to the OAS schema in v1.1.0 (Payment-OAS-FSD-en.docx.txt line 169, 294), but its only known setter is gated on SYS_ORG_FUNCTION_SHORT_NAME=="PayAccp" — a short-name value that could not be found configured anywhere else in the codebase (module.xml or elsewhere) during the analysis pass. It is therefore unconfirmed whether any live Pay/Accept-named function actually populates this field today; treat it as optional/unreliable until traced further. The OAS property description itself is stated to carry this caveat verbatim so the ambiguity isn't lost to downstream consumers.

**Source:**
analysis/Payment-OAS-FSD-en.docx.txt (converted .txt) line 169: 'payInstrFlag | enum [F, A], optional | F (sight) or A (acceptance/deferred) — derived from whether the underlying instrument is Sight or Usance/Deferred tenor.'; analysis/Payment-OAS-FSD-en.docx.txt (converted .txt) line 294 (changelog): 'v1.1.0 | Added RTGS to AccountType (RPFM); split the single exchangeRate field into 4 distinct rate fields; added payInstrFlag.'; analysis/Payment_Mapping_Functions.docx (converted .txt) §10.1 R1, line 66: 'Open follow-up: the only setter for this flag is gated on SYS_ORG_FUNCTION_SHORT_NAME=="PayAccp", a short-name value not found configured anywhere else in the codebase (module.xml or elsewhere) — its reachability in the current baseline could not be confirmed this session.'

**Problem:**
Business intention cannot be determined from available evidence.

**Question:**
Re-opened Payment-OAS-FSD-en.docx.txt and confirmed line 169 verbatim as cited. However the second citation in the candidate rule (same file, lines 505-512) does NOT exist — the converted file is only 302 lines total, so that specific line range is a stale/incorrect citation from the original extracting agent. The rule's substantive claim is still independently and fully confirmed via Payment_Mapping_Functions.docx.txt §10.1 R1 (lines 65-66), which was verified verbatim and contains the exact 'PayAccp'/reachability-unconfirmed language. Since the core claim holds on solid evidence (just via a different citation than one of the two originally given), I keep status UNCLEAR (correct — this is a genuinely open question per the source docs) rather than downgrading further, but flag the bad line citation in gaps_found for transparency.

---

### GAP-052 (Other)

**Observed:**
The single legacy exchangeRate field was split into 4 distinct rate fields (drRate, drBuyRate, crBuyRate, sellRate) in OAS v1.1.0 to match the source XSD schema (form_schema_PaymentDebit.xsd:20,51,61,83 / form_schema_PaymentCredit.xsd:26,54,64,85). Of these, only drBuyRate's semantics are confirmed: Debit_ExchangingRate() (SSSS_PaymentDebit.js:417-421) selects it as the applicable buy-or-sell rate by an amount threshold, for IMCO — both the 'Buying Rate' and 'Selling Rate' lookups write to this one field. The other three fields' (drRate, crBuyRate, sellRate) exact business usage/selection logic was NOT fully traced in either analysis pass — flagged explicitly as an open follow-up both in the OAS field descriptions themselves and in the Mapping Functions report.

**Source:**
analysis/PaymentComponent-Microservice-FSD-zh.docx (converted .txt) lines 574-601 — full OAS property description block for drRate/drBuyRate/crBuyRate/sellRate, each stating 'not fully resolved this pass' / 'specific selection logic not traced this pass' / 'relationship between the two not fully resolved this pass', except drBuyRate which is described as 'Confirmed as the applicable buy-or-sell rate selected by an amount threshold in Debit_ExchangingRate() (SSSS_PaymentDebit.js:417-421) for IMCO'; analysis/Payment_Mapping_Functions.docx (converted .txt) §10.2 R2, lines 67-68: 'drBuyRate's semantics are confirmed (Debit_ExchangingRate(), SSSS_PaymentDebit.js:417-421...). drRate, crBuyRate, and sellRate's exact business usage was not traced this pass...'

**Problem:**
Business intention cannot be determined from available evidence.

**Question:**
Re-opened both cited files and confirmed both citations verbatim and precisely at the stated line ranges (PaymentComponent-Microservice-FSD-zh.docx.txt lines 574-601 exactly match; Payment_Mapping_Functions.docx.txt §10.2 R2 lines 67-68 exactly match). This is the most precisely-cited rule of the six reviewed. Status UNCLEAR is correct and unchanged. Related to, but not a duplicate of, the cross-domain rule 'fx-rate-fields-not-fully-traced' / 'leg-rate-fields-purpose-unresolved' — those are the same underlying fact restated by other extracting agents under FX domain; not merged here since this verification task is scoped to the 'Other' domain list only, but flagged as likely near-duplicates across domains for the aggregator's awareness.

---

### GAP-057 (SWIFT)

**Observed:**
Unlike LC messages (which have explicit ext_IPLC_*/ext_EPLC_* tag-level mapping files), no equivalent tag-level mapping XML for MT103/MT202 payment messages was found in X/CALJS or X/Default/SWIFT, and no explicit 'send message' trigger function was found — this logic likely lives in a server-side SWIFT engine outside the analyzed baseline's scope. The field mapping documented in the FSD should be treated as directionally correct but incomplete; a dedicated follow-up trace of the server-side SWIFT engine is recommended before implementation.

**Source:**
analysis__PaymentComponent-Microservice-FSD-zh.docx.txt §4.2.2 (line 99) — '本次分析並未在 X/CALJS 或 X/Default/SWIFT 內找到 MT103/MT202 付款報文的逐標籤對映 XML...此對映邏輯很可能位於本 baseline 範圍外的伺服端 SWIFT 引擎中。此項已列為第 8 章的待辦事項'; analysis__PaymentComponent-Microservice-FSD-zh.docx.txt risk table (~line 997) — 'MT103/MT202 未找到逐標籤層級對映' with mitigation '§4.2.2 的欄位對映應視為方向正確但不完整;實作前需針對伺服端 SWIFT 引擎另做一次專項分析'

**Problem:**
Business intention cannot be determined from available evidence.

**Question:**
Re-read both cited passages in the zh FSD; both state the gap plainly as an open item, not resolved anywhere else in the corpus (the actual microservice code implements only the fields the FSD does document — settlementCurrency/Amount, instructedCurrency/Amount, uetr — with no deeper tag-level mapping visible either). Correctly remains UNCLEAR — this is a genuine documented gap, not a confidently-stated rule.

---

### GAP-082 (Validation)

**Observed:**
The OAS's MonetaryAmount regex (^-?\d{1,18}(\.\d{1,3})?$) cannot by itself enforce that a JPY amount has 0 decimals or a BHD amount has up to 3 — that per-currency check must live in application code (a zod superRefine), not the OpenAPI schema itself. Neither OAS file (Payment_component.yaml) documents this validator directly within the MonetaryAmount schema block — only a passing prose reference elsewhere ('fixes a false-negative H-2 rejection...', line 164) hints at its existence without describing the mechanism.

**Source:**
analysis/Payment_component.yaml MonetaryAmount schema+description (lines 438-447) — pattern alone, no per-currency scale note in the schema block itself; analysis/Payment_component.yaml line 164 (the only H-2 mention in the whole file, a passing prose reference); CLAUDE.md's repeated references to 'H-2 currency-scale validation (knownMinorUnitsForCurrency)' — corroborating the check exists in code, but not in the OAS documentation itself

**Problem:**
Business intention cannot be determined from available evidence.

**Question:**
Re-checked: confirmed the OAS MonetaryAmount schema block genuinely does not document the H-2 validator (grep found exactly one incidental 'H-2' mention in the whole file, unrelated to the schema definition itself). Correctly marked UNCLEAR as originally stated — the underlying enforcement mechanism IS confirmed elsewhere (requestSchema.ts, see the merged h2-currency-minor-unit-scale entry), but its absence from the OAS's own documentation is accurately UNCLEAR/undocumented, not a gap in this verification.

---

### GAP-083 (Validation)

**Observed:**
payInstrFlag is documented as F when CPYT_C_SDA_FLAG=='Sight', else A, per SSSS_PaymentInstruction.js:72-77. The OAS flags an explicit CAUTION: the only setter for this flag is gated on SYS_ORG_FUNCTION_SHORT_NAME=='PayAccp', a short-name value the review session could NOT confirm is configured anywhere else in the codebase. The OAS instructs treating the field as optional until resolved.

**Source:**
analysis/Payment_component.yaml PaymentInstructionConfirmRequest.payInstrFlag (lines 482-495, the CAUTION text verbatim) and PaymentInstruction.payInstrFlag (line 681); analysis/payment-instructions-post.yaml lines 495-504 (the identical CAUTION text)

**Problem:**
Business intention cannot be determined from available evidence.

**Question:**
Confirmed by direct read of payment-instructions-post.yaml lines 495-504 — the CAUTION text matches the rule statement verbatim. Correctly kept as UNCLEAR since the underlying question (is SYS_ORG_FUNCTION_SHORT_NAME=='PayAccp' actually configured anywhere) genuinely remains unresolved in the evidence available.

---

## Domain-level conflicts (24)

### GAP-002 (API)

**Observed:**
swiftmessage-schema-diverges-between-two-oas-files: Payment_component.yaml's SwiftMessage schema (no instructedCurrency, no H-3 notes) genuinely disagrees with payment-instructions-post.yaml's SwiftMessage schema (has instructedCurrency, has H-3 notes), despite both files claiming to be kept in lockstep at the same declared version 1.10.1 — confirmed by direct re-read of both schemas.

**Source:**
(see rule files with status CONFLICT in this domain)

**Problem:**
Two or more sources disagree.

**Question:**
Which source should be treated as authoritative going forward, and should the losing source be corrected?

---

### GAP-003 (API)

**Observed:**
Cross-domain (not re-verified in depth here, flagged for awareness): the API domain's current-state idempotency-key rules (originModule, mainRef, sequence) describe the IMPLEMENTED contract, while the separately-tracked RDD/Architecture-domain rule 'idempotency-key-lc-event-not-sequence' describes a PLANNED, reviewer-confirmed future migration to (originModule, bankContractRef, eventSeq). This is not a contradiction within the API domain itself (both are accurately describing different points in time — current vs. planned), but a reader skimming rule titles alone could mistake it for one; the cross-domain CONFLICT rule 'response-shape-outdated-vs-planned-rdd' already exists to flag this and should be read alongside the API domain's idempotency rules.

**Source:**
(see rule files with status CONFLICT in this domain)

**Problem:**
Two or more sources disagree.

**Question:**
Which source should be treated as authoritative going forward, and should the losing source be corrected?

---

### GAP-011 (Accounting)

**Observed:**
#43/#36 vs zh-FSD three-voucher-stream design: confirmed genuine — en FSD + live source code (confirmPaymentInstruction.ts, accountEntries.ts, both read in full) agree Charge/Liability generation was removed in v1.6.0; the earlier zh FSD's three-stream design (voucherType enum SETTLEMENT/CHARGE/LIABILITY) is superseded design intent, not current behavior. This CONFLICT is correctly attributed to doc-vs-doc disagreement, with code independently confirming which side reflects current reality.

**Source:**
(see rule files with status CONFLICT in this domain)

**Problem:**
Two or more sources disagree.

**Question:**
Which source should be treated as authoritative going forward, and should the losing source be corrected?

---

### GAP-012 (Accounting)

**Observed:**
#69 use-case-4-eplc-discount-conflict: confirmed as a real conflict between an actual registered function (EPLC:Discount, directly confirmed present in voucherDescription.ts's VOUCHER_CODE_PREFIXES table this pass) and a proposed use case with the opposite money-flow direction.

**Source:**
(see rule files with status CONFLICT in this domain)

**Problem:**
Two or more sources disagree.

**Question:**
Which source should be treated as authoritative going forward, and should the losing source be corrected?

---

### GAP-013 (Accounting)

**Observed:**
#71 sourcecomponent-attribution-ambiguous: confirmed that sourceComponent has zero functional/processing consequence (corroborated directly in code this pass), so the CHARGE-vs-BALANCE labeling disagreement between two documentation sources is a real but purely-informational conflict, not a system-behavior risk.

**Source:**
(see rule files with status CONFLICT in this domain)

**Problem:**
Two or more sources disagree.

**Question:**
Which source should be treated as authoritative going forward, and should the losing source be corrected?

---

### GAP-014 (Accounting)

**Observed:**
Cross-domain note (not independently verified, flagging only): the cross-domain title list includes 'voucher-type-enum-stale-after-v160-removal' (Validation/CONFLICT) and 'swiftmessage-schema-diverges-between-two-oas-files' (API/CONFLICT) which describe closely related staleness issues to the Accounting-domain conflict above (voucherType enum still lists CHARGE/LIABILITY in the OAS even though the code no longer generates them) — these look like the same underlying 'OAS lags implementation' phenomenon documented independently across three different rule extractions (Accounting, Validation, API domains), which is itself worth flagging to whoever owns the OAS files as one root cause with three symptoms.

**Source:**
(see rule files with status CONFLICT in this domain)

**Problem:**
Two or more sources disagree.

**Question:**
Which source should be treated as authoritative going forward, and should the losing source be corrected?

---

### GAP-020 (Architecture)

**Observed:**
response-shape-outdated-vs-planned-rdd (rule 24): confirmed as a genuine CONFLICT between the CURRENT OAS/implementation (flat originModule/mainRef/sequence:integer natural key) and the reviewer-confirmed PLANNED design (bankContractRef/eventSeq as string-pattern codes, CLAUDE.md D-1..D-8 and expert-review rule 37 'idempotency-key-design'). Both sides verified directly: Payment_component.yaml:469-477 and payment-instructions-post.yaml:478-486 both still type sequence as integer with no transactionReference/event/customerRef/edition block anywhere in either OAS file.

**Source:**
(see rule files with status CONFLICT in this domain)

**Problem:**
Two or more sources disagree.

**Question:**
Which source should be treated as authoritative going forward, and should the losing source be corrected?

---

### GAP-021 (Architecture)

**Observed:**
Cross-domain-only (not one of my assigned Architecture rules, surfaced for awareness): the Validation-domain pair 'h2-currency-minor-unit-scale' (CONFIRMED, H-2 IS enforced) vs 'currency-minor-units-not-validated-on-input' (CONFIRMED, H-2 is NOT enforced, an open control gap) are flatly contradictory as titled. I checked current source directly: microservices/payment-component/src/validation/requestSchema.ts:130-144 DOES cross-validate each submitted leg amount's decimal places against knownMinorUnitsForCurrency(currency) and rejects over-precision as a 400. The 'not validated on input' framing is the STALE state described by docs/payment-component-expert-review.md's H-2 finding (written before the fix landed) — that finding is now historical/resolved, not a current gap. The Validation-domain verifier should downgrade or retitle 'currency-minor-units-not-validated-on-input' to reflect that H-2 was subsequently implemented, to avoid this direct contradiction standing in the merged KB.

**Source:**
(see rule files with status CONFLICT in this domain)

**Problem:**
Two or more sources disagree.

**Question:**
Which source should be treated as authoritative going forward, and should the losing source be corrected?

---

### GAP-025 (CONFLICT)

**Observed:**
rtgs-vs-accounttype-schema-evolution: confirmed as a genuine but RESOLVED disagreement between the zh FSD/Mapping-Functions report (describing OAS v1.1.0/v1.2.0, 6-value AccountType enum including RTGS) and the current OAS schema plus en FSD changelog (v1.3.0+, 5-value enum, RTGS replaced by NOSTRO+rtgsIndicator flag). The current OAS's own doc comments narrate this evolution explicitly, so this is documented version history rather than an unexplained contradiction — but it is real disagreement between what two document sets say the current schema is, which is why it must stay tagged CONFLICT rather than being silently normalized to CONFIRMED.

**Source:**
(see rule files with status CONFLICT in this domain)

**Problem:**
Two or more sources disagree.

**Question:**
Which source should be treated as authoritative going forward, and should the losing source be corrected?

---

### GAP-028 (Charges)

**Observed:**
No direct conflicts found among the 13 Charges-domain candidate rules themselves. Cross-domain note (not a conflict, but a near-duplicate worth flagging): rule 4 (fbc-embedding-vs-separate-debit, this domain) restates essentially the same mechanism as the Accounting-domain rule 'per-charge-currency-selection-with-embedding-rule' — both describe the same-currency-embed / different-currency-separate-Dr-CA rule from the same lc-*.element.ts files. Not a conflict since both agents independently read the same code and agree; flagged here only so the KB doesn't publish it twice as if it were two independent findings.

**Source:**
(see rule files with status CONFLICT in this domain)

**Problem:**
Two or more sources disagree.

**Question:**
Which source should be treated as authoritative going forward, and should the losing source be corrected?

---

### GAP-035 (Classification)

**Observed:**
transaction-currency-inference-staleness-risk (Classification domain): response-viewer.component.ts's groupedSettlementEntries still infers 'transaction currency' from entries[0].currency, matching the server's pre-v1.10.0 behavior, while the server itself (confirmPaymentInstruction.ts) moved to an explicit transactionCurrency wire field in v1.10.0 specifically to fix this same class of bug. No test in response-viewer.component.spec.ts exercises an all-foreign-currency scenario, so whether this causes real misattribution in practice is unverified.

**Source:**
(see rule files with status CONFLICT in this domain)

**Problem:**
Two or more sources disagree.

**Question:**
Which source should be treated as authoritative going forward, and should the losing source be corrected?

---

### GAP-036 (Classification)

**Observed:**
classification-rule-two-doc-variants: COMMON-PaymentComponent-Cross-Reference.md states a 2-term merged-Nostro/Vostro XOR rule that is not algebraically equivalent to the 3-term Rev.2 rule implemented in classification.ts and described everywhere else (OAS, both FSD docs, Calculation Validation doc). The executable code and majority of docs use the 3-term rule; the cross-reference doc does not flag its own statement as outdated.

**Source:**
(see rule files with status CONFLICT in this domain)

**Problem:**
Two or more sources disagree.

**Question:**
Which source should be treated as authoritative going forward, and should the losing source be corrected?

---

### GAP-037 (Classification)

**Observed:**
rtgs-vs-accounttype-schema-evolution (cross-domain, corroborated within Classification evidence): the zh FSD doc (PaymentComponent-Microservice-FSD-zh) contains a stale embedded OAS schema excerpt showing AccountType with a 6th 'RTGS' enum value (a v1.1.0/v1.2.0 draft state), immediately followed by that same document's own v1.3.0 correction note removing it — the live microservice types.ts and Payment_component.yaml both confirm only 5 values with no RTGS. This is a documentation-staleness artifact, not a live contradiction in the running system, but readers of the zh FSD doc in isolation could be misled.

**Source:**
(see rule files with status CONFLICT in this domain)

**Problem:**
Two or more sources disagree.

**Question:**
Which source should be treated as authoritative going forward, and should the losing source be corrected?

---

### GAP-044 (FX)

**Observed:**
Terminology/mechanism drift across three documents for the same underlying pattern: the FSD (analysis__Payment-OAS-FSD-en.docx.txt §7.8) and the expert-review doc describe a `chargeComponentBridge` boolean wire-extension flag gating residual-sized FX Exchange entries for a 'no real credit leg' LC-issuance scenario; the Trade_Finance_Payment_Component_Architecture_v4-cn.docx.txt instead calls a related concept `chargeBridge: true` (referencing a business-case-registry entry named `iplc-issue-charge-bridge`); but a grep of the entire microservice source and both OAS yaml files for `chargeComponentBridge` returns ZERO matches — no such flag exists anywhere in the implemented/validated contract. The actual shipped mechanism (v1.9.0, confirmed by direct code read of suspenseBridge.ts) achieves the same residual-vs-gross FX sizing unconditionally for every debitEntries bucket, gated by nothing but `side === 'DEBIT'` and the presence of a foreign-currency Suspense entry — no flag of any name is checked anywhere in the code. Downgraded the FX-domain rule citing this (id_hint 'charge-bridge-fx-sizing-difference-not-gross') from CONFIRMED to INFERRED as a result. This is a genuine drift between design-history documentation (which describes a flag-gated special case) and the generalized rule the code actually ships (which needs no flag).

**Source:**
(see rule files with status CONFLICT in this domain)

**Problem:**
Two or more sources disagree.

**Question:**
Which source should be treated as authoritative going forward, and should the losing source be corrected?

---

### GAP-045 (FX)

**Observed:**
Rule 44 ('[Proposed, NOT implemented] sum-then-round for multi-currency aggregation, residual to P&L') from the Architecture v4 doc directly contradicts the ALREADY-SHIPPED per-entry-rounding design documented in suspenseBridge.ts's own v1.7.3/v1.7.4 history and confirmed live in the code (rule 'suspense-bridge-per-entry-gross-conversion' — each Suspense entry converts/rounds alone, never summed-then-rounded-once, specifically because sum-then-round was found to break the exact-equality V8 balance check by a minor unit in a real worked example). Both are internally consistent and separately CONFIRMED against their own sources — this is a documented architectural tension between an FSD-era aspiration (round after summing, for a different problem: multi-currency CHARGE aggregation before it ever reaches the Payment Component) and the Payment Component's own shipped, opposite convention (round per Suspense entry, before/at the bridge boundary), not a contradiction within either document taken alone. Flagged so the KB does not present the v4 proposal as compatible guidance for suspenseBridge.ts's existing behavior.

**Source:**
(see rule files with status CONFLICT in this domain)

**Problem:**
Two or more sources disagree.

**Question:**
Which source should be treated as authoritative going forward, and should the losing source be corrected?

---

### GAP-058 (SWIFT)

**Observed:**
None found strictly within the SWIFT-domain candidate set itself (rules 1-24 are internally consistent once near-duplicates are merged). Two apparent temporal 'conflicts' were resolved as before/after pairs rather than true contradictions: (a) the legacy-defect rules (swift-32a-33b-same-source-legacy / swift-32a-33b-equal-cross-currency-defect, describing the PRE-fix state where 32A and 33B were forced equal) vs. the H-3 hardened rules (h3-swift-32a-vs-33b-uetr / h3-32a-33b-decoupled-hardened, describing the POST-fix state, code-verified this session) — both are accurate for their respective points in time and are kept as two separate CONFIRMED rules rather than merged or flagged CONFLICT, since the code (highest-priority evidence) confirms the fix is what currently ships. (b) Cross-domain candidate 'response-shape-outdated-vs-planned-rdd' (Architecture/CONFLICT) already flags, at the domain-agnostic level, that the current OAS idempotency key model has NOT yet been migrated to the confirmed structured Reference/Event design described in this SWIFT-tagged pair's own id_hint=idempotency-key-lc-event-not-sequence rule — i.e. that Architecture-domain CONFLICT entry and this SWIFT-tagged rule are describing the same gap from two angles, not disagreeing with each other.

**Source:**
(see rule files with status CONFLICT in this domain)

**Problem:**
Two or more sources disagree.

**Question:**
Which source should be treated as authoritative going forward, and should the losing source be corrected?

---

### GAP-063 (Suspense)

**Observed:**
Rule 'charge-component-bridge-no-credit-leg' (FSD §7.8): the FSD documents a `chargeComponentBridge` boolean extension flag as the gating mechanism for empty creditLegs, and a diff/residual-based (not gross) FX sizing for the Charge Component Bridge fee-collection scenario. Neither matches the actual implemented server code: (a) `chargeComponentBridge` does not exist anywhere in microservices/payment-component/src/ — the real gating (requestSchema.ts) checks only whether suspenseBridge itself contributes a credit leg; (b) the real v1.9.0 diff-netting logic (suspenseBridge.ts) applies only to a debitEntries-vs-debitLegs (same-side) comparison, never to a creditEntries-vs-debitLegs (opposite-side) comparison as FSD §7.8 describes — a creditEntries bucket (which is what the actual LC-issue fee-collection pattern uses per CLAUDE.md's own documented example) is always posted gross with independent, non-netted FX pairs. This means the cross-domain rule 'charge-bridge-fx-sizing-difference-not-gross' (tagged CONFIRMED in the full rule-title list from another domain) is also suspect and should be re-examined by whichever domain owns it — it appears to restate the same unimplemented FSD claim.

**Source:**
(see rule files with status CONFLICT in this domain)

**Problem:**
Two or more sources disagree.

**Question:**
Which source should be treated as authoritative going forward, and should the losing source be corrected?

---

### GAP-064 (Suspense)

**Observed:**
The microservice README.md's suspenseBridge section (lines 122-179, headed 'v1.4.0 / v1.5.0 / v1.7.0-v1.8.0') documents the netting/combining mechanism using v1.7.0/v1.7.1's superseded 'Net_C'/'Combined_C' terminology and describes the credit side as generating ONE 'Combined' pair per currency bucket. The actual current code (suspenseBridge.ts, confirmed by direct reading) implements v1.8.0/v1.9.0 behavior instead: the credit side generates up to TWO independent pairs per bucket (a Suspense pair and a separate Leg pair), never one combined pair, and the debit side's v1.9.0 diff-netting is structured differently (per-bucket diff against debitLegs) than the README's described Net_C formula, even though the two may coincide numerically in simple cases. This is a real documentation staleness gap in the README itself, on top of the already-known FSD staleness — see gaps_found.

**Source:**
(see rule files with status CONFLICT in this domain)

**Problem:**
Two or more sources disagree.

**Question:**
Which source should be treated as authoritative going forward, and should the losing source be corrected?

---

### GAP-069 (TestScenario)

**Observed:**
No direct conflicts found among the 5 TestScenario candidate rules themselves, and no conflict identified against the full cross-domain title list for this domain's rules specifically. (Cross-domain conflicts flagged elsewhere, e.g. classification-rule-two-doc-variants, transaction-currency-inference-staleness-risk, rtgs-vs-accounttype-schema-evolution, are unrelated to TestScenario evidence and were not re-litigated here.)

**Source:**
(see rule files with status CONFLICT in this domain)

**Problem:**
Two or more sources disagree.

**Question:**
Which source should be treated as authoritative going forward, and should the losing source be corrected?

---

### GAP-074 (UI)

**Observed:**
No genuine internal conflicts found among the 26 UI-domain candidate rules themselves after verification. One near-duplicate cluster was merged (see verification_note on 'amount-percent-waterfall-4-rule-v1123'): candidates amount-percent-waterfall-4-rule-v1123 (angular-leg-allocator), amount-waterfall-4-rules (expert-reviews-manuals), pct-waterfall-whole-percent-only (expert-reviews-manuals), and amount-waterfall-4-rule-model (root-context) all describe the identical v1.12.3 4-rule waterfall mechanism from different source documents (component code doc comment vs. user manual vs. CLAUDE.md) — merged into one entry citing the primary source-code evidence.

**Source:**
(see rule files with status CONFLICT in this domain)

**Problem:**
Two or more sources disagree.

**Question:**
Which source should be treated as authoritative going forward, and should the losing source be corrected?

---

### GAP-075 (UI)

**Observed:**
Cross-domain awareness check: the UI rule 'row-auto-delete-at-zero' (root-context) and 'auto-prune-zero-rows' (angular-leg-allocator) are the same rule from two source documents — already effectively covered by the merged/kept 'auto-prune-zero-rows' entry above; no conflict, just redundant sourcing, not merged into a separate list item since root-context's version added no new substantive detail beyond citing CLAUDE.md's own section.

**Source:**
(see rule files with status CONFLICT in this domain)

**Problem:**
Two or more sources disagree.

**Question:**
Which source should be treated as authoritative going forward, and should the losing source be corrected?

---

### GAP-076 (UI)

**Observed:**
No UI-domain rule was found to conflict with any Classification/Accounting/Validation domain rule from the full cross-domain title list — the UI-domain rules concern component-local rebalancing/display/reset mechanics that don't overlap in subject matter with the flagged cross-domain CONFLICT rules (e.g. classification-rule-two-doc-variants, rtgs-vs-accounttype-schema-evolution, response-shape-outdated-vs-planned-rdd, transaction-currency-inference-staleness-risk, voucher-type-enum-stale-after-v160-removal, swiftmessage-schema-diverges-between-two-oas-files, use-case-4-eplc-discount-conflict, sourcecomponent-attribution-ambiguous) — those are all server/data-model/documentation-lineage conflicts, orthogonal to the Angular leg-allocator/response-viewer/suspense-entries/business-case-fields component behavior this UI batch covers.

**Source:**
(see rule files with status CONFLICT in this domain)

**Problem:**
Two or more sources disagree.

**Question:**
Which source should be treated as authoritative going forward, and should the losing source be corrected?

---

### GAP-084 (Validation)

**Observed:**
voucher-type-enum-stale-after-v160-removal: AccountEntry.voucherType is still declared enum [SETTLEMENT, CHARGE, LIABILITY] in both Payment_component.yaml:839 and payment-instructions-post.yaml:887, even though the v1.6.0 changelog in the same two files (and confirmPaymentInstruction.ts's own top doc comment) states Charge/Liability Voucher generation was removed entirely and only SETTLEMENT entries are ever produced. The declared contract (schema) and the documented/implemented current behavior disagree.

**Source:**
(see rule files with status CONFLICT in this domain)

**Problem:**
Two or more sources disagree.

**Question:**
Which source should be treated as authoritative going forward, and should the losing source be corrected?

---

### GAP-085 (Validation)

**Observed:**
h2-gap-doc-vs-current-code: docs/payment-component-expert-review.md (dated 2026-08-09) documents H-2 ('Submitted leg amounts are not validated against the currency's minor units') as an OPEN gap with a recommended fix. The current requestSchema.ts (verified by direct read) already implements exactly that recommended fix (checkScale(), called for every debitLegs/creditLegs/suspenseBridge amount) — the same H-2 label is used both by the older gap-analysis doc (describing an absent check) and by the FSD Appendix B / CLAUDE.md / code comments (describing an implemented check). The gap-analysis doc is stale relative to the current code; evidence-priority (executable code > doc) resolves this in favor of 'implemented', but the doc itself was accurately describing the code AT THE TIME it was written, so this is a temporal doc-staleness conflict, not a fabrication.

**Source:**
(see rule files with status CONFLICT in this domain)

**Problem:**
Two or more sources disagree.

**Question:**
Which source should be treated as authoritative going forward, and should the losing source be corrected?

---

## Verification-flagged gaps (51)

### GAP-004 (API)

**Observed:**
Rule 'iwgt-liability-conditional-not-in-oas' documents a gap that is now partially moot: v1.6.0 removed ALL Liability Voucher generation from this service (per the charge-liability-voucher-removed-v160 rule elsewhere in this rule set), so the MTHD_OF_ISS conditional this rule describes no longer has any code path to apply to at all. The original calculation-validation doc's §6.3.5/§12.4 passage appears to predate or not account for the v1.6.0 architecture decision. Worth flagging in the KB that this open item is now superseded rather than actionable, to avoid a reader thinking it's still a live gap to close.

**Source:**
(verification pass for this domain)

**Problem:**
Flagged during adversarial verification as an open question or thin evidence.

**Question:**
Needs a follow-up read of the cited area, or a decision from the business/eng owner.

---

### GAP-005 (API)

**Observed:**
GET /payment-instructions (list/search) has no pagination, limit, or sort parameters in either the OAS or the implementation (confirmed by re-reading routes/paymentInstructions.ts's GET handler, which only accepts originModule and mainRef) — for a production deployment backed by more than an in-memory Map this would be a real gap, but no candidate rule in this domain's list called it out explicitly.

**Source:**
(verification pass for this domain)

**Problem:**
Flagged during adversarial verification as an open question or thin evidence.

**Question:**
Needs a follow-up read of the cited area, or a decision from the business/eng owner.

---

### GAP-006 (API)

**Observed:**
The RequestExtensions fields (sourceFunctionCode, voucherCodePrefixOverride, dryRun) are read directly off req.body with a raw `as RequestExtensions` cast and NO runtime validation of their types at all (e.g. a caller could send dryRun: 'yes' (a string) and `ext.dryRun ? 200 : ...` would still truthily treat it as dryRun-on, or a malformed non-boolean would silently pass through to confirmPaymentInstruction's dryRun option). None of the candidate rules examined this specific runtime-type-safety gap on the three extension fields.

**Source:**
(verification pass for this domain)

**Problem:**
Flagged during adversarial verification as an open question or thin evidence.

**Question:**
Needs a follow-up read of the cited area, or a decision from the business/eng owner.

---

### GAP-007 (API)

**Observed:**
GET /api/fx/rates (demo backend) and the Payment Component microservice have completely disjoint currency/rate models — the demo backend's /api/fx/rates is unrelated to the microservice's own FX handling (which requires the caller to supply already-resolved rates per the 'fx-rate-resolution-out-of-scope' cross-domain rule). No candidate rule flagged that these are two entirely separate, non-integrated FX data sources in the same repository, which could confuse a reader of the KB into thinking the microservice consults the demo backend's rate table.

**Source:**
(verification pass for this domain)

**Problem:**
Flagged during adversarial verification as an open question or thin evidence.

**Question:**
Needs a follow-up read of the cited area, or a decision from the business/eng owner.

---

### GAP-015 (Accounting)

**Observed:**
gl-posting-engine-not-in-baseline-scope (UNCLEAR, not independently re-verified in depth this pass beyond a targeted grep confirming the exact zh-FSD line 996 quote exists) — directly relevant gap: the AccountEntry schema is acknowledged by the FSD's own risk table as 'not an actual confirmed downstream integration,' meaning every Accounting rule in this list about 'what gets posted' describes a simulated/designed voucher shape, not a verified live GL posting. This caveat should travel with the whole Accounting domain, not just this one rule.

**Source:**
(verification pass for this domain)

**Problem:**
Flagged during adversarial verification as an open question or thin evidence.

**Question:**
Needs a follow-up read of the cited area, or a decision from the business/eng owner.

---

### GAP-016 (Accounting)

**Observed:**
rounding-difference-gl-account-open-gap (UNCLEAR, not independently re-opened this pass, relying on the expert-review doc's own self-description) — genuinely still open as far as evidence shows: now that M-7 enforces exact Dr=Cr balance with zero tolerance, no code path in confirmPaymentInstruction.ts/suspenseBridge.ts was found (in the portions read this pass) that books a residual to a dedicated rounding-difference GL account; a caller whose legs don't reconcile to the exact minor unit simply gets a 409 LEGS_UNBALANCED with no system-provided remediation leg. Worth flagging as a live, unaddressed control gap rather than a stale historical note.

**Source:**
(verification pass for this domain)

**Problem:**
Flagged during adversarial verification as an open question or thin evidence.

**Question:**
Needs a follow-up read of the cited area, or a decision from the business/eng owner.

---

### GAP-017 (Accounting)

**Observed:**
Near-duplicate rules NOT explicitly merged above (left as separate list entries per their distinct id_hints/evidence, but noted here for completeness): 'account-entry-unconditional-per-leg-fsd' and 'settlement-entry-per-leg-unconditional' describe the identical fact from FSD-doc vs. code evidence; 'voucher-description-assembly-fsd' and 'voucher-desc-per-leg-formula' likewise. Both pairs were verified independently and left as two entries each (code-sourced + doc-sourced) rather than collapsed to one, since the two evidence types are worth preserving separately for a KB reader who wants to trace design-intent-doc vs. actual-implementation lineage.

**Source:**
(verification pass for this domain)

**Problem:**
Flagged during adversarial verification as an open question or thin evidence.

**Question:**
Needs a follow-up read of the cited area, or a decision from the business/eng owner.

---

### GAP-018 (Accounting)

**Observed:**
Time/scope caveat: given the volume of candidate rules (73) for this domain plus extensive cross-referencing needed against 40+ related titles from other domains, deep re-verification (opening every cited file/line) was performed for roughly half the rules — the higher-risk/most-central ones (V8 balance, voucher description, suspense bridge netting, money.ts decimal handling, the v1.6.0 Charge/Liability removal conflict, and several leg-allocator/response-viewer rules). The remainder were kept at their original status with a corroboration note explaining what indirect evidence was checked (e.g. call-graph grep, cross-referencing against directly-read sibling code, or consistency with the extensively detailed CLAUDE.md decision log) rather than a full independent file re-read. None were found to be actually wrong; all downgrades/upgrades made are noted individually in each rule's verification_note.

**Source:**
(verification pass for this domain)

**Problem:**
Flagged during adversarial verification as an open question or thin evidence.

**Question:**
Needs a follow-up read of the cited area, or a decision from the business/eng owner.

---

### GAP-019 (Accounting)

**Observed:**
Two rules (#41 exchangerate1-2-underdocumented, #15 voucher-two-dual-prefix-rows) were UPGRADED from UNCLEAR to CONFIRMED after direct file verification showed the underlying claim is actually a directly-verifiable structural/code fact, not a matter of interpretation — worth flagging to whoever set the original UNCLEAR status that these should not have been marked UNCLEAR in the first place, since the evidence was already cited correctly, just not opened.

**Source:**
(verification pass for this domain)

**Problem:**
Flagged during adversarial verification as an open question or thin evidence.

**Question:**
Needs a follow-up read of the cited area, or a decision from the business/eng owner.

---

### GAP-022 (Architecture)

**Observed:**
Rule 31's specific claim that voucher-description centralization happened 'per-module in IMCO/GTEE/IWGT (SYM_*_SetPaymentVchDesc/CAL_PAYMENT_AC_DESC)' is only directly evidenced for IMCO (SYM_IMCO_SetPaymentVchDesc, PaymentComponent-Microservice-FSD-zh.docx.txt line 114) in the excerpt I checked; I did not find a direct SYM_GTEE_SetPaymentVchDesc / SYM_IWGT_SetPaymentVchDesc citation in the sections I read (only an aggregate mention of IPLC/EPLC/EXCO/IMCO/GTEE/IWGT all having 'consistent' Payment Component capability at line 172). The rule's core claim (Payment Component is a shared settlement layer, not a product) is solidly confirmed regardless — only the GTEE/IWGT half of the per-module implementation-function attribution is unconfirmed from what I read.

**Source:**
(verification pass for this domain)

**Problem:**
Flagged during adversarial verification as an open question or thin evidence.

**Question:**
Needs a follow-up read of the cited area, or a decision from the business/eng owner.

---

### GAP-023 (Architecture)

**Observed:**
Not a rule gap but worth flagging to the KB maintainer: rules 36/37/38 (idempotency payload-fingerprint, key-design, atomic-upsert) and rule 10 (current natural-key) sit at different maturity stages of the SAME idempotency subsystem — 10 is CURRENT/implemented, 36/38 are CURRENT/implemented hardening on top of 10, and 37 is the PLANNED future key shape (same as rule 24's CONFLICT). A reader assembling these four into one KB page should sequence them (current -> current hardening -> planned future) rather than read them as four independent facts, or the planned bankContractRef/eventSeq design could be mistaken for already-shipped behavior.

**Source:**
(verification pass for this domain)

**Problem:**
Flagged during adversarial verification as an open question or thin evidence.

**Question:**
Needs a follow-up read of the cited area, or a decision from the business/eng owner.

---

### GAP-024 (Architecture)

**Observed:**
No new previously-unnoticed architectural gap surfaced beyond what the candidate rules already documented (voucher-prefix-not-in-OAS, RPFM partial integration, four confirmed non-users, LC Issue not yet adopted, extended usage scenarios not registry-wired, OAS version lag, SwiftMessage schema divergence between the two OAS files) — this verification pass confirms rather than extends that list for the Architecture domain specifically.

**Source:**
(verification pass for this domain)

**Problem:**
Flagged during adversarial verification as an open question or thin evidence.

**Question:**
Needs a follow-up read of the cited area, or a decision from the business/eng owner.

---

### GAP-026 (CONFLICT)

**Observed:**
Because this domain's candidate list contained only a single rule, no merging of near-duplicates was needed within this batch. However, the cross-domain title list contains at least 4 separately-titled rules (rtgs-modeled-as-nostro-flag, rtgs-remodeled-as-nostro-flag, rtgs-modeled-as-nostro-flag-not-account-type, rtgs-modeled-as-nostro-flag-not-distinct-type) that all assert the same current-state conclusion this CONFLICT rule reaches — the downstream KB should link/cross-reference this CONFLICT entry to those, since together they show the CONFLICT is fully resolved in favor of the NOSTRO+flag model and none of those other entries need to hedge or re-litigate it.

**Source:**
(verification pass for this domain)

**Problem:**
Flagged during adversarial verification as an open question or thin evidence.

**Question:**
Needs a follow-up read of the cited area, or a decision from the business/eng owner.

---

### GAP-027 (CONFLICT)

**Observed:**
The current OAS's self-documented version narrative (v1.1.0 add RTGS -> v1.2.0 correct its description -> v1.3.0 remove and replace with rtgsIndicator) is strong provenance, but I did not find independent confirmation in the microservice's own TypeScript source/tests (e.g. types.ts, requestSchema.ts) that the current implementation actually rejects a bare 'RTGS' AccountType value at runtime (as opposed to just the OAS schema omitting it from the enum). This distinction — schema-level removal vs. enforced runtime rejection — was outside the scope of the files cited for this rule and is worth a follow-up check against the microservice's actual Zod/validation schema before treating runtime rejection as confirmed.

**Source:**
(verification pass for this domain)

**Problem:**
Flagged during adversarial verification as an open question or thin evidence.

**Question:**
Needs a follow-up read of the cited area, or a decision from the business/eng owner.

---

### GAP-029 (Charges)

**Observed:**
The demo backend's actual charge-collection mechanism (hardcoded per-endpoint chargeSelections logic in backend/server.js) does not implement, and is architecturally quite different from, the proposed Charge Settlement Policy (rule 13, INDIVIDUAL/SUM_BY_CURRENCY/SUM_ALL/HYBRID) — the demo lets the customer pick ONE currency per named fee (e.g. 'comm' in TWD or lcCcy) rather than a bank-parameterized aggregation policy across multiple simultaneous charge lines. Worth noting in the KB as 'current demo behavior vs. proposed target architecture' so a reader doesn't assume the demo already implements the v4 proposal.

**Source:**
(verification pass for this domain)

**Problem:**
Flagged during adversarial verification as an open question or thin evidence.

**Question:**
Needs a follow-up read of the cited area, or a decision from the business/eng owner.

---

### GAP-030 (Charges)

**Observed:**
None of the 13 Charges rules were cross-checked against the microservice's own domain/suspenseBridge.ts or the Charge Component <-> Payment Component boundary section in CLAUDE.md, even though that boundary is directly relevant to Charges (e.g., 'Payment Component never calculates or posts individual charge lines' vs. this demo backend's server.js, which DOES calculate and post individual charge/commission lines directly to GL 'Income' accounts). This is not a contradiction — the legacy web-components/backend mock is a different, older system than the microservices/payment-component service — but the KB should make this scope boundary explicit so a reader doesn't conflate the demo backend's charge-calculation logic with the Payment Component's documented 'charges are the Charge Component's job, never posted here' rule.

**Source:**
(verification pass for this domain)

**Problem:**
Flagged during adversarial verification as an open question or thin evidence.

**Question:**
Needs a follow-up read of the cited area, or a decision from the business/eng owner.

---

### GAP-031 (Charges)

**Observed:**
Rule 3's original evidence did not cover Export Collection's 'Bill Credit' charge line at all, yet the candidate statement asserted it 'defaults to TWD with the bill currency as an alternative' — this is factually backwards per lc-collection.element.ts (see verification_note on rule 3): Bill Credit actually defaults to the bill currency (foreign), with TWD as the alternative, i.e. it follows the SAME pattern as Margin (trade-amount-linked charges default to foreign ccy), not the Commission/SWIFT/Advising pattern (bank-income charges default to TWD). This was corrected in the verified statement rather than left as a silent error.

**Source:**
(verification pass for this domain)

**Problem:**
Flagged during adversarial verification as an open question or thin evidence.

**Question:**
Needs a follow-up read of the cited area, or a decision from the business/eng owner.

---

### GAP-032 (Charges)

**Observed:**
No candidate rule addresses whether/how the Charges domain's minimum-fee floors (MIN_COMM, MIN_NEGO, MIN_COLLECTION) or the LC Balance/tolerance commission base are themselves currency-scale-aware (H-2 style) — all TWD minimums are flat integers and TWD is 0-decimal, so this is moot in the demo, but the gap (no explicit currency-decimal-awareness check on charge minimums) was never examined by any prior agent and is worth a follow-up note in the KB rather than silently assuming it's fine.

**Source:**
(verification pass for this domain)

**Problem:**
Flagged during adversarial verification as an open question or thin evidence.

**Question:**
Needs a follow-up read of the cited area, or a decision from the business/eng owner.

---

### GAP-038 (Classification)

**Observed:**
No test in response-viewer.component.spec.ts (or elsewhere in this evidence set) constructs a scenario where an entire debit or credit side is denominated in a currency other than the deal's true transaction currency and then checks groupedSettlementEntries' FX-pair Debit/Credit attribution — this is the exact scenario that broke the server pre-v1.10.0, and it's untested on the client side despite the client using the same vulnerable inference (entries[0].currency).

**Source:**
(verification pass for this domain)

**Problem:**
Flagged during adversarial verification as an open question or thin evidence.

**Question:**
Needs a follow-up read of the cited area, or a decision from the business/eng owner.

---

### GAP-039 (Classification)

**Observed:**
The suspense-pair-attribution heuristic (response-viewer.component.ts) only ever compares a candidate pair's gross amount against Suspense-Debit sums; it never independently checks against Suspense-Credit sums. This means the code cannot actually distinguish a genuine 'tie' (matches both) from a normal single match — the claim in the original candidate rule that 'both resulting pairs are attributed to Debit' in a tie is architecturally plausible (since anything matching Suspense-Debit routes to Debit, and Suspense-Credit is never separately checked) but is not exercised by any cited test, so this specific tie-handling detail is asserted from code-reading, not observed test behavior.

**Source:**
(verification pass for this domain)

**Problem:**
Flagged during adversarial verification as an open question or thin evidence.

**Question:**
Needs a follow-up read of the cited area, or a decision from the business/eng owner.

---

### GAP-040 (Classification)

**Observed:**
The RPFM GAP cases' INTERNAL vs SUSPENSE modeling choice (id_hint: rpfm-internal-account-type-judgment-call) is corroborated by two independent source documents (business-case-registry.ts and RPFM-PaymentComponent-Gap-Analysis.md) using near-identical wording, which suggests one was derived from the other rather than being independent confirmation — worth noting for anyone treating the RPFM-PaymentComponent-Gap-Analysis.md citation as separate corroboration.

**Source:**
(verification pass for this domain)

**Problem:**
Flagged during adversarial verification as an open question or thin evidence.

**Question:**
Needs a follow-up read of the cited area, or a decision from the business/eng owner.

---

### GAP-041 (Classification)

**Observed:**
No rule in this domain's candidate list addresses whether the Payment Component microservice's classify-only endpoint (used by GAP/RPFM cases) validates or rejects an RTGS-scoped-to-non-RPFM submission at the classification layer specifically (as opposed to the general schema/request-validation layer) — the FSD text says 'server-side validation should reject it for any other originModule' but this domain's evidence doesn't show where or whether that specific check is implemented in classification.ts (it isn't — classify() takes no originModule parameter at all), which may itself be worth flagging as a possible implementation gap rather than just an FSD aspiration.

**Source:**
(verification pass for this domain)

**Problem:**
Flagged during adversarial verification as an open question or thin evidence.

**Question:**
Needs a follow-up read of the cited area, or a decision from the business/eng owner.

---

### GAP-046 (FX)

**Observed:**
No unit test was found (within the file set available to this review) that specifically constructs a case where diffNative and diffTrx (suspenseBridge.ts's DEBIT-side netting) disagree in sign — the M-3 expert-review finding describes a structurally real gap in the code (confirmed directly: the diffNative.greaterThan(0) branch does not independently sign-check or .abs() diffTrx the way the lessThan(0) branch does), but whether this is empirically reachable given both quantities derive from the same already-rounded, minor-unit-scale inputs remains untested either way. Worth a dedicated regression test either proving it unreachable or reproducing it.

**Source:**
(verification pass for this domain)

**Problem:**
Flagged during adversarial verification as an open question or thin evidence.

**Question:**
Needs a follow-up read of the cited area, or a decision from the business/eng owner.

---

### GAP-047 (FX)

**Observed:**
Rule 52 (multi-currency CUSTOMER leg needing no new server capability) is sourced entirely from a Proposed Use Cases document (PaymentComponentProposedUseCases-EN.docx.txt), not from any executed test or registry business case. CLAUDE.md explicitly confirms these use cases are 'NOT yet in the business-case-registry' — no citation, no default account numbers, no regression test exists for this scenario end-to-end. The structural claim (does not trigger suspenseBridge's FX mechanism) is code-consistent, but the specific worked example (V8 balancing on amountTxCcy alone for a multi-currency CA split) has only been verified by hand in the doc, never by running the service.

**Source:**
(verification pass for this domain)

**Problem:**
Flagged during adversarial verification as an open question or thin evidence.

**Question:**
Needs a follow-up read of the cited area, or a decision from the business/eng owner.

---

### GAP-048 (FX)

**Observed:**
PaymentLegInput's four rate fields (drRate, drBuyRate, crBuyRate, sellRate) have no single authoritative selection rule documented anywhere in this file set beyond drBuyRate's IMCO-specific threshold logic — this is an acknowledged, still-open gap (see the two UNCLEAR rules above) that indirectly weakens confidence in how universally rule 'account-ccy-conversion-formula-8-2' (amountAccountCcy = amountTxCcy × 'the' buy rate) applies when a leg could plausibly populate more than one of these four fields with different values — no code or test in this review's scope disambiguates which field 'wins' at the microservice layer beyond the fixed convention already confirmed in accountEntries.ts's exchangeRate1 sourcing (drRate ?? drBuyRate for DEBIT, crBuyRate ?? sellRate for CREDIT).

**Source:**
(verification pass for this domain)

**Problem:**
Flagged during adversarial verification as an open question or thin evidence.

**Question:**
Needs a follow-up read of the cited area, or a decision from the business/eng owner.

---

### GAP-049 (FX)

**Observed:**
Three different documents (FSD, expert-review, Architecture-v4) use three different names/framings for what appears to be conceptually the same 'no independent credit leg, Suspense-Credit funds the whole credit side' pattern — chargeComponentBridge (flag), chargeBridge:true (business-case flag), and the actual shipped v1.9.0/v1.10.1 mechanism (no flag, just a non-empty suspenseBridge). None of the FX-domain candidate rules that cite these documents cross-reference this naming drift; a KB consumer following only the FX-domain evidence trail could easily conclude a `chargeComponentBridge` flag exists in the live API when it does not.

**Source:**
(verification pass for this domain)

**Problem:**
Flagged during adversarial verification as an open question or thin evidence.

**Question:**
Needs a follow-up read of the cited area, or a decision from the business/eng owner.

---

### GAP-053 (Other)

**Observed:**
The rpfm-settle-participant-idr-quirk rule (and the broader RPFM GAP findings) never states whether the IDR-branch quirk affects only the RTGS assignment or also leaves CPYT_CR_AC_TYPE at some stale/wrong prior value that could cascade into wrong voucher-description TypeChar or wrong classification if RPFM is ever wired to the Payment Component — this downstream consequence is asserted in the Mapping Functions table's phrase 'CPYT_CR_AC_TYPE is left at its prior value' but never traced further (e.g. what that prior value typically is, whether it's ever CUSTOMER/NOSTRO by coincidence).

**Source:**
(verification pass for this domain)

**Problem:**
Flagged during adversarial verification as an open question or thin evidence.

**Question:**
Needs a follow-up read of the cited area, or a decision from the business/eng owner.

---

### GAP-054 (Other)

**Observed:**
The payInstrFlag rule and the drRate/crBuyRate/sellRate rule are both symptomatic of a broader, unstated pattern: v1.1.0 of the OAS added several fields (payInstrFlag, drRate, crBuyRate, sellRate) purely by porting XSD/source field names into the schema without confirming a live setter exists or tracing full selection logic. No rule currently names this pattern explicitly ('OAS schema completeness sometimes outruns confirmed business-logic tracing') — worth a dedicated note for downstream readers so they don't assume every OAS field is fully behaviorally understood just because it's typed and documented.

**Source:**
(verification pass for this domain)

**Problem:**
Flagged during adversarial verification as an open question or thin evidence.

**Question:**
Needs a follow-up read of the cited area, or a decision from the business/eng owner.

---

### GAP-055 (Other)

**Observed:**
The a1-eplc-liability-desc-typo rule is scoped only to EPLC (TrxSys.js:5908), but per the CLAUDE.md Charge/Liability Voucher removal note, Liability Voucher generation (§6.3) was removed entirely from the microservice in v1.6.0 — so this typo's business-decision ('replicate vs fix') is now moot for the microservice itself (there is no Liability Voucher stream to replicate it into). No rule states this resolution explicitly; a reader could still think this is an open decision for the current codebase when in practice v1.6.0 already mooted it by removing the whole voucher stream.

**Source:**
(verification pass for this domain)

**Problem:**
Flagged during adversarial verification as an open question or thin evidence.

**Question:**
Needs a follow-up read of the cited area, or a decision from the business/eng owner.

---

### GAP-056 (Other)

**Observed:**
The payInstrFlag rule's second citation (Payment-OAS-FSD-en.docx.txt lines 505-512) does not correspond to any content in the actual converted file, which is only 302 lines long -- likely a stale/incorrect line reference from the original extracting agent. The rule's substance is still independently confirmed via the Payment_Mapping_Functions.docx.txt §10.1 R1 citation, so this is a citation-precision issue, not a substance issue.

**Source:**
(verification pass for this domain)

**Problem:**
Flagged during adversarial verification as an open question or thin evidence.

**Question:**
Needs a follow-up read of the cited area, or a decision from the business/eng owner.

---

### GAP-059 (SWIFT)

**Observed:**
Two of the 24 candidate rules (idempotency-key-lc-event-not-sequence, reversal-event-type) are tagged domain=SWIFT in the source list but are substantively about the idempotency-key/event-model architecture, not SWIFT messaging — their only SWIFT touchpoint is D-4's aside that customerRef is carried for 'SWIFT field 21 (related reference)'. They are verbatim/near-duplicates of the Architecture-domain candidates 'idempotency-key-design' and 'idempotency-payload-aware-fingerprint'. Recommend the downstream KB either re-tag these two to Architecture/Idempotency, or keep a single canonical version and cross-link rather than maintaining near-identical entries under two domain tags.

**Source:**
(verification pass for this domain)

**Problem:**
Flagged during adversarial verification as an open question or thin evidence.

**Question:**
Needs a follow-up read of the cited area, or a decision from the business/eng owner.

---

### GAP-060 (SWIFT)

**Observed:**
The swift-field-mapping-incomplete gap (UNCLEAR, tag-level MT103/MT202 mapping XML not found) has never been revisited or closed by any later document in this corpus — every other H-1/H-2/H-3/M-1/M-2/C-2 hardening item found a corresponding code fix, but this one has no code-side counterpart at all (there is genuinely no tag-level SWIFT wire-format builder anywhere in src/ — swiftMessages.ts only populates a handful of OAS-level fields like settlementCurrency/settlementAmount/instructedCurrency/instructedAmount/uetr, never a full MT103/MT202 tag block). This looks like a real, still-open implementation gap worth flagging distinctly to a Trade Finance BA/architect audience: the service claims to 'generate SWIFT messages' but what it actually produces is a small structured summary object, not anything resembling an actual SWIFT MT/ISO20022 wire message with tags/blocks. This is close to, but not quite identical to, the already-UNCLEAR rule 18 — it's the DOWNSTREAM consequence (what buildAdviceMessage/buildCoverMessage actually produce today is far short of a real SWIFT message) that the candidate list never states directly as its own rule.

**Source:**
(verification pass for this domain)

**Problem:**
Flagged during adversarial verification as an open question or thin evidence.

**Question:**
Needs a follow-up read of the cited area, or a decision from the business/eng owner.

---

### GAP-061 (SWIFT)

**Observed:**
SwiftMessage.correspondentBic exists in the OAS schema (Payment_component.yaml line 871) and is referenced conceptually in the FSD's routing-resolution step ('先解析往來行路由 / getPaymentRouting()'), but is never populated anywhere in swiftMessages.ts — confirmed by direct code read (buildAdviceMessage/buildCoverMessage never set correspondentBic). This sits alongside the already-known 'payment-routing-not-implemented' cross-domain finding (GET /payment-routing is aspirational/unimplemented) but the candidate list never explicitly connects the two: since routing is never resolved, correspondentBic can structurally never be populated on any generated SwiftMessage today. Worth a dedicated rule/gap in the downstream KB rather than leaving it implicit.

**Source:**
(verification pass for this domain)

**Problem:**
Flagged during adversarial verification as an open question or thin evidence.

**Question:**
Needs a follow-up read of the cited area, or a decision from the business/eng owner.

---

### GAP-062 (SWIFT)

**Observed:**
serviceTypeId and isGpiMember are repeatedly mentioned across multiple source documents (OAS schema, H-3 notes, expert review) as 'a config-driven follow-up, not yet implemented' but no candidate rule states this as its own explicit, standalone fact — it is buried as a trailing clause inside the H-3 rules. Given how many times it recurs independently across sources, it may deserve its own explicit UNCLEAR/gap entry in the KB rather than remaining a footnote.

**Source:**
(verification pass for this domain)

**Problem:**
Flagged during adversarial verification as an open question or thin evidence.

**Question:**
Needs a follow-up read of the cited area, or a decision from the business/eng owner.

---

### GAP-065 (Suspense)

**Observed:**
The microservice README.md's suspenseBridge section (lines 122-179) is titled as covering 'v1.4.0 / v1.5.0 / v1.7.0-v1.8.0' but its prose body describes the v1.7.0/v1.7.1 Net_C/Combined_C mechanism as if it were still current, without acknowledging that suspenseBridge.ts's own code (and its own top-of-file doc comment) documents this as SUPERSEDED first by v1.8.0 (independent per-source pairs) and then, for the debit side only, by v1.9.0 (diff-netting). A reader of just the README would come away with an inaccurate mental model of the current credit-side behavior (believing it produces one 'Combined' pair per bucket) and an imprecise one for the debit side (Net_C vs. the actual v1.9.0 diff formula, which happen to be similar but are described differently). This should be corrected in the README per this repo's own standing rule of keeping docs in sync with code.

**Source:**
(verification pass for this domain)

**Problem:**
Flagged during adversarial verification as an open question or thin evidence.

**Question:**
Needs a follow-up read of the cited area, or a decision from the business/eng owner.

---

### GAP-066 (Suspense)

**Observed:**
FSD §7.8's 'Charge Component Bridge — No-Credit-Leg Case' describes both a `chargeComponentBridge` gating flag (not present anywhere in the actual server source) and diff-based FX sizing for a creditEntries-vs-opposite-side-debitLegs scenario that the actual v1.9.0 netting code never implements (netting is debit-side-only, same-side only). This is a real, previously-unflagged FSD-vs-implementation gap, distinct from the already-known 'oas-info-version-lags-implementation' and 'charge-liability-voucher-removed-v1.6.0' staleness items in the cross-domain rule list — worth surfacing to whichever team owns FSD accuracy, since a caller trying to implement exactly what §7.8 describes (an opposite-side diff-netted FX pair, gated by a flag) would not get that behavior from the current API.

**Source:**
(verification pass for this domain)

**Problem:**
Flagged during adversarial verification as an open question or thin evidence.

**Question:**
Needs a follow-up read of the cited area, or a decision from the business/eng owner.

---

### GAP-067 (Suspense)

**Observed:**
No test or code path in the reviewed evidence demonstrates a suspenseBridge scenario where BOTH debitEntries and creditEntries are non-empty simultaneously in the same request and share a common foreign currency with each other (as opposed to with the caller's own legs) — the interaction between the debit-side bucket's netting and the credit-side bucket's independent-pairs behavior, when both buckets exist in the same currency in one request, is untested and its correctness is UNCLEAR from the evidence reviewed.

**Source:**
(verification pass for this domain)

**Problem:**
Flagged during adversarial verification as an open question or thin evidence.

**Question:**
Needs a follow-up read of the cited area, or a decision from the business/eng owner.

---

### GAP-068 (Suspense)

**Observed:**
The candidate list's evidence for suspense-bridge-wire-shape (buildSuspenseBridgeEntries/buildSuspenseBridge) cites several specific spec.ts test names (e.g. 'a cross-currency Suspense entry resolves and attaches crossRate (6dp)') that were not individually re-opened and line-verified in this pass — only the producing functions' existence and doc comments were directly confirmed. This rule's CONFIRMED status rests on slightly thinner direct verification than the others and could be revisited with a full spec.ts read if higher confidence is needed.

**Source:**
(verification pass for this domain)

**Problem:**
Flagged during adversarial verification as an open question or thin evidence.

**Question:**
Needs a follow-up read of the cited area, or a decision from the business/eng owner.

---

### GAP-070 (TestScenario)

**Observed:**
Numeric-count error found and corrected: the original 'no-unit-tests-for-lc-elements' rule claimed '11 LC *.element.ts files' — direct enumeration finds exactly 9 (4 under web-components/import/, 5 under web-components/export/), matching README.md's own '9 vanilla Custom Elements' figure and the cross-domain rule citing '10 LC Payment widgets' (9 elements + journal-entry.element.ts). The substantive claim (no spec files exist) was unaffected, only the count.

**Source:**
(verification pass for this domain)

**Problem:**
Flagged during adversarial verification as an open question or thin evidence.

**Question:**
Needs a follow-up read of the cited area, or a decision from the business/eng owner.

---

### GAP-071 (TestScenario)

**Observed:**
jest.config.js (the actual file containing collectCoverageFrom) was not present among the uploaded files for this review — the 'test-coverage-excludes-templates' rule's evidence rests entirely on README.md's and the expert-review doc's descriptions of that config, not on independent inspection of the config file itself. If jest.config.js is later made available, it should be checked directly to fully CONFIRM (rather than infer via secondary documentation) the exact collectCoverageFrom exclusion list.

**Source:**
(verification pass for this domain)

**Problem:**
Flagged during adversarial verification as an open question or thin evidence.

**Question:**
Needs a follow-up read of the cited area, or a decision from the business/eng owner.

---

### GAP-072 (TestScenario)

**Observed:**
The 'leg-defaults-illustrative-vs-fsd-verified' rule's INFERRED status reflects a real coverage gap: only 2 of 23 registry cases' notes were spot-checked against their claimed regression-scenario citations (test/regression.ts), and none were checked against the underlying legacy SYF_*.js source scripts themselves — a systematic per-case audit of all 23 notes against both test/regression.ts and the legacy scripts would be needed to upgrade this to CONFIRMED.

**Source:**
(verification pass for this domain)

**Problem:**
Flagged during adversarial verification as an open question or thin evidence.

**Question:**
Needs a follow-up read of the cited area, or a decision from the business/eng owner.

---

### GAP-073 (TestScenario)

**Observed:**
No rule in this domain's candidate set addresses whether the 15 PASS-case business-case-registry.spec.ts (which does exist, at src/app/payment-component/business-case-registry.spec.ts) tests the registry's OWN data integrity (e.g. verdict counts, module coverage) — this file was not read as part of this verification pass but its existence suggests some of the numeric claims in 'simulator-23-business-cases-catalog' might additionally be asserted by an executable test, not just observable via manual grep; worth a follow-up read to see if it strengthens that rule's evidence further.

**Source:**
(verification pass for this domain)

**Problem:**
Flagged during adversarial verification as an open question or thin evidence.

**Question:**
Needs a follow-up read of the cited area, or a decision from the business/eng owner.

---

### GAP-077 (UI)

**Observed:**
response-viewer.component.html was not opened directly to verify the literal `{{ e.amount }}` (unformatted) interpolation claimed for chargeEntries/liabilityEntries in rule 18 — the .ts-side asymmetry (no formatAmount call site for those getters) is confirmed and strongly implies the claim, but the template-level detail is unverified.

**Source:**
(verification pass for this domain)

**Problem:**
Flagged during adversarial verification as an open question or thin evidence.

**Question:**
Needs a follow-up read of the cited area, or a decision from the business/eng owner.

---

### GAP-078 (UI)

**Observed:**
lc-payment-wc/src/app/web-components/import/lc-settlement.element.ts (the third file cited for rule 21, covering the 'billCurrency OR corrBankChargesCcy — two independent currency fields both trigger the reset' sub-claim) was not opened; only the export lc-settlement.element.ts and import lc-issue.element.ts were directly verified. The dual-trigger detail for the import lc-settlement element remains unverified though plausible given the consistent pattern in the two files that were checked.

**Source:**
(verification pass for this domain)

**Problem:**
Flagged during adversarial verification as an open question or thin evidence.

**Question:**
Needs a follow-up read of the cited area, or a decision from the business/eng owner.

---

### GAP-079 (UI)

**Observed:**
The onConfirm() method body in business-case-runner.component.ts was not read end-to-end to positively confirm the total absence of a debitValid/creditValid gate (rule 22) — verification relied on runPreview()'s contrasting explicit gate plus an independent corroborating doc comment in response-viewer.component.ts. A direct read of onConfirm() would make this fully first-hand rather than corroborated.

**Source:**
(verification pass for this domain)

**Problem:**
Flagged during adversarial verification as an open question or thin evidence.

**Question:**
Needs a follow-up read of the cited area, or a decision from the business/eng owner.

---

### GAP-080 (UI)

**Observed:**
A new, previously unreported rule was surfaced while verifying suspense-entries.component.ts: SuspenseEntry.sourceComponent is a UI dropdown defaulting to 'CHARGE', using wire value 'BALANCE' (not 'LIABILITY') for the Liability option — this UI-level default/labeling detail wasn't present in any of the 26 candidate UI rules (a related but distinct fact, 'sourceComponent-provenance-only', exists in the Suspense domain list but describes server-side inertness, not the UI dropdown's own default value or CHARGE/BALANCE label mapping). Added as its own verified entry rather than silently dropped.

**Source:**
(verification pass for this domain)

**Problem:**
Flagged during adversarial verification as an open question or thin evidence.

**Question:**
Needs a follow-up read of the cited area, or a decision from the business/eng owner.

---

### GAP-081 (UI)

**Observed:**
None of the 26 original candidate rules were dropped without inclusion — all 26 appear above, with one 4-way near-duplicate cluster consolidated into a single merged entry as documented in conflicts_found and that entry's verification_note.

**Source:**
(verification pass for this domain)

**Problem:**
Flagged during adversarial verification as an open question or thin evidence.

**Question:**
Needs a follow-up read of the cited area, or a decision from the business/eng owner.

---

### GAP-086 (Validation)

**Observed:**
No test/evidence in this domain's read set traces WHERE the client's H-2/H-3 guard in leg-allocator.component.ts vs business-case-runner.component.ts vs README.md gets its 'H-2'/'H-3' label from consistently — README.md line 114 calls the amount-precision guard 'H-3 hardening', while the code's own doc comments (business-case-runner.component.ts line ~165, leg-allocator.component.ts) and CLAUDE.md consistently call the identical mechanism 'H-2'. This is a minor but real label inconsistency in the documentation (H-3 elsewhere unambiguously means the SWIFT 32A/33B settlement-vs-instructed-amount fix, not currency-scale validation) that nobody has reconciled.

**Source:**
(verification pass for this domain)

**Problem:**
Flagged during adversarial verification as an open question or thin evidence.

**Question:**
Needs a follow-up read of the cited area, or a decision from the business/eng owner.

---

### GAP-087 (Validation)

**Observed:**
The classify endpoint's stricter creditLegs.min(1) (still true in current requestSchema.ts's classifyRequestSchema, confirmed by direct read) is documented as a known L-2 inconsistency in the expert-review doc but has evidently never been fixed to match the Confirm endpoint's conditional relaxation — worth flagging as an open, still-live gap rather than a historical note.

**Source:**
(verification pass for this domain)

**Problem:**
Flagged during adversarial verification as an open question or thin evidence.

**Question:**
Needs a follow-up read of the cited area, or a decision from the business/eng owner.

---

### GAP-088 (Validation)

**Observed:**
requestSchema.ts's checkScale/checkNonNegative logic is entirely embedded in one large superRefine closure with no unit-level exports of the individual check functions (unlike money.ts's decimalPlaces/isNegativeAmount, which ARE exported and unit-testable in isolation) — meaning the requestSchema-level M-1/H-2 behavior is only verifiable via full-schema integration tests, not standalone; this doesn't invalidate any rule above but is a testability gap worth surfacing.

**Source:**
(verification pass for this domain)

**Problem:**
Flagged during adversarial verification as an open question or thin evidence.

**Question:**
Needs a follow-up read of the cited area, or a decision from the business/eng owner.

---

### GAP-089 (Validation)

**Observed:**
None of the read evidence shows a request-body-size cap, rate limiting, or auth on the validation layer itself (consistent with the cross-domain 'no-transport-security-controls' rule) — every 400/409 rule verified here assumes a well-formed HTTP request has already reached Express; nothing in this domain's files validates that assumption itself.

**Source:**
(verification pass for this domain)

**Problem:**
Flagged during adversarial verification as an open question or thin evidence.

**Question:**
Needs a follow-up read of the cited area, or a decision from the business/eng owner.

---

