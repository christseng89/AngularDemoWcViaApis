---
knowledge_id: Payment-Traceability-Matrix
title: "Payment Traceability Matrix"
domain: Payment
category: Traceability
snapshot_date: 2026-08-22
tags:
  - payment
  - traceability
---

# Payment Traceability Matrix

Rule -> Implementation -> Test, for all 304 business rules. "Test" is `—` where a rule's evidence cites only implementation code with no corresponding test file — treat those as a weaker evidence tier (still CONFIRMED/INFERRED per the rule's own status, but not independently proven by an executable assertion). See [[Test-Scenario-Index]] for the fuller scenario-level detail behind each Test column entry, and [[Source-to-Knowledge-Map]] for the reverse direction (source file -> rules).

## API (20 rules, 9 with direct test evidence)

| Rule | Status | Implementation | Test |
|---|---|---|---|
| [[API-RULE-001]] | ✅ | `microservices/payment-component/src/domain/voucherDescription.ts` | `microservices/payment-component/test/unit/domain/voucherDescription.test.ts` |
| [[API-RULE-002]] | ✅ | `microservices/payment-component/src/routes/paymentInstructions.ts` | `microservices/payment-component/test/unit/routes/paymentInstructions.test.ts` |
| [[API-RULE-003]] | ✅ | `microservices/payment-component/src/routes/paymentInstructions.ts` | `—` |
| [[API-RULE-004]] | ✅ | `microservices/payment-component/src/routes/paymentInstructions.ts` | `microservices/payment-component/test/unit/routes/paymentInstructions.test.ts` |
| [[API-RULE-005]] | ✅ | `microservices/payment-component/src/routes/paymentInstructions.ts` | `microservices/payment-component/test/unit/routes/paymentInstructions.test.ts` |
| [[API-RULE-006]] | ✅ | `microservices/payment-component/src/routes/paymentInstructions.ts` | `microservices/payment-component/test/unit/routes/paymentInstructions.test.ts` |
| [[API-RULE-007]] | ✅ | `—` | `microservices/payment-component/test/regression.ts` |
| [[API-RULE-008]] | ✅ | `microservices/payment-component/src/domain/confirmPaymentInstruction.ts` | `microservices/payment-component/test/regression.ts` |
| [[API-RULE-009]] | ✅ | `—` | `microservices/payment-component/test/regression.ts` |
| [[API-RULE-010]] | ✅ | `src/app/payment-component/business-case-runner.component.ts` | `—` |
| [[API-RULE-011]] | ✅ | `src/app/payment-component/payment-component-api.service.ts` | `payment-component-api.service.spec.ts` |
| [[API-RULE-012]] | 🟡 | `backend/server.js` | `—` |
| [[API-RULE-013]] | ✅ | `analysis/Payment_component.yaml` | `—` |
| [[API-RULE-014]] | ✅ | `analysis/Payment_component.yaml` | `—` |
| [[API-RULE-015]] | ✅ | `converted/analysis__Payment-OAS-FSD-en.docx` | `—` |
| [[API-RULE-016]] | ✅ | `analysis/Payment_component.yaml` | `—` |
| [[API-RULE-017]] | ✅ | `analysis/Payment_component.yaml` | `—` |
| [[API-RULE-018]] | ⚠️ | `analysis/Payment_component.yaml` | `—` |
| [[API-RULE-019]] | ✅ | `converted/analysis__Payment_Component_Calculation_Validation.docx` | `—` |
| [[API-RULE-020]] | ✅ | `converted/PaymentComponentProposedUseCases-EN.docx` | `—` |

## Accounting (47 rules, 5 with direct test evidence)

| Rule | Status | Implementation | Test |
|---|---|---|---|
| [[POSTING-RULE-001]] | ✅ | `src/domain/confirmPaymentInstruction.ts` | `test/unit/domain/confirmPaymentInstruction.test.ts` |
| [[POSTING-RULE-002]] | ✅ | `src/domain/confirmPaymentInstruction.ts` | `test/unit/domain/confirmPaymentInstruction.test.ts` |
| [[POSTING-RULE-003]] | ✅ | `src/domain/confirmPaymentInstruction.ts` | `—` |
| [[POSTING-RULE-004]] | ✅ | `src/domain/accountEntries.ts` | `—` |
| [[POSTING-RULE-005]] | ✅ | `src/domain/accountEntries.ts` | `accountEntries.test.ts` |
| [[POSTING-RULE-006]] | ✅ | `src/domain/accountEntries.ts` | `—` |
| [[POSTING-RULE-007]] | ✅ | `src/money.ts` | `—` |
| [[POSTING-RULE-008]] | ✅ | `src/money.ts` | `—` |
| [[POSTING-RULE-009]] | ✅ | `src/money.ts` | `—` |
| [[POSTING-RULE-010]] | ✅ | `src/domain/accountEntries.ts` | `—` |
| [[POSTING-RULE-011]] | ✅ | `src/domain/suspenseBridge.ts` | `—` |
| [[POSTING-RULE-012]] | ✅ | `src/domain/suspenseBridge.ts` | `—` |
| [[POSTING-RULE-013]] | ✅ | `src/domain/voucherDescription.ts` | `—` |
| [[POSTING-RULE-014]] | ✅ | `src/domain/voucherDescription.ts` | `—` |
| [[POSTING-RULE-015]] | ✅ | `src/domain/voucherDescription.ts` | `—` |
| [[POSTING-RULE-016]] | ✅ | `src/validation/requestSchema.ts` | `test/unit/validation/requestSchema.test.ts` |
| [[POSTING-RULE-017]] | ✅ | `analysis/Payment_component.yaml` | `—` |
| [[POSTING-RULE-018]] | ✅ | `src/app/payment-component/business-case-runner.component.ts` | `—` |
| [[POSTING-RULE-019]] | ✅ | `src/app/payment-component/business-case-runner.component.ts` | `—` |
| [[POSTING-RULE-020]] | ✅ | `leg-allocator.component.ts` | `—` |
| [[POSTING-RULE-021]] | ✅ | `src/app/payment-component/leg-allocator.component.ts` | `—` |
| [[POSTING-RULE-022]] | ✅ | `src/app/payment-component/leg-allocator.component.ts` | `—` |
| [[POSTING-RULE-023]] | ✅ | `leg-allocator.component.ts` | `—` |
| [[POSTING-RULE-024]] | ✅ | `src/app/payment-component/leg-allocator.component.ts` | `—` |
| [[POSTING-RULE-025]] | ✅ | `src/app/payment-component/leg-allocator.component.ts` | `—` |
| [[POSTING-RULE-026]] | ✅ | `src/app/payment-component/currency.service.ts` | `—` |
| [[POSTING-RULE-027]] | ✅ | `src/app/payment-component/response-viewer.component.ts` | `—` |
| [[POSTING-RULE-028]] | ✅ | `src/app/payment-component/response-viewer.component.ts` | `response-viewer.component.spec.ts` |
| [[POSTING-RULE-029]] | ✅ | `src/app/web-components/journal-entry.element.ts` | `—` |
| [[POSTING-RULE-030]] | ✅ | `backend/server.js` | `—` |
| [[POSTING-RULE-031]] | ✅ | `backend/server.js` | `—` |
| [[POSTING-RULE-032]] | ✅ | `analysis/Payment_component.yaml` | `—` |
| [[POSTING-RULE-033]] | ✅ | `analysis/Payment_component.yaml` | `—` |
| [[POSTING-RULE-034]] | ✅ | `src/domain/suspenseBridge.ts` | `—` |
| [[POSTING-RULE-035]] | ⚠️ | `/home/claude/payment-kb/converted/analysis__PaymentComponent-Microservice-FSD-zh.docx` | `—` |
| [[POSTING-RULE-036]] | ✅ | `analysis__Payment-OAS-FSD-en.docx` | `—` |
| [[POSTING-RULE-037]] | ✅ | `analysis__Payment-OAS-FSD-en.docx` | `—` |
| [[POSTING-RULE-038]] | ✅ | `business-case-registry.ts` | `—` |
| [[POSTING-RULE-039]] | ✅ | `CLAUDE.md` | `—` |
| [[POSTING-RULE-040]] | ✅ | `CLAUDE.md` | `—` |
| [[POSTING-RULE-041]] | ✅ | `microservices/payment-component/src/money.ts` | `—` |
| [[POSTING-RULE-042]] | ✅ | `payment-component-expert-review.md` | `—` |
| [[POSTING-RULE-043]] | ✅ | `payment-component-expert-review.md` | `—` |
| [[POSTING-RULE-044]] | ✅ | `docs__LC-Payment-WC-User-Manual-en.docx` | `—` |
| [[POSTING-RULE-045]] | ✅ | `PaymentComponentProposedUseCases-EN.docx` | `—` |
| [[POSTING-RULE-046]] | ⚠️ | `PaymentComponentProposedUseCases-EN.docx` | `—` |
| [[POSTING-RULE-047]] | ⚠️ | `PaymentComponentProposedUseCases-EN.docx` | `—` |

## Architecture (41 rules, 1 with direct test evidence)

| Rule | Status | Implementation | Test |
|---|---|---|---|
| [[ARCH-RULE-001]] | ✅ | `microservices/payment-component/src/domain/confirmPaymentInstruction.ts` | `—` |
| [[ARCH-RULE-002]] | ✅ | `microservices/payment-component/src/domain/classifyPreview.ts` | `—` |
| [[ARCH-RULE-003]] | ✅ | `microservices/payment-component/src/domain/classifyPreview.ts` | `—` |
| [[ARCH-RULE-004]] | ✅ | `microservices/payment-component/src/domain/accountEntries.ts` | `—` |
| [[ARCH-RULE-005]] | ✅ | `microservices/payment-component/src/domain/accountEntries.ts` | `—` |
| [[ARCH-RULE-006]] | ✅ | `microservices/payment-component/src/money.ts` | `—` |
| [[ARCH-RULE-007]] | ✅ | `microservices/payment-component/src/domain/suspenseBridge.ts` | `—` |
| [[ARCH-RULE-008]] | ✅ | `microservices/payment-component/src/domain/suspenseBridge.ts` | `—` |
| [[ARCH-RULE-009]] | ✅ | `microservices/payment-component/src/domain/voucherDescription.ts` | `—` |
| [[ARCH-RULE-010]] | ✅ | `microservices/payment-component/src/store/paymentInstructionStore.ts` | `—` |
| [[ARCH-RULE-011]] | ✅ | `microservices/payment-component/src/app.ts` | `—` |
| [[ARCH-RULE-012]] | ✅ | `microservices/payment-component/src/store/paymentInstructionStore.ts` | `—` |
| [[ARCH-RULE-013]] | ✅ | `src/app/payment-component/business-case.model.ts` | `src/app/payment-component/business-case-registry.spec.ts` |
| [[ARCH-RULE-014]] | ✅ | `src/app/payment-component/business-case-fields.ts` | `—` |
| [[ARCH-RULE-015]] | ✅ | `src/app/payment-component/business-case-runner.component.ts` | `—` |
| [[ARCH-RULE-016]] | ✅ | `src/app/payment-component/business-case-runner.component.ts` | `—` |
| [[ARCH-RULE-017]] | ✅ | `src/app/payment-component/leg-allocator.component.ts` | `—` |
| [[ARCH-RULE-018]] | ✅ | `src/app/payment-component/fx-rate.service.ts` | `—` |
| [[ARCH-RULE-019]] | ✅ | `src/app/payment-component/payment-component.types.ts` | `—` |
| [[ARCH-RULE-020]] | 🟡 | `src/app/payment-component/response-viewer.component.ts` | `—` |
| [[ARCH-RULE-021]] | ✅ | `src/app/payment-component/suspense-entries.component.ts` | `—` |
| [[ARCH-RULE-022]] | ✅ | `src/app/web-components/shared.ts` | `—` |
| [[ARCH-RULE-023]] | ✅ | `backend/server.js` | `—` |
| [[ARCH-RULE-024]] | ⚠️ | `analysis/Payment_component.yaml` | `—` |
| [[ARCH-RULE-025]] | ✅ | `analysis/Payment_component.yaml` | `—` |
| [[ARCH-RULE-026]] | ✅ | `converted/analysis__Payment-OAS-FSD-en.docx` | `—` |
| [[ARCH-RULE-027]] | ✅ | `converted/analysis__Payment-OAS-FSD-en.docx` | `—` |
| [[ARCH-RULE-028]] | ✅ | `converted/analysis__Payment-OAS-FSD-en.docx` | `—` |
| [[ARCH-RULE-029]] | ✅ | `converted/analysis__Payment-OAS-FSD-en.docx` | `—` |
| [[ARCH-RULE-030]] | ✅ | `converted/analysis__Payment_Mapping_Functions.docx` | `—` |
| [[ARCH-RULE-031]] | ✅ | `converted/analysis__Payment-OAS-FSD-en.docx` | `—` |
| [[ARCH-RULE-032]] | ✅ | `converted/analysis__Trade_Finance_Payment_Component_Architecture_v4-cn.docx` | `—` |
| [[ARCH-RULE-033]] | ✅ | `converted/analysis__Trade_Finance_Payment_Component_Architecture_v4-cn.docx` | `—` |
| [[ARCH-RULE-034]] | ✅ | `converted/analysis__Trade_Finance_Payment_Component_Architecture_v4-cn.docx` | `—` |
| [[ARCH-RULE-035]] | ✅ | `docs/payment-component-expert-review.md` | `—` |
| [[ARCH-RULE-036]] | ✅ | `docs/payment-component-expert-review.md` | `—` |
| [[ARCH-RULE-037]] | ✅ | `docs/payment-component-expert-review.md` | `—` |
| [[ARCH-RULE-038]] | ✅ | `docs/payment-component-expert-review.md` | `—` |
| [[ARCH-RULE-039]] | ✅ | `docs/payment-component-expert-review.md` | `—` |
| [[ARCH-RULE-040]] | ✅ | `converted/docs__LC-Payment-WC-User-Manual-en.docx` | `—` |
| [[ARCH-RULE-041]] | ✅ | `converted/docs__LC-Payment-WC-User-Manual-en.docx` | `—` |

## CONFLICT (1 rules, 0 with direct test evidence)

| Rule | Status | Implementation | Test |
|---|---|---|---|
| [[CLASS-RULE-001]] | ⚠️ | `analysis__PaymentComponent-Microservice-FSD-zh.docx` | `—` |

## Charges (12 rules, 1 with direct test evidence)

| Rule | Status | Implementation | Test |
|---|---|---|---|
| [[CHARGE-RULE-001]] | ✅ | `shared.ts` | `shared.spec.ts` |
| [[CHARGE-RULE-002]] | ✅ | `lc-issue.element.ts` | `—` |
| [[CHARGE-RULE-003]] | ✅ | `lc-issue.element.ts` | `—` |
| [[CHARGE-RULE-004]] | ✅ | `lc-collection.element.ts` | `—` |
| [[CHARGE-RULE-005]] | ✅ | `lc-confirmed.element.ts` | `—` |
| [[CHARGE-RULE-006]] | ✅ | `lc-nego.element.ts` | `—` |
| [[CHARGE-RULE-007]] | ✅ | `backend/server.js` | `—` |
| [[CHARGE-RULE-008]] | ✅ | `backend/server.js` | `—` |
| [[CHARGE-RULE-009]] | 🟡 | `backend/server.js` | `—` |
| [[CHARGE-RULE-010]] | ✅ | `backend/server.js` | `—` |
| [[CHARGE-RULE-011]] | ✅ | `backend/server.js` | `—` |
| [[CHARGE-RULE-012]] | ✅ | `analysis__Trade_Finance_Payment_Component_Architecture_v4-cn.docx` | `—` |

## Classification (27 rules, 12 with direct test evidence)

| Rule | Status | Implementation | Test |
|---|---|---|---|
| [[CLASS-RULE-002]] | ✅ | `microservices/payment-component/src/domain/classification.ts` | `microservices/payment-component/test/unit/domain/classification.test.ts` |
| [[CLASS-RULE-003]] | ✅ | `microservices/payment-component/src/domain/classification.ts` | `test/unit/domain/classification.test.ts` |
| [[CLASS-RULE-004]] | ✅ | `microservices/payment-component/src/domain/classification.ts` | `test/unit/domain/classification.test.ts` |
| [[CLASS-RULE-005]] | ✅ | `microservices/payment-component/src/domain/classification.ts` | `—` |
| [[CLASS-RULE-006]] | ✅ | `microservices/payment-component/src/domain/confirmPaymentInstruction.ts` | `test/unit/domain/confirmPaymentInstruction.test.ts` |
| [[CLASS-RULE-007]] | ✅ | `microservices/payment-component/src/domain/voucherDescription.ts` | `test/unit/domain/voucherDescription.test.ts` |
| [[CLASS-RULE-008]] | ✅ | `converted/analysis__PaymentComponent-Microservice-FSD-zh.docx` | `—` |
| [[CLASS-RULE-009]] | ✅ | `src/app/payment-component/business-case.model.ts` | `src/app/payment-component/business-case-registry.spec.ts` |
| [[CLASS-RULE-010]] | ✅ | `src/app/payment-component/business-case-registry.ts` | `src/app/payment-component/business-case-registry.spec.ts` |
| [[CLASS-RULE-011]] | ✅ | `src/app/payment-component/business-case-registry.ts` | `src/app/payment-component/business-case-registry.spec.ts` |
| [[CLASS-RULE-012]] | ✅ | `src/app/payment-component/business-case-registry.ts` | `src/app/payment-component/business-case-registry.spec.ts` |
| [[CLASS-RULE-013]] | ✅ | `src/app/payment-component/business-case-runner.component.ts` | `—` |
| [[CLASS-RULE-014]] | ✅ | `src/app/payment-component/business-case-runner.component.ts` | `—` |
| [[CLASS-RULE-015]] | ✅ | `src/app/payment-component/business-case-runner.component.ts` | `—` |
| [[CLASS-RULE-016]] | ✅ | `src/app/payment-component/business-case-runner.component.ts` | `—` |
| [[CLASS-RULE-017]] | ✅ | `src/app/payment-component/response-viewer.component.ts` | `response-viewer.component.spec.ts` |
| [[CLASS-RULE-018]] | ✅ | `src/app/payment-component/response-viewer.component.ts` | `response-viewer.component.spec.ts` |
| [[CLASS-RULE-019]] | ⚠️ | `src/app/payment-component/response-viewer.component.ts` | `response-viewer.component.spec.ts` |
| [[CLASS-RULE-020]] | ✅ | `src/app/web-components/journal-entry.element.ts` | `—` |
| [[CLASS-RULE-021]] | ✅ | `src/app/web-components/import/lc-sight-payment.element.ts` | `—` |
| [[CLASS-RULE-022]] | ✅ | `src/app/web-components/export/lc-advise.element.ts` | `—` |
| [[CLASS-RULE-023]] | ✅ | `src/app/web-components/import/lc-issue.element.ts` | `—` |
| [[CLASS-RULE-024]] | ✅ | `microservices/payment-component/src/types.ts` | `—` |
| [[CLASS-RULE-025]] | ⚠️ | `converted/analysis__Payment_Component_Calculation_Validation.docx` | `—` |
| [[CLASS-RULE-026]] | ✅ | `analysis/COMMON-PaymentComponent-Cross-Reference.md` | `—` |
| [[CLASS-RULE-027]] | ✅ | `PaymentComponentProposedUseCases-EN.docx` | `—` |
| [[CLASS-RULE-028]] | ✅ | `PaymentComponentProposedUseCases-EN.docx` | `—` |

## FX (45 rules, 10 with direct test evidence)

| Rule | Status | Implementation | Test |
|---|---|---|---|
| [[FX-RULE-001]] | ✅ | `microservices/payment-component/src/domain/suspenseBridge.ts` | `test/unit/domain/confirmPaymentInstruction.test.ts` |
| [[FX-RULE-002]] | ✅ | `microservices/payment-component/src/domain/suspenseBridge.ts` | `test/unit/domain/confirmPaymentInstruction.test.ts` |
| [[FX-RULE-003]] | ✅ | `suspenseBridge.ts` | `test/unit/domain/confirmPaymentInstruction.test.ts` |
| [[FX-RULE-004]] | ✅ | `money.ts` | `test/unit/money.test.ts` |
| [[FX-RULE-005]] | ✅ | `money.ts` | `test/unit/money.test.ts` |
| [[FX-RULE-006]] | ✅ | `money.ts` | `test/unit/money.test.ts` |
| [[FX-RULE-007]] | ✅ | `suspenseBridge.ts` | `—` |
| [[FX-RULE-008]] | ✅ | `suspenseBridge.ts` | `—` |
| [[FX-RULE-009]] | ✅ | `suspenseBridge.ts` | `—` |
| [[FX-RULE-010]] | ✅ | `suspenseBridge.ts` | `—` |
| [[FX-RULE-011]] | ✅ | `suspenseBridge.ts` | `—` |
| [[FX-RULE-012]] | ✅ | `suspenseBridge.ts` | `—` |
| [[FX-RULE-013]] | ✅ | `swiftMessages.ts` | `—` |
| [[FX-RULE-014]] | ✅ | `requestSchema.ts` | `test/unit/validation/requestSchema.test.ts` |
| [[FX-RULE-015]] | ✅ | `requestSchema.ts` | `test/unit/validation/requestSchema.test.ts` |
| [[FX-RULE-016]] | ✅ | `suspenseBridge.ts` | `test/curl-tests/requests/case1-suspense-fx-and-nostro-usd.js` |
| [[FX-RULE-017]] | ✅ | `suspenseBridge.ts` | `—` |
| [[FX-RULE-018]] | ✅ | `suspenseBridge.ts` | `test/curl-tests/requests/case1-suspense-fx-and-nostro-usd.js` |
| [[FX-RULE-019]] | ✅ | `business-case-request.ts` | `—` |
| [[FX-RULE-020]] | ✅ | `business-case-runner.component.ts` | `—` |
| [[FX-RULE-021]] | ✅ | `leg-allocator.component.ts` | `—` |
| [[FX-RULE-022]] | ✅ | `leg-allocator.component.ts` | `—` |
| [[FX-RULE-023]] | ✅ | `leg-allocator.component.ts` | `—` |
| [[FX-RULE-024]] | ✅ | `leg-allocator.component.ts` | `—` |
| [[FX-RULE-025]] | ✅ | `leg-allocator.component.ts` | `—` |
| [[FX-RULE-026]] | ✅ | `leg-allocator.component.ts` | `—` |
| [[FX-RULE-027]] | ✅ | `currency.service.ts` | `—` |
| [[FX-RULE-028]] | ✅ | `fx-rate.service.ts` | `—` |
| [[FX-RULE-029]] | ✅ | `fx-rate.service.ts` | `—` |
| [[FX-RULE-030]] | ✅ | `payment-component.types.ts` | `—` |
| [[FX-RULE-031]] | ✅ | `payment-component.types.ts` | `—` |
| [[FX-RULE-032]] | ✅ | `payment-instructions-post.yaml` | `—` |
| [[FX-RULE-033]] | 🟡 | `analysis__Payment-OAS-FSD-en.docx` | `—` |
| [[FX-RULE-034]] | ✅ | `analysis__Trade_Finance_Payment_Component_Architecture_v4-cn.docx` | `—` |
| [[FX-RULE-035]] | ✅ | `analysis__Payment_Component_Calculation_Validation.docx` | `—` |
| [[FX-RULE-036]] | ✅ | `analysis__Payment_Component_Calculation_Validation.docx` | `—` |
| [[FX-RULE-037]] | ✅ | `payment-component-expert-review.md` | `—` |
| [[FX-RULE-038]] | ✅ | `payment-component-expert-review.md` | `—` |
| [[FX-RULE-039]] | ✅ | `payment-component-expert-review.md` | `—` |
| [[FX-RULE-040]] | ✅ | `payment-component-expert-review.md` | `—` |
| [[FX-RULE-041]] | ✅ | `PaymentComponentProposedUseCases-EN.docx` | `—` |
| [[FX-RULE-042]] | ✅ | `docs__LC-Payment-WC-User-Manual-en.docx` | `—` |
| [[FX-RULE-043]] | ✅ | `CLAUDE.md` | `—` |
| [[FX-RULE-044]] | ✅ | `CLAUDE.md` | `—` |
| [[FX-RULE-045]] | ✅ | `Payment-Component-Suspense-FX-Test-Cases-zh.md` | `—` |

## Other (3 rules, 0 with direct test evidence)

| Rule | Status | Implementation | Test |
|---|---|---|---|
| [[ARCH-RULE-042]] | ✅ | `analysis/Payment_Component_Calculation_Validation.docx` | `—` |
| [[ARCH-RULE-043]] | ✅ | `CLAUDE.md` | `—` |
| [[ARCH-RULE-044]] | ✅ | `README.md` | `—` |

## SWIFT (15 rules, 6 with direct test evidence)

| Rule | Status | Implementation | Test |
|---|---|---|---|
| [[SWIFT-RULE-001]] | ✅ | `src/domain/confirmPaymentInstruction.ts` | `test/unit/domain/confirmPaymentInstruction.test.ts` |
| [[SWIFT-RULE-002]] | ✅ | `src/domain/swiftMessages.ts` | `test/unit/domain/swiftMessages.test.ts` |
| [[SWIFT-RULE-003]] | ✅ | `src/domain/swiftMessages.ts` | `test/unit/domain/swiftMessages.test.ts` |
| [[SWIFT-RULE-004]] | ✅ | `src/domain/swiftMessages.ts` | `—` |
| [[SWIFT-RULE-005]] | ✅ | `src/domain/swiftMessages.ts` | `test/unit/domain/swiftMessages.test.ts` |
| [[SWIFT-RULE-006]] | ✅ | `src/domain/swiftMessages.ts` | `test/unit/domain/swiftMessages.test.ts` |
| [[SWIFT-RULE-007]] | ✅ | `src/app/payment-component/payment-component.types.ts` | `—` |
| [[SWIFT-RULE-008]] | ✅ | `analysis/Payment_component.yaml` | `—` |
| [[SWIFT-RULE-009]] | ✅ | `analysis__Payment-OAS-FSD-en.docx` | `—` |
| [[SWIFT-RULE-010]] | ✅ | `src/domain/swiftMessages.ts` | `—` |
| [[SWIFT-RULE-011]] | ✅ | `src/domain/swiftMessages.ts` | `test/unit/domain/swiftMessages.test.ts` |
| [[SWIFT-RULE-012]] | ✅ | `analysis__Payment_Component_Calculation_Validation.docx` | `—` |
| [[SWIFT-RULE-013]] | ✅ | `src/domain/confirmPaymentInstruction.ts` | `—` |
| [[SWIFT-RULE-014]] | ✅ | `CLAUDE.md` | `—` |
| [[SWIFT-RULE-015]] | ✅ | `CLAUDE.md` | `—` |

## Suspense (21 rules, 15 with direct test evidence)

| Rule | Status | Implementation | Test |
|---|---|---|---|
| [[SUSPENSE-RULE-001]] | ✅ | `src/domain/confirmPaymentInstruction.ts` | `test/unit/domain/confirmPaymentInstruction.test.ts` |
| [[SUSPENSE-RULE-002]] | ✅ | `src/domain/confirmPaymentInstruction.ts` | `test/unit/domain/confirmPaymentInstruction.test.ts` |
| [[SUSPENSE-RULE-003]] | ✅ | `suspenseBridge.ts` | `suspenseBridge.test.ts` |
| [[SUSPENSE-RULE-004]] | ✅ | `src/types.ts` | `suspenseBridge.test.ts` |
| [[SUSPENSE-RULE-005]] | ✅ | `suspenseBridge.ts` | `suspenseBridge.test.ts` |
| [[SUSPENSE-RULE-006]] | ✅ | `suspenseBridge.ts` | `suspenseBridge.test.ts` |
| [[SUSPENSE-RULE-007]] | ✅ | `business-case-request.ts` | `business-case-request.spec.ts` |
| [[SUSPENSE-RULE-008]] | ✅ | `business-case-runner.component.ts` | `business-case-runner.component.spec.ts` |
| [[SUSPENSE-RULE-009]] | ✅ | `business-case-runner.component.ts` | `business-case-runner.component.spec.ts` |
| [[SUSPENSE-RULE-010]] | ✅ | `business-case-runner.component.ts` | `business-case-runner.component.spec.ts` |
| [[SUSPENSE-RULE-011]] | ✅ | `business-case-runner.component.ts` | `business-case-runner.component.spec.ts` |
| [[SUSPENSE-RULE-012]] | ✅ | `business-case-runner.component.ts` | `business-case-runner.component.spec.ts` |
| [[SUSPENSE-RULE-013]] | ✅ | `business-case-runner.component.ts` | `business-case-runner.component.spec.ts` |
| [[SUSPENSE-RULE-014]] | ✅ | `business-case-runner.component.ts` | `business-case-runner.component.spec.ts` |
| [[SUSPENSE-RULE-015]] | ✅ | `payment-component.types.ts` | `—` |
| [[SUSPENSE-RULE-016]] | ✅ | `suspense-entries.component.ts` | `—` |
| [[SUSPENSE-RULE-017]] | ✅ | `analysis__Payment-OAS-FSD-en.docx` | `—` |
| [[SUSPENSE-RULE-018]] | ⚠️ | `analysis__Payment-OAS-FSD-en.docx` | `test/unit/domain/confirmPaymentInstruction.test.ts` |
| [[SUSPENSE-RULE-019]] | ✅ | `analysis__Trade_Finance_Payment_Component_Architecture_v4-cn.docx` | `—` |
| [[SUSPENSE-RULE-020]] | ✅ | `analysis__Trade_Finance_Payment_Component_Architecture_v4-cn.docx` | `—` |
| [[SUSPENSE-RULE-021]] | ✅ | `microservices/payment-component/README.md` | `—` |

## TestScenario (5 rules, 2 with direct test evidence)

| Rule | Status | Implementation | Test |
|---|---|---|---|
| [[TEST-RULE-001]] | 🟡 | `src/app/payment-component/business-case-registry.ts` | `microservices/payment-component/test/regression.ts` |
| [[TEST-RULE-002]] | ✅ | `README.md` | `src/app/web-components/shared.spec.ts` |
| [[TEST-RULE-003]] | ✅ | `README.md` | `—` |
| [[TEST-RULE-004]] | ✅ | `src/app/payment-component/business-case-registry.ts` | `—` |
| [[TEST-RULE-005]] | ✅ | `src/app/payment-component/business-case-runner.component.ts` | `—` |

## UI (24 rules, 2 with direct test evidence)

| Rule | Status | Implementation | Test |
|---|---|---|---|
| [[UI-RULE-001]] | ✅ | `business-case-fields.ts` | `business-case-fields.spec.ts` |
| [[UI-RULE-002]] | ✅ | `business-case-fields.ts` | `business-case-fields.spec.ts` |
| [[UI-RULE-003]] | ✅ | `business-case-runner.component.ts` | `—` |
| [[UI-RULE-004]] | ✅ | `business-case-runner.component.ts` | `—` |
| [[UI-RULE-005]] | ✅ | `leg-allocator.component.ts` | `—` |
| [[UI-RULE-006]] | ✅ | `applyAmountWaterfall() lines 806-920 (doc comment + body) — ` | `—` |
| [[UI-RULE-007]] | ✅ | `applyPctWaterfall doc comment lines 672-679 (structural-inva` | `—` |
| [[UI-RULE-008]] | ✅ | `pruneZeroRow() lines 946-954 — length<=1 guard, checks row.p` | `—` |
| [[UI-RULE-009]] | ✅ | `onAccountTypeChange() lines 1106-1111` | `—` |
| [[UI-RULE-010]] | ✅ | `ensureRemainderRow() doc comment lines 1160-1173, explaining` | `—` |
| [[UI-RULE-011]] | ✅ | `emit() doc comment lines 1238-1250 and sort logic lines 1284` | `—` |
| [[UI-RULE-012]] | ✅ | `leg-allocator.component.html` | `—` |
| [[UI-RULE-013]] | ✅ | `response-viewer.component.ts` | `—` |
| [[UI-RULE-014]] | ✅ | `response-viewer.component.ts` | `—` |
| [[UI-RULE-015]] | ✅ | `response-viewer.component.ts` | `—` |
| [[UI-RULE-016]] | ✅ | `response-viewer.component.ts` | `—` |
| [[UI-RULE-017]] | ✅ | `response-viewer.component.ts` | `—` |
| [[UI-RULE-018]] | ✅ | `response-viewer.component.ts` | `—` |
| [[UI-RULE-019]] | ✅ | `suspense-entries.component.ts` | `—` |
| [[UI-RULE-020]] | ✅ | `suspense-entries.component.ts` | `—` |
| [[UI-RULE-021]] | ✅ | `lc-issue.element.ts` | `—` |
| [[UI-RULE-022]] | ✅ | `business-case-runner.component.ts` | `—` |
| [[UI-RULE-023]] | ✅ | `leg-allocator.component.ts` | `—` |
| [[UI-RULE-024]] | ✅ | `suspense-entries.component.ts` | `—` |

## Validation (43 rules, 26 with direct test evidence)

| Rule | Status | Implementation | Test |
|---|---|---|---|
| [[VALIDATION-RULE-001]] | ✅ | `microservices/payment-component/src/domain/confirmPaymentInstruction.ts` | `test/unit/domain/confirmPaymentInstruction.test.ts` |
| [[VALIDATION-RULE-002]] | ✅ | `microservices/payment-component/src/domain/confirmPaymentInstruction.ts` | `test/unit/domain/confirmPaymentInstruction.test.ts` |
| [[VALIDATION-RULE-003]] | ✅ | `microservices/payment-component/src/domain/confirmPaymentInstruction.ts` | `test/unit/domain/confirmPaymentInstruction.test.ts` |
| [[VALIDATION-RULE-004]] | ✅ | `microservices/payment-component/src/domain/suspenseBridge.ts` | `test/unit/domain/suspenseBridge.test.ts` |
| [[VALIDATION-RULE-005]] | ✅ | `microservices/payment-component/src/domain/classifyPreview.ts` | `test/unit/domain/classifyPreview.test.ts` |
| [[VALIDATION-RULE-006]] | ✅ | `microservices/payment-component/src/domain/classifyPreview.ts` | `test/unit/domain/classifyPreview.test.ts` |
| [[VALIDATION-RULE-007]] | ✅ | `microservices/payment-component/src/domain/balanceValidation.ts` | `test/unit/domain/balanceValidation.test.ts` |
| [[VALIDATION-RULE-008]] | ✅ | `microservices/payment-component/src/domain/balanceValidation.ts` | `test/unit/domain/balanceValidation.test.ts` |
| [[VALIDATION-RULE-009]] | ✅ | `microservices/payment-component/src/money.ts` | `microservices/payment-component/test/unit/money.test.ts` |
| [[VALIDATION-RULE-010]] | ✅ | `microservices/payment-component/src/money.ts` | `test/unit/money.test.ts` |
| [[VALIDATION-RULE-011]] | ✅ | `microservices/payment-component/src/domain/suspenseBridge.ts` | `test/unit/domain/suspenseBridge.test.ts` |
| [[VALIDATION-RULE-012]] | ✅ | `microservices/payment-component/src/domain/swiftMessages.ts` | `test/unit/domain/swiftMessages.test.ts` |
| [[VALIDATION-RULE-013]] | ✅ | `microservices/payment-component/src/errors.ts` | `—` |
| [[VALIDATION-RULE-014]] | ✅ | `microservices/payment-component/src/validation/requestSchema.ts` | `—` |
| [[VALIDATION-RULE-015]] | ✅ | `microservices/payment-component/src/validation/requestSchema.ts` | `test/unit/validation/requestSchema.test.ts` |
| [[VALIDATION-RULE-016]] | ✅ | `microservices/payment-component/src/validation/requestSchema.ts` | `test/unit/validation/requestSchema.test.ts` |
| [[VALIDATION-RULE-017]] | ✅ | `src/app/payment-component/business-case-fields.ts` | `business-case-fields.spec.ts` |
| [[VALIDATION-RULE-018]] | ✅ | `src/app/payment-component/business-case-request.ts` | `business-case-registry.spec.ts` |
| [[VALIDATION-RULE-019]] | ✅ | `src/app/payment-component/business-case-request.ts` | `business-case-request.spec.ts` |
| [[VALIDATION-RULE-020]] | ✅ | `src/app/payment-component/business-case-runner.component.ts` | `business-case-runner.component.spec.ts` |
| [[VALIDATION-RULE-021]] | ✅ | `src/app/payment-component/business-case-runner.component.ts` | `business-case-runner.component.spec.ts` |
| [[VALIDATION-RULE-022]] | ✅ | `src/app/payment-component/leg-allocator.component.ts` | `leg-allocator.component.spec.ts` |
| [[VALIDATION-RULE-023]] | ✅ | `src/app/payment-component/leg-allocator.component.ts` | `leg-allocator.component.spec.ts` |
| [[VALIDATION-RULE-024]] | ✅ | `src/app/payment-component/leg-allocator.component.ts` | `leg-allocator.component.spec.ts` |
| [[VALIDATION-RULE-025]] | ✅ | `src/app/payment-component/leg-allocator.component.ts` | `leg-allocator.component.spec.ts` |
| [[VALIDATION-RULE-026]] | ✅ | `src/app/payment-component/payment-component-api.service.ts` | `payment-component-api.service.spec.ts` |
| [[VALIDATION-RULE-027]] | ✅ | `src/app/payment-component/payment-component-api.service.ts` | `—` |
| [[VALIDATION-RULE-028]] | ✅ | `microservices/payment-component/src/validation/requestSchema.ts` | `—` |
| [[VALIDATION-RULE-029]] | ✅ | `src/app/payment-component/suspense-entries.component.ts` | `suspense-entries.component.spec.ts` |
| [[VALIDATION-RULE-030]] | ✅ | `src/app/web-components/shared.ts` | `—` |
| [[VALIDATION-RULE-031]] | ✅ | `backend/server.js` | `—` |
| [[VALIDATION-RULE-032]] | ✅ | `backend/server.js` | `—` |
| [[VALIDATION-RULE-033]] | ✅ | `backend/server.js` | `backend/test/export-settlement.test.js` |
| [[VALIDATION-RULE-034]] | ⚠️ | `analysis/Payment_component.yaml` | `—` |
| [[VALIDATION-RULE-035]] | ✅ | `analysis/Payment_component.yaml` | `—` |
| [[VALIDATION-RULE-036]] | ✅ | `analysis__Payment_Component_Calculation_Validation.docx` | `—` |
| [[VALIDATION-RULE-037]] | ✅ | `analysis__Payment_Component_Calculation_Validation.docx` | `—` |
| [[VALIDATION-RULE-038]] | ✅ | `microservices/payment-component/src/validation/requestSchema.ts` | `—` |
| [[VALIDATION-RULE-039]] | ⚠️ | `docs/payment-component-expert-review.md` | `—` |
| [[VALIDATION-RULE-040]] | ✅ | `microservices/payment-component/src/validation/requestSchema.ts` | `—` |
| [[VALIDATION-RULE-041]] | ✅ | `microservices/payment-component/src/validation/requestSchema.ts` | `—` |
| [[VALIDATION-RULE-042]] | ✅ | `microservices/payment-component/src/domain/confirmPaymentInstruction.ts` | `—` |
| [[VALIDATION-RULE-043]] | ✅ | `Payment-Component-Suspense-FX-Test-Cases-zh.md` | `—` |

