---
knowledge_id: API-RULE-004
title: "POST /payment-instructions/classify is an unofficial, non-OAS preview endpoint requiring BOTH debitLegs and creditLegs to be non-empty (stricter than the confirm endpoint)"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - api
  - confirmed
---

# API-RULE-004 — POST /payment-instructions/classify is an unofficial, non-OAS preview endpoint requiring BOTH debitLegs and creditLegs to be non-empty (stricter than the confirm endpoint)

## Status
CONFIRMED

## Business Rule
Unlike POST /payment-instructions (which can accept an empty creditLegs when a suspenseBridge compensates), classifyRequestSchema requires both debitLegs and creditLegs to each have >=1 item unconditionally, with no suspenseBridge-aware relaxation, and accepts only debitLegs, creditLegs, and optional balanceTolerance (no originModule/mainRef/sequence/unitCode). It exists specifically for RPFM's GAP-verdict business cases which have no voucher-assembly routine, and never creates/persists a PaymentInstruction.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
No worked numeric example available in the source evidence reviewed.

## Verification Note
Re-read requestSchema.ts's classifyRequestSchema directly, confirmed both legs have unconditional min(1) and only 3 fields (debitLegs, creditLegs, balanceTolerance) exist in the schema. No change to status.

## Source Evidence
- microservices/payment-component/src/routes/paymentInstructions.ts: router.post('/payment-instructions/classify', ...) doc comment (lines 57-59)
- microservices/payment-component/src/validation/requestSchema.ts: classifyRequestSchema (lines 214-218, both `.min(1)`, doc comment 206-213)
- microservices/payment-component/test/unit/routes/paymentInstructions.test.ts describe 'POST /payment-instructions/classify'
- microservices/payment-component/test/unit/validation/requestSchema.test.ts describe 'validateClassifyRequest'

## Related Knowledge
- [[Payment Instructions API]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
