---
knowledge_id: CLASS-RULE-022
title: "Export LC components model a 5-stage event set: Advise (B1) → optional Confirm (B2) → Negotiation (B3) → Settlement, either via EBL-clearing/Direct (B4) or On-Collection with no EBL (B5)"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - classification
  - confirmed
---

# CLASS-RULE-022 — Export LC components model a 5-stage event set: Advise (B1) → optional Confirm (B2) → Negotiation (B3) → Settlement, either via EBL-clearing/Direct (B4) or On-Collection with no EBL (B5)

## Status
CONFIRMED

## Business Rule
The five export-side components carry explicit stage labels (B1–B5): B1 (lc-advise.element.ts) advises the LC to the beneficiary for a flat TWD fee; B2 (lc-confirmed.element.ts) is an optional add-on where the advising bank also confirms for a quarterly risk-based commission; B3 (lc-nego.element.ts) negotiates/pays the beneficiary's bill; B4 (lc-settlement.element.ts, export) settles either by clearing a previously-booked EBL advance or by paying 'Direct to CA' with its own settlement commission; B5 (lc-collection.element.ts) is a distinct 'Settlement without EBL (On Collection)' product.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
No worked numeric example available in the source evidence reviewed.

## Verification Note
Grepped all five files for their stage-label comments — all found verbatim as cited, including the B4 direct-settlement branch and B5's charge structure.

## Source Evidence
- src/app/web-components/export/lc-advise.element.ts line 67 ('B1 — Export LC Advise')
- src/app/web-components/export/lc-confirmed.element.ts line 71 ('B2 — Export LC Confirmed')
- src/app/web-components/export/lc-nego.element.ts line 72 ('B3 — Export LC Negotiation Payment')
- src/app/web-components/export/lc-settlement.element.ts line 93 ('B4 — Export LC Settlement') and lines 61-69 (settlementType==='direct' branch)
- src/app/web-components/export/lc-collection.element.ts line 7, line 82 ('B5 — Export LC On Collection (Settlement without EBL)')

## Related Knowledge
- [[Payment Instruction Classification]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
