---
knowledge_id: POSTING-RULE-014
title: "The voucher code prefix is keyed by (originModule, sourceFunctionCode) pair, not by originModule alone"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - accounting
  - confirmed
---

# POSTING-RULE-014 — The voucher code prefix is keyed by (originModule, sourceFunctionCode) pair, not by originModule alone

## Status
CONFIRMED

## Business Rule
VOUCHER_CODE_PREFIXES is keyed 'Module:FunctionCode' — two different prefixes exist for the same originModule 'IPLC' depending on which business function triggered the confirm. resolveVoucherCodePrefix throws RequestValidationError for any (module,function) combination not in the 13-entry table.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
resolveVoucherCodePrefix('IPLC','PayAccept') → 'IPLC03NULLNULLNULL'; resolveVoucherCodePrefix('IPLC','PaymentAtMaturity') → 'IPLC06NULLNULLNULL'

## Verification Note
Confirmed directly — table has exactly 13 entries including two IPLC keys with different prefix values, matching the claim.

## Source Evidence
- src/domain/voucherDescription.ts VOUCHER_CODE_PREFIXES table (13 entries) and resolveVoucherCodePrefix, read in full

## Related Knowledge
- [[Accounting Model]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
