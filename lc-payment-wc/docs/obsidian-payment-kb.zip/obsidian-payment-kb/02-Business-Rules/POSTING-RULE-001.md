---
knowledge_id: POSTING-RULE-001
title: "M-7: exact Dr=Cr balance (zero tolerance) required for EVERY originModule including RPFM — legacy ±0.01 RPFM slack removed"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - accounting
  - confirmed
---

# POSTING-RULE-001 — M-7: exact Dr=Cr balance (zero tolerance) required for EVERY originModule including RPFM — legacy ±0.01 RPFM slack removed

## Status
CONFIRMED

## Business Rule
The default balanceTolerance for the V8 Dr/Cr check is 0 for all originModules including RPFM. The legacy ±0.01 RPFM slack was determined to have been a screen-level percentage-split slack, not a valid GL posting rule, and is no longer auto-applied. An explicit balanceTolerance can still be passed per call as a deliberate escape hatch.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
RPFM debit NOSTRO CNY 100 vs credit CUSTOMER CNY 99.99 -> BusinessValidationError (409); same legs at CNY 100/100 -> confirms normally.

## Verification Note
Re-read confirmPaymentInstruction.ts directly (lines 1-200). The doc comment and the `const tolerance = options.balanceTolerance ?? 0;` line exactly match the claim. Confirmed as-is.

## Source Evidence
- src/domain/confirmPaymentInstruction.ts lines 76-84 (balanceTolerance doc comment) and line 174 (tolerance = options.balanceTolerance ?? 0), read in full
- test/unit/domain/confirmPaymentInstruction.test.ts 'balance tolerance' describe block (cited)

## Related Knowledge
- [[Accounting Model]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
