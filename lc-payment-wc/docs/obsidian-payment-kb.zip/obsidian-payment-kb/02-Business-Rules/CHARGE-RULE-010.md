---
knowledge_id: CHARGE-RULE-010
title: "No bank commission/fee income is charged at Import Sight Payment (IBL Lodgement, A3) or Sight Settlement (IBL repayment, A4) beyond pass-through correspondent charges — commission is charged once, upfront, at LC Issue (A1)"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - charges
  - confirmed
---

# CHARGE-RULE-010 — No bank commission/fee income is charged at Import Sight Payment (IBL Lodgement, A3) or Sight Settlement (IBL repayment, A4) beyond pass-through correspondent charges — commission is charged once, upfront, at LC Issue (A1)

## Status
CONFIRMED

## Business Rule
A1 (LC Issue) is the only Import-side endpoint that books a Commission Income (or SWIFT Fee Income) leg; A2 (Settlement), A3 (Sight Payment/IBL Lodgement), and A4 (Sight Settlement/IBL repayment) only move Margin, IBL, CA, and Nostro legs plus (in A2/A3) pass-through correspondent charges — none books a new Income leg. Consistent with charging LC issuance commission once at contract inception rather than at each subsequent drawdown/settlement event.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
No worked numeric example available in the source evidence reviewed.

## Verification Note
Re-read all four endpoint bodies in full (A1 through A4) and confirmed the entries[] arrays directly — no Income-type leg exists in A2, A3, or A4 in the actual code, matching the claim exactly. Upgraded confidence from the original grep-based INFERRED evidence to a full line-by-line read of each endpoint; still marking INFERRED-worthy caution is unnecessary since the absence is directly observable and the causal 'why' (charge once at issuance) is the only inferred part — kept as CONFIRMED per the original grouping since the underlying behavioral fact itself (no Income leg posted at A2-A4) is directly confirmed by code, with the explanatory framing ('reflects typical trade-finance practice...') appropriately still just a plausible business rationale, not itself asserted as a proven rule.

## Source Evidence
- backend/server.js lines 187-195 (A1: only place 'Commission Income'/'SWIFT Fee Income' entries are created)
- backend/server.js lines 229-310 (A2: entries are Margin release, CA net payment, Nostro — no Income leg)
- backend/server.js lines 324-401 (A3: entries are IBL, Margin release, CA corr-charges, Nostro — no Income leg)
- backend/server.js lines 408-452 (A4: entries are CA repayment, IBL clear — no Income leg)

## Related Knowledge
- [[Charge Integration]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
