---
knowledge_id: POSTING-RULE-010
title: "Settlement entry amount is parsed/re-formatted with NO scale override — preserves the input leg string's own precision rather than forcing a fixed 2dp"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - accounting
  - confirmed
---

# POSTING-RULE-010 — Settlement entry amount is parsed/re-formatted with NO scale override — preserves the input leg string's own precision rather than forcing a fixed 2dp

## Status
CONFIRMED

## Business Rule
makeEntry() calls formatMonetaryAmount(amount) with the scale parameter omitted, so a SETTLEMENT AccountEntry amount is not re-rounded to any fixed decimal count.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
No worked numeric example available in the source evidence reviewed.

## Verification Note
Confirmed directly — line 47 has no second argument to formatMonetaryAmount.

## Source Evidence
- src/domain/accountEntries.ts line 47: `amount: formatMonetaryAmount(amount)` (no scale arg)
- src/money.ts lines 53-54 doc comment

## Related Knowledge
- [[Accounting Model]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
