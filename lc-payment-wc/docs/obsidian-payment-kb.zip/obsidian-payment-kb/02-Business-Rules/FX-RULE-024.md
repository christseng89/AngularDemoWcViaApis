---
knowledge_id: FX-RULE-024
title: "A directly-typed Account Ccy Equiv. figure is stored raw and preferred over re-derivation, to avoid a precision-loss round-trip bug"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - fx
  - confirmed
---

# FX-RULE-024 — A directly-typed Account Ccy Equiv. figure is stored raw and preferred over re-derivation, to avoid a precision-loss round-trip bug

## Status
CONFIRMED

## Business Rule
amountTxCcy is always rounded to the TRANSACTION currency's own scale, so re-deriving the account-currency figure as amountTxCcy × rate for display/wire can lose precision when the row's own currency has coarser minor units. Row.accountCcyOverride stores the exact typed figure and is preferred by accountCcyAmountDecimal() (used by both the display getter and emit()'s wire amountAccountCcy) whenever still valid.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
Row currency JPY, rate 149.0825. Typing Account Ccy Equiv. 20000 gives amountTxCcy=134.15 (rounded) but accountCcyAmount() and the wire's amountAccountCcy both read back exactly 20000, not the lossy re-derivation 19999.

## Verification Note
Directly read and confirmed accountCcyAmountDecimal()'s exact implementation — override preferred, falls back to amountTxCcy×rate re-derivation otherwise, exactly as claimed. No status change.

## Source Evidence
- leg-allocator.component.ts Row.accountCcyOverride doc comment lines 57-80
- accountCcyAmountDecimal() lines 418-421 (read in full: `if (row.accountCcyOverride !== null) return money(row.accountCcyOverride, ...); return money(row.amountTxCcy.times(row.rate), ...)`)

## Related Knowledge
- [[FX Processing]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
