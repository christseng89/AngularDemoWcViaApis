---
knowledge_id: POSTING-RULE-029
title: "Journal Entry viewer enforces Debit=Credit balance in TWD (functional currency), with a sub-1-TWD rounding tolerance"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - accounting
  - confirmed
---

# POSTING-RULE-029 — Journal Entry viewer enforces Debit=Credit balance in TWD (functional currency), with a sub-1-TWD rounding tolerance

## Status
CONFIRMED

## Business Rule
journal-entry.element.ts sums entries.amountTwd separately for leg='Dr' and leg='Cr' and displays a BALANCED/UNBALANCED badge based on Math.abs(totalDr-totalCr) < 1. TWD is treated as the bank's base/functional currency for balancing purposes.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
totalDr = totalCr within < TWD 1 → 'BALANCED' badge (green); otherwise 'UNBALANCED' (red).

## Verification Note
Directly confirmed by reading the exact source lines this pass.

## Source Evidence
- src/app/web-components/journal-entry.element.ts lines 68-70, read directly: `const totalDr = entries.filter(e => e.leg === 'Dr').reduce(...); const totalCr = ...; const balanced = Math.abs(totalDr - totalCr) < 1;`

## Related Knowledge
- [[Accounting Model]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
