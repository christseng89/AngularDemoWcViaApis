---
knowledge_id: SUSPENSE-RULE-002
title: "creditLegs may be submitted empty when suspenseBridge itself supplies a credit-direction leg (v1.10.0/v1.10.1 fee-collection pattern) — gated purely on suspenseBridge content, NOT any request flag"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - suspense
  - confirmed
---

# SUSPENSE-RULE-002 — creditLegs may be submitted empty when suspenseBridge itself supplies a credit-direction leg (v1.10.0/v1.10.1 fee-collection pattern) — gated purely on suspenseBridge content, NOT any request flag

## Status
CONFIRMED

## Business Rule
A pure fee-collection Confirm (Dr Customer A/C, Cr Suspense - Credit) can be submitted with creditLegs:[] as long as suspenseBridge.creditEntries (or debitEntries) is non-empty, since the bridge expansion always contributes at least one credit-direction leg. debitLegs retains its unconditional requirement of at least one leg. This gating is implemented purely by checking suspenseBridge content in requestSchema.ts's superRefine — there is NO 'chargeComponentBridge' boolean flag anywhere in the server source.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
debitLegs=[{CUST-ACC,USD,25}], creditLegs=[], suspenseBridge.creditEntries=[{25,USD,CHARGE}] -> created:true, instruction.creditLegs=[{Suspense - Credit, USD, 25}]

## Verification Note
Confirmed both the confirmPaymentInstruction.ts leg assembly and the actual requestSchema.ts gating logic. Strengthened the statement to explicitly note there is no flag — this directly CONFLICTS with FSD rule #20 below ('charge-component-bridge-no-credit-leg'), which documents a chargeComponentBridge boolean extension flag as the gating mechanism. See rule #20's verification_note and gaps_found for the conflict.

## Source Evidence
- src/domain/confirmPaymentInstruction.ts lines 166-167 (creditLegsInput assembly) — confirmed
- src/validation/requestSchema.ts lines 100-122 (creditLegs schema, superRefine checking bridgeContributesCreditLeg, error path ['creditLegs']) — read directly, confirmed; also line 216 shows the unconditional min(1) fallback schema used elsewhere
- test/unit/domain/confirmPaymentInstruction.test.ts line 248 'v1.10.0: pure fee collection (Dr Customer A/C / Cr Suspense - Credit) confirms with an EMPTY creditLegs' — test present
- grep of src/ confirms NO 'chargeComponentBridge' string exists anywhere in the microservice source — only in the FSD docx and an expert-review markdown

## Related Knowledge
- [[Suspense Account]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
