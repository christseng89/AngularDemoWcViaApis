---
knowledge_id: FX-RULE-012
title: "When sizing the transaction-currency side of a real-leg FX pair, the module always sums each matching leg's own already-submitted amountTxCcy verbatim — never re-derives it from a rate"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - fx
  - confirmed
---

# FX-RULE-012 — When sizing the transaction-currency side of a real-leg FX pair, the module always sums each matching leg's own already-submitted amountTxCcy verbatim — never re-derives it from a rate

## Status
CONFIRMED

## Business Rule
sumLegsTrxCcy sums amountTxCcy directly (no fallback, no rate multiplication) for legs matching the bucket's currency.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
No worked numeric example available in the source evidence reviewed.

## Verification Note
Confirmed. No status change.

## Source Evidence
- suspenseBridge.ts lines 227-231 (sumLegsTrxCcy)

## Related Knowledge
- [[FX Processing]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
