---
knowledge_id: ARCH-RULE-011
title: "Any non-ApiError thrown deep in the stack is masked as a generic 500, never leaked to the client"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - architecture
  - confirmed
---

# ARCH-RULE-011 — Any non-ApiError thrown deep in the stack is masked as a generic 500, never leaked to the client

## Status
CONFIRMED

## Business Rule
The central error handler in app.ts treats anything that is not an instance of ApiError (e.g. an unexpected store/database failure) as an unhandled internal error: it logs the real error via console.error but returns a generic HTTP 500 body {code:'INTERNAL_ERROR', message:'Unexpected server error'} to the caller, never the underlying exception's message or stack. This is a deliberate security/robustness boundary.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
No worked numeric example available in the source evidence reviewed.

## Verification Note
Confirmed by reading the entire app.ts file directly. Statement matches exactly.

## Source Evidence
- microservices/payment-component/src/app.ts, full file read (31 lines): the error-handling middleware at the bottom does exactly `if (err instanceof ApiError) { res.status(err.httpStatus).json(err.toBody()); return; } console.error(...); res.status(500).json({code:'INTERNAL_ERROR', message:'Unexpected server error'});`

## Related Knowledge
- [[Payment Architecture]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
