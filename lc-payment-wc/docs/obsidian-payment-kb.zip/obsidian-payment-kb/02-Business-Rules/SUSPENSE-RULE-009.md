---
knowledge_id: SUSPENSE-RULE-009
title: "Credit Leg #1 seed = case Total Amount minus Sigma(Suspense Credit entries, each independently FX-converted/rounded)"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - suspense
  - confirmed
---

# SUSPENSE-RULE-009 — Credit Leg #1 seed = case Total Amount minus Sigma(Suspense Credit entries, each independently FX-converted/rounded)

## Status
CONFIRMED

## Business Rule
Mirror of the Debit rule: suspenseAdjustment('CREDIT', ...) = total.minus(bucket.trxEquivalent), subtracting each Suspense Credit entry's trx-currency equivalent from the case's Total Amount. Business meaning: Suspense Credit = the bank pays the customer LESS, reducing the Credit side's total.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
Total 1000, Suspense Credit 75 USD (same ccy) => Credit Leg#1 seed = 925

## Verification Note
Confirmed directly in the same code read as the Debit rule above (line 358: ternary covers both directions in one line). Status unchanged: CONFIRMED.

## Source Evidence
- business-case-runner.component.ts suspenseAdjustment() line 358 (side==='CREDIT' -> total.minus)
- business-case-runner.component.spec.ts line 262 'Credit Leg #1 = Total - Suspense Credit (same currency)'

## Related Knowledge
- [[Suspense Account]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
