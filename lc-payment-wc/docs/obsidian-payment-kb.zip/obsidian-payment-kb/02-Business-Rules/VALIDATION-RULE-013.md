---
knowledge_id: VALIDATION-RULE-013
title: "400 (schema/shape) and 409 (business rule) errors are deliberately distinct classes, dispatched via a single ApiError base + central middleware"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - validation
  - confirmed
---

# VALIDATION-RULE-013 — 400 (schema/shape) and 409 (business rule) errors are deliberately distinct classes, dispatched via a single ApiError base + central middleware

## Status
CONFIRMED

## Business Rule
RequestValidationError (malformed/incomplete request shape) always maps to HTTP 400 with code REQUEST_VALIDATION_FAILED. BusinessValidationError (e.g. unbalanced legs, SWIFT advice/cover mismatch, idempotency conflict) always maps to HTTP 409 with a caller-supplied code. NotFoundError maps to 404 NOT_FOUND. Enforced structurally via an abstract ApiError base class (httpStatus/code) and a single central Express error-handling middleware dispatching purely on `err instanceof ApiError`.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
An unbalanced request throws BusinessValidationError('LEGS_UNBALANCED') -> 409; a malformed amount string throws RequestValidationError -> 400.

## Verification Note
Confirmed by direct read of errors.ts (all 3 classes, exact httpStatus/code values as stated).

## Source Evidence
- microservices/payment-component/src/errors.ts: ApiError (abstract, httpStatus/code/toBody), RequestValidationError (400/REQUEST_VALIDATION_FAILED, line 19-22), BusinessValidationError (409, dynamic code, line 25-33), NotFoundError (404, line 35-38)
- microservices/payment-component/src/app.ts: central error-handler middleware mapping ApiError subclasses onto res.status(err.httpStatus).json(err.toBody())

## Related Knowledge
- [[Request Validation]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
