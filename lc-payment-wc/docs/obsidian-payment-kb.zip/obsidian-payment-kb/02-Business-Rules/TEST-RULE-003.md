---
knowledge_id: TEST-RULE-003
title: "Test coverage explicitly excludes the 9 vanilla custom elements and all .html templates from collectCoverageFrom"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - testscenario
  - confirmed
---

# TEST-RULE-003 — Test coverage explicitly excludes the 9 vanilla custom elements and all .html templates from collectCoverageFrom

## Status
CONFIRMED

## Business Rule
README.md states: 'the 9 vanilla Custom Elements under web-components/import|export/ and every component's own .html template need TestBed/DOM-level rendering tests, which this project deliberately hasn't taken on; excluded from collectCoverageFrom in jest.config.js rather than silently dragging the coverage numbers down.' The expert review document independently corroborates this (L-4) and explicitly ties it to the prior NG9 template-compile incident recorded in CLAUDE.md, recommending the 'ng build after any template change' rule be enforced in CI rather than left to convention.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
No worked numeric example available in the source evidence reviewed.

## Verification Note
Re-read both README.md:122-126 and payment-component-expert-review.md:258-261 in full; wording matches the claim closely (README says '9 vanilla Custom Elements', review doc paraphrases as '9 vanilla custom elements'). Note: jest.config.js itself (the actual collectCoverageFrom array) was not present among the uploaded files for this review to directly inspect — the claim rests on the README's and expert-review doc's descriptions of that config, both of which are consistent with each other, not on the config file itself. Kept as CONFIRMED since two independent documentation sources agree and this is consistent with the observed absence of any .element.ts spec files (previous rule).

## Source Evidence
- README.md:122-126
- docs/payment-component-expert-review.md:258-261 (L-4)

## Related Knowledge
- [[Testing Methodology and Coverage]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
