---
knowledge_id: API-RULE-016
title: "GET /payment-routing is a documented but entirely unimplemented aspirational endpoint"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - api
  - confirmed
---

# API-RULE-016 — GET /payment-routing is a documented but entirely unimplemented aspirational endpoint

## Status
CONFIRMED

## Business Rule
The /payment-routing path (equivalent of legacy getPaymentRouting()/SYST_PaymentRouting.jsp) is explicitly marked NOT IMPLEMENTED — draft/aspirational scope only. There is no corresponding route file, no PaymentRoutingResult consumer anywhere in src/, and the actual SWIFT message-type selection logic does not call this or anything equivalent. Kept in the OAS purely as a citation of the legacy function shape a future implementation would need to match.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
No worked numeric example available in the source evidence reviewed.

## Verification Note
Re-read Payment_component.yaml lines 336-360 directly (full /payment-routing path definition) and confirmed routes/paymentInstructions.ts (the sole routes file read) contains no such route. No change to status.

## Source Evidence
- analysis/Payment_component.yaml: paths./payment-routing.get.description (lines 336-349) — 'NOT IMPLEMENTED — draft/aspirational scope only ... no routes/payment-routing.ts (or equivalent) anywhere in microservices/payment-component/src/'
- microservices/payment-component/src/routes/paymentInstructions.ts: confirmed no /payment-routing route exists in the only routes file in the repo

## Related Knowledge
- [[Payment Instructions API]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
