---
knowledge_id: CHARGE-RULE-006
title: "Export Negotiation discount interest applies only to usance (deferred-payment) bills, never to sight bills, with a TWD 800 minimum on the nego fee"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - charges
  - confirmed
---

# CHARGE-RULE-006 — Export Negotiation discount interest applies only to usance (deferred-payment) bills, never to sight bills, with a TWD 800 minimum on the nego fee

## Status
CONFIRMED

## Business Rule
Export LC Negotiation (B3) treats discountDays===0 as 'sight' (isSight) — the Discount Rate input is disabled and no discount amount is shown/charged in that case; a non-zero discountDays marks the bill as usance, enabling the discount rate and computing a discount amount subtracted before 'Net to Exporter'. The Nego Fee itself carries a separate TWD 800 minimum (MIN_NEGO), independent of whether a discount applies.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
No worked numeric example available in the source evidence reviewed.

## Verification Note
Confirmed both client (UI gating) and server (actual discountDays>0 conditional, dedicated MIN_NEGO=800 constant distinct from MIN_COMM/MIN_COLLECTION). No change to status.

## Source Evidence
- lc-nego.element.ts line 67 (const isSight = f.discountDays === 0;)
- lc-nego.element.ts line 91 (Discount Rate input disabled when isSight)
- lc-nego.element.ts line 105 ('Min Applied? ... Yes (min TWD 800)')
- backend/server.js line 38 (const MIN_NEGO = 800), lines 572-575 (discountAmt computed only when discountDays > 0), line 606 (minimumApplied: rawNegoFee < MIN_NEGO)

## Related Knowledge
- [[Charge Integration]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
