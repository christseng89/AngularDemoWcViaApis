---
knowledge_id: CHARGE-RULE-009
title: "A small number of TWD minimum-fee floors are reused verbatim across multiple, conceptually distinct charge types rather than each fee type having its own dedicated minimum"
domain: Payment
category: Business Rule
status: INFERRED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - charges
  - inferred
---

# CHARGE-RULE-009 — A small number of TWD minimum-fee floors are reused verbatim across multiple, conceptually distinct charge types rather than each fee type having its own dedicated minimum

## Status
INFERRED

## Business Rule
MIN_COMM (TWD 1000, commented 'general minimum (A1 commission)') also floors B2's Export LC Confirming commission — a different fee concept from A1's LC issuance commission. MIN_COLLECTION (TWD 500, commented 'B5 collection fee minimum') also floors B4 Direct-path's 'Settlement Commission' — again a differently-named fee. MIN_NEGO (TWD 800) is, by contrast, its OWN dedicated constant used only for B3's Nego Fee — it is NOT part of this cross-reuse pattern. Whether the MIN_COMM/MIN_COLLECTION reuse reflects a genuine bank policy of shared minimum-fee tiers or is incidental demo-code reuse is not stated anywhere in the codebase or comments.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
No worked numeric example available in the source evidence reviewed.

## Verification Note
Re-verified all constant declarations and every usage site via grep. Confirmed MIN_COMM used at 2 sites (A1, B2), MIN_COLLECTION used at 2 sites (B4-direct, B5), MIN_NEGO used at exactly 1 site (B3, not shared). Added the MIN_NEGO non-sharing detail to sharpen the statement (it's relevant contrast evidence the original rule didn't mention). Status unchanged (INFERRED — no comment anywhere confirms this reuse is deliberate bank policy vs. incidental).

## Source Evidence
- backend/server.js line 37 (MIN_COMM=1000, 'general minimum (A1 commission)') reused at line 523 for B2's confCommTwd
- backend/server.js line 39 (MIN_COLLECTION=500, 'B5 collection fee minimum') reused at line 702 for B4-direct's settlement comm calculation, and again at line 795 for B5's own collectionFee
- backend/server.js line 38 (MIN_NEGO=800) used only at line 572 (B3) — confirmed NOT shared with any other endpoint

## Related Knowledge
- [[Charge Integration]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
