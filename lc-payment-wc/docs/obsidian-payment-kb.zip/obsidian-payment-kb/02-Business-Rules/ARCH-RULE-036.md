---
knowledge_id: ARCH-RULE-036
title: "[Planned, not yet implemented] Idempotency key = (originModule, bankContractRef, eventSeq); customer LC number is never the key"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - architecture
  - confirmed
---

# ARCH-RULE-036 — [Planned, not yet implemented] Idempotency key = (originModule, bankContractRef, eventSeq); customer LC number is never the key

## Status
CONFIRMED

## Business Rule
The idempotency key must use the bank-internal contract number (行内合约号), not the customer LC number, because customer LC numbers are not globally unique across banks/counterparties. eventSeq represents Event Time tied to a TF event and is a zero-padded string (pattern ^\d{2,3}$), not an integer counter. 'edition' (版次) is reference-only and never participates in the key. customerRef is carried for audit and SWIFT field 21 but is also not in the key. eventType includes REVERSAL. This design is CONFIRMED as a reviewer-agreed decision but NOT yet implemented in the current OAS/code (see the response-shape-outdated-vs-planned-rdd CONFLICT) — it should be read as a planned future state, not current behavior.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
No worked numeric example available in the source evidence reviewed.

## Verification Note
Confirmed the design is documented consistently in two independent sources (expert-review.md and CLAUDE.md's RDD section). Explicitly re-tagged in the title/statement as PLANNED, not current, to avoid it being read alongside the CURRENT natural-key rule (#10) as if both describe today's behavior — this is the same underlying fact as rule #24's CONFLICT, viewed from the design side rather than the OAS-gap side.

## Source Evidence
- docs/payment-component-expert-review.md 'Agreed idempotency-field design' subsection, lines 68-83, directly re-read: matches every clause of the statement verbatim, including the string-pattern eventSeq detail and the REVERSAL eventType rationale
- cross-checked against CLAUDE.md's own RDD section (same design, same decisions D-1..D-8, provided in this task's context) — the two sources agree exactly

## Related Knowledge
- [[Payment Architecture]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
