---
knowledge_id: CLASS-RULE-018
title: "A Suspense-driven FX pair's Debit/Credit section attribution is a best-effort magnitude match with an accepted tie ambiguity"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - classification
  - confirmed
---

# CLASS-RULE-018 — A Suspense-driven FX pair's Debit/Credit section attribution is a best-effort magnitude match with an accepted tie ambiguity

## Status
CONFIRMED

## Business Rule
Because no wire field names which suspenseBridge list (debitEntries vs creditEntries) produced a given generated 'FX Exchange {ccy} - Suspense' pair, the UI attributes it to 'Debit' vs 'Credit' display sections by comparing the pair's Other-Ccy-site leg gross amount against the real Suspense-Debit clearing entries' own per-currency sums (0.005 tolerance) — only Suspense-Debit sums are computed and compared; anything not matching (including a genuine tie with a Suspense-Credit-sourced amount, or no match at all) falls into the Credit bucket by default. This is an explicitly acknowledged display-only ambiguity that affects only which section header a pair appears under, not any accounting figure.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
susp-other (D FX Exchange USD - Suspense, EUR 50) + susp-trx (C FX Exchange EUR - Suspense, USD 55) with no matching Suspense-Debit/Suspense-Credit lines present -> debitSum is NaN -> falls into 'FX Credit Suspense Pair' by default.

## Verification Note
Read the implementation directly — confirmed the code compares only against suspenseDebitSums (line 184, `sumByGlAccount('Suspense - Debit')`); a match routes to Debit, everything else (including NaN from no match, or a genuine tie against a Suspense-Credit amount that happens to equal a different Suspense-Debit sum) routes to Credit. The original statement's claim that 'both resulting pairs are attributed to Debit' in a same-currency-same-sum tie between a debitEntries and creditEntries bucket is plausible but not independently verified by a dedicated test in this file — reworded slightly to describe the code's actual comparison target (Suspense-Debit sums only) rather than asserting the specific tie-both-to-Debit scenario as directly tested, since only the no-match-falls-to-Credit case has a cited test.

## Source Evidence
- src/app/payment-component/response-viewer.component.ts lines 152-162 (doc comment) and lines 219-225 (implementation, `suspenseDebitSums.get(...)`, `Math.abs(grossAmount - debitSum) < 0.005 ? suspensePairsDebit : suspensePairsCredit`)
- response-viewer.component.spec.ts 'a Suspense pair with no Suspense-Debit/Suspense-Credit clearing match... attributes to Credit by default rather than throwing'

## Related Knowledge
- [[Payment Instruction Classification]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
