---
knowledge_id: VALIDATION-RULE-027
title: "The /payment-instructions/classify endpoint exists specifically for RPFM's GAP-verdict business cases"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - validation
  - confirmed
---

# VALIDATION-RULE-027 — The /payment-instructions/classify endpoint exists specifically for RPFM's GAP-verdict business cases

## Status
CONFIRMED

## Business Rule
PaymentComponentApiService.classify() is documented as used ONLY by RPFM's GAP-verdict cases. Its response carries only a §6.1 Settlement-stream accountEntries (one entry per submitted leg) — no Charge/Liability entries and no swiftMessages, matching classifyPreview.ts's server-side scope exactly.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
n/a — architecture/scope rule.

## Verification Note
Confirmed by direct read of the api service doc comment, and cross-checked for consistency against the server-side classifyPreview.ts already read for a separate rule — both sides of this client/server pairing agree.

## Source Evidence
- src/app/payment-component/payment-component-api.service.ts lines 54-57 (classify() doc comment)
- src/app/payment-component/payment-component.types.ts ClassifyPreviewResult doc comment (lines 234-243)
- microservices/payment-component/src/domain/classifyPreview.ts top doc comment (independently confirmed above)

## Related Knowledge
- [[Request Validation]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
