---
knowledge_id: POSTING-RULE-012
title: "Multiple Suspense entries in the same currency stay individually itemized legs — never merged into one combined posting"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - accounting
  - confirmed
---

# POSTING-RULE-012 — Multiple Suspense entries in the same currency stay individually itemized legs — never merged into one combined posting

## Status
CONFIRMED

## Business Rule
Each entry in a currency bucket independently produces its own PaymentLegInput via buildSuspenseBridgeLeg; only the FX Exchange pair (a separate, additional leg) is computed from the bucket's aggregate. Individual Suspense legs are never summed into one line.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Audit trail preserves each individual charge/fee line even though the FX conversion overlay operates on the currency bucket's total.

## Example
No worked numeric example available in the source evidence reviewed.

## Verification Note
Directly confirmed — each bucket entry independently produces and pushes its own leg; no summation into a single leg occurs anywhere in expandSuspenseBridge.

## Source Evidence
- src/domain/suspenseBridge.ts expandSuspenseBridge's per-entry loop: `for (const entry of bucket) { const leg = buildSuspenseBridgeLeg(...); if (leg) { credit.push(leg); bucketSuspenseLegs.push(leg); } }`, read directly

## Related Knowledge
- [[Accounting Model]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
