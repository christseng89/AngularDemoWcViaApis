---
knowledge_id: FX-RULE-013
title: "H-3 fix: MT103/PACS008 field 32A (settled amount) and 33B (instructed amount) are populated from DIFFERENT source fields and DIFFER for a cross-currency leg"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - fx
  - confirmed
---

# FX-RULE-013 — H-3 fix: MT103/PACS008 field 32A (settled amount) and 33B (instructed amount) are populated from DIFFERENT source fields and DIFFER for a cross-currency leg

## Status
CONFIRMED

## Business Rule
buildAdviceMessage sets settlementCurrency/settlementAmount (32A) from leg.currency and leg.amountAccountCcy ?? leg.amountTxCcy, and separately sets instructedCurrency/instructedAmount (33B) from the request's transactionCurrency and leg.amountTxCcy. Same-currency legs collapse to identical figures on both fields; genuine cross-currency legs differ.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
Credit leg currency=EUR, amountTxCcy=100 (USD), amountAccountCcy=120 (EUR); transactionCurrency='USD' → settlementCurrency=EUR/settlementAmount=120 (32A), instructedCurrency=USD/instructedAmount=100 (33B).

## Verification Note
Confirmed directly in swiftMessages.ts — settlementAmount uses amountAccountCcy??amountTxCcy while instructedAmount uses amountTxCcy verbatim with instructedCurrency=transactionCurrency, exactly as claimed. No status change.

## Source Evidence
- swiftMessages.ts doc comment lines 57-69 and body lines 81-84 (buildAdviceMessage)

## Related Knowledge
- [[FX Processing]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
