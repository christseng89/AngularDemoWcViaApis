---
knowledge_id: FX-RULE-018
title: "A Suspense bridge entry whose currency equals the transaction currency never generates an FX Exchange pair — it folds directly into the credit side at its own face amount"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - fx
  - confirmed
---

# FX-RULE-018 — A Suspense bridge entry whose currency equals the transaction currency never generates an FX Exchange pair — it folds directly into the credit side at its own face amount

## Status
CONFIRMED

## Business Rule
Merged with 'same-ccy-suspense-passthrough' above (identical rule, sourced from the same suspenseBridge.ts lines 122-130 and 313). Kept as a single entry; see that entry for the full statement and evidence.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
suspenseBridge.debitEntries=[{amount:'10',currency:'USD'},{amount:'20',currency:'USD'}] with transactionCurrency='USD' -> two plain Suspense-Debit credit legs, zero FX Exchange legs.

## Verification Note
Duplicate of 'same-ccy-suspense-passthrough' (both describe the identical code path with the identical citations). Merged; status unchanged, CONFIRMED.

## Source Evidence
- suspenseBridge.ts buildSuspenseBridgeLeg() same-currency branch; expandSuspenseBridge() line 313 'case 1 — no FX pair, ever.'
- test/curl-tests/requests/case1-suspense-fx-and-nostro-usd.json

## Related Knowledge
- [[FX Processing]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
