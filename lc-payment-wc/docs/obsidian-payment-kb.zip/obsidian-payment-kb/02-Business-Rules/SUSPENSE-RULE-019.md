---
knowledge_id: SUSPENSE-RULE-019
title: "[Proposed, NOT implemented] Two distinct Payment Clearing posting-order patterns — Cash-First vs Accrual-First — carry materially different risk profiles"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - suspense
  - confirmed
---

# SUSPENSE-RULE-019 — [Proposed, NOT implemented] Two distinct Payment Clearing posting-order patterns — Cash-First vs Accrual-First — carry materially different risk profiles

## Status
CONFIRMED

## Business Rule
Architecture v4 proposal: Cash-First (collect cash first, then allocate) means the bank already holds the cash — risk during the unclearing window is only allocation-timing/FX revaluation, not customer collection risk. Accrual-First (recognize fee income first, then collect) means the bank has recognized receivable income before collecting — if deduction later fails, this carries genuine customer Credit/Collection Risk requiring ageing management. Design rule proposed: Accrual-First is NOT recommended for scenarios with real customer default possibility; both are acceptable only when the amount is already locked and collection can be triggered immediately.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
n/a — policy proposal, not a numeric worked example.

## Verification Note
Read the source Chinese-language document directly (grep lines 125-138) and confirmed every specific sub-claim (9.1/9.2 headers, per-product Cash-First/Accrual-First tagging, ageing-management linkage, the recommendation rule) is present essentially verbatim, matching the candidate's English paraphrase closely. Explicitly and correctly tagged '[Proposed, NOT implemented]' — no implementation code exists for this in the microservice, consistent with the rest of this architecture-v4 document being aspirational. Status unchanged: CONFIRMED (as an accurately-documented proposal, not as implemented behavior).

## Source Evidence
- analysis__Trade_Finance_Payment_Component_Architecture_v4-cn.docx.txt §9 (lines 125-138, verified directly: 9.1 Cash-First line 127, 9.2 Accrual-First line 131, the per-product tagging requirement line 136, the ageing-management cross-reference line 137, the recommendation-against-Accrual-First-for-default-risk line 138)

## Related Knowledge
- [[Suspense Account]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
