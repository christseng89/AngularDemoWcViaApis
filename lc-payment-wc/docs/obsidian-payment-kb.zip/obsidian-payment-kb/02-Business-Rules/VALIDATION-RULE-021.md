---
knowledge_id: VALIDATION-RULE-021
title: "A live preview is withheld (previewIncomplete, no API call) until both sides' legs are structurally valid AND (for PASS) mainRef+unitCode are populated"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - validation
  - confirmed
---

# VALIDATION-RULE-021 — A live preview is withheld (previewIncomplete, no API call) until both sides' legs are structurally valid AND (for PASS) mainRef+unitCode are populated

## Status
CONFIRMED

## Business Rule
runPreview() clears any stale result and sets previewIncomplete=true without calling the API when debitValid/creditValid (from each <app-leg-allocator>'s validChange) are not both true. For a PASS case, it additionally requires the built request's mainRef and unitCode to be non-empty before calling api.confirm(dryRun:true); otherwise it likewise shows previewIncomplete.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
n/a — gating logic, no numeric example given.

## Verification Note
Confirmed exactly by direct read of runPreview() lines 702-748.

## Source Evidence
- src/app/payment-component/business-case-runner.component.ts lines 724-730 ('!this.debitValid || !this.creditValid' branch), lines 743-748 ('if (!request.mainRef || !request.unitCode)' branch)
- business-case-runner.component.spec.ts: 'sets previewIncomplete and clears result when legs are not yet valid'; 'PASS: previewIncomplete when mainRef/unitCode are missing even though legs are valid'

## Related Knowledge
- [[Request Validation]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
