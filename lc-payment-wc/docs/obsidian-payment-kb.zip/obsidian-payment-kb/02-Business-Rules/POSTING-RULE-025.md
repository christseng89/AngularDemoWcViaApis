---
knowledge_id: POSTING-RULE-025
title: "amountTxCcy is always denominated in the deal's Transaction Currency, never the row's own currency — the single field the wire/%-split/V8-balance math all operate on"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - accounting
  - confirmed
---

# POSTING-RULE-025 — amountTxCcy is always denominated in the deal's Transaction Currency, never the row's own currency — the single field the wire/%-split/V8-balance math all operate on

## Status
CONFIRMED

## Business Rule
Row.amountTxCcy is treated as transaction-currency-denominated regardless of the row's own settlement currency; amountAccountCcy (the row's own currency figure) is always a separately-tracked/derived value, never conflated with amountTxCcy.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
No worked numeric example available in the source evidence reviewed.

## Verification Note
Directly confirmed by reading the emit() code — the two fields are computed against two different currency scales exactly as claimed.

## Source Evidence
- src/app/payment-component/leg-allocator.component.ts emit(), read directly this pass — lines around 1259-1281 show amountTxCcy formatted to `this.scaleFor(this.transactionCurrency)` while amountAccountCcy is formatted to `this.scaleFor(r.currency)` (rowScale), a clearly separate scale/value

## Related Knowledge
- [[Accounting Model]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
