---
knowledge_id: SWIFT-RULE-014
title: "Idempotency key for LC/payment instructions is planned to become (originModule, bankContractRef, eventSeq) via a structured Reference/Event model — NOT yet implemented"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - swift
  - confirmed
---

# SWIFT-RULE-014 — Idempotency key for LC/payment instructions is planned to become (originModule, bankContractRef, eventSeq) via a structured Reference/Event model — NOT yet implemented

## Status
CONFIRMED

## Business Rule
Per the reviewer-confirmed (2026-08-09) planning record, the idempotency key is intended to be an LC's Event, not a running sequence number: sequence represents Event Time tied to TF events (LC Issue=00, Amendment=01, Document Arrival=02, ...). Primary reference is planned to become the bank-internal contract number (行内合约号), not the customer LC number (not globally unique). Instructions are mutable while PENDING (update = delete-old + create-new) and become immutable only after RELEASE (4-eyes/maker-checker). The Confirm endpoint posts an already-RELEASED instruction; the PENDING drafting loop and 4-eyes release live upstream, out of scope. D-6 retains mainRef/sequence as legacy aliases for backward compatibility; D-7 allows data migration; D-8 makes eventSeq/edition string+pattern ^\d{2,3}$ to preserve zero-padding. This is a CONFIRMED planning decision, not yet reflected in the actual implemented code (types.ts/requestSchema.ts still use the flat originModule/mainRef/sequence natural key verified directly in confirmPaymentInstruction.ts).

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
n/a

## Verification Note
This rule and its sibling 'reversal-event-type' are tagged SWIFT domain in the candidate list but are substantively about idempotency-key architecture and the LC event model, not SWIFT messaging logic (the only SWIFT touchpoint is D-4's mention of the customerRef being carried for 'SWIFT field 21 (related reference)'). They duplicate the Architecture-domain candidates 'idempotency-key-design'/'idempotency-payload-aware-fingerprint' verbatim. Confirmed the CLAUDE.md decision-log content matches what's quoted, and independently confirmed via this session's own read of confirmPaymentInstruction.ts that the current code has NOT yet implemented this (still uses the flat natural key) — consistent with the candidate's own 'planned, NOT yet implemented' framing. Kept CONFIRMED (the decision itself is confirmed-recorded) rather than downgraded, but flagged the domain-tagging and cross-domain duplication as a gap below.

## Source Evidence
- CLAUDE.md 'Confirmed Requirement — OAS structured Reference / Event model' section, decisions D-1 through D-8 (reviewer-confirmed 2026-08-09)
- docs/RDD-oas-reference-event-model.md (full record, cited in CLAUDE.md, not independently re-opened this pass)
- src/domain/confirmPaymentInstruction.ts (this session's own read) confirms the CURRENT idempotency key implementation is still the plain (originModule, mainRef, sequence) natural key — store.find(request.originModule, request.mainRef, request.sequence) — matching D-6's stated legacy-alias fallback, i.e. the structured block itself is not yet present in code

## Related Knowledge
- [[SWIFT Messaging and Vouchers]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
