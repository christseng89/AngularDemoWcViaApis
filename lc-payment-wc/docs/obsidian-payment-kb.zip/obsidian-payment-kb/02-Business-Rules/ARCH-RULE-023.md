---
knowledge_id: ARCH-RULE-023
title: "The /api/currencies ('Get Currency API') endpoint's conceptual lineage is traced to the legacy STAN core banking system's Currency Master function group, but its response shape is invented, not ported"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - architecture
  - confirmed
---

# ARCH-RULE-023 — The /api/currencies ('Get Currency API') endpoint's conceptual lineage is traced to the legacy STAN core banking system's Currency Master function group, but its response shape is invented, not ported

## Status
CONFIRMED

## Business Rule
The endpoint's business concept (a currency master lookup) is explicitly traced back to a real legacy baseline system component — STAN's 'Currency Master' function group — but the comment is explicit that STAN's own screen (a generic framework CRUD JSP) gave no bespoke field list to copy, so this endpoint's actual JSON shape was invented for the demo and should not be assumed to match STAN's real interface.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
No worked numeric example available in the source evidence reviewed.

## Verification Note
Confirmed verbatim against the file. Unchanged.

## Source Evidence
- backend/server.js lines 13-21, directly re-read: 'The real baseline concept this models is the STAN "Currency Master" function group (X/EE_SYS/FUNCGRP/grp_G49082300152.xml, InquireCurrency F05030701358) — a generic framework CRUD screen (JSP screen/STD/Std_Currency_Edit.jsp) with no bespoke field list to trace a response shape from, so this endpoint's shape is invented for the demo, same category as the pre-existing fake rate table it now replaces.'

## Related Knowledge
- [[Payment Architecture]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
