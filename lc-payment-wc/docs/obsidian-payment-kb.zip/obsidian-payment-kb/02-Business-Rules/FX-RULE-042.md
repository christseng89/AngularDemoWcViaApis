---
knowledge_id: FX-RULE-042
title: "Account Ccy Equiv. round-trips exactly as typed rather than being re-derived from the rounded Amount (Tx Ccy) figure"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - fx
  - confirmed
---

# FX-RULE-042 — Account Ccy Equiv. round-trips exactly as typed rather than being re-derived from the rounded Amount (Tx Ccy) figure

## Status
CONFIRMED

## Business Rule
Duplicate of 'account-ccy-override-exact-roundtrip' above — same rule, this instance sourced from the (converted) bilingual User Manual's §6.3.1 rather than the code comment directly.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
JPY 20000 at rate 149.0825 previously redisplayed as JPY 19999 due to round-trip precision loss; now redisplays as exactly 20000.

## Verification Note
Merged conceptually with 'account-ccy-override-exact-roundtrip' — identical underlying fix, cross-referenced from the user manual instead of the source code comment. Both fully confirmed against the same accountCcyAmountDecimal() implementation already read directly. No status change.

## Source Evidence
- docs__LC-Payment-WC-User-Manual-en.docx.txt §6.3.1
- leg-allocator.component.ts accountCcyAmountDecimal() (already confirmed in full above)

## Related Knowledge
- [[FX Processing]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
