---
knowledge_id: POSTING-RULE-026
title: "Currency minor-unit decimal places (decimals()) are the single source of truth for currency-correct rounding of computed amounts"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - accounting
  - confirmed
---

# POSTING-RULE-026 — Currency minor-unit decimal places (decimals()) are the single source of truth for currency-correct rounding of computed amounts

## Status
CONFIRMED

## Business Rule
CurrencyService.decimals() returns a Record<currency, decimalPlaces> sourced from the /api/currencies response, defaulting to 2 decimal places for any currency missing a decimals field. Used wherever a COMPUTED monetary amount needs currency-correct rounding, so the UI's rounding agrees with the microservice's own currency-scale rounding for the same computation.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
USD -> 2 decimals, JPY -> 0 decimals; missing decimals field -> defaults to 2.

## Verification Note
Server-side counterpart (money.ts's CURRENCY_MINOR_UNITS/minorUnitsForCurrency, whose doc comment explicitly cross-references CurrencyService.decimals() by name) was directly read and confirms this rule's premise. Client-side currency.service.ts itself not independently re-opened this pass; kept CONFIRMED on the strength of the server-side corroboration and consistent cross-referencing.

## Source Evidence
- src/app/payment-component/currency.service.ts decimals() doc comment (cited, not independently re-opened this pass)
- microservices/payment-component/src/money.ts CURRENCY_MINOR_UNITS table, read directly this pass, confirms the server-side mirror of this same concept exists and is documented as needing to 'stay in agreement' with CurrencyService.decimals()

## Related Knowledge
- [[Accounting Model]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
