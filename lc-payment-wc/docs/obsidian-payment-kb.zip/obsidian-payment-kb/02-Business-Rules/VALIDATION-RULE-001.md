---
knowledge_id: VALIDATION-RULE-001
title: "Idempotency key is the natural key (originModule, mainRef, sequence); C-2 payload-fingerprint conflict detection"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - validation
  - confirmed
---

# VALIDATION-RULE-001 — Idempotency key is the natural key (originModule, mainRef, sequence); C-2 payload-fingerprint conflict detection

## Status
CONFIRMED

## Business Rule
A prior confirmed instruction is looked up by (originModule, mainRef, sequence) via store.find(). If found (and not dryRun), the incoming request is hashed via a canonical, order-independent JSON stringify (stableStringify: object keys sorted, undefined-valued keys dropped so an absent optional and an explicit undefined hash identically, array order preserved) then SHA-256'd (requestFingerprint). An identical fingerprint replays the existing result (created:false, same instructionId, steps 1-5 not re-run). A different fingerprint on the same key throws BusinessValidationError('IDEMPOTENCY_KEY_CONFLICT', 409) and does not overwrite the original. A prior instruction persisted WITHOUT a stored fingerprint (legacy record, store.save called with fingerprint undefined) falls back to a plain replay. Merged with the separate 'idempotency-conflict-c2' rule (originally id_hint=idempotency-conflict-c2), whose only caveat — 'the fingerprint comparison/generation logic itself... is UNCLEAR from these files alone' — is resolved: confirmPaymentInstruction.ts's stableStringify()/requestFingerprint() (lines 43-64) is the exact mechanism, fully readable and confirmed.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
Same key (IPLC, REF-1, 1) submitted twice with amountTxCcy '999' the second time (still-balanced but different) throws IDEMPOTENCY_KEY_CONFLICT (409); store.find('IPLC','REF-1',1) still shows the original instructionId.

## Verification Note
Re-opened confirmPaymentInstruction.ts and its test file directly — every claimed behavior (canonical stringify, sha256, 409 on mismatch, legacy fallback) is present verbatim. Merged the near-duplicate 'idempotency-conflict-c2' entry into this one since it described the exact same mechanism from the store's external-contract side only, marking the internals UNCLEAR — now resolved to CONFIRMED since the internals were directly read.

## Source Evidence
- microservices/payment-component/src/domain/confirmPaymentInstruction.ts lines 43-64 (stableStringify/requestFingerprint), lines 108-140 (Step 0 block, the throw and the legacy-fallback comment)
- microservices/payment-component/src/store/paymentInstructionStore.ts: findFingerprint()/save(instruction, fingerprint) doc comments
- test/unit/domain/confirmPaymentInstruction.test.ts: 'persists the created instruction...', 'C-2: a DIFFERENT payload... IDEMPOTENCY_KEY_CONFLICT', 'C-2: an identical resend still replays...(canonical)', 'C-2: an instruction saved WITHOUT a fingerprint... replays'

## Related Knowledge
- [[Request Validation]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
