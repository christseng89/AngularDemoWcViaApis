---
knowledge_id: API-RULE-012
title: "GET /api/currencies is guaranteed by the startup guard to be exactly the set of currencies every FX calculator can successfully rate against TWD"
domain: Payment
category: Business Rule
status: INFERRED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - api
  - inferred
---

# API-RULE-012 — GET /api/currencies is guaranteed by the startup guard to be exactly the set of currencies every FX calculator can successfully rate against TWD

## Status
INFERRED

## Business Rule
Because the module-load-time startup guard throws before the server can start if any currency in the master lacks a TWD rate (either direction), any currency returned by GET /api/currencies is guaranteed, by construction, to succeed in every calc endpoint's rate(ccy,'TWD') call. This is an inferred consequence (the guard's actual purpose), not a documented API contract, and is scoped only to the demo backend, not the Payment Component microservice.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
No worked numeric example available in the source evidence reviewed.

## Verification Note
Re-read server.js lines 1-100 directly; confirmed the startup guard logic and the /api/currencies handler exactly. Minor wording correction: the original statement said the endpoint 'simply echoes CURRENCIES verbatim' — in fact it wraps CURRENCIES in `{currencies: CURRENCIES, at}`, an unchanged pass-through, not a literal bare echo; this is a trivial phrasing nuance, not a substantive error, so status stays INFERRED (unchanged) since the guard's guarantee is still a reasonable but undocumented inference, not stated as an explicit contract anywhere.

## Source Evidence
- backend/server.js: startup guard (lines 26-35), throwing if `!(\`${c.code}/TWD\` in RATES) && !(\`TWD/${c.code}\` in RATES)`
- backend/server.js: `GET /api/currencies` (lines 93-95) returns `{ currencies: CURRENCIES, at }` — CURRENCIES passed through with no filtering/transformation

## Related Knowledge
- [[Payment Instructions API]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
