---
knowledge_id: FX-RULE-040
title: "FX pair construction reuses already-on-the-wire, already-rounded amounts rather than re-multiplying by a rate a second time"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - fx
  - confirmed
---

# FX-RULE-040 — FX pair construction reuses already-on-the-wire, already-rounded amounts rather than re-multiplying by a rate a second time

## Status
CONFIRMED

## Business Rule
Duplicate of 'fx-pair-amounts-reused-verbatim' above — same claim (buildFxPair never re-derives trxCcyAmount from ownCcyAmount×rate), restated from the expert-review's summary perspective citing the v1.7.x history.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
No worked numeric example available in the source evidence reviewed.

## Verification Note
Merged conceptually with 'fx-pair-amounts-reused-verbatim' — identical substance, different source (expert review summary vs. the code's own doc comment). No status change; CONFIRMED via direct code read already performed.

## Source Evidence
- payment-component-expert-review.md §1, §6 (v1.7.x history in suspenseBridge.ts referenced)
- suspenseBridge.ts lines 165-171, 194-195 (already confirmed above)

## Related Knowledge
- [[FX Processing]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
