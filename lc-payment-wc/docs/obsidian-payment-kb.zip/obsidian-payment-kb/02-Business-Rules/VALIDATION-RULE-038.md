---
knowledge_id: VALIDATION-RULE-038
title: "M-2: exchange rate must be strictly greater than 0"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - validation
  - confirmed
---

# VALIDATION-RULE-038 — M-2: exchange rate must be strictly greater than 0

## Status
CONFIRMED

## Business Rule
A zero exchange rate is rejected with 400 (isZeroRate check in exchangeRateSchema's .refine()); a negative rate was already structurally blocked by the ExchangeRate pattern (no leading sign). Applies to every rate field (drRate/drBuyRate/crBuyRate/sellRate) and to SuspenseEntry.crossRate. Merges the fsd-architecture-docs and validation-gap-docs duplicate entries (exchange-rate-positive-m2 / m2-rate-gt-zero) describing this identical rule.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
A zero-value crossRate/drRate/etc. -> 400 'ExchangeRate must be greater than 0'.

## Verification Note
Confirmed by direct read of requestSchema.ts and money.ts, cross-checked against both FSD docs, all in exact agreement. Merged 2 duplicate doc-sourced entries.

## Source Evidence
- microservices/payment-component/src/validation/requestSchema.ts lines 33-40 (exchangeRateSchema's .refine((v) => !isZeroRate(v), ...))
- microservices/payment-component/src/money.ts lines 161-172 (isZeroRate, with its doc comment explaining a zero rate would silently drop a leg)
- analysis__Payment-OAS-FSD-en.docx.txt Appendix B, M-2 (line 137)
- analysis__Payment_Component_Calculation_Validation.docx.txt Hardening Review M-2 (line 378)

## Related Knowledge
- [[Request Validation]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
