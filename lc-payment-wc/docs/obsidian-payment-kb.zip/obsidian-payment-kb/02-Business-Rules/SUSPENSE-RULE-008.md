---
knowledge_id: SUSPENSE-RULE-008
title: "Debit Leg #1 seed = case Total Amount + Sigma(Suspense Debit entries, each independently FX-converted/rounded)"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - suspense
  - confirmed
---

# SUSPENSE-RULE-008 — Debit Leg #1 seed = case Total Amount + Sigma(Suspense Debit entries, each independently FX-converted/rounded)

## Status
CONFIRMED

## Business Rule
The Debit side's Leg #1 seed amount fed into <app-leg-allocator [initialTotalAmount]> is the case's base Total Amount PLUS each Suspense Debit entry's trx-currency equivalent, via suspenseAdjustment('DEBIT', ...) = total.plus(bucket.trxEquivalent) per currency bucket. Same-currency entries pass through unconverted; cross-currency entries are converted via resolveCrossRate() and rounded to the transaction currency's own decimal scale before being summed. Only Leg #1 is affected — the case's own registry Total Amount is never mutated. Business meaning: Suspense Debit = the bank collects MORE from the customer.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
Case Total Amount USD 1000, Suspense Debit = USD 100 + EUR 50 (crossRate 2) => Debit Leg#1 seed = 1000 + 100 + (50*2) = 1200

## Verification Note
Read business-case-runner.component.ts lines 320-500 in full — suspenseAdjustment/sideDefaults code matches exactly (total.plus for DEBIT at line 358). Confirmed both cited spec test names exist verbatim. Status unchanged: CONFIRMED.

## Source Evidence
- business-case-runner.component.ts sideDefaults() (lines 469-493) and suspenseAdjustment() (lines 355-361, side==='DEBIT' -> total.plus)
- business-case-runner.component.spec.ts line 254 'Debit Leg #1 = Total + Suspense Debit (same currency, no FX conversion)'
- business-case-runner.component.spec.ts line 270 'sums multiple Suspense entries across different currencies, each converted at its own crossRate'

## Related Knowledge
- [[Suspense Account]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
