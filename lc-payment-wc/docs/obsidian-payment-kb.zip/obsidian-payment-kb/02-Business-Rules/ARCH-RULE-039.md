---
knowledge_id: ARCH-RULE-039
title: "Entry/leg/message IDs use module-global counters + Date.now() instead of UUIDs, unlike instructionId"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - architecture
  - confirmed
---

# ARCH-RULE-039 — Entry/leg/message IDs use module-global counters + Date.now() instead of UUIDs, unlike instructionId

## Status
CONFIRMED

## Business Rule
accountEntries.ts, voucherDescription.ts, and swiftMessages.ts generate IDs from module-global counters plus Date.now(), which is collision-prone across multiple service instances and non-deterministic, whereas instructionId already correctly uses randomUUID(). Recommendation: use randomUUID() consistently for entry/leg/message IDs too.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
No worked numeric example available in the source evidence reviewed.

## Verification Note
Confirmed the finding is still accurate against CURRENT source (not just the historical review doc) — directly grepped all three files' ID-generator functions. Unchanged, and additionally verified this specific gap has NOT been fixed since the review was written.

## Source Evidence
- docs/payment-component-expert-review.md L-1 bullet, lines 246-248, directly re-read
- grep of current source directly confirms this STILL holds: accountEntries.ts:27 `return \`entry-${Date.now()}-${entryIdCounter}\`;`, voucherDescription.ts:114 `return \`leg-${Date.now()}-${legIdCounter}\`;`, swiftMessages.ts:50 `return \`swift-${Date.now()}-${messageIdCounter}\`;` — while swiftMessages.ts separately DOES use randomUUID() for the UETR field (line 126), confirming the contrast the rule draws between instructionId/UETR (UUID) and entry/leg/message IDs (counter+Date.now())

## Related Knowledge
- [[Payment Architecture]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
