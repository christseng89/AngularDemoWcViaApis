---
knowledge_id: FX-RULE-014
title: "M-2: every exchange rate field must be strictly greater than zero"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - fx
  - confirmed
---

# FX-RULE-014 — M-2: every exchange rate field must be strictly greater than zero

## Status
CONFIRMED

## Business Rule
drRate, drBuyRate, crBuyRate, sellRate (on any leg) and crossRate (on any Suspense entry) must be a positive decimal string. The regex pattern forbids a leading '-' (blocking negatives structurally) but does not block '0'/'0.0000000000' — a separate .refine() explicitly rejects zero.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
No worked numeric example available in the source evidence reviewed.

## Verification Note
Confirmed directly in requestSchema.ts. No status change.

## Source Evidence
- requestSchema.ts line 36-40 (exchangeRateSchema .refine + '// M-2:' comment)
- test/unit/validation/requestSchema.test.ts 'exchange rate must be > 0 (M-2)' describe block

## Related Knowledge
- [[FX Processing]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
