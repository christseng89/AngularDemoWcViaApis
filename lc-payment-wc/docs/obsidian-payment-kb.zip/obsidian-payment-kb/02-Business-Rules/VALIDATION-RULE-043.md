---
knowledge_id: VALIDATION-RULE-043
title: "A foreign-currency leg must carry amountAccountCcy for debit-side FX netting to compare correctly"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - validation
  - confirmed
---

# VALIDATION-RULE-043 — A foreign-currency leg must carry amountAccountCcy for debit-side FX netting to compare correctly

## Status
CONFIRMED

## Business Rule
The v1.9.0 debit-side netting logic (suspenseBridge.ts) compares Suspense entries' native-currency amounts against the leg's own amountAccountCcy. If a leg omits amountAccountCcy and sends only amountTxCcy, the netting comparison falls back to comparing a transaction-currency-equivalent figure against a native-currency figure — producing a materially wrong netting result. Documented explicitly in the Chinese test-cases doc as a caller pitfall.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
n/a — documented pitfall, no worked failure example given in the source.

## Verification Note
Confirmed by direct read of the Chinese test-cases doc — the exact wording matches the rule statement. Did not independently re-derive the v1.9.0 netting code's fallback-to-amountTxCcy branch line-by-line in this pass (out of this domain's core evidence set), but the documented claim is consistent with the general amountAccountCcy-vs-amountTxCcy denomination distinction confirmed elsewhere (payment-component.types.ts doc comments) — kept as CONFIRMED on the strength of the direct doc citation.

## Source Evidence
- Payment-Component-Suspense-FX-Test-Cases-zh.md line 92 (worked example leg carrying both amountAccountCcy and amountTxCcy), lines 112-113 ('EUR 的 leg 一定要帶 amountAccountCcy...debit 側 netting 邏輯是拿 amountAccountCcy...跟 Suspense 的原幣金額互相核對，沒有這個欄位會退回用 amountTxCcy 去比對')

## Related Knowledge
- [[Request Validation]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
