---
knowledge_id: ARCH-RULE-004
title: "Payment Component never generates Charge Voucher (§6.2) / Liability Voucher (§6.3) postings, and never calculates or posts individual charge lines — a clean, permanent v1.6.0 architecture boundary with the Charge Component"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - architecture
  - confirmed
---

# ARCH-RULE-004 — Payment Component never generates Charge Voucher (§6.2) / Liability Voucher (§6.3) postings, and never calculates or posts individual charge lines — a clean, permanent v1.6.0 architecture boundary with the Charge Component

## Status
CONFIRMED

## Business Rule
The §6.2 Charge Voucher and §6.3 Liability Voucher streams (chargeContext/liabilityContext, buildChargeVoucherEntry/buildLiabilityVoucherEntries) were removed from this service entirely in v1.6.0. A separate Balance/Charge Component that bridges through Suspense books its own Liability/Charge leg on its own books; this service only ever produces SETTLEMENT entries. SuspenseEntry.sourceComponent is pure provenance/audit metadata and never triggers Charge/Liability posting here. More generally, the Payment Component never calculates or posts individual charge/margin/commission lines at all — that responsibility belongs entirely to a separate Charge Component service; the two link only through the Suspense-Credit clearing account (Payment Component posts Dr Customer A/C / Cr Suspense-Credit; the Charge Component separately posts Dr Suspense-Credit / Cr Margin+Commission+Charges on its own books).

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
No worked numeric example available in the source evidence reviewed.

## Verification Note
Merged with candidate #43 (id_hint=charge-payment-component-boundary), which is the same architecture decision restated from the CLAUDE.md side rather than the code side (root-context group) — both cite the identical v1.6.0 removal and the identical Suspense-Credit clearing-account boundary, so keeping them as two separate rules would double-count one decision. Kept the fuller code-plus-doc statement, folding in #43's 'never duplicate charge calculation/posting' framing. Both source files re-read directly and confirmed word-for-word.

## Source Evidence
- microservices/payment-component/src/domain/accountEntries.ts:1-17 top doc comment, directly re-read: 'the §6.2 Charge Voucher and §6.3 Liability Voucher streams ... were removed from this service entirely ... this service only ever produces SETTLEMENT entries, regardless of a Suspense entry's sourceComponent tag'
- microservices/payment-component/src/domain/confirmPaymentInstruction.ts:1-23 top doc comment, directly re-read: identical v1.6.0 removal narrative plus the v1.5.0 SUSPENSE_CONTEXT_CONFLICT-guard history
- project CLAUDE.md 'Charge Component ↔ Payment Component boundary' section (verbatim, provided in this task's own context): the Dr Customer A/C / Cr Suspense-Credit vs Dr Suspense-Credit / Cr Margin+Commission+Charges worked example, and 'the Payment Component must never duplicate charge calculation or charge posting logic'

## Related Knowledge
- [[Payment Architecture]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
