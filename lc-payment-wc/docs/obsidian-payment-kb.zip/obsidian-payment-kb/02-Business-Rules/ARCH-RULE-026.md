---
knowledge_id: ARCH-RULE-026
title: "FX rate resolution is explicitly out of scope — caller must supply already-resolved rates"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - architecture
  - confirmed
---

# ARCH-RULE-026 — FX rate resolution is explicitly out of scope — caller must supply already-resolved rates

## Status
CONFIRMED

## Business Rule
Every rate field (drRate, drBuyRate, crBuyRate, sellRate, SuspenseEntry.crossRate) must be supplied by the caller, already resolved. This service performs arithmetic with rates, never looks them up. This is a deliberate scope exclusion, not a gap.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
No rate-lookup endpoint or logic in this service

## Example
No worked numeric example available in the source evidence reviewed.

## Verification Note
Confirmed verbatim in the §2.2 Out of Scope list. Unchanged.

## Source Evidence
- converted/analysis__Payment-OAS-FSD-en.docx.txt line 20, directly re-read: 'FX rate resolution — every rate field (drRate, drBuyRate, crBuyRate, sellRate, SuspenseEntry.crossRate) must be supplied by the caller, already resolved; this service performs arithmetic with rates, never looks them up.'

## Related Knowledge
- [[Payment Architecture]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
