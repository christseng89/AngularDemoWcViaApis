---
knowledge_id: SWIFT-RULE-004
title: "SWIFT message type selection is driven purely by the leg's own message-type fields, never by accountType or the RTGS flag"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - swift
  - confirmed
---

# SWIFT-RULE-004 — SWIFT message type selection is driven purely by the leg's own message-type fields, never by accountType or the RTGS flag

## Status
CONFIRMED

## Business Rule
Since v1.3.0, which message (MT103/PACS008/MT202/MT202COV/PACS009COV) is generated for a leg comes solely from leg.payAdviceMsgType/leg.payCoverMsgType. A NOSTRO leg with rtgsIndicator=true is processed identically to a plain NOSTRO leg for SWIFT message purposes — there is no RTGS-specific SWIFT message type in this schema. rtgsIndicator is preserved on the leg object (not discarded) purely so a future routing distinction could key off it, but no such distinction exists today in swiftMessages.ts.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
n/a

## Verification Note
Re-read swiftMessages.ts in full; confirmed no reference to accountType or rtgsIndicator anywhere in the message-building functions. CONFIRMED as originally stated.

## Source Evidence
- src/domain/swiftMessages.ts top doc comment (lines 8-14): 'message type here is selected purely from the leg's own payAdviceMsgType/payCoverMsgType fields — never from accountType. ... there is no RTGS-specific message type in source or in this schema'
- src/domain/swiftMessages.ts buildAdviceMessage/buildCoverMessage/buildSwiftMessages (lines 74-135) reference only leg.payAdviceMsgType/leg.payCoverMsgType/leg.currency/leg.amountTxCcy/leg.amountAccountCcy/leg.valueDate — never leg.accountType or leg.rtgsIndicator

## Related Knowledge
- [[SWIFT Messaging and Vouchers]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
