---
knowledge_id: FX-RULE-003
title: "A cross-currency Suspense entry with no matching real leg still generates Suspense-suffixed FX Exchange pair legs (v1.8.0/v1.9.0)"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - fx
  - confirmed
---

# FX-RULE-003 — A cross-currency Suspense entry with no matching real leg still generates Suspense-suffixed FX Exchange pair legs (v1.8.0/v1.9.0)

## Status
CONFIRMED

## Business Rule
When there is no real leg in the Suspense entry's foreign currency to net or pair against, the bridge still generates an FX Exchange pair, and the generated legs are always suffixed '- Suspense' (e.g. 'FX Exchange EUR - Suspense'), even with no competing leg-anchored pair to disambiguate from. On the DEBIT side this is the diffNative>0 'common case' (reduces to the full gross amount when no matching debitLegs exist); on the CREDIT side the Suspense pair is unconditional.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
debitLegs=[{CUST-ACC,USD,111}], suspenseBridge.debitEntries=[{10,EUR,crossRate:1.1}] -> generated legs include 'FX Exchange EUR - Suspense' / 'FX Exchange USD - Suspense'.

## Verification Note
Confirmed against code directly — both the DEBIT-side residual branch (when diffNative reduces to gross, i.e. no offsetting debitLegs) and the CREDIT-side unconditional Suspense pair use accountSuffix=' - Suspense'. No status change.

## Source Evidence
- suspenseBridge.ts lines 360-363 (DEBIT diffNative>0 branch, sourceDirection CREDIT, suffix ' - Suspense') and lines 382-384 (CREDIT-side unconditional Suspense pair, also suffixed)
- test/unit/domain/confirmPaymentInstruction.test.ts 'a cross-currency entry with no matching leg...' test

## Related Knowledge
- [[FX Processing]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
