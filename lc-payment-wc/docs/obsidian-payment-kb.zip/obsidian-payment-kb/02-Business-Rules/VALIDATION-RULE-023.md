---
knowledge_id: VALIDATION-RULE-023
title: "H-2 companion check: a raw typed leg amount with more decimal places than its currency allows is flagged and blocks preview/Confirm"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - validation
  - confirmed
---

# VALIDATION-RULE-023 — H-2 companion check: a raw typed leg amount with more decimal places than its currency allows is flagged and blocks preview/Confirm

## Status
CONFIRMED

## Business Rule
checkRowScale() validates the RAW typed value (before money() rounds it) against CurrencyService.decimals() for the relevant currency, storing a per-row error message (rowScaleErrors Map). These are aggregated in amountScaleErrors and emitted via scaleErrorsChange so business-case-runner can block preview/Confirm the same way it gates the header Total Amount and Suspense entries. A currency absent from the Currency master is skipped.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
n/a — no worked numeric example given beyond the test names.

## Verification Note
Confirmed exactly by direct read of leg-allocator.component.ts lines 275-303.

## Source Evidence
- src/app/payment-component/leg-allocator.component.ts lines 275-303 (checkRowScale, amountScaleErrors getter)
- leg-allocator.component.spec.ts 'amountScaleErrors (H-2: leg amount over-precision vs Currency API decimals)' describe block: flags 9999.112 against USD (max 2), flags any decimals for JPY (max 0), skips BHD (absent from master)

## Related Knowledge
- [[Request Validation]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
