---
knowledge_id: API-RULE-020
title: "Multiple CUSTOMER legs on one side (e.g. margin from a separate account) require no new server or OAS capability — the wire contract already supports arrays"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - api
  - confirmed
---

# API-RULE-020 — Multiple CUSTOMER legs on one side (e.g. margin from a separate account) require no new server or OAS capability — the wire contract already supports arrays

## Status
CONFIRMED

## Business Rule
debitLegs/creditLegs are already arrays in the OAS contract; nothing in classification.ts or balanceValidation.ts (V8) cares how many legs of the same accountType appear on a side, only the aggregate per side. The only real limitation is that business-case-registry.ts's own case defaults are fixed at one leg per side — registering a multi-leg sub-case needs either a registry entry whose default seed already has two rows, or documented Simulator-UI guidance to use the leg-allocator's add-row control starting from the base case.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
Sub Use Cases 1a, 2A-1, 2B-1, 3a, 4a all split a single side into two CUSTOMER legs using only the existing array capability.

## Verification Note
Re-read the source doc passage directly (line 175) and confirmed the array-typed schema fields in requestSchema.ts support the claim. classification.ts/balanceValidation.ts were confirmed to exist at the cited paths but not read line-by-line in this verification pass — the claim about their internals (leg-count-agnostic) rests on the doc's own assertion plus the structural fact that nothing in requestSchema.ts imposes a per-type leg-count cap. No change to status; evidence is solid though slightly indirect for the classification.ts/balanceValidation.ts internals specifically.

## Source Evidence
- converted/PaymentComponentProposedUseCases-EN.docx.txt: 'Cross-cutting Open Questions Summary' (line 169), item on 'Multiple CUSTOMER legs on one side' (line 175)
- microservices/payment-component/src/validation/requestSchema.ts: `debitLegs: z.array(paymentLegInputSchema).min(1, ...)`, `creditLegs: z.array(paymentLegInputSchema)` (lines 98, 104) — confirmed both are arrays with no per-side leg-count-by-type restriction
- microservices/payment-component/src/domain/classification.ts and balanceValidation.ts: files exist and are cited by the doc as the relevant logic (not independently re-read line-by-line in this pass, but their existence and role as the classification/balance-check modules is corroborated by requestSchema.ts's own doc comments referencing them)

## Related Knowledge
- [[Payment Instructions API]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
