---
knowledge_id: FX-RULE-010
title: "An FX pair's amounts are always REUSED verbatim from an already-computed, already-on-the-wire figure — never freshly re-derived by multiplying a combined magnitude by a rate"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - fx
  - confirmed
---

# FX-RULE-010 — An FX pair's amounts are always REUSED verbatim from an already-computed, already-on-the-wire figure — never freshly re-derived by multiplying a combined magnitude by a rate

## Status
CONFIRMED

## Business Rule
trxCcyAmount passed into buildFxPair is the source's own already-rounded transaction-currency total and is used as-is (only re-rounded to the same scale it should already be at, never recomputed from ownCcyAmount×rate). This is what prevents the v1.7.x 'combine-then-reconvert' rounding-drift bug.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
No worked numeric example available in the source evidence reviewed.

## Verification Note
Confirmed: buildFxPair's body never multiplies trxCcyAmount by rateStr; it only rounds each of ownCcyAmount and trxCcyAmount to their own currency's scale. No status change.

## Source Evidence
- suspenseBridge.ts lines 165-171 (buildFxPair doc comment) and lines 194-195 (formatMonetaryAmount applied to the passed-in amounts, no multiplication)
- suspenseBridge.ts top doc comment lines 15-27 documenting the v1.7.x superseded bug this design avoids

## Related Knowledge
- [[FX Processing]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
