---
knowledge_id: POSTING-RULE-031
title: "'Charge embedding' rule: a pass-through/fee charge denominated in the SAME currency as the customer's main settlement (Cr CA) leg is netted directly into that leg instead of being booked as its own separate Dr CA entry"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - accounting
  - confirmed
---

# POSTING-RULE-031 — 'Charge embedding' rule: a pass-through/fee charge denominated in the SAME currency as the customer's main settlement (Cr CA) leg is netted directly into that leg instead of being booked as its own separate Dr CA entry

## Status
CONFIRMED

## Business Rule
In both B4's Direct-to-CA path and B5's Collection path, FBC and the relevant commission/collection fee are each independently tested against the Cr CA leg's own chosen currency; a same-currency match nets the charge into the Cr CA amount, while a currency mismatch produces its own explicit Dr CA leg for that charge. A1/A2/A3 do NOT implement this embedding rule.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
No worked numeric example available in the source evidence reviewed.

## Verification Note
Directly confirmed by reading the exact backend/server.js lines this pass for both the B4 and B5 code paths — code matches the claim exactly, including the explicit inline comment naming the rule.

## Source Evidence
- backend/server.js lines ~705-712 (B4): `const fbcEmbedded = fbc > 0 && fbcCcy === effectiveBillPayCcy; const commEmbedded = comm > 0 && effectiveCommPayCcy === effectiveBillPayCcy;` read directly
- backend/server.js lines ~810-820 (B5): `const fbcEmbedded = fbc > 0 && fbcCcy === netPayCcy; const colFeeEmbedded = colFeeCcy === netPayCcy;` read directly, plus explicit inline comment 'Embedding rule: any charge in the SAME ccy as Cr CA → net into Cr CA (no separate Dr CA).'

## Related Knowledge
- [[Accounting Model]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
