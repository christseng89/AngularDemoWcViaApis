---
knowledge_id: ARCH-RULE-029
title: "PYMT_IMLCPayment, REIM, CFNC, SBLC are confirmed non-users of the Payment Component"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - architecture
  - confirmed
---

# ARCH-RULE-029 — PYMT_IMLCPayment, REIM, CFNC, SBLC are confirmed non-users of the Payment Component

## Status
CONFIRMED

## Business Rule
Four modules/functions were verified via full-text source search to NEVER call the Payment Component nor read/write payment-related account-type fields inside their ConfirmBusinessCall, and have no SWIFT trigger points: PYMT_IMLCPayment, REIM, CFNC, SBLC. This is a business-integration gap in the baseline requiring a business decision, not an OAS/schema defect.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Verdict N/A — not applicable, not a defect

## Example
No worked numeric example available in the source evidence reviewed.

## Verification Note
Confirmed directly, with the individual per-module source citations recovered from the document. Unchanged.

## Source Evidence
- converted/analysis__Payment-OAS-FSD-en.docx.txt §8 CFNC/SBLC/REIM/PYMT section, lines 115-120, directly re-read: 'CFNC/SBLC/REIM/PYMT — Confirmed Non-Users ... to make explicit, source-verified statements that they do NOT use the Payment Component' with individual source citations for each of the four (SYF_CFNC_Overdue.js:32-39, SYF_SBLC_SBLCIssue.js:334-346, SYF_REIM_SettleClaim.js:183-207, PYMT_IMLCPayment ConfirmBusinessCall:136-144)

## Related Knowledge
- [[Payment Architecture]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
