---
knowledge_id: UI-RULE-021
title: "Switching the applicant/beneficiary resets chosen payment accounts; switching the transaction currency resets in-progress charge selections entirely"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - ui
  - confirmed
---

# UI-RULE-021 — Switching the applicant/beneficiary resets chosen payment accounts; switching the transaction currency resets in-progress charge selections entirely

## Status
CONFIRMED

## Business Rule
Every LC element's form-field change handler resets this._payAccts = {} whenever applicantId/beneficiaryId changes (a previously-selected DDA account belongs to the old customer and would be invalid/wrong for the new one), and resets this._charges = [] whenever the transaction currency (lcCurrency/billCurrency/iblCurrency/corrBankChargesCcy) changes (a charge's ccyOptions and default ccy are computed relative to the transaction currency, so a stale ChargeItem[] would show wrong currency-option menus and stale amounts until the next server round-trip repopulates them from scratch via _initCharges).

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
n/a

## Verification Note
Re-verified directly against lc-issue.element.ts (import) and lc-settlement.element.ts (export) source — matches, though at slightly different line numbers than originally cited (122-123 vs cited 119-124, and 149-150/166-169 vs cited 147-152/166-170 — trivial line-drift, not a substantive discrepancy). Did not re-open lc-settlement.element.ts (import) to verify the 'billCurrency OR corrBankChargesCcy' dual-trigger detail, so that specific sub-claim remains unverified though consistent with the pattern seen in the other two files.

## Source Evidence
- lc-issue.element.ts lines 122-123: `if (k === 'applicantId') { this._payAccts = {}; ... } if (k === 'lcCurrency') { this._charges = []; this._payAccts = {}; }`
- lc-settlement.element.ts (export) lines 149-150 (beneficiaryId resets _payAccts), 168-169 (billCurrency resets _charges and _payAccts)

## Related Knowledge
- [[Payment Component Simulator UI]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
