---
knowledge_id: VALIDATION-RULE-037
title: "[Legacy, pre-microservice] Credit leg sum must not exceed the shared target total (CHK_Total_Pct), wider CFNC tolerance"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - validation
  - confirmed
---

# VALIDATION-RULE-037 — [Legacy, pre-microservice] Credit leg sum must not exceed the shared target total (CHK_Total_Pct), wider CFNC tolerance

## Status
CONFIRMED

## Business Rule
Same shape as the debit-side check (V1) but with an additional CFNC-only tolerance of up to 0.02 (CFNC is out of the 15 confirmed-consumer scope, so this branch is inert for in-scope functions) plus the same RPFM ±0.01 tolerance, and a SettleParticipant-specific silent reset-to-zero-and-accept branch.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
n/a — legacy formula, structurally identical to V1 with the noted additions.

## Verification Note
Confirmed exactly by direct read of the doc's §3.2 excerpt, including the CFNC-out-of-scope note.

## Source Evidence
- analysis__Payment_Component_Calculation_Validation.docx.txt §3.2 (lines 46-68), full source excerpt of CHK_Total_Pct() (SSSS_PaymentCredit.js:164-210) with both tolerance branches and the SettleParticipant reset-to-zero comment

## Related Knowledge
- [[Request Validation]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
