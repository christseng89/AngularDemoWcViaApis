---
knowledge_id: API-RULE-005
title: "GET /payment-instructions?originModule=<invalid> is silently treated as 'no filter' rather than a 400"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - api
  - confirmed
---

# API-RULE-005 — GET /payment-instructions?originModule=<invalid> is silently treated as 'no filter' rather than a 400

## Status
CONFIRMED

## Business Rule
The GET list endpoint's originModule query parameter is checked via the isOriginModule type guard; an unrecognized value is simply not applied as a filter (all instructions returned) rather than rejecting the request as invalid — a deliberate lenient-query-parameter posture distinct from the strict POST body validation.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
No worked numeric example available in the source evidence reviewed.

## Verification Note
Re-read the route handler directly; confirmed exact behavior. No change to status.

## Source Evidence
- microservices/payment-component/src/routes/paymentInstructions.ts: `const originModule = isOriginModule(originModuleRaw) ? originModuleRaw : undefined;` (line 72)
- microservices/payment-component/test/unit/routes/paymentInstructions.test.ts: 'ignores an originModule query value outside the enum (treated as no filter)'

## Related Knowledge
- [[Payment Instructions API]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
