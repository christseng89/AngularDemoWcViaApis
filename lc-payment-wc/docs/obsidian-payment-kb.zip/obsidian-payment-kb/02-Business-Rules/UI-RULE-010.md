---
knowledge_id: UI-RULE-010
title: "A row's position in the internal rows array never changes just because its remainder status flips"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - ui
  - confirmed
---

# UI-RULE-010 — A row's position in the internal rows array never changes just because its remainder status flips

## Status
CONFIRMED

## Business Rule
ensureRemainderRow() deliberately avoids reassigning this.rows = [...fixed, remainderRow] on every edit, because Angular's *ngFor (even with trackBy) physically relocates a row's DOM node when its array position changes, dropping keyboard focus/cursor mid-edit. Only genuine add (append) or remove operations change array shape; flipping isRemainder never does.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
n/a

## Verification Note
Confirmed against source: ensureRemainderRow only appends new rows (never reassigns [...fixed, remainderRow] wholesale) and the doc comment explicitly states the *ngFor DOM-relocation rationale.

## Source Evidence
- ensureRemainderRow() doc comment lines 1160-1173, explaining the focus-loss regression this avoids
- implementation lines 1194-1234: existing rows keep position; only a brand-new row is appended

## Related Knowledge
- [[Payment Component Simulator UI]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
