---
knowledge_id: ARCH-RULE-019
title: "payment-component.types.ts is a deliberately independent duplicate of the microservice's own types.ts, not a shared/imported module"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - architecture
  - confirmed
---

# ARCH-RULE-019 — payment-component.types.ts is a deliberately independent duplicate of the microservice's own types.ts, not a shared/imported module

## Status
CONFIRMED

## Business Rule
The Angular app's payment-component.types.ts mirrors microservices/payment-component/src/types.ts (tracking payment-instructions-post.yaml v1.6.0) but is duplicated rather than imported cross-project, since lc-payment-wc/backend also does not import the microservice — the two Node projects are kept independently deployable. This means the two type definitions can drift apart over time and must be kept in sync manually.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
n/a

## Verification Note
Confirmed verbatim against the file. Unchanged.

## Source Evidence
- src/app/payment-component/payment-component.types.ts lines 1-6, directly re-read: 'TypeScript types mirroring microservices/payment-component/src/types.ts (payment-instructions-post.yaml v1.6.0). Duplicated here rather than imported cross-project — lc-payment-wc/backend doesn't import the microservice either; these two Node projects stay independently deployable.'

## Related Knowledge
- [[Payment Architecture]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
