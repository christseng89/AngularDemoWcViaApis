---
knowledge_id: ARCH-RULE-006
title: "All wire monetary/rate strings must be parsed via money.ts's Decimal-based parser — the sole allowed choke point for constructing a Decimal from a wire string"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - architecture
  - confirmed
---

# ARCH-RULE-006 — All wire monetary/rate strings must be parsed via money.ts's Decimal-based parser — the sole allowed choke point for constructing a Decimal from a wire string

## Status
CONFIRMED

## Business Rule
The OAS types every monetary/rate field as a pattern-constrained STRING, never `number`, specifically so server-side arithmetic and the Dr/Cr balance check use decimal/BigDecimal and never IEEE-754 double. money.ts is documented as the only module allowed to construct a Decimal from a wire string; every other module should go through parseMonetaryAmount/parseExchangeRate rather than touching Decimal directly.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
No worked numeric example available in the source evidence reviewed.

## Verification Note
Confirmed verbatim against the file. Unchanged.

## Source Evidence
- microservices/payment-component/src/money.ts lines 1-11 top doc comment, directly re-read: 'This module is the only place in the service allowed to construct a Decimal from a wire string — every other module should go through here rather than touching Decimal directly'

## Related Knowledge
- [[Payment Architecture]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
