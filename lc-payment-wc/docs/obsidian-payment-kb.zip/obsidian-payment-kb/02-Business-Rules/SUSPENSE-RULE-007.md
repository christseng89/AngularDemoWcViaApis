---
knowledge_id: SUSPENSE-RULE-007
title: "suspenseBridge is an optional, verbatim passthrough field on the client's Confirm request builder — present only when the caller supplies it"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - suspense
  - confirmed
---

# SUSPENSE-RULE-007 — suspenseBridge is an optional, verbatim passthrough field on the client's Confirm request builder — present only when the caller supplies it

## Status
CONFIRMED

## Business Rule
buildConfirmRequest only sets request.suspenseBridge when a truthy suspenseBridge argument is passed in; when omitted, the resulting request object has no suspenseBridge key at all. When supplied it is attached exactly as given (===, not deep-equal), with no transformation.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
buildConfirmRequest(config, model, debitLegs, creditLegs, 'USD') (no 6th arg) -> req.suspenseBridge === undefined. With a SuspenseBridge object passed, req.suspenseBridge === that exact object.

## Verification Note
Read business-case-request.ts directly (lines 20-37) — code matches exactly, including the v1.10.0 transactionCurrency field sent alongside it. Confirmed both cited test names exist. Status unchanged: CONFIRMED.

## Source Evidence
- business-case-request.ts lines 33-35 (`if (suspenseBridge) { request.suspenseBridge = suspenseBridge; }`)
- business-case-request.spec.ts line 77 'suspenseBridge passthrough (v1.4.0)' describe block: line 78 'is omitted from the request when not supplied', line 83 'is included verbatim when supplied'

## Related Knowledge
- [[Suspense Account]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
