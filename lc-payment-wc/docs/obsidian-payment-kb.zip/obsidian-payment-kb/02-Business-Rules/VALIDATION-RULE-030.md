---
knowledge_id: VALIDATION-RULE-030
title: "All web components render via raw innerHTML template literals with manual escapeHtml calls — currently safe only because interpolated values are fixed dropdowns/mock data"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - validation
  - confirmed
---

# VALIDATION-RULE-030 — All web components render via raw innerHTML template literals with manual escapeHtml calls — currently safe only because interpolated values are fixed dropdowns/mock data

## Status
CONFIRMED

## Business Rule
shared.ts's own doc comment on escapeHtml explicitly flags that these vanilla Custom Elements build markup via template-literal .innerHTML assignment (not a framework's auto-escaping binding), so nothing is escaped by default; it states this is 'not exploitable today' only because server-derived text is currently constrained to fixed dropdowns/mock data, but warns it 'would become a real stored/reflected-XSS vector the moment a free-text field... is added.' escapeHtml IS applied consistently in the files sampled — journal-entry.element.ts escapes account/description/ccy/type/leg for every row, and lc-issue.element.ts's error-message rendering (`⚠ ${escapeHtml(this._error)}`) also correctly escapes server error text.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
n/a — architecture/security finding.

## Verification Note
Confirmed by direct read of all three files — every claimed detail (the doc comment's own self-assessment, journal-entry.element.ts's consistent escaping, lc-issue.element.ts's error-escaping) verified present verbatim.

## Source Evidence
- src/app/web-components/shared.ts lines 35-47 (escapeHtml doc comment, self-identified latent risk), lines 48-55 (implementation)
- src/app/web-components/journal-entry.element.ts lines 77-83 (escapeHtml applied to leg/account/ccy/type/description in every row)
- src/app/web-components/import/lc-issue.element.ts line 97 ('⚠ ${escapeHtml(this._error)}'), line 113 (escapeHtml applied to JSON.stringify(entries) attribute)

## Related Knowledge
- [[Request Validation]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
