---
knowledge_id: SUSPENSE-RULE-017
title: "General Suspense/Charge Component bridge — raw amounts expand into offsetting Suspense legs + FX Exchange pairs (per FSD §5.4/§7.7)"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - suspense
  - confirmed
---

# SUSPENSE-RULE-017 — General Suspense/Charge Component bridge — raw amounts expand into offsetting Suspense legs + FX Exchange pairs (per FSD §5.4/§7.7)

## Status
CONFIRMED

## Business Rule
A Balance Component (tracking Import/Export Bill Liability) or a Charge Component (margin/commission/fees) hands its own Suspense-account posting to the Payment Component via suspenseBridge.debitEntries[]/.creditEntries[] carrying raw amounts, without the Payment Component needing to understand or recompute what the upstream component calculated. This service expands each entry into its own offsetting Suspense leg — always at the entry's own full gross amount, always credit-direction regardless of which list it came from — plus, for any entry in a currency other than the transaction currency, an FX Exchange pair so the settlement voucher balances by currency, not only in aggregate.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
Balance Component (own books): Dr IBL / Cr Suspense. Payment Component (this service): Dr Suspense / Cr Nostro.

## Verification Note
Read the FSD doc directly (lines 30-80) and confirmed both §5.4 (line 42) and §7.7 (lines 68-73) match the stated rule and worked example verbatim. This general mechanism accurately describes the ACTUAL implemented behavior (confirmed against suspenseBridge.ts code above for the gross/always-credit/FX-pair aspects). Status unchanged: CONFIRMED.

## Source Evidence
- analysis__Payment-OAS-FSD-en.docx.txt line 42 (§5.4) and lines 68-73 (§7.7, verbatim worked example)

## Related Knowledge
- [[Suspense Account]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
