---
knowledge_id: POSTING-RULE-006
title: "Settlement entry amount prefers amountAccountCcy over amountTxCcy"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - accounting
  - confirmed
---

# POSTING-RULE-006 — Settlement entry amount prefers amountAccountCcy over amountTxCcy

## Status
CONFIRMED

## Business Rule
For each leg, the SETTLEMENT entry's posted amount is leg.amountAccountCcy when present, falling back to leg.amountTxCcy only when amountAccountCcy is absent.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
leg({amountTxCcy:'100', amountAccountCcy:'150'}) -> posted amount '150'

## Verification Note
Directly confirmed reading the exact source line.

## Source Evidence
- src/domain/accountEntries.ts line 94: `const amountStr = leg.amountAccountCcy ?? leg.amountTxCcy;`

## Related Knowledge
- [[Accounting Model]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
