---
knowledge_id: VALIDATION-RULE-003
title: "Voucher code prefix must be resolvable via sourceFunctionCode or override, else RequestValidationError"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - validation
  - confirmed
---

# VALIDATION-RULE-003 — Voucher code prefix must be resolvable via sourceFunctionCode or override, else RequestValidationError

## Status
CONFIRMED

## Business Rule
Step 3 requires a voucherCodePrefix, resolved either from options.voucherCodePrefixOverride (priority, bypasses sourceFunctionCode resolution entirely) or from resolveVoucherCodePrefix(originModule, sourceFunctionCode), which throws RequestValidationError if the (originModule:sourceFunctionCode) key isn't in the VOUCHER_CODE_PREFIXES table. Two FSD rows (EPLC PayAccept, EXCO SettlementAtMaturity) are deliberately omitted from that table and REQUIRE the direct override.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
confirmPaymentInstruction(store, request(), {voucherCodePrefixOverride:'EPLC07NULLNULLNULL'}) -> debitLegs[0].accountDesc = 'EPLC07NULLNULLNULLC', bypassing sourceFunctionCode entirely.

## Verification Note
Confirmed by direct read of both confirmPaymentInstruction.ts and voucherDescription.ts.

## Source Evidence
- microservices/payment-component/src/domain/confirmPaymentInstruction.ts lines 68-74 (options doc comment), line 184 (resolution)
- microservices/payment-component/src/domain/voucherDescription.ts lines 28-65 (VOUCHER_CODE_PREFIXES table and resolveVoucherCodePrefix, including its explicit throw message naming the two dual-prefix rows)
- test/unit/domain/confirmPaymentInstruction.test.ts: 'voucherCodePrefixOverride bypasses sourceFunctionCode resolution entirely'; 'throws RequestValidationError when neither sourceFunctionCode nor an override is supplied'

## Related Knowledge
- [[Request Validation]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
