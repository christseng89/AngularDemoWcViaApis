---
knowledge_id: CLASS-RULE-026
title: "Dr/Cr AccountType values are user-selected screen data, not hardcoded per function — the XOR rule is data-driven"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - classification
  - confirmed
---

# CLASS-RULE-026 — Dr/Cr AccountType values are user-selected screen data, not hardcoded per function — the XOR rule is data-driven

## Status
CONFIRMED

## Business Rule
CPYT_DR_AC_TYPE/CPYT_CR_AC_TYPE come from whichever account the user selects for each PaymentDebit/PaymentCredit grid row (CUSTOMER, NOSTRO, VOSTRO, SUSPENSE, or INTERNAL) — the calculation JS only assembles the voucher description once the type is known, it does not decide the account type itself. Evaluating the XOR rule for a specific transaction therefore requires the actual runtime-selected Dr/Cr account types, not just static code inspection.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
No worked numeric example available in the source evidence reviewed.

## Verification Note
Confirmed both citations verbatim; also independently corroborated by the parallel statement in the en/zh FSD §7.2/§2.3 text. No changes needed.

## Source Evidence
- analysis/COMMON-PaymentComponent-Cross-Reference.md 'Key Takeaways' point 3, line 77
- converted/analysis__PaymentComponent-Microservice-FSD-zh.docx.txt line 59 ('the rule is evaluated identically across all eleven modules — it is data-driven from whichever account types the operator actually selected, never hardcoded per module or function')

## Related Knowledge
- [[Payment Instruction Classification]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
