---
knowledge_id: UI-RULE-003
title: "A failed or incomplete preview/Confirm always clears the previously displayed result rather than leaving a stale one on screen next to the new error"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - ui
  - confirmed
---

# UI-RULE-003 — A failed or incomplete preview/Confirm always clears the previously displayed result rather than leaving a stale one on screen next to the new error

## Status
CONFIRMED

## Business Rule
Every failure/incomplete branch in runPreview() (scale error, invalid legs, missing mainRef/unitCode, API error) and in onConfirm()'s error handler sets this.result = null before/alongside setting the error message — explicitly called out in code comments as 'Point 1 fix' — so a stale accountEntries/classification table is never shown alongside a new error banner.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
n/a

## Verification Note
Grepped the component and confirmed at least 7 distinct call sites setting result=null in error/incomplete branches, matching the claim.

## Source Evidence
- business-case-runner.component.ts lines 634, 694-696, 718, 726, 744, 764, 791 — multiple 'this.result = null;' assignments, several annotated '// Point 1 fix: ...'

## Related Knowledge
- [[Payment Component Simulator UI]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
