---
knowledge_id: ARCH-RULE-033
title: "[Proposed, NOT implemented] EBL and IBL share a Loan+Payment+Charge pattern that differs only in the external settlement endpoint"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - architecture
  - confirmed
---

# ARCH-RULE-033 — [Proposed, NOT implemented] EBL and IBL share a Loan+Payment+Charge pattern that differs only in the external settlement endpoint

## Status
CONFIRMED

## Business Rule
Architecture v4 proposal: Export Bill Loan (EBL) financing and Import Bills Financing (IBL) can share the same Loan Component + Payment Component + Charge Engine framework — the Loan Component establishes the loan asset without needing to know how the net payment will be split. The key structural difference is the external funds endpoint: EBL typically pays out to the Customer Current Account (the exporter), while IBL typically settles externally via Nostro/Beneficiary Bank (the importer's financing is used to pay an overseas correspondent). This endpoint difference is flagged as the primary reason this is a 'high reuse value' pattern.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Two near-identical Loan+Payment+Charge flows differing only in Customer-vs-Nostro settlement endpoint

## Example
No worked numeric example available in the source evidence reviewed.

## Verification Note
Confirmed directly, including the worked Dr/Cr journal lines for both EBL and IBL. Unchanged.

## Source Evidence
- converted/analysis__Trade_Finance_Payment_Component_Architecture_v4-cn.docx.txt §6-7, lines 69-92, directly re-read: full EBL and IBL sections with journal-entry-style Dr/Cr worked examples for each, and the explicit '核心特徵：EBL 的主要外部資金去向通常是 Customer C/A ... IBL 與 EBL 可共用 Loan + Payment Framework，但資金端點不同' summary line

## Related Knowledge
- [[Payment Architecture]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
