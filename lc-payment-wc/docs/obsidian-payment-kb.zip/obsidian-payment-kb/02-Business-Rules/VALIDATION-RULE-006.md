---
knowledge_id: VALIDATION-RULE-006
title: "previewClassification accepts an optional tolerance so a within-tolerance mismatch still reports balanced=true"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - validation
  - confirmed
---

# VALIDATION-RULE-006 — previewClassification accepts an optional tolerance so a within-tolerance mismatch still reports balanced=true

## Status
CONFIRMED

## Business Rule
previewClassification's third parameter (toleranceAbs, default 0) is compared against the absolute difference of debit/credit totals via difference.abs().lessThanOrEqualTo(toleranceAbs); a nonzero difference within tolerance still reports balanced:true.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
previewClassification([{100}],[{99.5}], '1') -> balance.balanced=true (difference 0.5 <= tolerance 1)

## Verification Note
Confirmed exactly by direct read.

## Source Evidence
- microservices/payment-component/src/domain/classifyPreview.ts line 47 (default param) and line 67 (the lessThanOrEqualTo comparison)
- test/unit/domain/classifyPreview.test.ts: 'within a custom tolerance, a nonzero difference still reports balanced=true' (100 vs 99.5 with tolerance '1' -> balanced=true)

## Related Knowledge
- [[Request Validation]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
