---
knowledge_id: VALIDATION-RULE-020
title: "Client-side amount-precision guard blocks both live preview and Confirm before any server round-trip"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - validation
  - confirmed
---

# VALIDATION-RULE-020 — Client-side amount-precision guard blocks both live preview and Confirm before any server round-trip

## Status
CONFIRMED

## Business Rule
Every user-entered amount (header Total Amount, each Suspense Debit/Credit entry via business-case-runner.component.ts's amountScaleErrors; each leg-allocator row amount via leg-allocator.component.ts's own checkRowScale/amountScaleErrors, aggregated into the runner's allAmountScaleErrors) is checked client-side against the currency's own decimal-places limit (CurrencyService.decimals()). If any amount exceeds its currency's allowed decimal places, onConfirm() refuses to call the API (sets confirmError) and runPreview() short-circuits with previewError instead of firing a request that would only 400 server-side. A currency absent from the decimals map is skipped, mirroring the microservice's own knownMinorUnitsForCurrency posture. Merges the README-level summary entry 'client-precision-guard-mirrors-server' into this one, since it describes the identical mechanism.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
Total Amount 10000.123 with USD (2dp) => amountScaleErrors[0] = 'Total Amount 10000.123 has 3 decimal place(s) but USD allows at most 2.'

## Verification Note
Confirmed by direct read of business-case-runner.component.ts. Merged the README-sourced duplicate entry. NOTE (flagged in gaps_found, not a status downgrade): README.md labels this guard 'H-3 hardening', but the code's own comments and CLAUDE.md consistently call the identical mechanism 'H-2' — a real but minor documentation label inconsistency, since 'H-3' elsewhere unambiguously refers to the unrelated SWIFT 32A/33B fix.

## Source Evidence
- src/app/payment-component/business-case-runner.component.ts: amountScaleErrors getter (lines 187-204), decimalPlaces() (lines 170-174), onConfirm() (lines 663-669), runPreview() H-2 guard (lines 715-722)
- business-case-runner.component.spec.ts describe('amountScaleErrors...') — flags Total Amount over-precision, Suspense Debit/Credit over-precision, skips unknown currency (BHD), skips empty amounts; 'onConfirm refuses to POST while an amount is over-precise'; 'runPreview surfaces the precision error and does not call the API'
- README.md lines 114-120 ('Client-side amount-precision guard (H-3 hardening, 2026-08)')

## Related Knowledge
- [[Request Validation]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
