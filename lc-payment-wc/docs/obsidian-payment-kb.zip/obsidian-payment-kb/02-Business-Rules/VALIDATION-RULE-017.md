---
knowledge_id: VALIDATION-RULE-017
title: "An unresolved FSD ambiguity (two candidate voucher prefixes) is surfaced as a mandatory user choice, never guessed"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - validation
  - confirmed
---

# VALIDATION-RULE-017 — An unresolved FSD ambiguity (two candidate voucher prefixes) is surfaced as a mandatory user choice, never guessed

## Status
CONFIRMED

## Business Rule
For the two source functions where the legacy FSD documents two possible voucher-code prefixes without stating the selecting condition (EPLC Pay/Accept, EXCO Settlement at Maturity), the UI renders a required voucherPrefix select (defaulted to the first option as a form-default convenience, still user-editable) with a description pointing back to the citation; buildConfirmRequest uses voucherCodePrefixOverride from that selection instead of a fixed sourceFunctionCode.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
EPLC Pay/Accept dualPrefixOptions = [{label:'EPLC07NULLNULLNULL (discount leg)'},{label:'EPLC03NULLNULLNULL (sight leg)'}]; selecting the second sends voucherCodePrefixOverride='EPLC03NULLNULLNULL' and sourceFunctionCode is left undefined.

## Verification Note
Cross-checked against business-case-request.ts (directly read): `sourceFunctionCode: config.dualPrefixOptions ? undefined : config.sourceFunctionCode, voucherCodePrefixOverride: config.dualPrefixOptions ? model['voucherPrefix'] : undefined` — confirms the ternary logic exactly as claimed.

## Source Evidence
- src/app/payment-component/business-case-fields.ts lines 21-33 (dualPrefixOptions branch)
- src/app/payment-component/business-case-registry.ts eplc-pay-accept and exco-settlement-at-maturity entries (dualPrefixOptions)
- business-case-fields.spec.ts 'adds a voucherPrefix select... when dualPrefixOptions is set'; business-case-request.spec.ts 'uses model.voucherPrefix (not config.sourceFunctionCode) when dualPrefixOptions is set'

## Related Knowledge
- [[Request Validation]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
