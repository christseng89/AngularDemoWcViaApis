---
knowledge_id: UI-RULE-004
title: "A stale Confirm error banner self-clears the moment the debounced preview pipeline next runs, regardless of whether that preview itself succeeds"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - ui
  - confirmed
---

# UI-RULE-004 — A stale Confirm error banner self-clears the moment the debounced preview pipeline next runs, regardless of whether that preview itself succeeds

## Status
CONFIRMED

## Business Rule
runPreview() resets confirmError = null at its top, alongside previewError/previewIncomplete. Since runPreview fires on every debounced edit (any Formly field, leg-allocator row, Suspense entry, or header override), correcting the field that caused a prior 400 (e.g. filling in a blank Account No.) makes the stale error banner disappear on the next recompute cycle, whether or not that fresh preview itself succeeds (a still-failing preview shows its own fresh previewError instead of stacking both).

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
n/a

## Verification Note
Read the exact code block; confirmError=null is set unconditionally at the top of runPreview, immediately confirming this rule as written.

## Source Evidence
- business-case-runner.component.ts lines 702-713 — runPreview() top: previewError=null, previewIncomplete=false, confirmError=null with an explanatory doc comment matching this exact rule

## Related Knowledge
- [[Payment Component Simulator UI]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
