---
knowledge_id: SUSPENSE-RULE-012
title: "A Suspense entry's same-currency vs. cross-currency classification (and thus whether crossRate is attached) uses the EXPLICIT transaction currency, never a leg's own currency nor a stale registry default"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - suspense
  - confirmed
---

# SUSPENSE-RULE-012 — A Suspense entry's same-currency vs. cross-currency classification (and thus whether crossRate is attached) uses the EXPLICIT transaction currency, never a leg's own currency nor a stale registry default

## Status
CONFIRMED

## Business Rule
Both the wire-level suspenseBridge entries (buildSuspenseBridgeEntries) and the Leg #1 seed conversion (sideDefaults/suspenseAdjustment) compare a Suspense entry's currency against this.transactionCurrency — the explicit override/registry-default value — not against any individual leg's settlement currency.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
n/a — classification-boundary test, not a numeric formula example.

## Verification Note
Confirmed sideDefaults() line 472 uses this.transactionCurrency (the explicit getter) as the conversion target, per the code read above; confirmed cited test name exists. Status unchanged: CONFIRMED.

## Source Evidence
- business-case-runner.component.ts sideDefaults() line 472 (trxCurrency = this.transactionCurrency) and buildSuspenseBridgeEntries's own use of transactionCurrency
- business-case-runner.component.spec.ts line 835 'a Suspense entry is classified against the EXPLICIT Transaction Currency (override), not any leg's own currency'

## Related Knowledge
- [[Suspense Account]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
