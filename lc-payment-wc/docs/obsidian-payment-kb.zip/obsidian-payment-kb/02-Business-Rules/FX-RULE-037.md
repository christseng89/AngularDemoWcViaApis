---
knowledge_id: FX-RULE-037
title: "Exchange rate of zero is accepted [at the pattern level] and, absent the M-2 guard, would silently drop the resulting Suspense leg, losing a real charge"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - fx
  - confirmed
---

# FX-RULE-037 — Exchange rate of zero is accepted [at the pattern level] and, absent the M-2 guard, would silently drop the resulting Suspense leg, losing a real charge

## Status
CONFIRMED

## Business Rule
EXCHANGE_RATE_PATTERN itself accepts '0' (the regex has no lower bound). A zero crossRate would make trxEquivalent = 0, and buildSuspenseBridgeLeg returns null (drops the leg entirely) — a real charge would disappear from the posting with no error, IF the M-2 .refine() guard in requestSchema.ts were absent or bypassed. There is also no upper/lower sanity bound on the rate at all beyond the pattern's digit-count caps.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
crossRate = 0 → trxEquivalent = 0 → buildSuspenseBridgeLeg returns null → the charge silently vanishes from the voucher — IF this ever reached buildSuspenseBridgeLeg without being rejected first.

## Verification Note
Confirmed the underlying mechanics (pattern allows '0'; buildSuspenseBridgeLeg would return null on a zero-derived amount) directly in the code. IMPORTANT CLARIFICATION not fully surfaced in the original candidate: this describes what WOULD happen absent a guard — but requestSchema.ts's M-2 .refine() (verified above as 'm2-exchange-rate-must-be-positive') already rejects a zero crossRate with a 400 before it ever reaches buildSuspenseBridgeLeg, for any request going through the normal validated POST /payment-instructions endpoint. The expert-review finding is best read as documenting the RATIONALE for why M-2 exists (i.e., 'this is the failure mode M-2 prevents'), not as a live, currently-reachable bug in the validated request path. Kept CONFIRMED for the mechanics described, but the practical severity is lower than a literal reading suggests — added this caveat since the FX title list's own cross-domain entries (m2-exchange-rate-must-be-positive, m2-rate-gt-zero) already independently confirm the guard is in place and enforced pre-persistence.

## Source Evidence
- payment-component-expert-review.md M-2 (money.ts:16,41-46; suspenseBridge.ts:133-137)
- money.ts EXCHANGE_RATE_PATTERN (no lower-bound digit restriction)
- requestSchema.ts's M-2 .refine() (already confirmed above) — this is the guard that actually PREVENTS this scenario from reaching production

## Related Knowledge
- [[FX Processing]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
