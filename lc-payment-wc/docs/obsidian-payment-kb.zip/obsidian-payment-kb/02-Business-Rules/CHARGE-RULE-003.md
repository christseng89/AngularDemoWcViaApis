---
knowledge_id: CHARGE-RULE-003
title: "Each fee type has a distinct default settlement currency and a bank-defined menu of alternatives — but the 'trade-amount vs bank-income' split does not extend to Export Collection's Bill Credit as originally claimed"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - charges
  - confirmed
---

# CHARGE-RULE-003 — Each fee type has a distinct default settlement currency and a bank-defined menu of alternatives — but the 'trade-amount vs bank-income' split does not extend to Export Collection's Bill Credit as originally claimed

## Status
CONFIRMED

## Business Rule
The default currency offered for each charge is not uniform: Margin (LC Issue) defaults to the transaction/LC currency with TWD as the alternative; Commission (Issue/Confirmed), SWIFT Fee, and Nego's Collection Fee-equivalent default to TWD with the transaction/bill currency as the alternative; Advising Commission is a flat TWD fee with no rate at all ('No advRate — flat TWD 500 commission'); Nego 'Net to Exporter' defaults to TWD with the bill currency as an alternative. Export Collection's 'Bill Credit' (id: 'net') is DIFFERENT from what was originally claimed: it defaults to the bill currency (foreign), with TWD as the alternative — i.e. it follows the Margin/trade-amount pattern, not the Commission/TWD-default pattern. The overall banking logic still holds: charges representing the bank's own local-currency income/cost (Commission, SWIFT, Advising, Nego fee) default to TWD, while charges economically part of the underlying trade amount (Margin, Bill Credit/net proceeds) default to the transaction's own foreign currency.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
No worked numeric example available in the source evidence reviewed.

## Verification Note
Re-opened lc-collection.element.ts, which the original rule cited by name ('Export Collection's Bill Credit') but did not actually cite a file/line for. Found the claim was backwards: Bill Credit's ChargeItem is constructed with ccy: ccy (= this._form.billCurrency, foreign) and ccyOptions: [ccy, 'TWD'] — i.e. it defaults to the foreign bill currency, not TWD. Corrected the statement accordingly; kept status CONFIRMED since the corrected, evidence-backed version of the rule (including the broader bank-income-vs-trade-amount theory) is fully supported by the code, and the correction actually strengthens rather than weakens the stated business logic (Bill Credit behaves like Margin, an underlying-trade-amount charge, exactly as the theory would predict).

## Source Evidence
- lc-issue.element.ts lines 44-56 (_initCharges: Margin ccy=lcCurrency/ccyOptions=[ccy,'TWD']; Commission and SWIFT ccy='TWD'/ccyOptions=['TWD',ccy])
- lc-advise.element.ts lines 33,44-52 ('No advRate — flat TWD 500 commission'; ccy='TWD')
- lc-nego.element.ts lines 47-56 (Net to Exporter ccy='TWD'/ccyOptions=['TWD',ccy])
- lc-collection.element.ts lines 50-62 (Bill Credit 'net' item: ccy=ccy [billCurrency, foreign], ccyOptions=[ccy,'TWD'] — NOT TWD-default as originally claimed)

## Related Knowledge
- [[Charge Integration]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
