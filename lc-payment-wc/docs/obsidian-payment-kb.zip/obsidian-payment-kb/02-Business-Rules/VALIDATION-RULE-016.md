---
knowledge_id: VALIDATION-RULE-016
title: "H-2: submitted amounts must not exceed the currency's own decimal-place precision (Currency-API master); unknown currencies are skipped"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - validation
  - confirmed
---

# VALIDATION-RULE-016 — H-2: submitted amounts must not exceed the currency's own decimal-place precision (Currency-API master); unknown currencies are skipped

## Status
CONFIRMED

## Business Rule
Every monetary amount (leg amountTxCcy/amountAccountCcy, Suspense entry amount) is checked against knownMinorUnitsForCurrency for its OWN currency (amountTxCcy against transactionCurrency; amountAccountCcy against the leg's own currency; Suspense entry against its own currency). Submitting more decimal places than allowed is a 400. If a currency's minor-unit count is NOT known (knownMinorUnitsForCurrency returns undefined), the check is SKIPPED entirely rather than defaulting to 2dp. Merges 3 near-duplicate id_hints (h2-currency-minor-unit-scale/currency-minor-unit-validation-h2/h2-currency-minor-unit-validation) that all describe this identical rule from api-validation, fsd-architecture-docs, and validation-gap-docs sourcing. NOTE: this rule directly CONTRADICTS the older 'currency-minor-units-not-validated-on-input' claim (id_hint 58 in the candidate list, sourced from a 2026-08-09 expert-review doc) — see the separate CONFLICT entry below for that reconciliation.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
amountTxCcy '100.50' with currency JPY -> 400 '... has 2 decimal place(s) but currency JPY allows at most 0 (per the Currency master)'. amountTxCcy '1.234' with currency BHD (not in the known map) -> accepted.

## Verification Note
Confirmed by direct read of requestSchema.ts — this check is fully live in current code (see the CONFLICT entry below regarding the older gap-analysis doc that predates this implementation). Merged 2 duplicate FSD/gap-doc entries.

## Source Evidence
- microservices/payment-component/src/validation/requestSchema.ts lines 127-146 (checkScale, doc comment), lines 173-201 (applied to every debitLegs/creditLegs/suspenseBridge amount)
- test/unit/validation/requestSchema.test.ts: 'rejects amountTxCcy with more decimals than the transaction currency allows (JPY = 0)'; 'rejects an EUR amount with 3 decimal places (EUR = 2)'; 'rejects amountAccountCcy (native) with more decimals than the leg currency allows' (TWD); 'rejects a suspenseBridge entry amount with more decimals than its currency allows (JPY = 0)'; 'accepts an amount at exactly the currency minor-unit boundary (USD = 2)'; 'SKIPS the decimal check for a currency not in the Currency master ... a 3-dp BHD amount passes'
- analysis__Payment-OAS-FSD-en.docx.txt Appendix B, H-2 (line 134)
- analysis__Payment_Component_Calculation_Validation.docx.txt Hardening Review H-2 (line 375)

## Related Knowledge
- [[Request Validation]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
