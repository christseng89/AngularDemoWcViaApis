---
knowledge_id: VALIDATION-RULE-040
title: "valueDate is optional and never validated against back-value tolerance or a currency/RTGS business-day calendar"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - validation
  - confirmed
---

# VALIDATION-RULE-040 — valueDate is optional and never validated against back-value tolerance or a currency/RTGS business-day calendar

## Status
CONFIRMED

## Business Rule
valueDate on a payment instruction leg is optional (dateSchema.optional() in requestSchema.ts, only checking ISO YYYY-MM-DD format) and passes through to SWIFT message generation unvalidated — not checked for excessive back-valuing, and not checked against a currency- or RTGS-specific business-day calendar.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
n/a — an absence-of-validation finding.

## Verification Note
Confirmed by direct re-read of requestSchema.ts — valueDate genuinely has only the ISO-date-format check (dateSchema), no back-value or business-day-calendar logic exists anywhere in the file. Unlike the H-2 rule above, this gap-analysis finding is STILL accurate against current code (no later hardening change addressed it) — correctly remains CONFIRMED, not a stale claim.

## Source Evidence
- microservices/payment-component/src/validation/requestSchema.ts line 57 (`valueDate: dateSchema.optional()` — only a regex format check, no business-day/back-value logic anywhere in the file)
- docs/payment-component-expert-review.md M-5 (lines 198-201): 'valueDate on a payment instruction is optional and passes through to SWIFT message generation unvalidated'

## Related Knowledge
- [[Request Validation]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
