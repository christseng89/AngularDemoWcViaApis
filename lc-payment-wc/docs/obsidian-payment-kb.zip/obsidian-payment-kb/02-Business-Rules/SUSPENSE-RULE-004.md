---
knowledge_id: SUSPENSE-RULE-004
title: "SuspenseEntry.sourceComponent/balanceModule (server) and SuspenseBridgeEntry.sourceComponent/balanceModule (client wire type) are pure provenance/audit metadata — they never change leg expansion, have zero server-side validation/posting consequence, and never trigger Charge/Liability Voucher generation (that stream was removed entirely in v1.6.0)"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - suspense
  - confirmed
---

# SUSPENSE-RULE-004 — SuspenseEntry.sourceComponent/balanceModule (server) and SuspenseBridgeEntry.sourceComponent/balanceModule (client wire type) are pure provenance/audit metadata — they never change leg expansion, have zero server-side validation/posting consequence, and never trigger Charge/Liability Voucher generation (that stream was removed entirely in v1.6.0)

## Status
CONFIRMED

## Business Rule
A sourceComponent-tagged entry (e.g. sourceComponent:'BALANCE', balanceModule:'IBL') expands byte-for-byte identically to an untagged one — same accountNo, accountType, amount — and produces only a SETTLEMENT-type accountEntry, never CHARGE or LIABILITY. sourceComponent/balanceModule are accepted and type-validated (must be valid enum members) but trigger no cross-field consistency check; a v1.5.0-era SUSPENSE_CONTEXT_CONFLICT check was removed in v1.6.0.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
n/a — metadata-only field, confirmed via expansion equality test, not a numeric worked example.

## Verification Note
MERGED three near-duplicate candidates (original id_hints: sourceComponent-provenance-only [group=suspense], suspense-provenance-no-validation-consequence [group=api-validation], suspense-bridge-entry-provenance-metadata-only [group=angular-services]) into one rule, since all three assert the identical fact at different code layers (server domain logic, server types+validation+route test, client wire-type duplicate). Verified every cited file and test name directly — all present and accurate. Status: CONFIRMED.

## Source Evidence
- suspenseBridge.test.ts lines 167-173 'a sourceComponent-tagged entry expands exactly like an untagged one — the tag is pure provenance metadata (v1.5.0/v1.6.0)'
- src/types.ts lines 121-143 (SuspenseEntry interface, sourceComponent doc comment: 'does NOT trigger any additional Charge/Liability Voucher generation... SUSPENSE_CONTEXT_CONFLICT check... removed v1.6.0')
- src/validation/requestSchema.ts: suspenseEntrySchema accepts sourceComponent/balanceModule as optional enums with no cross-field superRefine check on them
- test/unit/routes/paymentInstructions.test.ts line 97 'a sourceComponent-tagged suspenseBridge entry ... produces only a SETTLEMENT entry' (asserts every accountEntries[].voucherType === 'SETTLEMENT')
- test/unit/validation/requestSchema.test.ts lines 349, 369, 374 (accepts BALANCE/IBL-EBL; throws for invalid sourceComponent/balanceModule enum values)
- src/app/payment-component/payment-component.types.ts lines 89-114 (client-side SuspenseBridgeEntry doc comment, independently duplicated, same claim)

## Related Knowledge
- [[Suspense Account]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
