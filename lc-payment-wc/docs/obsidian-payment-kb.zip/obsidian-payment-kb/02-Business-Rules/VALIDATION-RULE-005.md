---
knowledge_id: VALIDATION-RULE-005
title: "previewClassification never throws on an unbalanced request — imbalance is a normal in-progress UI state"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - validation
  - confirmed
---

# VALIDATION-RULE-005 — previewClassification never throws on an unbalanced request — imbalance is a normal in-progress UI state

## Status
CONFIRMED

## Business Rule
Unlike confirmPaymentInstruction's Step 1 (validateDrCrBalance, which throws BusinessValidationError on imbalance), previewClassification always returns a result — balance.balanced is a boolean flag with a signed difference, computed for live onChange input from a Formly form where a not-yet-balanced state is expected and normal.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
previewClassification([{CUSTOMER,100}],[{NOSTRO,80}]) -> balance.balanced=false, balance.difference='20', and accountEntries still has length 2 (no throw).

## Verification Note
Confirmed by direct read — classifyPreview.ts's previewClassification has no throw statement at all, structurally impossible to throw on imbalance.

## Source Evidence
- microservices/payment-component/src/domain/classifyPreview.ts top doc comment (lines 19-22) and function body (no throw path at all, just difference.abs().lessThanOrEqualTo(toleranceAbs))
- test/unit/domain/classifyPreview.test.ts: 'reports balanced=false with the correct signed difference when totals mismatch, and never throws'; 'produces entries even when the legs are unbalanced (never throws)'

## Related Knowledge
- [[Request Validation]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
