---
knowledge_id: ARCH-RULE-040
title: "The 10 LC Payment widgets communicate purely via string HTML attributes, not framework-specific object props, for framework portability"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - architecture
  - confirmed
---

# ARCH-RULE-040 — The 10 LC Payment widgets communicate purely via string HTML attributes, not framework-specific object props, for framework portability

## Status
CONFIRMED

## Business Rule
Each widget is a plain JS/TS class extending HTMLElement, registered via customElements.define. Communication with the outside world happens through HTML attributes (strings), not framework-specific props — e.g. <journal-entry entries='[...]'> takes one JSON-encoded attribute; attributeChangedCallback re-parses and re-renders whenever the attribute changes. This string-based contract is what makes the same unmodified bundle consumable identically from plain HTML, React, Vue, and Angular.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
No worked numeric example available in the source evidence reviewed.

## Verification Note
Confirmed verbatim against the manual text. Unchanged.

## Source Evidence
- converted/docs__LC-Payment-WC-User-Manual-en.docx.txt lines 18, 26-27, directly re-read: 'Every widget is a plain JavaScript/TypeScript class that extends the browser-native HTMLElement and registers itself with the browser via customElements.define(tag, class) ... Web Components communicate with the outside world through HTML attributes (strings), not framework-specific object props ... The element's attributeChangedCallback re-parses the JSON and re-renders whenever the attribute changes.'

## Related Knowledge
- [[Payment Architecture]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
