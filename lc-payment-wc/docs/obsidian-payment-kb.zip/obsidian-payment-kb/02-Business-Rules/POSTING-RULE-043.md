---
knowledge_id: POSTING-RULE-043
title: "Per-currency balance is hard-enforced via the FX Exchange account as a self-balancing pair — an earlier finding that this was ungoverned was withdrawn"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - accounting
  - confirmed
---

# POSTING-RULE-043 — Per-currency balance is hard-enforced via the FX Exchange account as a self-balancing pair — an earlier finding that this was ungoverned was withdrawn

## Status
CONFIRMED

## Business Rule
Per-currency balance is hard-enforced because every cross-currency conversion must flow through the FX Exchange account as a self-balancing pair, so each currency's own Dr = Cr holds by construction, while aggregate V8 still catches genuine discrepancies. An earlier draft finding that this was ungoverned was withdrawn after team review.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
No worked numeric example available in the source evidence reviewed.

## Verification Note
Directly corroborated by reading buildFxPair() in suspenseBridge.ts this pass — the function is literally named and documented as producing a self-balancing pair, matching the claim's mechanism exactly.

## Source Evidence
- payment-component-expert-review.md, note above §2 and §6 (cited)
- Directly corroborated this pass by suspenseBridge.ts's buildFxPair() function (read in full), whose entire structure is explicitly a self-balancing Dr/Cr pair per currency ('ONE self-balancing FX Exchange pair for a single source...')

## Related Knowledge
- [[Accounting Model]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
