---
knowledge_id: ARCH-RULE-034
title: "[Proposed] Payment Component adoption should be scoped per PRODUCT+FUNCTION/EVENT, never declared wholesale per product"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - architecture
  - confirmed
---

# ARCH-RULE-034 — [Proposed] Payment Component adoption should be scoped per PRODUCT+FUNCTION/EVENT, never declared wholesale per product

## Status
CONFIRMED

## Business Rule
Architecture v4 recommendation: it is NOT advisable to declare 'full adoption of Payment Component' at the product level; the minimum unit of inventory/scoping must be product+function/event. Each candidate function must be checked individually for real Customer/Nostro money movement; a pure-charge voucher function with no genuine Customer/Nostro payment semantics should NOT be forced onto the Payment Component merely for architectural uniformity. This is grounded in the source-verified finding that GTEE has ~55 non-CE Confirm functions of which only 1 (Outward Claim Settlement) reaches the Payment Component.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Adoption matrix tags each candidate function Current/Target/Out-of-Scope with file:line evidence before estimating remediation effort

## Example
No worked numeric example available in the source evidence reviewed.

## Verification Note
Confirmed both the §11 recommendation text and the GTEE ~55-functions/1-reaches-PaymentComponent grounding figure directly. Unchanged.

## Source Evidence
- converted/analysis__Trade_Finance_Payment_Component_Architecture_v4-cn.docx.txt §11, lines 141-146, directly re-read: '不建議以「產品」為單位直接宣告全面採用 Payment Component；應以「產品+功能/Event」為最小盤點單位' plus the four bullet criteria
- converted/analysis__Payment-OAS-FSD-en.docx.txt line 104, directly re-read: 'Of the roughly 55 non-CE Confirm functions in this module, only one — settling a beneficiary's claim — reaches the shared Payment Component settlement layer'

## Related Knowledge
- [[Payment Architecture]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
