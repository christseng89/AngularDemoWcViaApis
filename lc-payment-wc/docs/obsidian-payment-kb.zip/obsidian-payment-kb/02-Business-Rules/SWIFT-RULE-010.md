---
knowledge_id: SWIFT-RULE-010
title: "SwiftMessage.status enum includes GENERATED/TRANSMITTED/FAILED but only PENDING is currently reachable; message-record creation is synchronous while actual SWIFT transmission is asynchronous and never implemented"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - swift
  - confirmed
---

# SWIFT-RULE-010 — SwiftMessage.status enum includes GENERATED/TRANSMITTED/FAILED but only PENDING is currently reachable; message-record creation is synchronous while actual SWIFT transmission is asynchronous and never implemented

## Status
CONFIRMED

## Business Rule
SwiftMessage records are created synchronously within the same POST /payment-instructions call and embedded in swiftMessages[], always with status: 'PENDING' (buildAdviceMessage/buildCoverMessage in swiftMessages.ts hardcode status: 'PENDING' with no other code path that ever changes it). The OAS's GET .../swift-messages endpoint description explicitly states the service never actually transitions a SwiftMessage's status past PENDING today — no transmission integration exists in src/. The GENERATED/TRANSMITTED/FAILED enum values, and the conceptual PENDING -> GENERATED -> TRANSMITTED/FAILED lifecycle described in the FSD, are reserved for a future integration, not currently reachable through any code path.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
n/a

## Verification Note
Merged near-duplicate candidates id_hint swift-status-lifecycle-pending-only-reachable and swift-transmission-async-status-tracking (both fsd/api-contracts groups, describing the same synchronous-creation/async-transmission design) into this one statement, keeping the stronger 'only PENDING is currently reachable' claim as primary since it is directly corroborated by the actual absence of any status-mutating code in src/. Re-read swiftMessages.ts to confirm no code path ever sets a status other than PENDING. CONFIRMED.

## Source Evidence
- src/domain/swiftMessages.ts lines 74-103 — both buildAdviceMessage and buildCoverMessage hardcode status: 'PENDING'; no other function in the file (or elsewhere in src/) ever writes to a SwiftMessage.status field
- analysis/Payment_component.yaml paths./payment-instructions/{instructionId}/swift-messages.get.description (lines ~310-325) — 'the service never actually transitions a SwiftMessage's status past PENDING today (no transmission integration exists in src/) — the GENERATED/TRANSMITTED/FAILED values are reserved for that future integration, not currently reachable'
- analysis__PaymentComponent-Microservice-FSD-zh.docx.txt line 350 and line 1017 — '(status transitions PENDING -> GENERATED -> TRANSMITTED/FAILED)', '報文傳輸狀態;建立時為 PENDING/GENERATED,實際送達 SWIFT 網路後續狀態變化可由 GET .../swift-messages 查詢最新值'
- payment-instructions-post.yaml does not include the GET endpoints at all (narrower extract) — corroborated only by Payment_component.yaml

## Related Knowledge
- [[SWIFT Messaging and Vouchers]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
