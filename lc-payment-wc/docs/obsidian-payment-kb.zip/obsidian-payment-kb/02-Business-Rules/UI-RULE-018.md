---
knowledge_id: UI-RULE-018
title: "Charge Voucher and Liability Voucher sections are plain voucherType filters with none of Settlement's display enhancements"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - ui
  - confirmed
---

# UI-RULE-018 — Charge Voucher and Liability Voucher sections are plain voucherType filters with none of Settlement's display enhancements

## Status
CONFIRMED

## Business Rule
chargeEntries/liabilityEntries are simple filters on accountEntries by voucherType ('CHARGE'/'LIABILITY') with no zero-amount exclusion, no FX-pair grouping/reordering, and no currency-scale amount formatting.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
n/a

## Verification Note
Confirmed against source lines 322-327 — no zero-amount filter, no grouping, no formatAmount usage present, matching the claim. Did not independently verify the .html template's literal interpolation (`{{ e.amount }}`), but the .ts-side asymmetry with settlementEntries/formatAmount is directly confirmed and sufficient to support the rule.

## Source Evidence
- response-viewer.component.ts lines 322-327: `get chargeEntries() { return (this.accountEntries ?? []).filter((e) => e.voucherType === 'CHARGE'); }` and the LIABILITY mirror, with no amount filter or formatAmount() call

## Related Knowledge
- [[Payment Component Simulator UI]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
