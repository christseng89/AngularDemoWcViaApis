---
knowledge_id: ARCH-RULE-015
title: "Any edit to the header form, leg allocators, or Suspense entries triggers a single shared 400ms-debounced live recompute (dryRun preview or classify)"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - architecture
  - confirmed
---

# ARCH-RULE-015 — Any edit to the header form, leg allocators, or Suspense entries triggers a single shared 400ms-debounced live recompute (dryRun preview or classify)

## Status
CONFIRMED

## Business Rule
selectCase() subscribes to merge(this.form.valueChanges, this.legsChanged$) piped through debounceTime(400) then switchMap(() => runPreview(...)). legsChanged$ is manually .next()'d from onDebitLegsChange/onCreditLegsChange/onSuspenseDebitEntriesChange/onSuspenseCreditEntriesChange/onTransactionCurrencyInput/onTransactionAmountInput, unifying every source of change into one debounced pipeline so rapid successive edits only trigger one API round-trip.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
No worked numeric example available in the source evidence reviewed.

## Verification Note
Confirmed directly against the file (the debounceTime(400) call and merge() construction are both present exactly as described).

## Source Evidence
- src/app/payment-component/business-case-runner.component.ts line 654-658, directly re-read: `this.previewSub = merge(this.form.valueChanges.pipe(map(() => undefined)), this.legsChanged$).pipe(debounceTime(400), switchMap(() => this.runPreview(businessCase))).subscribe();`

## Related Knowledge
- [[Payment Architecture]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
