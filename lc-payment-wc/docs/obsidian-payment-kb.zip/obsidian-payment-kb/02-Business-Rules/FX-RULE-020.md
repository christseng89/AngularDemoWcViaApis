---
knowledge_id: FX-RULE-020
title: "The Debit/Credit FX Conversion Pair preview panel suppresses its naive per-row conversion for any currency that also has a matching-side Suspense entry"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - fx
  - confirmed
---

# FX-RULE-020 — The Debit/Credit FX Conversion Pair preview panel suppresses its naive per-row conversion for any currency that also has a matching-side Suspense entry

## Status
CONFIRMED

## Business Rule
filterFxPairsNettedBySuspense() removes both legs of a leg-allocator-computed FX Conversion Pair for any currency that appears in the corresponding side's Suspense entries, because the server may already have netted that exposure differently and the authoritative result is already reflected in the Settlement Vouchers table. A foreign-currency leg with NO Suspense entry in its currency is unaffected.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
No worked numeric example available in the source evidence reviewed.

## Verification Note
Confirmed the method and its call sites exist exactly as described by grepping business-case-runner.component.ts. Did not re-read the full spec file's test assertions line-by-line, but the method signature and its two call sites match the claim structurally. No status change.

## Source Evidence
- business-case-runner.component.ts filterFxPairsNettedBySuspense() at line 563, and its call sites (creditFxPairs/debitFxPairs getters) at lines 599/605

## Related Knowledge
- [[FX Processing]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
