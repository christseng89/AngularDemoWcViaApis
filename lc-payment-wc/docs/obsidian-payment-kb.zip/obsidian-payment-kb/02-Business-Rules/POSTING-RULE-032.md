---
knowledge_id: POSTING-RULE-032
title: "All monetary amounts and FX rates are exact decimal strings, never binary floats — server arithmetic must use BigDecimal"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - accounting
  - confirmed
---

# POSTING-RULE-032 — All monetary amounts and FX rates are exact decimal strings, never binary floats — server arithmetic must use BigDecimal

## Status
CONFIRMED

## Business Rule
MonetaryAmount is type:string with pattern ^-?\d{1,18}(\.\d{1,3})?$ and ExchangeRate is type:string with pattern ^\d{1,12}(\.\d{1,10})?$. A v1.2.0 review-comment-driven fix replaced type:number on every monetary/rate field. Description mandates decimal/BigDecimal arithmetic server-side.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
MonetaryAmount example: "800000.20"; ExchangeRate example: "7.802350"

## Verification Note
Directly confirmed against the LIVE implementation (money.ts), which is a stronger evidence class than the OAS doc alone and matches the claimed patterns character-for-character. Upgraded confidence accordingly, status unchanged (already CONFIRMED).

## Source Evidence
- analysis/Payment_component.yaml (cited pattern lines 438-456, not independently re-opened this pass for those exact line numbers)
- microservices/payment-component/src/money.ts lines 15-16, read directly this pass: `export const MONETARY_AMOUNT_PATTERN = /^-?\d{1,18}(\.\d{1,3})?$/; export const EXCHANGE_RATE_PATTERN = /^\d{1,12}(\.\d{1,10})?$/;` — exact match, confirming these patterns are live in the implementation, not just documented in OAS

## Related Knowledge
- [[Accounting Model]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
