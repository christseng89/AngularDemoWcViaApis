---
knowledge_id: TEST-RULE-001
title: "Registry leg defaults are either an exact reproduction of a cited FSD/regression scenario, or an illustrative BA-judgment starting point — distinguished per case in `note`"
domain: Payment
category: Business Rule
status: INFERRED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - testscenario
  - inferred
---

# TEST-RULE-001 — Registry leg defaults are either an exact reproduction of a cited FSD/regression scenario, or an illustrative BA-judgment starting point — distinguished per case in `note`

## Status
INFERRED

## Business Rule
business-case-registry.ts's top-of-file doc comment states this as an explicit design principle: 'where a citation names a specific FSD/regression-verified scenario, the default reproduces it exactly (noted per case). Elsewhere, defaults are an illustrative BA-judgment starting point, not a verbatim FSD scenario — every accountType is editable, which is the actual point.' Spot-checked cases confirm the two categories are real and distinguishable via each case's `note` field.

## Conditions
A case's `note` field either cites a specific FSD/regression scenario by name/section, or does not.

## Result
If cited, the default legs are claimed to reproduce that scenario exactly; if not cited, the defaults are an illustrative starting point only.

## Example
iplc-pay-accept-discount note (line 67): 'Default legs reproduce test/regression.ts §13.1 scenario 2 (DISCNT_FLG=YES, STL_FLG≠By Loan) exactly.' exco-payment note (line 120): 'Default legs are the exact values verified end-to-end in test/regression.ts's HTTP smoke test.' Both confirmed present verbatim, and test/regression.ts genuinely exists at microservices/payment-component/test/regression.ts. By contrast, iplc-pay-accept's note (line 57, 'Calls the Payment Component voucher-description routine directly inside ConfirmBusinessCall') and eplc-pay-accept's note (line 87, documents an unresolved FSD dual-prefix ambiguity) cite no regression scenario for their specific leg amounts — consistent with the illustrative category.

## Verification Note
Re-opened business-case-registry.ts and confirmed the doc comment's exact wording and all four sampled per-case notes match the claim precisely (quotes verified character-for-character). Kept as INFERRED (not upgraded to CONFIRMED) because the review sampled only 4 of 23 cases — whether every remaining case's note correctly self-labels its category was not independently traced against the underlying legacy SYF_*.js scripts. No downgrade needed; original status was already appropriately conservative.

## Source Evidence
- src/app/payment-component/business-case-registry.ts:9-14 (top-of-file doc comment) — read in full, quote confirmed accurate
- business-case-registry.ts:67 (iplc-pay-accept-discount note, verbatim FSD/regression citation)
- business-case-registry.ts:120 (exco-payment note, verbatim FSD/regression citation)
- business-case-registry.ts:57 (iplc-pay-accept note, no regression citation — illustrative)
- business-case-registry.ts:87-91 (eplc-pay-accept note, unresolved dual-prefix ambiguity, no regression citation)
- microservices/payment-component/test/regression.ts exists, confirming the citation target is real

## Related Knowledge
- [[Testing Methodology and Coverage]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
