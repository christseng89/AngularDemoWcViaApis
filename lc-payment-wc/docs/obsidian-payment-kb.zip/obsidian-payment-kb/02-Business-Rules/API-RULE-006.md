---
knowledge_id: API-RULE-006
title: "account-entries and swift-messages are read-only sub-resources of a persisted PaymentInstruction, never independently queryable, and 404 identically to the parent when the id is unknown"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - api
  - confirmed
---

# API-RULE-006 — account-entries and swift-messages are read-only sub-resources of a persisted PaymentInstruction, never independently queryable, and 404 identically to the parent when the id is unknown

## Status
CONFIRMED

## Business Rule
GET .../account-entries and .../swift-messages both look up the parent instruction by id first (same store.findById as the plain GET-by-id endpoint) and return 404 NOT_FOUND if it doesn't exist, before inspecting the sub-resource — so they are always accessed in the context of a specific confirmed instruction, never independently. The FSD frames these as audit/reconciliation-only, not part of the confirm flow.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
No worked numeric example available in the source evidence reviewed.

## Verification Note
Re-read routes/paymentInstructions.ts and confirmed all four cited tests exist with matching names/line positions. No change to status.

## Source Evidence
- microservices/payment-component/src/routes/paymentInstructions.ts: both GET sub-resource handlers (lines 90-114), top-of-file doc comment (lines 1-5) citing '§6.2 of the FSD — audit/reconciliation only'
- microservices/payment-component/test/unit/routes/paymentInstructions.test.ts: 'GET account-entries returns 404 for an unknown id' (line 216), 'GET swift-messages returns 404 for an unknown id' (line 236), 'GET account-entries returns 200 with the entries array' (208), 'GET swift-messages returns 200 with the messages array' (222)

## Related Knowledge
- [[Payment Instructions API]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
