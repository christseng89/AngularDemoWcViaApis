---
knowledge_id: VALIDATION-RULE-034
title: "AccountEntry.voucherType enum still includes CHARGE and LIABILITY even though v1.6.0 removed the ability to generate them"
domain: Payment
category: Business Rule
status: CONFLICT
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - validation
  - conflict
---

# VALIDATION-RULE-034 — AccountEntry.voucherType enum still includes CHARGE and LIABILITY even though v1.6.0 removed the ability to generate them

## Status
CONFLICT

## Business Rule
AccountEntry.voucherType is declared as enum [SETTLEMENT, CHARGE, LIABILITY] in both OAS files, but the v1.6.0 changelog (same files, and independently confirmed in confirmPaymentInstruction.ts's own top doc comment) states the §6.2 Charge Voucher and §6.3 Liability Voucher generation paths were removed entirely and the service now only ever produces SETTLEMENT entries. The schema enum was not narrowed to reflect this removal.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
n/a — schema-vs-documented-behavior mismatch, both sides confirmed present in the same files.

## Conflict Note
> [!warning] Sources disagree
> CONFIRMED CONFLICT (status correctly kept as CONFLICT, not downgraded): both halves of the disagreement — the still-broad enum and the v1.6.0 changelog's narrower claim — were directly re-read in both OAS files at the cited line numbers, and independently corroborated against the microservice's own source code doc comment, which confirms only SETTLEMENT entries are actually generated. This is a genuine, still-unresolved staleness gap in the OAS schema, not a misreading.

## Verification Note
CONFIRMED CONFLICT (status correctly kept as CONFLICT, not downgraded): both halves of the disagreement — the still-broad enum and the v1.6.0 changelog's narrower claim — were directly re-read in both OAS files at the cited line numbers, and independently corroborated against the microservice's own source code doc comment, which confirms only SETTLEMENT entries are actually generated. This is a genuine, still-unresolved staleness gap in the OAS schema, not a misreading.

## Source Evidence
- analysis/Payment_component.yaml line 839 (voucherType enum) vs. lines 83-88 (v1.6.0 changelog)
- analysis/payment-instructions-post.yaml line 887 (identical stale enum) vs. lines 94-112 (v1.6.0 changelog, matching text)
- microservices/payment-component/src/domain/confirmPaymentInstruction.ts lines 9-22 (top doc comment independently confirming only Settlement entries are ever generated post-v1.6.0)

## Related Knowledge
- [[Request Validation]]
- [[Business-Rule-Index]]
- [[Knowledge-Gaps]]
- [[Payment-Traceability-Matrix]]
