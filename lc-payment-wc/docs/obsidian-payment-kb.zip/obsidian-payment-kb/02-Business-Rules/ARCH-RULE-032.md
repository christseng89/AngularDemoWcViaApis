---
knowledge_id: ARCH-RULE-032
title: "[Proposed, NOT implemented] Charge Engine computes fees from Business Component's rate parameters; Payment Component only ever handles Collect Legs, never charge calculation"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - architecture
  - confirmed
---

# ARCH-RULE-032 — [Proposed, NOT implemented] Charge Engine computes fees from Business Component's rate parameters; Payment Component only ever handles Collect Legs, never charge calculation

## Status
CONFIRMED

## Business Rule
Architecture v4 proposal (not yet implemented in the analyzed baseline): Business Component generates business events/parameters but does NOT itself compute the fee amount. Charge Engine computes the actual fee from those parameters and produces currency/category-itemised Charge Legs; it does not produce GL entries and does not decide the actual collection mechanism. A new Charge Settlement Engine converts Charge Legs into Collect Legs per bank policy. Payment Component handles only Collect/Pay/Transfer/Refund/Return/Reverse against real Customer/Nostro endpoints. Accounting Engine produces the final Dr/Cr GL entries. This mirrors the CONFIRMED implemented boundary in the current Payment Component microservice.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Component responsibility diagram: Business Component -> Payment Instruction -> Payment Component; Business Component -> Business Event+Rate Params -> Charge Engine -> Charge Legs -> Charge Settlement Engine -> Collect Legs -> Payment Component(Collect) -> Accounting Engine -> GL

## Example
No worked numeric example available in the source evidence reviewed.

## Verification Note
Confirmed directly against the full §4 text and diagram. Unchanged.

## Source Evidence
- converted/analysis__Trade_Finance_Payment_Component_Architecture_v4-cn.docx.txt §4, lines 26-54, directly re-read (Chinese text and the full component-flow diagram both confirm the statement's every clause)

## Related Knowledge
- [[Payment Architecture]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
