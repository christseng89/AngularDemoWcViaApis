---
knowledge_id: CLASS-RULE-011
title: "N_A (non-user) modules carry no legs and must document the verification breadth behind the verdict"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - classification
  - confirmed
---

# CLASS-RULE-011 — N_A (non-user) modules carry no legs and must document the verification breadth behind the verdict

## Status
CONFIRMED

## Business Rule
Every N_A BusinessCaseConfig has an empty legs array and a required, populated moduleStats string summarizing how many Confirm functions/files were checked and how many touched PaymentDebit/PaymentCredit (always 0 for N_A) — giving the verdict an auditable evidence trail rather than a bare label.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
sblc-non-user moduleStats: '9 Confirm functions checked; 5... call the generic SYT_CHG_VOUCHER() charge routine, 4 call none; 0 touch PaymentDebit/PaymentCredit.'

## Verification Note
Confirmed directly — all 4 NA_CASES entries carry populated moduleStats strings as cited.

## Source Evidence
- src/app/payment-component/business-case-registry.spec.ts 'every N_A case has no legs and a populated moduleStats summary'
- src/app/payment-component/business-case-registry.ts NA_CASES entries lines 281-319, moduleStats fields e.g. cfnc-non-user line 289

## Related Knowledge
- [[Payment Instruction Classification]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
