---
knowledge_id: VALIDATION-RULE-036
title: "[Legacy, pre-microservice] Debit leg sum must not exceed the shared target total (Debit_Chk_Total_Pct)"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - validation
  - confirmed
---

# VALIDATION-RULE-036 — [Legacy, pre-microservice] Debit leg sum must not exceed the shared target total (Debit_Chk_Total_Pct)

## Status
CONFIRMED

## Business Rule
Each Debit leg edit re-sums every PaymentDebit leg's CPYT_DR_AMT_TXCCY (existing legs + the leg being added/edited − its own prior saved value) and rejects if the new sum exceeds the instruction-level CPYT_DR_TTL_AMT_TTLCCY target total, with an RPFM-only tolerance historically allowing the sum to exceed the target by up to 0.01.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
newSum(debit) ≤ CPYT_DR_TTL_AMT_TTLCCY, or for RPFM: 0 ≤ newSum(debit) − CPYT_DR_TTL_AMT_TTLCCY ≤ 0.01

## Verification Note
Confirmed exactly by direct read of the doc's §3.1 excerpt — this is a legacy (pre-microservice) rule, explicitly superseded in the actual service by V8 (see the merged v8-exact-balance entry above), but accurately documents the legacy source it was ported/deviated from.

## Source Evidence
- analysis__Payment_Component_Calculation_Validation.docx.txt §3.1 (lines 15-38), full source excerpt of Debit_Chk_Total_Pct() (SSSS_PaymentDebit.js:347-390) with the RPFM tolerance branch and formula spelled out

## Related Knowledge
- [[Request Validation]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
