---
knowledge_id: POSTING-RULE-022
title: "Once every row is amount-driven (no floating remainder), the LAST row's displayed % is forced to the exact complement, not independently rounded"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - accounting
  - confirmed
---

# POSTING-RULE-022 — Once every row is amount-driven (no floating remainder), the LAST row's displayed % is forced to the exact complement, not independently rounded

## Status
CONFIRMED

## Business Rule
When ensureRemainderRow() finds the split fully allocated by amount (amountRemaining ≤ 0, not negative), the last row's .pct is set to 100 − Σ(every other row's own .pct), a pure DISPLAY correction (amountTxCcy never touched). Skipped when genuinely over-allocated.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
Total 3, three equal legs of 1.00 each: displayed %s are 33.33 / 33.33 / 33.34, summing to exactly 100.

## Verification Note
Directly confirmed by reading the exact guard condition in ensureRemainderRow() — matches the claimed 'skipped when genuinely over-allocated' behavior.

## Source Evidence
- src/app/payment-component/leg-allocator.component.ts lines ~1226-1234, read directly: `if (this.rows.length > 0 && !amountRemaining.isNegative()) { ... }` guarding the % complement correction

## Related Knowledge
- [[Accounting Model]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
