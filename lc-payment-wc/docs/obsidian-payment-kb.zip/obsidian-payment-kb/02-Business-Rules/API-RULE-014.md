---
knowledge_id: API-RULE-014
title: "Idempotency key = (originModule, mainRef, sequence); a resubmission with the identical natural key replays the ORIGINAL result unchanged (200), a new key creates a new instruction (201); sequence is required specifically because a partial payment against the same transaction must not be misidentified as a resubmission"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - api
  - confirmed
---

# API-RULE-014 — Idempotency key = (originModule, mainRef, sequence); a resubmission with the identical natural key replays the ORIGINAL result unchanged (200), a new key creates a new instruction (201); sequence is required specifically because a partial payment against the same transaction must not be misidentified as a resubmission

## Status
CONFIRMED

## Business Rule
A resubmission matching an existing payment instruction's (originModule, mainRef, sequence) returns the existing result with HTTP 200 and does NOT re-trigger GL/SWIFT output (none of the five Confirm steps re-run); a new natural key creates a new instruction with HTTP 201. sequence (= Event Time) is a required field specifically because omitting it degrades the key to (originModule, mainRef) alone, which would misidentify a second partial payment against the same transaction as a resubmission and silently skip it.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
200 (replay) vs 201 (new instruction)

## Example
No worked numeric example available in the source evidence reviewed.

## Verification Note
Merged four near-duplicate candidate rules that all state the same core fact from different source documents (id_hints: 'idempotency-natural-key' from api-contracts, 'idempotency-natural-key' [second occurrence] and 'idempotency-natural-key' from fsd-architecture-docs, and the base statement embedded in 'idempotency-payload-fingerprint-conflict-c2'/'c2-payload-aware-idempotency'). Re-read analysis__Payment-OAS-FSD-en.docx.txt §7.6 directly and confirmPaymentInstruction.ts's Step 0 implementation directly — both confirm the statement exactly. No change to status; this is the base rule, kept separate from the C-2 payload-fingerprint refinement below since that is a materially different, later-added behavior (409 on payload mismatch), not the same rule.

## Source Evidence
- analysis/Payment_component.yaml paths./payment-instructions.post.description (lines 214-218), responses 200/201 (lines 225-237)
- analysis/payment-instructions-post.yaml PaymentInstructionConfirmRequest.sequence description (per original citation)
- docs (converted) analysis__Payment-OAS-FSD-en.docx.txt §7.6 (lines 66-67), §7.6 header text re-read directly: 'A resubmission of the same (originModule, mainRef, sequence) natural key ... returns the ORIGINAL confirmed result unchanged (HTTP 200) ... A genuinely new natural key ... creates a new instruction (HTTP 201).'
- analysis__PaymentComponent-Microservice-FSD-zh.docx.txt §6.1 design principle and sequence field description (per original citation, not independently re-read in this pass but consistent with the EN doc)
- microservices/payment-component/src/domain/confirmPaymentInstruction.ts: Step 0 (lines 113-140) — `store.find(originModule, mainRef, sequence)` returns existing instruction with `created: false` if found

## Related Knowledge
- [[Payment Instructions API]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
