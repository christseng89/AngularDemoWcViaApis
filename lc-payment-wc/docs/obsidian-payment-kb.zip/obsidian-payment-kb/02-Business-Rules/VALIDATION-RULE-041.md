---
knowledge_id: VALIDATION-RULE-041
title: "The classify preview endpoint still requires at least one credit leg, inconsistent with the relaxed Confirm rule"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - validation
  - confirmed
---

# VALIDATION-RULE-041 — The classify preview endpoint still requires at least one credit leg, inconsistent with the relaxed Confirm rule

## Status
CONFIRMED

## Business Rule
classifyRequestSchema (used by POST /payment-instructions/classify) keeps .min(1) on creditLegs unconditionally, so a legitimate chargeComponentBridge case with an empty credit side cannot use the preview endpoint even though the Confirm endpoint was relaxed (v1.10.1) to allow empty creditLegs when suspenseBridge contributes the credit-direction leg. This remains a live, unfixed inconsistency in the current code.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
n/a — an endpoint-inconsistency finding.

## Verification Note
Re-verified against the CURRENT requestSchema.ts (unlike the H-2 finding above, this one is still accurate) — classifyRequestSchema's creditLegs.min(1) is unconditional, with no superRefine relaxation, confirmed by direct read at lines 214-218. Correctly remains CONFIRMED as a still-live gap, added to gaps_found as well since it appears not to have been fixed alongside the related v1.10.1 Confirm-endpoint change.

## Source Evidence
- microservices/payment-component/src/validation/requestSchema.ts lines 214-218 (classifyRequestSchema: `creditLegs: z.array(paymentLegInputSchema).min(1, 'creditLegs must contain at least 1 item')` — unconditional, unlike the confirm-request schema's conditional superRefine)
- docs/payment-component-expert-review.md L-2 (line 252: 'classify preview requires ≥1 credit leg... requestSchema.ts:130-134 keeps .min(1)')

## Related Knowledge
- [[Request Validation]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
