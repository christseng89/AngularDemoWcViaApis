---
knowledge_id: POSTING-RULE-005
title: "One Settlement AccountEntry per submitted leg, generated unconditionally (merged with 'account-entry-unconditional-per-leg')"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - accounting
  - confirmed
---

# POSTING-RULE-005 — One Settlement AccountEntry per submitted leg, generated unconditionally (merged with 'account-entry-unconditional-per-leg')

## Status
CONFIRMED

## Business Rule
buildSettlementEntries() maps every leg in debitLegs/creditLegs 1:1 to a voucherType='SETTLEMENT' AccountEntry with drCrIndicator derived purely from which array (side) it came from. This generation is unconditional, independent of any upstream classification result.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
Two debit legs (accountNo 'A' and 'B') -> two SETTLEMENT entries, one per leg

## Verification Note
Confirmed directly by reading accountEntries.ts — `legs.map((leg) => ...)` with no filtering/gating confirms unconditional 1:1 mapping. Same rule as fsd-architecture-docs' 'account-entry-unconditional-per-leg' and validation-gap-docs' related claims; treated as the same confirmed fact from two evidence sources (code + FSD), not merged into one entry since the FSD-doc version is listed separately below under its own id (see 'account-entry-unconditional-per-leg-fsd').

## Source Evidence
- src/domain/accountEntries.ts:1-17 top doc comment; lines 87-107 buildSettlementEntries()
- accountEntries.test.ts 'maps one entry per leg for multiple legs', 'returns an empty array for no legs' (cited)

## Related Knowledge
- [[Accounting Model]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
