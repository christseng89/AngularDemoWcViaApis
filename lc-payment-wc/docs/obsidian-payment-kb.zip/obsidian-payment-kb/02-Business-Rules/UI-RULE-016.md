---
knowledge_id: UI-RULE-016
title: "A client-only FX Conversion Pair overlay is required in Currency View so a real foreign-currency leg doesn't display as falsely one-sided/Unbalanced"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - ui
  - confirmed
---

# UI-RULE-016 — A client-only FX Conversion Pair overlay is required in Currency View so a real foreign-currency leg doesn't display as falsely one-sided/Unbalanced

## Status
CONFIRMED

## Business Rule
A real settlement leg whose own currency differs from the transaction currency carries its full amount denominated only in the transaction currency on the wire; without a matching counterpart entry, that leg's own foreign currency would show up in Currency View with only one Dr/Cr side ever populated, always reading as Unbalanced even though nothing is actually wrong. debitFxPairs/creditFxPairs — the leg-allocator component's client-side-only fxPairs getter, never sent to or returned by the microservice — supplies the missing counterpart row so both the transaction currency and the real leg's own foreign currency balance correctly in Currency View.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
EUR 9232.95 debit + USD 10000.00 credit real legs, plus overlay pair -> both EUR and USD groups show Balanced; without the overlay, EUR shows Debit 9232.95/Credit 0.00 and USD shows Debit 0.00/Credit 10000.00, both Unbalanced.

## Verification Note
Confirmed against source doc comment lines 239-262 and the currencyGroups implementation which merges debitFxPairs/creditFxPairs into the same per-currency buckets as real entries.

## Source Evidence
- response-viewer.component.ts lines 239-262 (doc comment explaining why the overlay is needed and how double-counting is avoided via filterFxPairsNettedBySuspense upstream)

## Related Knowledge
- [[Payment Component Simulator UI]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
