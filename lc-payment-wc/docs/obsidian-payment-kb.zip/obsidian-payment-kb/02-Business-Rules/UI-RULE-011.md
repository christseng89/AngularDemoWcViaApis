---
knowledge_id: UI-RULE-011
title: "The emitted (wire) leg array sorts a transaction-currency-matching leg first, independent of the internal row order"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - ui
  - confirmed
---

# UI-RULE-011 — The emitted (wire) leg array sorts a transaction-currency-matching leg first, independent of the internal row order

## Status
CONFIRMED

## Business Rule
emit() sorts the outgoing PaymentLegInput[] so a leg whose OWN currency matches the shared transactionCurrency appears first (a readability nicety for anything that iterates the array, e.g. the Settlement Vouchers table) — this is purely a DISPLAY/ordering choice on the OUTPUT array and never mutates this.rows' own internal order. Since v1.10.0 the server derives transactionCurrency from an explicit request field rather than legs[0].currency, so this ordering is cosmetic, not functionally required.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
n/a

## Verification Note
Confirmed exactly against source lines 1284-1288.

## Source Evidence
- emit() doc comment lines 1238-1250 and sort logic lines 1284-1288: `.sort((a,b) => { const aMatch = a.currency === this.transactionCurrency; ... })`

## Related Knowledge
- [[Payment Component Simulator UI]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
