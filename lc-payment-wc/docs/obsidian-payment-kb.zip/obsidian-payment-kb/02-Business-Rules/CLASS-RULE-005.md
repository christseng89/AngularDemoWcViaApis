---
knowledge_id: CLASS-RULE-005
title: "Classification is informational only — it never blocks the Confirm flow or gates Account Entry generation"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - classification
  - confirmed
---

# CLASS-RULE-005 — Classification is informational only — it never blocks the Confirm flow or gates Account Entry generation

## Status
CONFIRMED

## Business Rule
The classification step (Step 2 of Confirm, §4) computes and records paymentComponentRelated but never throws and never conditions whether Settlement Account Entries (Step 4) are produced — entry generation is unconditional per §6.1/§7.4, independent of the classification result. Merges candidates 4 and 30.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
n/a — structural/negative rule.

## Verification Note
Directly confirmed by reading confirmPaymentInstruction.ts — the classification result is computed at line 180 and the accountEntries array is built unconditionally starting line 190, with no branch on classification.paymentComponentRelated in between. Merged candidate 30 (api-contracts group, same claim from the OAS) into this entry.

## Source Evidence
- microservices/payment-component/src/domain/classification.ts top comment lines 19-21
- microservices/payment-component/src/domain/confirmPaymentInstruction.ts lines 179-190 ('Step 2 (§4): classification — informational only, never blocks, never gates step 4.' then Step 4 builds accountEntries unconditionally)
- analysis/Payment_component.yaml ClassificationResult description lines 803-805 and AccountEntry description lines 831-835
- converted/analysis__Payment-OAS-FSD-en.docx.txt §7.4 line 63

## Related Knowledge
- [[Payment Instruction Classification]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
