---
knowledge_id: FX-RULE-009
title: "An FX Exchange pair is always two self-balancing legs: an 'Other Ccy site' leg (foreign-currency-denominated, opposite direction to the source) and a 'Trx Ccy site' leg (transaction-currency-denominated, same direction as the source)"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - fx
  - confirmed
---

# FX-RULE-009 — An FX Exchange pair is always two self-balancing legs: an 'Other Ccy site' leg (foreign-currency-denominated, opposite direction to the source) and a 'Trx Ccy site' leg (transaction-currency-denominated, same direction as the source)

## Status
CONFIRMED

## Business Rule
buildFxPair generates otherCcySiteLeg (account 'FX Exchange {transactionCurrency}{suffix}', currency=foreign currency, amount=ownCcyAmount rounded to that currency's own minor units) and trxCcySiteLeg (account 'FX Exchange {currency}{suffix}', currency=transactionCurrency, amount=trxCcyAmount rounded to the transaction currency's minor units). For sourceDirection CREDIT: otherCcySiteLeg is DEBIT, trxCcySiteLeg is CREDIT (and vice versa for DEBIT). Both legs of the pair always carry the identical amountTxCcy value.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
No worked numeric example available in the source evidence reviewed.

## Verification Note
Confirmed by direct code read — the CREDIT/DEBIT direction-swap logic and identical amountTxCcy on both legs (trxEquivalent used for both) are exactly as claimed. No status change.

## Source Evidence
- suspenseBridge.ts lines 183-219 (buildFxPair)

## Related Knowledge
- [[FX Processing]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
