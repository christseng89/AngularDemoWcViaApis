---
knowledge_id: FX-RULE-026
title: "A row's FX rate is auto-populated from GET /api/fx/rates when its currency first diverges, but stays freely editable and is left untouched if no rate is found"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - fx
  - confirmed
---

# FX-RULE-026 — A row's FX rate is auto-populated from GET /api/fx/rates when its currency first diverges, but stays freely editable and is left untouched if no rate is found

## Status
CONFIRMED

## Business Rule
applyFxRate() calls FxRateService.rates() and computes a cross rate for (transactionCurrency, row.currency), rounding to 6dp; if the backend has no rate for that pair, the existing row.rate is silently left unchanged rather than reset. The row's Exchange Account No. is simultaneously defaulted to 'FX Exchange {transactionCurrency}'.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
No worked numeric example available in the source evidence reviewed.

## Verification Note
Confirmed directly: `if (cross !== null) { row.rate = ... }` — when cross is null (crossRate returns null), row.rate is simply never touched, exactly as claimed. No status change.

## Source Evidence
- leg-allocator.component.ts applyFxRate() lines 587-596 (read in full)

## Related Knowledge
- [[FX Processing]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
