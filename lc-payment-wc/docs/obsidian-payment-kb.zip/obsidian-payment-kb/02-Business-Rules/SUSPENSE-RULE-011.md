---
knowledge_id: SUSPENSE-RULE-011
title: "Suspense entries in the same foreign currency are FX-converted and rounded PER ENTRY, not summed-then-converted-once — mirrors the server's buildSuspenseBridgeLeg, which also rounds per entry"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - suspense
  - confirmed
---

# SUSPENSE-RULE-011 — Suspense entries in the same foreign currency are FX-converted and rounded PER ENTRY, not summed-then-converted-once — mirrors the server's buildSuspenseBridgeLeg, which also rounds per entry

## Status
CONFIRMED

## Business Rule
When multiple Suspense entries share a currency, each is independently converted to the transaction currency and rounded to that currency's decimal scale before being summed (in suspenseCurrencyBuckets()). Rounding the combined raw total once instead can disagree by a minor unit whenever a currency has more than one entry.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
Suspense Credit EUR 60 + EUR 40 at rate 2: per-entry = round(60*2)+round(40*2) = 120+80 = 200 (a non-clean rate would diverge from a combined round(100*2))

## Verification Note
Read suspenseCurrencyBuckets() (lines 387-414) directly — confirms per-entry conversion into a Decimal-typed map, exactly as claimed. Confirmed cited test name. Status unchanged: CONFIRMED.

## Source Evidence
- business-case-runner.component.ts suspenseAdjustment()/suspenseCurrencyBuckets() doc comments (lines 320-414, explicitly: 'Converts PER ENTRY (not per currency-bucket) to mirror domain/suspenseBridge.ts's buildSuspenseBridgeLeg exactly')
- business-case-runner.component.spec.ts line 317 'multiple Suspense entries in the SAME foreign currency are converted and summed PER ENTRY, mirroring buildSuspenseBridgeLeg exactly'

## Related Knowledge
- [[Suspense Account]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
