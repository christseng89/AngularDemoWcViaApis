---
knowledge_id: ARCH-RULE-017
title: "The component only hard-resets to a single 100% row on a genuine business-case switch (caseKey change), never on a same-case re-seed of Total Amount/Currency"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - architecture
  - confirmed
---

# ARCH-RULE-017 — The component only hard-resets to a single 100% row on a genuine business-case switch (caseKey change), never on a same-case re-seed of Total Amount/Currency

## Status
CONFIRMED

## Business Rule
ngOnChanges treats caseKey as the ONLY signal for 'the parent selected a genuinely different business case' — a caseKey change triggers reset() (back to one 100% row, skipped on the very first/init binding). initialTotalAmount/initialCurrency are DERIVED, live values that legitimately change on the SAME case too (e.g. because the user edited a row's own currency, which changes what the live transaction currency resolves to upstream); a same-case change to either instead rescales/resyncs the EXISTING rows in place, preserving the user's split and any per-row currency divergence rather than silently reverting it.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
No worked numeric example available in the source evidence reviewed.

## Verification Note
Confirmed directly, including the firstChange guard and the explicit regression rationale in the doc comment (silently reverting a user's currency edit was the bug this design avoids).

## Source Evidence
- src/app/payment-component/leg-allocator.component.ts lines 185-205 (@Input caseKey doc comment) and lines 309-320 (ngOnChanges body), directly re-read: `if (changes['caseKey']) { if (!changes['caseKey'].firstChange) this.reset(); return; } // Same case — ... Rescale/resync the EXISTING rows in place rather than reset()ing`

## Related Knowledge
- [[Payment Architecture]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
