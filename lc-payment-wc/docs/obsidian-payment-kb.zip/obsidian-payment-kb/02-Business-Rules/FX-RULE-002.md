---
knowledge_id: FX-RULE-002
title: "A CREDIT-side Suspense bucket is deliberately NOT netted against a matching real credit leg — each source gets its own independent gross FX pair (v1.8.0)"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - fx
  - confirmed
---

# FX-RULE-002 — A CREDIT-side Suspense bucket is deliberately NOT netted against a matching real credit leg — each source gets its own independent gross FX pair (v1.8.0)

## Status
CONFIRMED

## Business Rule
Unlike the DEBIT-side (v1.9.0), a suspenseBridge.creditEntries bucket's real matching-currency creditLegs are on the SAME actual direction as the generated Suspense credit leg (both CREDIT) — a real leg here is an independent exposure that merely happens to share a currency, not 'the same money'. Netting would silently break per-currency balance. So each source (the real leg, and the Suspense entry) produces its own gross-sized FX Exchange pair via a separate, unconditional code path (lines 375-396), reusing that source's own already-computed amountTxCcy verbatim rather than re-deriving a combined figure.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
Real EUR credit leg 108.31/100 + Suspense creditEntries EUR 100 (rate 1.0831) -> two pairs: FX Exchange USD - Suspense (100) / FX Exchange EUR - Suspense (108.31) AND FX Exchange EUR (108.31, the leg's own figure, NOT (100+100)*rate).

## Verification Note
Confirmed directly against the code: the side==='CREDIT' branch falls through past the DEBIT-only netting block (which `continue`s) to the unconditional two-pair logic at lines 375-396. No status change.

## Source Evidence
- microservices/payment-component/src/domain/suspenseBridge.ts lines 375-396 (unconditional Suspense pair + leg pair, no netting)
- test/unit/domain/confirmPaymentInstruction.test.ts 'v1.8.0 CREDIT-side per-source pairs' test
- suspenseBridge.ts top doc comment lines 54-76, explicitly explaining why CREDIT-side netting is unsafe

## Related Knowledge
- [[FX Processing]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
