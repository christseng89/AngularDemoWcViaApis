---
knowledge_id: ARCH-RULE-041
title: "The Payment Component Simulator is deliberately excluded from the framework-free Web Components bundle and only exists inside the full Angular app"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - architecture
  - confirmed
---

# ARCH-RULE-041 — The Payment Component Simulator is deliberately excluded from the framework-free Web Components bundle and only exists inside the full Angular app

## Status
CONFIRMED

## Business Rule
Unlike the 10 catalog widgets, the Simulator (app-business-case-runner) depends on @ngx-formly/core and Angular's HttpClient, so it is deliberately excluded from the build:wc bundle — it only exists inside the full ng serve app (localhost:4200), never in dist/wc/index.html or a non-Angular host. It also talks to an entirely different backend: the microservices/payment-component Node/TypeScript service on port 3000, not backend/server.js on port 3001 which powers the 10-widget calculators.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
No worked numeric example available in the source evidence reviewed.

## Verification Note
Confirmed verbatim against the manual text, including the exact port numbers (3000 vs 3001). Unchanged.

## Source Evidence
- converted/docs__LC-Payment-WC-User-Manual-en.docx.txt §6.1, line 95, directly re-read: 'Unlike the ten widgets catalogued in Section 2, the Simulator (app-business-case-runner, src/app/payment-component/) is deliberately excluded from the build:wc bundle (Section 3) ... It also talks to a different backend entirely: the microservices/payment-component Node/TypeScript service on port 3000, not the backend/server.js on port 3001 that powers Sections 2–5.'

## Related Knowledge
- [[Payment Architecture]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
