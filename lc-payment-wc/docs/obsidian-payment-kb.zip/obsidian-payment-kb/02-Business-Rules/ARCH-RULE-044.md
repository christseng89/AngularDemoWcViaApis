---
knowledge_id: ARCH-RULE-044
title: "Both Angular app and microservice enforce a 90% coverage floor (statements/branches/functions/lines); microservice has 100% coverage currently"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - other
  - confirmed
---

# ARCH-RULE-044 — Both Angular app and microservice enforce a 90% coverage floor (statements/branches/functions/lines); microservice has 100% coverage currently

## Status
CONFIRMED

## Business Rule
jest.config.js on both projects sets coverageThreshold at 90% across statements/branches/functions/lines for everything collectCoverageFrom tracks; the microservice's own suite (262 tests) currently runs at 100% coverage. The Angular app's suite (319 tests, 12 suites) runs at 98.72% statements / 99.48% functions / 100% lines / 95.7% branches. The two Jest configs must never be run cross-directory — running the microservice's tests from the wrong working directory pulls its test files into the Angular project's stricter tsconfig.spec.json (which sets noPropertyAccessFromIndexSignature), causing false TS4111 failures in 2 suites even though nothing is actually broken.

## Conditions
Applies whenever running either project's Jest suite; the warning specifically concerns not letting the two tsconfigs/node_modules cross.

## Result
n/a

## Example
Angular app: 319 tests / 12 suites, 98.72% statements / 99.48% functions / 100% lines / 95.7% branches, both gated at a 90% floor. Microservice: 262 tests, 100% coverage, gated at a 90% floor (branches/functions/lines/statements).

## Verification Note
Re-opened /mnt/user-data/uploads/lc-payment-wc/README.md and confirmed every cited figure verbatim: the 90% floor language, the exact coverage table (98.72%/99.48%/100%/95.7%), the 319-test/12-suite figure, the 262-test/100%-coverage microservice figure, and the full cross-directory warning text about noPropertyAccessFromIndexSignature/TS4111. All numbers match exactly with no discrepancy. Status CONFIRMED is correct and fully supported by primary project documentation (tier-5 config/tier-6 doc evidence, but directly quoted and precise, and corroborated by the CLAUDE.md standing rule which independently restates the same 90% floor requirement for both projects).

## Source Evidence
- README.md 'Testing' section, lines 76-79: '319 tests, 12 suites; jest.config.js enforces a 90% floor (coverageThreshold) across statements/branches/functions/lines...'
- README.md coverage table, lines 91-96: Statements 98.72% / Functions 99.48% / Lines 100% / Branches 95.7%.
- README.md '⚠ Run each project's tests from its own directory' warning, lines 81-88: full explanation of the TS4111/noPropertyAccessFromIndexSignature cross-contamination risk.
- README.md lines 130-133: microservice 'has its own suite — 262 tests, 100% coverage — see its own README'.
- README.md lines 139: 'npm test # Jest unit suite (test/unit/), gated at 90% branches/functions/lines/statements' for the microservice.
- CLAUDE.md standing rule 'keep tests + docs in sync... run every test surface the change could plausibly touch, and confirm each exits clean at its own enforced coverage floor... 90% floor, gated' for both `npm test` invocations.

## Related Knowledge
- [[Payment Architecture]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
