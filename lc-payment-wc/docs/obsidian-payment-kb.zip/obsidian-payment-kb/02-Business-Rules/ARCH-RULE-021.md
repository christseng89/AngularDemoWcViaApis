---
knowledge_id: ARCH-RULE-021
title: "Suspense entry rows deliberately carry no Account No./Account Type/percentage fields, unlike leg-allocator's rows"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - architecture
  - confirmed
---

# ARCH-RULE-021 — Suspense entry rows deliberately carry no Account No./Account Type/percentage fields, unlike leg-allocator's rows

## Status
CONFIRMED

## Business Rule
SuspenseEntry only ever needs amount, currency, and sourceComponent because the generated Cr 'Suspense - Debit'/'Suspense - Credit' leg's own GL account is fixed by server-side domain logic (suspenseBridge.ts), not user-selectable — so this component intentionally does not replicate <app-leg-allocator>'s account-type/account-no/percentage-split machinery, keeping the row shape and the component itself materially simpler.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
No worked numeric example available in the source evidence reviewed.

## Verification Note
Confirmed directly against the file. Unchanged.

## Source Evidence
- src/app/payment-component/suspense-entries.component.ts lines 1-40, directly re-read: SuspenseEntry interface has only amount/currency/sourceComponent fields; doc comment explains why this is 'deliberately NOT a Formly repeat field' and simpler than leg-allocator's row model

## Related Knowledge
- [[Payment Architecture]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
