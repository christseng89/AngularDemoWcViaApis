---
knowledge_id: VALIDATION-RULE-033
title: "Fixed production bug: every B4 EBL-path settlement crashed with HTTP 500 ('crCaTwd is not defined') due to a const-scoping error, now fixed via hoisted let"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - validation
  - confirmed
---

# VALIDATION-RULE-033 — Fixed production bug: every B4 EBL-path settlement crashed with HTTP 500 ('crCaTwd is not defined') due to a const-scoping error, now fixed via hoisted let

## Status
CONFIRMED

## Business Rule
Prior to the fix, crCaAmt/crCaTwd were declared with const strictly inside the Direct-to-CA else block, but the shared summary object built after the if/else referenced both names unconditionally — a ReferenceError (HTTP 500) on every EBL-path request. The fix hoists both to `let` at the top of the handler (lines 667-668), assigned only on the Direct path; on the EBL path they remain undefined and are silently omitted by JSON.stringify rather than throwing.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
n/a — bug-fix verification, confirmed via cited regression test.

## Verification Note
Confirmed exactly by direct read of backend/server.js lines 655-713 and the corresponding regression test file.

## Source Evidence
- backend/server.js lines 662-668 (doc comment explaining the bug and fix), the `let crCaAmt; let crCaTwd;` hoisted declarations
- backend/test/export-settlement.test.js top-of-file comment: 'Reviewer-reported bug (2026-08-12): every EBL (clear advance) settlement returned HTTP 500 with {"error":"crCaTwd is not defined"}...' plus the regression test suite (line 26: 'returns 200, not the crCaTwd is not defined 500')

## Related Knowledge
- [[Request Validation]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
