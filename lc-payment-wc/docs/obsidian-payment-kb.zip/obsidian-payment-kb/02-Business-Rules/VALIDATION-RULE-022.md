---
knowledge_id: VALIDATION-RULE-022
title: "Every monetary figure in the leg-allocator rounds to ITS OWN currency's minor units, never a hardcoded 2dp"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - validation
  - confirmed
---

# VALIDATION-RULE-022 — Every monetary figure in the leg-allocator rounds to ITS OWN currency's minor units, never a hardcoded 2dp

## Status
CONFIRMED

## Business Rule
The money(value, scale) helper requires an explicit scale, sourced per-field from scaleFor(currency) (this.transactionCurrency for amountTxCcy, row.currency for amountAccountCcy/Account Ccy Equiv.), falling back to 2dp only for a currency absent from the Currency master. Both the display (accountCcyAmount) and the wire payload (emit()'s leg.amountAccountCcy/leg.amountTxCcy) use the SAME scale-aware conversion — fixing a prior bug where a hardcoded 2dp put fractional yen on screen and on the wire, which the microservice's own H-2 check would then reject.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
JPY row, amountTxCcy 100, rate 149.0825 -> accountCcyAmount = round(14908.25, 0dp ROUND_HALF_UP) = 14908, emitted as amountAccountCcy '14908' (no decimal point).

## Verification Note
Confirmed exactly by direct read of leg-allocator.component.ts lines 118-136 (function money(value, scale)) and 271-273 (scaleFor).

## Source Evidence
- src/app/payment-component/leg-allocator.component.ts lines 118-136 (money() doc comment and body), lines 264-273 (scaleFor())
- leg-allocator.component.spec.ts 'accountCcyAmount rounds to the ROW's own currency scale, not a hardcoded 2dp — JPY (0dp) shows no fractional yen'; 'emit() currency-scale formatting (JPY decimal precision fix)' describe block

## Related Knowledge
- [[Request Validation]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
