---
knowledge_id: SUSPENSE-RULE-005
title: "v1.9.0: A debitEntries Suspense bucket nets its gross amount against the caller's matching-currency debitLegs before generating any FX pair — 'Same Currency + Same Amount -> Direct Settlement -> No FX Pair'"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - suspense
  - confirmed
---

# SUSPENSE-RULE-005 — v1.9.0: A debitEntries Suspense bucket nets its gross amount against the caller's matching-currency debitLegs before generating any FX pair — 'Same Currency + Same Amount -> Direct Settlement -> No FX Pair'

## Status
CONFIRMED

## Business Rule
For a foreign-currency debitEntries bucket, diff = grossSuspense(bucket) minus Σ(matching-currency debitLegs, native amount). diff===0 -> no FX pair at all. diff>0 (Suspense exceeds real legs, incl. no matching leg at all) -> one CREDIT-anchored pair suffixed ' - Suspense', sized to the shortfall only. diff<0 (real legs exceed Suspense) -> one DEBIT-anchored, unsuffixed 'Leg' pair, sized to the excess only. This is plain Decimal subtraction of two already-rounded, on-the-wire figures — never a fresh rate re-conversion.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
Suspense Debit EUR 17 (crossRate 1.1) exactly matched by a real Debit Leg EUR 17 -> no FX pair generated at all, only the Suspense leg itself posts.

## Verification Note
Read the full suspenseBridge.ts implementation (lines 352-372) and the full 'v1.9.0 DEBIT side' test describe block — code and every cited test match the stated rule exactly, including the exact-match-skip and partial-match-residual worked examples. Status unchanged: CONFIRMED.

## Source Evidence
- suspenseBridge.ts lines 54-76 (top doc comment), 319-372 (expandSuspenseBridge's DEBIT-side inline algebraic justification, diffNative.greaterThan(0)/lessThan(0) branches)
- suspenseBridge.test.ts lines 175-257 'v1.9.0 DEBIT side' describe block, 7 tests including the exact-match-skips-pair case (line 192) and the partial-match residual case
- suspenseBridge.test.ts lines 319-331 'a partial-match debitEntries bucket nets to a residual pair unconditionally — no request flag is involved'

## Related Knowledge
- [[Suspense Account]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
