---
knowledge_id: CLASS-RULE-024
title: "AccountType enum has exactly 5 values (CUSTOMER/NOSTRO/VOSTRO/SUSPENSE/INTERNAL) in the Payment Component microservice; RTGS is not one of them (v1.3.0)"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - classification
  - confirmed
---

# CLASS-RULE-024 — AccountType enum has exactly 5 values (CUSTOMER/NOSTRO/VOSTRO/SUSPENSE/INTERNAL) in the Payment Component microservice; RTGS is not one of them (v1.3.0)

## Status
CONFIRMED

## Business Rule
The microservice's ACCOUNT_TYPES const (types.ts) is exactly ['CUSTOMER', 'NOSTRO', 'VOSTRO', 'SUSPENSE', 'INTERNAL'] — no RTGS value. This is the current (v1.3.0+) state; an earlier v1.1.0/v1.2.0 draft OAS snippet (still visible verbatim inside the zh FSD doc as a stale excerpt) briefly showed RTGS as a 6th enum value before being corrected in the same document. This is the direct source for the classification rule that RTGS folds into nostroXor via a flag rather than its own type.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
No worked numeric example available in the source evidence reviewed.

## Verification Note
New rule surfaced during verification, not present in the original candidate list as its own entry (though implied by several RTGS rules) — added here because it is the direct, load-bearing evidence underlying the merged 'rtgs-modeled-as-nostro-flag' entry, and because the zh FSD doc's stale embedded 6-value enum is worth flagging explicitly as a documentation artifact, not a current contradiction in the live schema.

## Source Evidence
- microservices/payment-component/src/types.ts line 40: `export const ACCOUNT_TYPES = ['CUSTOMER', 'NOSTRO', 'VOSTRO', 'SUSPENSE', 'INTERNAL'] as const;`
- analysis/Payment_component.yaml AccountType enum line 424: `enum: [CUSTOMER, NOSTRO, VOSTRO, SUSPENSE, INTERNAL]`
- converted/analysis__PaymentComponent-Microservice-FSD-zh.docx.txt line 441 shows an older embedded schema excerpt with `enum: [CUSTOMER, NOSTRO, VOSTRO, SUSPENSE, INTERNAL, RTGS]` immediately preceded by its own v1.3.0 correction note removing RTGS

## Related Knowledge
- [[Payment Instruction Classification]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
