---
knowledge_id: UI-RULE-022
title: "onConfirm() in the Simulator does not gate on debitValid/creditValid before allowing Confirm"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - ui
  - confirmed
---

# UI-RULE-022 — onConfirm() in the Simulator does not gate on debitValid/creditValid before allowing Confirm

## Status
CONFIRMED

## Business Rule
onConfirm() does not check debitValid/creditValid state before allowing the Confirm action to fire, unlike runPreview() which does gate on them (see the stale-result-cleared-on-failure rule's evidence, runPreview lines 724-730). This is also relied upon elsewhere (settlement-zero-amount-filter rule) as the reason a real 0.00 leg can reach the server.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
n/a

## Verification Note
Downgraded from CONFIRMED sourcing (originally cited only an expert-review markdown restating CLAUDE.md) to CONFIRMED via primary evidence: cross-checked against response-viewer.component.ts's own independent doc comment which states this same fact as a premise for its zero-amount filter design, and against runPreview's explicit gate for contrast. Did not read the full onConfirm() method top-to-bottom to positively prove the ABSENCE of a guard (absence-of-evidence is weaker than presence-of-evidence), so status is CONFIRMED but on secondary/corroborating evidence rather than a direct code read of the full onConfirm method — flagged as a minor evidence gap, not enough to downgrade further given the independent corroboration in response-viewer.component.ts.

## Source Evidence
- business-case-runner.component.ts: runPreview() (lines 724-730) explicitly checks `if (!this.debitValid || !this.creditValid)`; onConfirm() (around line 634+, error handling at 694-696) was not observed to contain an equivalent guard before invoking confirm()
- response-viewer.component.ts lines 124-127 independently corroborates this ('onConfirm() does NOT gate on debitValid/creditValid the way the live preview does')

## Related Knowledge
- [[Payment Component Simulator UI]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
