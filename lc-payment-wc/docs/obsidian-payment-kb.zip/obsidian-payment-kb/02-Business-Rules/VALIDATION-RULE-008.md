---
knowledge_id: VALIDATION-RULE-008
title: "M-7: legacy RPFM ±0.01 tolerance no longer auto-applied — exact balance required for every originModule including RPFM"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - validation
  - confirmed
---

# VALIDATION-RULE-008 — M-7: legacy RPFM ±0.01 tolerance no longer auto-applied — exact balance required for every originModule including RPFM

## Status
CONFIRMED

## Business Rule
RPFM_BALANCE_TOLERANCE (Decimal '0.01') is retained purely for reference/historical traceability. As of M-7, it is NOT applied automatically by validateDrCrBalance's default (toleranceAbs=0) for any originModule, RPFM included — the legacy ±0.01 was a screen-level percentage-split slack, not a GL-posting rule; a genuine rounding residual must be posted as an explicit rounding-difference leg (not yet implemented — see gaps). It remains available only as an explicit per-call override. Merges the FSD-doc-sourced duplicates 'exact-balance-all-modules-m7' (M-7 half) and 'm7-exact-balance-enforced-tolerance-removed'.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
validateDrCrBalance([100],[99.99]) with NO explicit tolerance throws (default is 0, not 0.01) — the tolerance must be passed explicitly (e.g. RPFM_BALANCE_TOLERANCE) to accept it.

## Verification Note
Confirmed by direct read. Merged 2 duplicate FSD-doc-sourced entries describing the identical M-7 fact.

## Source Evidence
- microservices/payment-component/src/domain/balanceValidation.ts lines 66-75 (RPFM_BALANCE_TOLERANCE doc comment and export)
- test/unit/domain/balanceValidation.test.ts: 'does not throw when the difference is exactly at the tolerance boundary' (passing '0.01' explicitly as 3rd arg); 'RPFM_BALANCE_TOLERANCE is 0.01'
- analysis__Payment-OAS-FSD-en.docx.txt Appendix B, M-7 (line 138)
- analysis__Payment_Component_Calculation_Validation.docx.txt 'Spec Sync — 2026-08 Hardening Review' M-7 (line 379), '261 unit tests, 100% coverage' (line 373)

## Related Knowledge
- [[Request Validation]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
