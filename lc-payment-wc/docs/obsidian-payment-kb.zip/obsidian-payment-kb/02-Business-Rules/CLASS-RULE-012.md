---
knowledge_id: CLASS-RULE-012
title: "All GAP-verdict cases belong to a single module, RPFM (Risk Participation Finance)"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - classification
  - confirmed
---

# CLASS-RULE-012 — All GAP-verdict cases belong to a single module, RPFM (Risk Participation Finance)

## Status
CONFIRMED

## Business Rule
The 4 GAP cases (Process Grantor, Repay Grantor, Process Participant, Settle Participant) are all RPFM functions — no other module in the 11-module registry has a GAP verdict; every other module's Confirm functions are either full PASS users or complete N_A non-users.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
rpfm-process-grantor, rpfm-repay-grantor, rpfm-process-participant, rpfm-settle-participant — module 'RPFM' in every case.

## Verification Note
Confirmed directly — GAP_CASES has exactly 4 entries, all module: 'RPFM'.

## Source Evidence
- src/app/payment-component/business-case-registry.spec.ts 'all 4 GAP cases belong to RPFM' line 40-44
- src/app/payment-component/business-case-registry.ts GAP_CASES array lines 237-273, module: 'RPFM' on all 4 entries

## Related Knowledge
- [[Payment Instruction Classification]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
