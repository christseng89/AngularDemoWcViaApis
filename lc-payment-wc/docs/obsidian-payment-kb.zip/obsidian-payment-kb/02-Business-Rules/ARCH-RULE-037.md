---
knowledge_id: ARCH-RULE-037
title: "Check-then-act idempotency is not atomic across instances; must become an atomic DB upsert"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - architecture
  - confirmed
---

# ARCH-RULE-037 — Check-then-act idempotency is not atomic across instances; must become an atomic DB upsert

## Status
CONFIRMED

## Business Rule
find() then save() is a classic check-then-act race. In the current in-memory, single-threaded, synchronous store this race is not triggerable, but once the store becomes shared/multi-instance, two concurrent identical Confirms can both miss find() and both save(), double-booking GL/SWIFT output. Production landing: UNIQUE(origin_module, main_ref, sequence) plus an atomic upsert (INSERT ... ON CONFLICT) that compares request_hash — same payload = 200 replay, different payload = 409. This single DB landing closes both the atomicity gap (H-1) and the payload-conflict gap (C-2) — there is no separate H-1 work item.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
No worked numeric example available in the source evidence reviewed.

## Verification Note
Confirmed verbatim against the document. This remains an accurately-described OPEN item (the in-memory store, confirmed unchanged via rule #12 above, has not been replaced with the atomic DB upsert described here) — CONFIRMED as an accurate description of a still-open gap, not confirming that the fix has shipped.

## Source Evidence
- docs/payment-component-expert-review.md H-1 section, lines 108-125, directly re-read: matches every clause including the explicit 'Resolved together with C-2 — one mechanism, not two' framing and 'no separate H-1 work item' conclusion

## Related Knowledge
- [[Payment Architecture]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
