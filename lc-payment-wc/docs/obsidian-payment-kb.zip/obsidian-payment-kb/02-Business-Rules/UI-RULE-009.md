---
knowledge_id: UI-RULE-009
title: "Switching a row's Account Type unconditionally resets its Account No. to that type's own default placeholder"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - ui
  - confirmed
---

# UI-RULE-009 — Switching a row's Account Type unconditionally resets its Account No. to that type's own default placeholder

## Status
CONFIRMED

## Business Rule
onAccountTypeChange sets row.accountNo to DEFAULT_ACCOUNT_NO_BY_TYPE[accountType] (CUST-ACC / NOSTRO-ACC / VOSTRO-ACC / SUSPENSE-ACC / INTERNAL-ACC) the moment the A/C Type dropdown changes — even overwriting a manually-typed Account No. — to avoid a stale account number reading as if the leg genuinely posts to a different account type. The field stays freely editable afterward; the reset only fires on a genuine type switch.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
n/a

## Verification Note
Confirmed exactly against source lines 1106-1111 (row.accountNo = DEFAULT_ACCOUNT_NO_BY_TYPE[accountType], unconditional).

## Source Evidence
- onAccountTypeChange() lines 1106-1111
- DEFAULT_ACCOUNT_NO_BY_TYPE constant lines 92-98

## Related Knowledge
- [[Payment Component Simulator UI]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
