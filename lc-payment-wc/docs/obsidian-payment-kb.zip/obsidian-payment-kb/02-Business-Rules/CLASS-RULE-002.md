---
knowledge_id: CLASS-RULE-002
title: "Payment Component Identification Rule (Rev 2) — XOR-based classification over CUSTOMER/NOSTRO/VOSTRO"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - classification
  - confirmed
---

# CLASS-RULE-002 — Payment Component Identification Rule (Rev 2) — XOR-based classification over CUSTOMER/NOSTRO/VOSTRO

## Status
CONFIRMED

## Business Rule
A payment instruction is classified paymentComponentRelated=true iff exactly one side (debit XOR credit) holds a leg of accountType CUSTOMER, OR exactly one side holds NOSTRO, OR exactly one side holds VOSTRO — evaluated over the full set of legs per side (Dr_has(t)/Cr_has(t) set-membership, not a single-leg comparison). If a type appears on both sides, or neither side, that term does not fire; any one term firing makes paymentComponentRelated true. This merges with candidates 8, 29, 33, and 38 (near-duplicates of the same rule at different levels of detail from different source groups) — kept as one statement.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
ClassificationResult.paymentComponentRelated boolean

## Example
classify('id-1', [CUSTOMER debit], [NOSTRO credit]) -> customerXor=true, nostroXor=true, vostroXor=false, paymentComponentRelated=true. FSD §8.3 worked example: all three legs (debit and credit) are CUSTOMER -> paymentComponentRelated=FALSE despite being multi-currency, multi-leg — scope depends on AccountType composition, not currency/leg count.

## Verification Note
Directly re-read classification.ts and its unit tests — implementation matches exactly. Also re-read the OAS schema and both FSD docs (en/zh) — all state the identical Rev.2 three-independent-XOR-term rule with matching worked examples. Merged candidates 1, 8, 29, 33, 38 into this single entry since they are the same rule stated by different source groups (microservice code, regression tests, OAS, FSD docs) with no material differences. Status remains CONFIRMED.

## Source Evidence
- microservices/payment-component/src/domain/classification.ts lines 41-62 (classify function, doc comment lines 1-26)
- microservices/payment-component/test/unit/domain/classification.test.ts — 'customerXor fires when only the debit side has CUSTOMER', 'no term fires when both sides are CUSTOMER', 'nostroXor is false when both sides have NOSTRO', 'vostroXor fires independently', 'multiple distinct types on one side can trigger multiple XOR terms at once'
- analysis/Payment_component.yaml ClassificationResult schema lines 797-828
- converted/analysis__Payment-OAS-FSD-en.docx.txt §7.2 lines 54-59
- converted/analysis__PaymentComponent-Microservice-FSD-zh.docx.txt §2.3 lines 21-33 and worked example lines 37-40
- converted/analysis__Payment_Component_Calculation_Validation.docx.txt §4 lines 80-88, §8.3 line 312, §13.1 lines 337-340

## Related Knowledge
- [[Payment Instruction Classification]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
