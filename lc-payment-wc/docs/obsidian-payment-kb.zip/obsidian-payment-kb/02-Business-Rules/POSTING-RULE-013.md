---
knowledge_id: POSTING-RULE-013
title: "Voucher description (accountDesc) = fixed per-function code prefix + single TypeChar derived from the leg's own accountType (merged with 'voucher-description-formula' and 'voucher-desc-code-assembly')"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - accounting
  - confirmed
---

# POSTING-RULE-013 — Voucher description (accountDesc) = fixed per-function code prefix + single TypeChar derived from the leg's own accountType (merged with 'voucher-description-formula' and 'voucher-desc-code-assembly')

## Status
CONFIRMED

## Business Rule
Each leg's GL voucher description code is computed independently as accountDescFor(accountType, voucherCodePrefix, rtgsIndicator) = voucherCodePrefix + typeChar, where typeChar is keyed off the leg's own accountType (CUSTOMER→C, NOSTRO→N, VOSTRO→V, SUSPENSE→S, INTERNAL→I), with a NOSTRO+rtgsIndicator=true leg getting 'R' instead of 'N'. Direct port of legacy SYF_EXCO_CAL_PAYMENT_AC_DESC().

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
accountDescFor('NOSTRO','IPLC03NULLNULLNULL', true) → 'IPLC03NULLNULLNULLR'; accountDescFor('CUSTOMER','IPLC03NULLNULLNULL') → 'IPLC03NULLNULLNULLC'

## Verification Note
Confirmed directly by reading voucherDescription.ts in full — code matches exactly. Merged with the near-duplicate fsd-architecture-docs/validation-gap-docs versions of this same rule (id_hints voucher-description-formula, voucher-desc-code-assembly) since they describe the identical formula sourced from the FSD text rather than code — kept as one entry with both evidence types noted.

## Source Evidence
- src/domain/voucherDescription.ts lines 1-88, read in full — top doc comment citing SYF_EXCO_CAL_PAYMENT_AC_DESC(); TYPE_CHARS table; accountDescFor() function

## Related Knowledge
- [[Accounting Model]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
