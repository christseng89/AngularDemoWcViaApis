---
knowledge_id: UI-RULE-017
title: "Amount display formatting to the currency's own minor units is presentation-only and never mutates the underlying accounting data"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - ui
  - confirmed
---

# UI-RULE-017 — Amount display formatting to the currency's own minor units is presentation-only and never mutates the underlying accounting data

## Status
CONFIRMED

## Business Rule
formatAmount() rounds/pads a raw wire amount string or FxPairEntry number to the row's own currency's minor-unit decimal places (via the currencyDecimals @Input, default 2 for an unlisted currency) purely for display in both Settlement Voucher tables and the FX overlay tables. The underlying AccountEntry.amount / FxPairEntry.amount values themselves are never changed by this.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
n/a

## Verification Note
Confirmed exactly against source lines 113-115 — a pure return-value function with no mutation of any Input.

## Source Evidence
- response-viewer.component.ts lines 92-115 (doc comment + implementation): `formatAmount(amount, currency): string { return new Decimal(amount).toFixed(this.currencyDecimals[currency] ?? 2); }`

## Related Knowledge
- [[Payment Component Simulator UI]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
