---
knowledge_id: API-RULE-013
title: "POST /payment-instructions is a single atomic create+classify+post+message endpoint, replacing an earlier multi-call draft design (header-create/per-leg-add/classify-preview/confirm)"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - api
  - confirmed
---

# API-RULE-013 — POST /payment-instructions is a single atomic create+classify+post+message endpoint, replacing an earlier multi-call draft design (header-create/per-leg-add/classify-preview/confirm)

## Status
CONFIRMED

## Business Rule
The service replaces an earlier multi-call draft design with ONE POST that accepts the complete header plus fully assembled debitLegs[]/creditLegs[] arrays and, synchronously within that single request, performs: (1) Dr/Cr balance validation, (2) Payment Component Identification Rule Rev.2 classification, (3) voucher description code assembly per leg, (4) unconditional Account Entry (GL) generation for the settlement stream, and (5) SWIFT/ISO 20022 message record creation when a credit leg's payAdviceMsgType/payCoverMsgType resolves non-None. All five results are embedded in one response body. Callers = IPLC/EPLC/IMCO/EXCO/GTEE/IWGT ConfirmBusinessCall equivalents, submitting the full leg set already assembled.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
No worked numeric example available in the source evidence reviewed.

## Verification Note
Merged with the near-duplicate candidate rule 'single-atomic-post-replaces-multistep-draft' (from fsd-architecture-docs group), which states the same fact from the FSD side. Re-read Payment_component.yaml's info.description and paths./payment-instructions.post.description directly and cross-checked against confirmPaymentInstruction.ts's actual 5-step implementation; both agree. No change to status.

## Source Evidence
- analysis/Payment_component.yaml: info.description (lines 4-15), paths./payment-instructions.post.description (lines 194-218)
- analysis/payment-instructions-post.yaml paths./payment-instructions.post.description (per original citation, not independently re-read but consistent with the Payment_component.yaml text, which explicitly states the two are kept in lockstep)
- microservices/payment-component/src/domain/confirmPaymentInstruction.ts: the actual 5-step implementation (Step 1 balance validateDrCrBalance, Step 2 classify, Step 3 enrichLegs/voucher assembly, Step 4 buildSettlementEntries, Step 5 validateSwiftCrossField+buildSwiftMessages) confirms the OAS description is not aspirational but matches the real code path

## Related Knowledge
- [[Payment Instructions API]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
