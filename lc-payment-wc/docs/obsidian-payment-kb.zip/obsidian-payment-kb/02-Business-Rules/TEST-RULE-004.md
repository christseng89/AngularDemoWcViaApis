---
knowledge_id: TEST-RULE-004
title: "The Payment Component Simulator catalogs 23 real business cases traced to legacy functions, tagged PASS/GAP/N_A across 11 modules"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - testscenario
  - confirmed
---

# TEST-RULE-004 — The Payment Component Simulator catalogs 23 real business cases traced to legacy functions, tagged PASS/GAP/N_A across 11 modules

## Status
CONFIRMED

## Business Rule
business-case-registry.ts enumerates exactly 23 business cases (directly counted via verdict field: 15 PASS + 4 GAP + 4 N_A = 23), spanning exactly 11 distinct module codes (IPLC, EPLC, IMCO, EXCO, GTEE, IWGT, RPFM, CFNC, SBLC, REIM, PYMT). PASS (15): confirmed Payment Component users with a working voucher-assembly routine — the Simulator drives the live microservice end-to-end (dry-run preview + real Confirm). GAP (4): all four belong to RPFM specifically (rpfm-process-grantor, rpfm-repay-grantor, rpfm-process-participant, rpfm-settle-participant) — confirmed callers of the classification step but no voucher-assembly routine exists, so preview-only (classify call), no Confirm action. N_A (4): confirmed non-users — cfnc-non-user, sblc-non-user, reim-non-user, pymt-imlcpayment-non-user — rendered as a static citation card with no form and no API call. Every case carries a source citation (file:line) and a note describing what the default leg values reproduce.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
Verdict tally directly counted from business-case-registry.ts: PASS=15, GAP=4 (all RPFM), N_A=4 (CFNC/SBLC/REIM/PYMT). Total=23 across 11 modules.

## Verification Note
Fully re-verified directly against source code (not just the manual): counted verdict tags and module tags in business-case-registry.ts and confirmed exact match to every number and grouping claimed (15/4/4=23, 11 modules, all 4 GAP cases are RPFM, all 4 N_A cases are CFNC/SBLC/REIM/PYMT). No changes needed — upgraded confidence from doc-citation-only to direct-code-verified.

## Source Evidence
- src/app/payment-component/business-case-registry.ts: grep of verdict field across the file (15 PASS, 4 GAP, 4 N_A)
- business-case-registry.ts:239,248,257,266 — all 4 GAP cases have module: 'RPFM'
- business-case-registry.ts:283,293,303,313 — the 4 N_A cases: cfnc-non-user/CFNC, sblc-non-user/SBLC, reim-non-user/REIM, pymt-imlcpayment-non-user/PYMT
- grep of module field across the file returns exactly 11 distinct codes: CFNC, EPLC, EXCO, GTEE, IMCO, IPLC, IWGT, PYMT, REIM, RPFM, SBLC
- docs__LC-Payment-WC-User-Manual-en.docx.txt §6.2/§6.3 and its Verdict summary table (cited by original candidate, consistent with the code)

## Related Knowledge
- [[Testing Methodology and Coverage]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
