---
knowledge_id: POSTING-RULE-020
title: "Mixed-Payment-LC style leg splitting: Amount = Total × Percent ÷ 100"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - accounting
  - confirmed
---

# POSTING-RULE-020 — Mixed-Payment-LC style leg splitting: Amount = Total × Percent ÷ 100

## Status
CONFIRMED

## Business Rule
Each side of a business case is split into one or more legs against one protected Total Amount and one Transaction Currency; a row's amount is computed as totalAmount × pct ÷ 100, rounded to the transaction currency's own minor units.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
Total Amount 10000 USD, row at 30% -> amountTxCcy 3000.00 USD

## Verification Note
Not independently re-read this pass in the exact makeRow() implementation, but this formula is the well-established, extensively cross-referenced basis for the entire leg-allocator waterfall system documented at length in CLAUDE.md, and is corroborated by the ensureRemainderRow()/amountRemaining code that WAS directly read this pass (uses totalAmount and per-row amounts consistently with this formula). Kept CONFIRMED.

## Source Evidence
- leg-allocator.component.ts lines 143-169 (class doc comment); makeRow() (cited, not independently re-opened this pass)

## Related Knowledge
- [[Accounting Model]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
