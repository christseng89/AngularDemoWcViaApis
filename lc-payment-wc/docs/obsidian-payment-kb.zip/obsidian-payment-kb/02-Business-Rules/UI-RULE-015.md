---
knowledge_id: UI-RULE-015
title: "Currency View always lists Debit rows before Credit rows within each currency group, via an explicit stable sort"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - ui
  - confirmed
---

# UI-RULE-015 — Currency View always lists Debit rows before Credit rows within each currency group, via an explicit stable sort

## Status
CONFIRMED

## Business Rule
currencyGroups applies its own explicit stable sort (Debit before Credit, relative order otherwise preserved) to every currency group's entries, per a reviewer-confirmed 2026-08-13 requirement, so the Dr/Cr ordering no longer depends — even incidentally — on Posting View's own section order.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
n/a

## Verification Note
Confirmed exactly against source line 306.

## Source Evidence
- response-viewer.component.ts lines 276-282 (doc comment), line 306 (implementation): `.sort((a, b) => (a.drCrIndicator === b.drCrIndicator ? 0 : a.drCrIndicator === 'D' ? -1 : 1))`

## Related Knowledge
- [[Payment Component Simulator UI]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
