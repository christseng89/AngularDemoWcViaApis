---
knowledge_id: UI-RULE-007
title: "The % waterfall's backward cascade (rule 4) can never be under-supplied, unlike the Amount waterfall's equivalent"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - ui
  - confirmed
---

# UI-RULE-007 — The % waterfall's backward cascade (rule 4) can never be under-supplied, unlike the Amount waterfall's equivalent

## Status
CONFIRMED

## Business Rule
Because Σ% across all rows always equals exactly 100 by construction, the donor pool for a last-row % increase ('every row except the last') always holds exactly 100 - (last row's current %), which is always >= any valid requested delta (a typed % is clamped to [0,100] first via clampPct). The Amount waterfall's equivalent rule CAN be capped short (Amount has no natural ceiling), but %'s rule 4 structurally cannot be — though %'s rule 1 (non-last-row increase, targeting only the LAST row) CAN still be capped short by an untouched middle row holding a large %.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
n/a

## Verification Note
Confirmed the structural reasoning directly against the source: clampPct bounds [0,100] and applyPctWaterfall's rule-4 loop only draws from non-last rows whose sum is exactly 100-last%. Algebraically sound as claimed.

## Source Evidence
- applyPctWaterfall doc comment lines 672-679 (structural-invariant reasoning)
- onPctInput lines 761-763 clampPct(pct).toDecimalPlaces(0,...) — clamps to [0,100] before the waterfall runs

## Related Knowledge
- [[Payment Component Simulator UI]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
