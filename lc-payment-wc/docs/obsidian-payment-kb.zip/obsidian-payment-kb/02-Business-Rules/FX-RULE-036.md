---
knowledge_id: FX-RULE-036
title: "Transaction-currency to account-currency conversion is symmetric multiply/divide by the leg's own rate, on both Dr and Cr sides"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - fx
  - confirmed
---

# FX-RULE-036 — Transaction-currency to account-currency conversion is symmetric multiply/divide by the leg's own rate, on both Dr and Cr sides

## Status
CONFIRMED

## Business Rule
CPYT_DR_AMT_DRCCY = CPYT_DR_AMT_TXCCY × CPYT_DR_BUY_RATE (and reverse division when the account-currency amount is entered directly). The credit side uses the exact symmetric formula with CPYT_CR_BUY_RATE.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
No worked numeric example available in the source evidence reviewed.

## Verification Note
Duplicate/overlap with 'account-ccy-conversion-formula-8-2' above — same §8.2 citation, same formula, from the same source document, restated with slightly different emphasis (this one also notes the open question of server-side recompute-vs-trust). Both kept as the candidate list already had them separately id'd from different groups; substance confirmed via money.ts's actual implementation. No status change.

## Source Evidence
- analysis__Payment_Component_Calculation_Validation.docx.txt §8.2 (SSSS_PaymentDebit.js:53-129, SSSS_PaymentCredit.js:261-321)
- money.ts convertTxCcyToAccountCcy (independently confirms this same formula is what the microservice actually implements)

## Related Knowledge
- [[FX Processing]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
