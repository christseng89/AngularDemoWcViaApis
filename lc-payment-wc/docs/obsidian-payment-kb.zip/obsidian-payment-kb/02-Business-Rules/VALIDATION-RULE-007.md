---
knowledge_id: VALIDATION-RULE-007
title: "V8: exact Dr/Cr aggregate balance required in transaction currency; a mismatch throws BusinessValidationError LEGS_UNBALANCED (409)"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - validation
  - confirmed
---

# VALIDATION-RULE-007 — V8: exact Dr/Cr aggregate balance required in transaction currency; a mismatch throws BusinessValidationError LEGS_UNBALANCED (409)

## Status
CONFIRMED

## Business Rule
Because PaymentInstructionConfirmRequest (OAS v1.2.0) carries no target-total field, the legacy Debit_Chk_Total_Pct()/CHK_Total_Pct() two-independent-≤-target-total screen checks cannot be reproduced verbatim. validateDrCrBalance instead requires Σ debitLegs[].amountTxCcy to EXACTLY equal Σ creditLegs[].amountTxCcy (default tolerance 0), throwing BusinessValidationError('LEGS_UNBALANCED', message naming both totals and the difference) on any excess beyond an optional tolerance. This is a deliberate, documented deviation from source (§12.1/§8.3 of the Calculation & Validation doc), verified against real FSD scenario §13.2 (debit 800,020 == credit 800,000+20). Merges the separately-extracted 'v8-throws-legs-unbalanced-409' (same evidence file/function, just the error-throwing half of the same rule), the FSD-doc-sourced 'v8-balance-validation' and 'exact-balance-all-modules-m7' entries, and the regression-scenario-sourced 'v8-balance-validation-exact-equality' entry (adds the worked failing example: 800020 vs 800000+19.99 -> throws).

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
debitTotal=800020, creditTotal=800020 -> passes, difference=0. debitTotal=800020, creditTotal=800019.99 (800000+19.99) -> throws LEGS_UNBALANCED.

## Verification Note
Confirmed by direct read of balanceValidation.ts and its test file, cross-checked against both FSD doc excerpts. Merged 5 near-duplicate id_hints (v8-throws-legs-unbalanced-409, v8-balance-validation, exact-balance-all-modules-m7's balance-formula half, v8-balance-validation-exact-equality) into this single comprehensive entry, since all cited the identical code/mechanism from slightly different extraction passes.

## Source Evidence
- microservices/payment-component/src/domain/balanceValidation.ts lines 1-25 (top doc comment), lines 45-64 (validateDrCrBalance, including the throw)
- test/unit/domain/balanceValidation.test.ts: 'passes and returns totals/difference when debit and credit totals match exactly', 'sums multiple legs per side before comparing', 'throws BusinessValidationError with LEGS_UNBALANCED when totals differ beyond the default zero tolerance' (100 vs 99.99 -> throws, code LEGS_UNBALANCED, httpStatus 409)
- analysis__Payment-OAS-FSD-en.docx.txt §7.1 (line 52-53) and Step 1 of the five-step flow (line 31)
- analysis__Payment_Component_Calculation_Validation.docx.txt §13.2 scenario 6 (800020 vs 800000+20 passes; 800020 vs 800000+19.99 throws)

## Related Knowledge
- [[Request Validation]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
