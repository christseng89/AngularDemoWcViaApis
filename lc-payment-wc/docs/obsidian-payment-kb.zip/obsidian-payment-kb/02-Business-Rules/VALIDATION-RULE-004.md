---
knowledge_id: VALIDATION-RULE-004
title: "A cross-currency suspenseBridge entry with no crossRate throws RequestValidationError before the balance check runs"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - validation
  - confirmed
---

# VALIDATION-RULE-004 — A cross-currency suspenseBridge entry with no crossRate throws RequestValidationError before the balance check runs

## Status
CONFIRMED

## Business Rule
buildSuspenseBridgeLeg (suspenseBridge.ts) throws RequestValidationError when a suspenseBridge entry's currency differs from the transaction currency and entry.crossRate is absent — this happens during the pre-Step-1 bridge expansion (called from confirmPaymentInstruction.ts before validateDrCrBalance), so the request never reaches the V8 balance check. Merged with the near-duplicate 'cross-ccy-crossrate-required' entry (same rule, same evidence file, different citation angle).

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
suspenseBridge.debitEntries=[{amount:'10', currency:'EUR'}] with no crossRate, against a USD transaction -> RequestValidationError thrown; store.find('IPLC','REF-SB-5',1) is undefined.

## Verification Note
Confirmed by direct read of suspenseBridge.ts lines 120-152. Merged the duplicate 'cross-ccy-crossrate-required' entry (from the 'suspense' extraction group) into this one — identical rule, identical evidence file, no new information.

## Source Evidence
- microservices/payment-component/src/domain/suspenseBridge.ts lines 120-137 (the currency !== transactionCurrency branch, the `if (!entry.crossRate) throw new RequestValidationError(...)` check)
- test/unit/domain/suspenseBridge.test.ts lines 59-63 ('throws RequestValidationError when currency differs but crossRate is missing')
- test/unit/domain/confirmPaymentInstruction.test.ts: 'propagates RequestValidationError when a cross-currency entry has no crossRate, before the balance check ever runs' — store.find('IPLC','REF-SB-5',1) confirmed undefined afterward

## Related Knowledge
- [[Request Validation]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
