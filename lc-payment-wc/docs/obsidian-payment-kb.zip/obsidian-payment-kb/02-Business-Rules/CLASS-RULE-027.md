---
knowledge_id: CLASS-RULE-027
title: "Which legacy module (EPLC vs EXCO) genuinely owns each of the export-side use cases (3-5) is unresolved"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - classification
  - confirmed
---

# CLASS-RULE-027 — Which legacy module (EPLC vs EXCO) genuinely owns each of the export-side use cases (3-5) is unresolved

## Status
CONFIRMED

## Business Rule
The legacy system models 'Export LC' functions across two separate modules — EPLC (Export Letter of Credit) and EXCO (Export Collection) — with different registered functions and different voucher-code prefixes. Use Case 3 (Export LC Sight) is defaulted to EXCO:Payment specifically because it is an unambiguous existing PASS case, but the document explicitly asks for confirmation this is the correct legacy screen for 'Export LC Sight' versus an EPLC function instead. This ambiguity applies to Use Cases 3, 4, and 5 collectively.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
No worked numeric example available in the source evidence reviewed.

## Verification Note
Upgraded from UNCLEAR to CONFIRMED-as-an-open-question: re-read the actual document text at both cited lines and confirmed the document itself explicitly frames this as an open, unresolved question requiring confirmation — the ORIGINAL claim (that this ambiguity exists and is unresolved in the source) is directly and clearly supported by the primary document text, not merely inferred. (Note: the underlying business question — which module truly owns each use case — remains itself unresolved/UNCLEAR as a business fact; but the rule being verified is 'this ambiguity is present and flagged in the source', which is CONFIRMED.)

## Source Evidence
- PaymentComponentProposedUseCases-EN.docx.txt (converted) line 113, Use Case 3 'Open items for review' — 'Module choice (EPLC vs EXCO) applies to Use Cases 3–5 ... please confirm this is the correct legacy screen for "Export LC Sight," vs. an EPLC function instead.'
- PaymentComponentProposedUseCases-EN.docx.txt line 171, Cross-cutting Open Questions Summary item 2

## Related Knowledge
- [[Payment Instruction Classification]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
