---
knowledge_id: FX-RULE-011
title: "When sizing the real-leg side of an FX pair by native currency amount, the module reads each leg's amountAccountCcy, falling back to amountTxCcy only when amountAccountCcy is absent"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - fx
  - confirmed
---

# FX-RULE-011 — When sizing the real-leg side of an FX pair by native currency amount, the module reads each leg's amountAccountCcy, falling back to amountTxCcy only when amountAccountCcy is absent

## Status
CONFIRMED

## Business Rule
sumLegsInCurrency filters legs by currency and sums amountAccountCcy ?? amountTxCcy — deliberately NOT amountTxCcy directly. The fallback exists for a raw API caller that omitted amountAccountCcy.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
No worked numeric example available in the source evidence reviewed.

## Verification Note
Confirmed by direct code read. Note: the expert-review's M-4 finding (see zero-exchange-rate-drops-charge-silently's sibling rule 'sumLegsInCurrency-wrong-fallback') criticizes this exact fallback as producing a wrong native-currency magnitude for a caller who omits amountAccountCcy, since amountTxCcy is transaction-currency-denominated, not native. That is a legitimate critique of this same code, not a contradiction — both rules describe the identical fallback from a factual vs. evaluative angle. No status change.

## Source Evidence
- suspenseBridge.ts lines 221-225 (sumLegsInCurrency)

## Related Knowledge
- [[FX Processing]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
