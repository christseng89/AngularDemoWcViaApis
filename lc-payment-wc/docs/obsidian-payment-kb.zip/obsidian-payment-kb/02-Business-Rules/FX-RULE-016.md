---
knowledge_id: FX-RULE-016
title: "Suspense-bridge DEBIT-side FX pair is sized to the NET shortfall/excess between the Suspense bucket and matching real debit legs in that currency, not the gross amount of either — demonstrated end-to-end by curl case 1"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - fx
  - confirmed
---

# FX-RULE-016 — Suspense-bridge DEBIT-side FX pair is sized to the NET shortfall/excess between the Suspense bucket and matching real debit legs in that currency, not the gross amount of either — demonstrated end-to-end by curl case 1

## Status
CONFIRMED

## Business Rule
For an EUR Suspense-Debit bucket (12 EUR, crossRate 1.0831) coexisting with a real EUR Customer Debit leg (200 EUR), the service nets grossSuspense(12 EUR) against debitLegs sum(200 EUR), finds debitLegs exceed Suspense by 188 EUR (203.62 USD-equivalent), and emits exactly ONE DEBIT-direction Leg-anchored FX Exchange pair sized to that excess.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
grossSuspense=12 EUR (13.00 USD-eq), debitLegs EUR=200 EUR (216.62 USD-eq) -> diffNative=-188, diffTrx=-203.62 -> single Leg-anchored pair for 188 EUR / 203.62 USD; Total Debit=Total Credit=10246.62.

## Verification Note
Merged with 'fx-pair-netting-debit-only' (id_hint 54) below — same rule, same evidence, restated with a slightly different worked example (curl case 1 vs the CLAUDE.md Import LC Pay/Accept example). Kept as one entry citing both; see 54 for cross-reference. Arithmetic independently verified against Payment-Component-Suspense-FX-Test-Cases-zh.md's Case #1 text. No status change.

## Source Evidence
- suspenseBridge.ts expandSuspenseBridge() DEBIT-side branch
- test/curl-tests/requests/case1-suspense-fx-and-nostro-usd.json
- Payment-Component-Suspense-FX-Test-Cases-zh.md 'Case #1' section

## Related Knowledge
- [[FX Processing]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
