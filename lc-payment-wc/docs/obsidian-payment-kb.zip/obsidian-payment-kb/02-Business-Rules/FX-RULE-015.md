---
knowledge_id: FX-RULE-015
title: "amountTxCcy is denominated in the deal's transactionCurrency, not any leg's own settlement currency; amountAccountCcy is denominated in the leg's own currency"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - fx
  - confirmed
---

# FX-RULE-015 — amountTxCcy is denominated in the deal's transactionCurrency, not any leg's own settlement currency; amountAccountCcy is denominated in the leg's own currency

## Status
CONFIRMED

## Business Rule
amountTxCcy on every leg is validated against data.transactionCurrency's own decimal scale (v1.10.0 field), NOT the individual leg's own `currency` field. Before v1.10.0, transactionCurrency was inferred as debitLegs[0].currency — retained only as a fallback when the field is omitted. amountAccountCcy is validated against the LEG's own currency field.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
Transaction currency USD (2dp), sole leg settles in JPY with amountTxCcy '10000.00' and transactionCurrency:'USD' sent explicitly -> validates successfully.

## Verification Note
Confirmed directly in requestSchema.ts. No status change.

## Source Evidence
- requestSchema.ts line 172 (`const transactionCurrency = data.transactionCurrency ?? data.debitLegs?.[0]?.currency;`)
- test/unit/validation/requestSchema.test.ts 'v1.10.0: uses the explicit transactionCurrency field...' tests

## Related Knowledge
- [[FX Processing]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
