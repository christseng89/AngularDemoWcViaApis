---
knowledge_id: FX-RULE-039
title: "sumLegsInCurrency's fallback treats transaction-currency amount as native currency, mixing currencies"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - fx
  - confirmed
---

# FX-RULE-039 — sumLegsInCurrency's fallback treats transaction-currency amount as native currency, mixing currencies

## Status
CONFIRMED

## Business Rule
When a foreign-currency leg omits amountAccountCcy, sumLegsInCurrency falls back to amountTxCcy (transaction-currency-denominated) as if it were the native-currency figure, to size the FX pair. Documented in code as intentional, but for a raw API caller who omits amountAccountCcy it silently produces a wrong FX-pair magnitude.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
No worked numeric example available in the source evidence reviewed.

## Verification Note
Confirmed directly — this is the identical code already verified under 'native-ccy-sum-uses-account-ccy-with-fallback' above, viewed here from the expert-review's critical angle rather than the factual/descriptive angle. Both entries describe the same fallback; kept as separate list items (per the original candidate IDs, sourced from different groups) but cross-referenced. No status change.

## Source Evidence
- payment-component-expert-review.md M-4 (suspenseBridge.ts:216-220)
- suspenseBridge.ts lines 221-225 (sumLegsInCurrency: `l.amountAccountCcy ?? l.amountTxCcy` — already confirmed above under 'native-ccy-sum-uses-account-ccy-with-fallback')

## Related Knowledge
- [[FX Processing]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
