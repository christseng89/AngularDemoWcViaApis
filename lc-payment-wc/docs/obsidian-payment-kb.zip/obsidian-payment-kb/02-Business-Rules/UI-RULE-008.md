---
knowledge_id: UI-RULE-008
title: "A row is removed from the grid the instant it settles at exactly 0% AND 0 amount, for both waterfalls"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - ui
  - confirmed
---

# UI-RULE-008 — A row is removed from the grid the instant it settles at exactly 0% AND 0 amount, for both waterfalls

## Status
CONFIRMED

## Business Rule
pruneZeroRow() splices out (in place) any row whose pct and amountTxCcy have both settled at exactly 0 — a donor drained by rule 4's backward cascade, the LAST row when rule 1's cap drains it to 0, or the edited row itself when a decrease settles it at 0. This is a UI-only grid-cleanliness change, not a wire-contract change: emit() already excludes 0%-rows from PaymentLegInput[] via its own pct.greaterThan(0) filter beforehand. Deliberately exempt: the single-row (not-yet-split) fixRow/ensureRemainderRow bypass path, and the grid is never pruned below 1 row.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
n/a

## Verification Note
Directly confirmed against source: pruneZeroRow implementation and all four/five call sites match the claim exactly, including the wentThroughWaterfall gating that exempts the single-row bypass.

## Source Evidence
- pruneZeroRow() lines 946-954 — length<=1 guard, checks row.pct.isZero() && row.amountTxCcy.isZero(), splices in place
- call sites in applyAmountWaterfall (897, 912) and applyPctWaterfall (718, 733) rule-4/rule-1 branches, plus onAmountInput/onAccountAmountInput/onPctInput's own edited-row prune check gated on wentThroughWaterfall (lines 781, 993, 1061)

## Related Knowledge
- [[Payment Component Simulator UI]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
