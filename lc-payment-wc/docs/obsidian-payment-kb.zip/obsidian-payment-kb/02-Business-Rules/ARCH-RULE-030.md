---
knowledge_id: ARCH-RULE-030
title: "Mixed Payment (Sight/Usance split) percentage/amount split happens in the calling module BEFORE this API is invoked"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - architecture
  - confirmed
---

# ARCH-RULE-030 — Mixed Payment (Sight/Usance split) percentage/amount split happens in the calling module BEFORE this API is invoked

## Status
CONFIRMED

## Business Rule
CPYT_C_PAY_PER/CPYT_N_PAY_AMT (per-leg split percentage/computed amount for Mixed Payment scenarios) are deliberately absent from PaymentLegInput — this split/recalculation (SYM_IPLC_CAL_AMEND_PAYMENT_AMT) happens inside the calling module before this OAS is invoked; the module submits the already-split amountTxCcy per leg. Confirmed not a gap.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
PaymentLegInput has no split-percentage field; each leg carries a pre-split final amount

## Example
No worked numeric example available in the source evidence reviewed.

## Verification Note
Confirmed directly against two independent locations in the same document (the field table and the explicit 'not gaps' section), which agree. Unchanged.

## Source Evidence
- converted/analysis__Payment_Mapping_Functions.docx.txt §5 table row, line 131, directly re-read: 'CPYT_C_PAY_PER, CPYT_N_PAY_AMT (Mixed Payment) | — (not in scope of this OAS) | N/A (out of scope) | Mixed Payment term split/recalculation (SYM_IPLC_CAL_AMEND_PAYMENT_AMT) happens inside the calling module before this OAS is invoked'
- §10.6 'Not gaps — confirmed by design' list, line 76, directly re-read, restating the same conclusion

## Related Knowledge
- [[Payment Architecture]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
