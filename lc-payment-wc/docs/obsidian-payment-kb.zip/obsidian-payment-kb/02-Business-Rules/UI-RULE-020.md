---
knowledge_id: UI-RULE-020
title: "Suspense entry rows are tracked by a monotonically-increasing row id, not array index, for stable rendering across add/remove"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - ui
  - confirmed
---

# UI-RULE-020 — Suspense entry rows are tracked by a monotonically-increasing row id, not array index, for stable rendering across add/remove

## Status
CONFIRMED

## Business Rule
Each row gets a unique id from a module-level rowIdCounter incremented on every addRow(); trackById returns this id (not the loop index) so Angular's *ngFor keeps DOM identity stable when a row in the middle of the list is removed, rather than every subsequent row's input state shifting.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
n/a

## Verification Note
Confirmed exactly against source.

## Source Evidence
- suspense-entries.component.ts line 26 (module-level `let rowIdCounter = 0`), lines 63-65 (trackById returns row.id), lines 67-71 (addRow increments rowIdCounter and assigns as id)

## Related Knowledge
- [[Payment Component Simulator UI]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
