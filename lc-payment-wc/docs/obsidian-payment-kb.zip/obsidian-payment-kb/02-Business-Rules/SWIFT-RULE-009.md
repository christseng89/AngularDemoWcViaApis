---
knowledge_id: SWIFT-RULE-009
title: "MT400/MT756 intentionally excluded from payAdviceMsgType — owned by the main transaction, not a schema gap"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - swift
  - confirmed
---

# SWIFT-RULE-009 — MT400/MT756 intentionally excluded from payAdviceMsgType — owned by the main transaction, not a schema gap

## Status
CONFIRMED

## Business Rule
MT400 (collection advice) and MT756 (documentary credit advice) are Category 4/7 messages describing the underlying trade instrument's status, not a real funds-transfer instruction — they are intentionally excluded from the Payment Component's payAdviceMsgType enum and remain the responsibility of the calling module (IPLC/EPLC/IMCO/EXCO), which generates and sends them itself, entirely outside this service's API. Confirmed as an intentional design decision (§4.2.3/§4.2.4), not a schema gap.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
n/a

## Verification Note
Re-read all three cited documents at the given line ranges; the exclusion and its rationale are stated identically and repeatedly across all of them. CONFIRMED.

## Source Evidence
- analysis__Payment-OAS-FSD-en.docx.txt §2.2 (line 19) and §7.5
- analysis__PaymentComponent-Microservice-FSD-zh.docx.txt §4.2.4 (lines 110-111) — '主交易(IPLC/EPLC/IMCO/EXCO)自行產生並送出其 MT400/MT756 通知報文...完全不在支付組件服務的 API 範圍內'; also lines 844, 890, 911-912, 1011 all reiterating the exclusion
- analysis__Payment_Mapping_Functions.docx.txt §10.6 (line 76) and line 128 — 'MT400/MT756 absent from payAdviceMsgType — intentional Payment Component scope boundary (FSD §4.2.3)'

## Related Knowledge
- [[SWIFT Messaging and Vouchers]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
