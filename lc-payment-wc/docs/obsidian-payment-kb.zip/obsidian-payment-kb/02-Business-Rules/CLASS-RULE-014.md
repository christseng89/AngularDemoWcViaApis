---
knowledge_id: CLASS-RULE-014
title: "A single Transaction Currency/Amount override, when set, seeds BOTH sides' Leg #1 identically"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - classification
  - confirmed
---

# CLASS-RULE-014 — A single Transaction Currency/Amount override, when set, seeds BOTH sides' Leg #1 identically

## Status
CONFIRMED

## Business Rule
transactionCurrencyOverride and transactionAmountOverride, once set via the header inputs, take priority over the selected case's own registry legs for BOTH debitDefaults and creditDefaults equally — matching the invariant that every registry business case already keeps its own debit/credit defaults symmetric (required for V8 balance). Clearing either override reverts to the case's own registry-derived default. Reset to null on every selectCase().

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
No worked numeric example available in the source evidence reviewed.

## Verification Note
Read sideDefaults() and selectCase() directly — confirmed both debitDefaults/creditDefaults call sideDefaults() which uses the shared override, and the override is reset to null in selectCase().

## Source Evidence
- src/app/payment-component/business-case-runner.component.ts sideDefaults() lines 469-493 (doc comment lines 464-467, `currency = this.transactionCurrencyOverride ?? legs[0]?.defaultCurrency ?? 'USD'` at line 471), onTransactionCurrencyInput/onTransactionAmountInput lines 266-280
- selectCase() reset at line 646 `this.transactionCurrencyOverride = null;`

## Related Knowledge
- [[Payment Instruction Classification]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
