---
knowledge_id: VALIDATION-RULE-035
title: "AML/sanctions screening and authN/authZ are explicitly out of scope for this service (per FSD §8.2)"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - validation
  - confirmed
---

# VALIDATION-RULE-035 — AML/sanctions screening and authN/authZ are explicitly out of scope for this service (per FSD §8.2)

## Status
CONFIRMED

## Business Rule
The v1.2.0 changelog records AML/sanctions screening and authentication/authorization as explicitly out-of-scope for this Payment Component service, per FSD §8.2 — these concerns are handled elsewhere in the broader system, not within POST /payment-instructions.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
n/a — scope statement.

## Verification Note
Confirmed exactly by direct read of both cited sources, in full agreement.

## Source Evidence
- analysis/Payment_component.yaml lines 45-46 ('recorded AML/sanctions screening and authN/authZ as explicitly out-of-scope (FSD §8.2)')
- analysis__Payment-OAS-FSD-en.docx.txt line 124 ('Out of scope: FX rate resolution, AML/sanctions, authN/authZ: Explicitly delegated to upstream systems/gateways')

## Related Knowledge
- [[Request Validation]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
