---
knowledge_id: TEST-RULE-002
title: "Only shared.ts's pure helper functions have unit test coverage under web-components/ — none of the 9 LC *.element.ts files (nor journal-entry.element.ts) have their own spec file"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - testscenario
  - confirmed
---

# TEST-RULE-002 — Only shared.ts's pure helper functions have unit test coverage under web-components/ — none of the 9 LC *.element.ts files (nor journal-entry.element.ts) have their own spec file

## Status
CONFIRMED

## Business Rule
A glob for '**/web-components/**/*.spec.*' returns exactly one file, shared.spec.ts, covering round/fmt/escapeHtml/CCYS/ddaAcctsByCcy/chargeAmt/groupChargesByCcy. None of the LC element files under web-components/import/ (lc-issue, lc-settlement, lc-sight-payment, lc-sight-settlement — 4 files) or web-components/export/ (lc-advise, lc-collection, lc-confirmed, lc-nego, lc-settlement — 5 files), nor journal-entry.element.ts, have a corresponding spec file — meaning every business rule that lives inside one of these *.element.ts files (commission floors, quarter-rounding, FBC-embedding logic, FX gain/loss display, state-reset behavior) is evidenced only by reading the implementation and its own code comments, not by an executable test.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
No worked numeric example available in the source evidence reviewed.

## Verification Note
Original claim said '11 LC *.element.ts files' — this count is WRONG and was corrected on re-verification. Direct enumeration of web-components/import/ and web-components/export/ finds exactly 9 *.element.ts files (4 import + 5 export), matching the README's own count ('the 9 vanilla Custom Elements under web-components/import|export/', README.md:122) and the cross-domain rule 'web-components-attribute-driven-contract' ('The 10 LC Payment widgets...' = 9 LC elements + journal-entry.element.ts). journal-entry.element.ts is separate (not under import/export, not counted in the README's '9 vanilla' figure, but still confirmed to have no spec file of its own). Downgraded the specific count from 11→9 but the substantive claim (no spec files exist for any of these element files) is fully CONFIRMED by direct file-glob evidence. jest.config.js itself was not present in this upload set to independently verify collectCoverageFrom's exact contents, so that detail rests on README.md's own text plus the cross-referencing expert-review doc (see next rule).

## Source Evidence
- find on src/app/web-components for *.spec.* returns only src/app/web-components/shared.spec.ts
- find on src/app/web-components for *.element.ts returns 9 files under import/ and export/ plus journal-entry.element.ts (10 total), none with a matching .spec.ts
- README.md:122-126: 'Not yet covered — a separate follow-up: the 9 vanilla Custom Elements under web-components/import|export/ ... excluded from collectCoverageFrom in jest.config.js'

## Related Knowledge
- [[Testing Methodology and Coverage]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
