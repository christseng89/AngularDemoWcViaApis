---
knowledge_id: CLASS-RULE-016
title: "An N_A (confirmed non-user) business case renders a static citation card only — no form, no API call, no live preview subscription"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - classification
  - confirmed
---

# CLASS-RULE-016 — An N_A (confirmed non-user) business case renders a static citation card only — no form, no API call, no live preview subscription

## Status
CONFIRMED

## Business Rule
selectCase() only opens the debounced preview subscription (merge of form.valueChanges and legsChanged$) when businessCase.verdict !== 'N_A'. The template shows a static 'Confirmed Non-User' card with sc.moduleStats for an N_A case instead of the header form / leg allocators.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
No worked numeric example available in the source evidence reviewed.

## Verification Note
Confirmed directly — selectCase()'s conditional and the template's na-card *ngIf both match the claim exactly.

## Source Evidence
- src/app/payment-component/business-case-runner.component.ts lines 629-654 (selectCase(): `if (businessCase && businessCase.verdict !== 'N_A') { ...previewSub = merge(...).subscribe() }`)
- src/app/payment-component/business-case-runner.component.html line 48 `<div class="na-card" *ngIf="sc.verdict === 'N_A'">`

## Related Knowledge
- [[Payment Instruction Classification]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
