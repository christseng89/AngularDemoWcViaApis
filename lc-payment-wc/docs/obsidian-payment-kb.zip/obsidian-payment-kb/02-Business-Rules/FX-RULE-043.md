---
knowledge_id: FX-RULE-043
title: "Same Currency + Same Amount → Direct Settlement → No FX Pair (debit side only, v1.9.0)"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - fx
  - confirmed
---

# FX-RULE-043 — Same Currency + Same Amount → Direct Settlement → No FX Pair (debit side only, v1.9.0)

## Status
CONFIRMED

## Business Rule
Duplicate of 'debit-bucket-fx-netting-v1.9.0' at the top of this list — same rule, sourced from CLAUDE.md's own v1.9.0 decision-log entry rather than the code/test files directly.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
Exact match: EUR 100 Suspense Debit + EUR 100 real debit leg → zero FX pair, direct settlement, no double conversion.

## Verification Note
Merged with 'debit-bucket-fx-netting-v1.9.0' — identical rule and root evidence (the code was already read and confirmed in full above). No status change.

## Source Evidence
- CLAUDE.md v1.9.0 decision-log section
- suspenseBridge.ts (already fully verified above)

## Related Knowledge
- [[FX Processing]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
