---
knowledge_id: VALIDATION-RULE-009
title: "MonetaryAmount/ExchangeRate are decimal STRINGS with fixed patterns, never binary floats — enforced at a single money.ts choke point"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - validation
  - confirmed
---

# VALIDATION-RULE-009 — MonetaryAmount/ExchangeRate are decimal STRINGS with fixed patterns, never binary floats — enforced at a single money.ts choke point

## Status
CONFIRMED

## Business Rule
MONETARY_AMOUNT_PATTERN = /^-?\d{1,18}(\.\d{1,3})?$/ (optional leading '-', 1-18 integer digits, optional 1-3 decimal digits); EXCHANGE_RATE_PATTERN = /^\d{1,12}(\.\d{1,10})?$/ (unsigned — no leading '-' at all, so a negative rate is rejected by the pattern itself, not a separate sign check; 1-12 integer digits, optional 1-10 decimal digits). parseMonetaryAmount/parseExchangeRate throw InvalidMonetaryAmountError/InvalidExchangeRateError on a non-match. requestSchema.ts's monetaryAmountSchema/exchangeRateSchema (zod .regex()) enforce these same patterns at the API boundary before any decimal-place/negativity/positivity check runs. Merges 5 near-duplicate id_hints describing the same two patterns from different files (money.ts, requestSchema.ts, payment-component.types.ts, both OAS yaml files, both FSD docs) — all consistent, no conflicting detail found anywhere.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
'1.234' parses OK (3dp); '1.2345' throws InvalidMonetaryAmountError. '10000.00' valid MonetaryAmount; '149.0825' valid ExchangeRate.

## Verification Note
Confirmed by direct read of money.ts, requestSchema.ts, and cross-checked against the OAS yaml and both FSD doc excerpts — all in exact agreement. Merged 'exchange-rate-pattern-unsigned', 'monetary-exchange-rate-decimal-string-patterns', 'monetary-amount-wire-precision-cap', and 'decimal-string-monetary-amounts' into this single entry as they all describe the identical two regex patterns from different citation angles with no substantive difference.

## Source Evidence
- microservices/payment-component/src/money.ts lines 14-46 (both patterns, both parse functions, both error classes)
- microservices/payment-component/src/validation/requestSchema.ts lines 29-40 (monetaryAmountSchema/exchangeRateSchema, importing the same patterns)
- microservices/payment-component/test/unit/money.test.ts: 'throws for more than 3 decimal places', 'parses a negative amount', 'parses an amount with up to 3 decimal places', 'throws InvalidExchangeRateError for a negative rate (pattern has no leading -)'
- src/app/payment-component/payment-component.types.ts lines 25-28 (client-side duplicate MonetaryAmount/ExchangeRate type doc comments citing the identical patterns)
- analysis/Payment_component.yaml lines 438-451 (OAS MonetaryAmount/ExchangeRate schema+pattern+description)
- analysis__Payment-OAS-FSD-en.docx.txt line 40, line 124 (both patterns cited with worked examples '800000.20', '7.802350')

## Related Knowledge
- [[Request Validation]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
