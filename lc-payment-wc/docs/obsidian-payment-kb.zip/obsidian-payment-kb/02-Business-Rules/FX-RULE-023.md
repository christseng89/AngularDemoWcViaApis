---
knowledge_id: FX-RULE-023
title: "The FX Conversion Pair table is a client-side preview only — never sent to or returned by the microservice"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - fx
  - confirmed
---

# FX-RULE-023 — The FX Conversion Pair table is a client-side preview only — never sent to or returned by the microservice

## Status
CONFIRMED

## Business Rule
FxPairEntry.rate and the whole fxPairs getter are explicitly documented as a same-page simulation for the UI, distinct from and never conflated with a real settlement entry's server-returned AccountEntry.exchangeRate1.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
No worked numeric example available in the source evidence reviewed.

## Verification Note
Confirmed both sides of this claim directly: leg-allocator.component.ts's fxPairs is a pure getter computing client-side values never included in emit()'s wire payload (emit() was inspected and only builds debitLegs/creditLegs/suspenseBridge — no fxPairs field), and response-viewer.component.ts's own doc comment independently corroborates the 'never conflate' framing. No status change.

## Source Evidence
- leg-allocator.component.ts FxPairEntry doc comment lines 102-115
- response-viewer.component.ts line 28 doc comment: 'NEVER conflate the two: for a real settlement entry it's AccountEntry.exchangeRate1...'

## Related Knowledge
- [[FX Processing]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
