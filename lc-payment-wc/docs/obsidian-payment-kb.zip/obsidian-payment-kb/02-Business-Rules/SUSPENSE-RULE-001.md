---
knowledge_id: SUSPENSE-RULE-001
title: "suspenseBridge expansion happens before the V8 balance check, so a caller must pre-fund the bridge amount in its own legs or the request is rejected as unbalanced"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - suspense
  - confirmed
---

# SUSPENSE-RULE-001 — suspenseBridge expansion happens before the V8 balance check, so a caller must pre-fund the bridge amount in its own legs or the request is rejected as unbalanced

## Status
CONFIRMED

## Business Rule
expandSuspenseBridge runs before Step 1's validateDrCrBalance in confirmPaymentInstruction.ts, generating the offsetting bridge leg(s) which are then included in the aggregate balance check. A caller that submits a suspenseBridge.debitEntries amount WITHOUT increasing its own real debitLegs total by the same amount produces an unbalanced voucher and gets a 409.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
debitLegs=[{CUST-ACC,USD,110}] (100 base + 10 pre-adjustment) + suspenseBridge.debitEntries=[{10,USD}] balances; debitLegs=[{CUST-ACC,USD,100}] (unadjusted) + the same bridge entry throws BusinessValidationError.

## Verification Note
Re-read confirmPaymentInstruction.ts lines 1-221 in full and confirmed the bridge expansion (line 152) precedes validateDrCrBalance (line 175). Confirmed both cited test names exist verbatim in confirmPaymentInstruction.test.ts. Status unchanged: CONFIRMED.

## Source Evidence
- src/domain/confirmPaymentInstruction.ts lines 142-176 (transactionCurrency derivation, bridge expansion, then validateDrCrBalance at line 175) — read in full, confirmed
- test/unit/domain/confirmPaymentInstruction.test.ts line 219 'expands debitEntries into a Suspense - Debit leg BEFORE the balance check, and includes it in accountEntries' — test present
- test/unit/domain/confirmPaymentInstruction.test.ts line 238 'a debitEntries bridge WITHOUT the caller pre-adjusting its own debit total is unbalanced -> 409' — test present

## Related Knowledge
- [[Suspense Account]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
