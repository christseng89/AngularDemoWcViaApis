---
knowledge_id: CLASS-RULE-009
title: "Every legacy module/function is classified PASS / GAP / N_A relative to Payment Component usage"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - classification
  - confirmed
---

# CLASS-RULE-009 — Every legacy module/function is classified PASS / GAP / N_A relative to Payment Component usage

## Status
CONFIRMED

## Business Rule
Each simulated business case carries a Verdict of PASS (legacy source code confirmed to call the Payment Component's voucher-description routine directly in ConfirmBusinessCall), GAP (Payment/RTGS legs are populated in source but no voucher-assembly routine exists — 'classify-only' preview), or N_A (the module/function never touches PaymentDebit/PaymentCredit at all, even if it calls a generic charge-voucher routine). The registry has 15 PASS + 4 GAP + 4 N_A = 23 total cases.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
iplc-pay-accept is PASS, citation 'SYF_IPLC_IPLC_PayAccept.js:23 (ConfirmBusinessCall) → SYF_IPLC_CAL_PAYMENT_AC_DESC():193'; rpfm-process-grantor is GAP ('calls no Payment/voucher routine of any kind'); cfnc-non-user is N_A ('never calls any voucher routine at all').

## Verification Note
Directly confirmed business-case.model.ts's Verdict type and business-case-registry.spec.ts's exact test title. No changes needed.

## Source Evidence
- src/app/payment-component/business-case.model.ts line 3 (Verdict type)
- src/app/payment-component/business-case-registry.ts PASS_CASES/GAP_CASES/NA_CASES section headers and per-case citation/note fields
- src/app/payment-component/business-case-registry.spec.ts line 4 'has 15 PASS...+4 GAP+4 N_A cases (23 total)'

## Related Knowledge
- [[Payment Instruction Classification]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
