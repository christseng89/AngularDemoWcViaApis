---
knowledge_id: API-RULE-003
title: "sourceFunctionCode / voucherCodePrefixOverride / dryRun are accepted alongside the strict OAS body but are NOT part of the formal validated schema"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - api
  - confirmed
---

# API-RULE-003 — sourceFunctionCode / voucherCodePrefixOverride / dryRun are accepted alongside the strict OAS body but are NOT part of the formal validated schema

## Status
CONFIRMED

## Business Rule
The request body is validated against paymentInstructionConfirmRequestSchema (the strict OAS-mirrored shape), but the route handler separately reads sourceFunctionCode, voucherCodePrefixOverride, and dryRun directly off the raw req.body, bypassing zod validation entirely for those three fields. sourceFunctionCode is documented in voucherDescription.ts as required out-of-band since the OAS request body carries only originModule, not a function/screen identifier.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
No worked numeric example available in the source evidence reviewed.

## Verification Note
Re-read routes/paymentInstructions.ts and requestSchema.ts directly; confirmed the three fields are absent from the zod schema and read raw off req.body. No change to status.

## Source Evidence
- microservices/payment-component/src/routes/paymentInstructions.ts: RequestExtensions interface and doc comment (lines 15-28); `const ext = req.body as RequestExtensions;` (line 43)
- microservices/payment-component/src/validation/requestSchema.ts: paymentInstructionConfirmRequestSchema (lines 82-202) has no sourceFunctionCode/voucherCodePrefixOverride/dryRun fields
- microservices/payment-component/src/domain/voucherDescription.ts: doc comment lines 11-24 on the out-of-band sourceFunctionCode gap

## Related Knowledge
- [[Payment Instructions API]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
