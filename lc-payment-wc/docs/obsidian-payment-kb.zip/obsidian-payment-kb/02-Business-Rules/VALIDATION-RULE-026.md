---
knowledge_id: VALIDATION-RULE-026
title: "HTTP 201 vs 200 on Confirm distinguishes a genuinely new instruction from an idempotent replay; the UI must surface this distinction"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - validation
  - confirmed
---

# VALIDATION-RULE-026 — HTTP 201 vs 200 on Confirm distinguishes a genuinely new instruction from an idempotent replay; the UI must surface this distinction

## Status
CONFIRMED

## Business Rule
ConfirmOutcome.created is true ONLY for HTTP 201 (a genuinely new instruction). For dryRun previews OR a replay of an already-confirmed (originModule, mainRef, sequence), the server returns HTTP 200 with the ORIGINAL result unchanged, regardless of the replay request's own legs (per FSD §6.1). The service's doc comment explicitly warns the UI must distinguish this, since a silent replay showing old/different data would otherwise read as a bug.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
Same POST body submitted twice with identical (originModule, mainRef, sequence) -> first call returns 201/created:true, second call returns 200/created:false with the original instruction's data even if the second request's legs differed.

## Verification Note
Confirmed exactly by direct read of payment-component-api.service.ts — the entire ConfirmOutcome interface and its mapping logic match the claim verbatim.

## Source Evidence
- src/app/payment-component/payment-component-api.service.ts lines 20-32 (ConfirmOutcome doc comment), line 49 (`created: res.status === 201`)
- payment-component-api.service.spec.ts: 'reports created:true only for HTTP 201' and 'reports created:false for HTTP 200 (idempotent replay)' tests

## Related Knowledge
- [[Request Validation]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
