---
knowledge_id: SWIFT-RULE-006
title: "A cover message (MT202/MT202COV/PACS009COV) carries only a settlement amount/currency (32A) and never an instructed amount/currency (33B)"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - swift
  - confirmed
---

# SWIFT-RULE-006 — A cover message (MT202/MT202COV/PACS009COV) carries only a settlement amount/currency (32A) and never an instructed amount/currency (33B)

## Status
CONFIRMED

## Business Rule
buildCoverMessage populates settlementCurrency/settlementAmount from leg.currency/leg.amountAccountCcy ?? leg.amountTxCcy, and deliberately does not set instructedCurrency or instructedAmount at all on the resulting SwiftMessage — reflecting that an interbank cover message settles the interbank amount only.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
n/a

## Verification Note
Re-read buildCoverMessage's object literal directly — confirmed no instructedAmount/instructedCurrency keys exist. Re-read the cited test. CONFIRMED.

## Source Evidence
- src/domain/swiftMessages.ts lines 90-103 — buildCoverMessage: comment 'A cover (MT202/MT202COV) settles the interbank amount only — 32A, no 33B.'; object literal omits instructedCurrency/instructedAmount entirely
- test/unit/domain/swiftMessages.test.ts line ~87-93 — 'produces only a cover message...': expect(messages[0].instructedAmount).toBeUndefined(); expect(messages[0].instructedCurrency).toBeUndefined()

## Related Knowledge
- [[SWIFT Messaging and Vouchers]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
