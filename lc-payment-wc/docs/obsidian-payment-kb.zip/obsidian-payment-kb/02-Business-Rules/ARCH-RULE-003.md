---
knowledge_id: ARCH-RULE-003
title: "previewClassification generates a clearly-namespaced, non-persisted 'preview-' prefixed ID on every call, distinct from a real instructionId"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - architecture
  - confirmed
---

# ARCH-RULE-003 — previewClassification generates a clearly-namespaced, non-persisted 'preview-' prefixed ID on every call, distinct from a real instructionId

## Status
CONFIRMED

## Business Rule
Each previewClassification call generates a fresh randomUUID prefixed 'preview-' as its previewId (used as the classification/accountEntries instructionId for that call), so it can never be mistaken for a real persisted instructionId. A fresh ID is generated on every call — two calls with identical inputs still yield distinct previewIds, and nothing is ever written to the store.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
n/a — identity/formatting rule

## Verification Note
Confirmed directly in the same file read as the previous rule (line 51, not 54 as originally cited, but same statement). CONFIRMED, evidence line number corrected.

## Source Evidence
- microservices/payment-component/src/domain/classifyPreview.ts line 51: `const previewId = \`preview-${randomUUID()}\`;` with the inline comment 'Not persisted — clearly namespaced so it's never mistaken for a real instructionId.'

## Related Knowledge
- [[Payment Architecture]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
