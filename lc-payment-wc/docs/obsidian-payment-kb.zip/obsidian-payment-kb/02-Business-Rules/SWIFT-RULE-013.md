---
knowledge_id: SWIFT-RULE-013
title: "Unlike Account Entry generation (unconditional per leg), SWIFT message record creation is conditional on a credit leg's payAdviceMsgType/payCoverMsgType resolving to a non-None value"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - swift
  - confirmed
---

# SWIFT-RULE-013 — Unlike Account Entry generation (unconditional per leg), SWIFT message record creation is conditional on a credit leg's payAdviceMsgType/payCoverMsgType resolving to a non-None value

## Status
CONFIRMED

## Business Rule
This is the same underlying rule as the merged 'swift-message-generation-gated-by-none' rule above, stated from the contrasting angle of Account Entry generation (step 4, unconditional per leg) vs. SWIFT message generation (step 5, conditional per credit leg on message-type field resolution). Confirmed directly in confirmPaymentInstruction.ts: buildSettlementEntries is called unconditionally for every debit/credit leg (step 4), while buildSwiftMessages internally gates per-leg on payAdviceMsgType/payCoverMsgType !== 'None' (step 5).

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
n/a

## Verification Note
This candidate (id_hint swift-message-only-generated-when-msg-type-resolves, api-contracts group) is substantively the same rule as 'swift-message-generation-gated-by-none' above (already merged from 4 candidates) but was kept as its own entry in the original candidate list specifically to draw the Account-Entry-vs-SWIFT contrast; re-verified that contrast directly against confirmPaymentInstruction.ts's step 4 vs step 5 code. Since the core claim duplicates the already-merged rule, downstream consumers should treat this as the same fact, cross-referenced rather than independently new — flagged here rather than silently dropped, per the merge instructions.

## Source Evidence
- src/domain/confirmPaymentInstruction.ts lines 188-197 — step 4 (buildSettlementEntries) is unconditional for every leg; step 5 (buildSwiftMessages) internally applies the non-None gate documented above
- analysis/Payment_component.yaml paths./payment-instructions.post.description (lines 208-212) contrasting step (4) 'unconditional, independent of the classification result' with step (5) 'when a credit leg's payAdviceMsgType/payCoverMsgType resolves to a non-None value'

## Related Knowledge
- [[SWIFT Messaging and Vouchers]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
