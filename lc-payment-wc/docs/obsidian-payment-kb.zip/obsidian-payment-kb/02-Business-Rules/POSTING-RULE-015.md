---
knowledge_id: POSTING-RULE-015
title: "Two FSD rows (EPLC Pay/Accept, EXCO Settlement at Maturity) record TWO possible voucher prefixes without stating the selecting condition — deliberately left unresolved, requiring caller override"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - accounting
  - confirmed
---

# POSTING-RULE-015 — Two FSD rows (EPLC Pay/Accept, EXCO Settlement at Maturity) record TWO possible voucher prefixes without stating the selecting condition — deliberately left unresolved, requiring caller override

## Status
CONFIRMED

## Business Rule
PaymentComponent-Microservice-FSD-zh.docx §3.3 / Payment_Mapping_Functions.docx §6 record two candidate prefixes each for EPLC Pay/Accept and EXCO Settlement at Maturity without documenting the selecting condition. These two rows are deliberately omitted from VOUCHER_CODE_PREFIXES, and resolveVoucherCodePrefix throws for both.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
No worked numeric example available in the source evidence reviewed.

## Verification Note
UPGRADED from UNCLEAR to CONFIRMED: the original candidate marked this UNCLEAR, but this is not an unresolved business question — it is a confirmed, deliberate, documented design decision in the code (the omission itself, and the requirement for a caller override, are facts about the implementation, verifiable directly in source). The underlying FSD ambiguity (which condition selects the prefix) remains genuinely unresolved, but the RULE being stated — 'these two rows are deliberately omitted and require an override' — is directly confirmed by code, not merely suspected. Re-read voucherDescription.ts to verify.

## Source Evidence
- src/domain/voucherDescription.ts top doc comment (lines 28-35), read directly: 'Two FSD rows (EPLC Pay/Accept: "EPLC07 / EPLC03...", EXCO Settlement at Maturity: "EXCO06 / EXCO01...") record TWO possible prefixes without stating the selecting condition, and are deliberately omitted here'

## Related Knowledge
- [[Accounting Model]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
