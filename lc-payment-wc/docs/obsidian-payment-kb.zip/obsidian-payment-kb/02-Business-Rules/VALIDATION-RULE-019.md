---
knowledge_id: VALIDATION-RULE-019
title: "The header form's Sequence value is coerced to a number before being sent on the wire"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - validation
  - confirmed
---

# VALIDATION-RULE-019 — The header form's Sequence value is coerced to a number before being sent on the wire

## Status
CONFIRMED

## Business Rule
Even though the Formly model may hold sequence as a string, buildConfirmRequest always applies Number(model['sequence']) when constructing the request, guaranteeing a numeric wire payload sequence field.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
model.sequence = '3' (string) -> req.sequence === 3 (number).

## Verification Note
Confirmed exactly by direct read of business-case-request.ts line 22.

## Source Evidence
- src/app/payment-component/business-case-request.ts line 22 (`sequence: Number(model['sequence'])`)
- business-case-request.spec.ts 'coerces model.sequence to a number' (passes string '3', expects number 3)

## Related Knowledge
- [[Request Validation]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
