---
knowledge_id: ARCH-RULE-035
title: "Idempotent replay must compare the request payload, not just the natural key"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - architecture
  - confirmed
---

# ARCH-RULE-035 — Idempotent replay must compare the request payload, not just the natural key

## Status
CONFIRMED

## Business Rule
On a second POST with the same natural key (originModule, mainRef, sequence), the service historically returned the original instruction unconditionally (created:false, HTTP 200) without checking whether the new body actually matched — silently swallowing a genuine correction. The fix (implemented) is to hash/compare the canonical request payload: same payload -> idempotent replay (200); different payload -> reject with 409 IDEMPOTENCY_KEY_CONFLICT. The fingerprint lives at the store layer (save(instruction, fingerprint)), never on the PaymentInstruction (OAS) type — it is a system-controlled common-transaction-field concern, not part of the API request/response body.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
Standard Stripe Idempotency-Key semantics: same key + same payload = replay; same key + different payload = conflict.

## Verification Note
Confirmed both the design-doc description AND the actual shipped implementation directly in confirmPaymentInstruction.ts (not just the doc's own 'Status: implemented' claim) — this is doubly verified against executable logic per the stated evidence-priority order.

## Source Evidence
- docs/payment-component-expert-review.md C-2 section, lines 40-101, directly re-read: full problem description, recommendation, and 'Status: implemented (payload-aware fingerprint at the store layer; 245 tests, 100% coverage)' closing line
- confirmed live in code: microservices/payment-component/src/domain/confirmPaymentInstruction.ts's requestFingerprint()/stableStringify() and the priorFingerprint !== fingerprint 409 IDEMPOTENCY_KEY_CONFLICT branch, directly re-read in the full-file read for rule #1 above

## Related Knowledge
- [[Payment Architecture]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
