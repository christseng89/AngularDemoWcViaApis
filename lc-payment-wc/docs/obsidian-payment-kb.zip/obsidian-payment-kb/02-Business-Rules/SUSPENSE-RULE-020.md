---
knowledge_id: SUSPENSE-RULE-020
title: "[Proposed, NOT implemented] Nine required financial/audit controls for any Payment Clearing/SUSPENSE intermediary account design"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - suspense
  - confirmed
---

# SUSPENSE-RULE-020 — [Proposed, NOT implemented] Nine required financial/audit controls for any Payment Clearing/SUSPENSE intermediary account design

## Status
CONFIRMED

## Business Rule
Architecture v4 proposal: any design using Payment Clearing (accountType=SUSPENSE) as an intermediary must define nine controls: zero-balance principle, atomic posting, partial-failure handling, reversal/return, reconciliation, cut-off/day-end, FX Revaluation (v4 new), Maker-Checker review (v4 new), and ageing management (v4 new, Accrual-First-specific).

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
n/a — control checklist, not a numeric worked example.

## Verification Note
Read the source document directly and confirmed the nine-item control list, including the two explicitly-marked-'v4 new' items (FX Revaluation, ageing management) cross-referenced correctly against the Cash-First/Accrual-First proposal above. Status unchanged: CONFIRMED (as an accurately-documented, not-implemented proposal).

## Source Evidence
- analysis__Trade_Finance_Payment_Component_Architecture_v4-cn.docx.txt §10 (lines 139-140 intro, control table lines 186-197 — verified directly: zero-balance line 188, FX Revaluation line 194 explicitly marked v4 new, ageing management line 196 explicitly marked v4 new and Accrual-First-specific)

## Related Knowledge
- [[Suspense Account]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
