---
knowledge_id: VALIDATION-RULE-014
title: "debitLegs is unconditionally required (min 1); no mechanism can ever synthesize a debit leg"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - validation
  - confirmed
---

# VALIDATION-RULE-014 — debitLegs is unconditionally required (min 1); no mechanism can ever synthesize a debit leg

## Status
CONFIRMED

## Business Rule
debitLegs must contain at least one caller-submitted item in every case (z.array(...).min(1)). This is structural: expandSuspenseBridge always generates its offsetting leg on the CREDIT side regardless of whether the originating Suspense entry came from suspenseBridge.debitEntries or creditEntries — so there is no code path that can ever produce a debit-direction leg other than a caller-submitted PaymentLegInput.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
n/a — structural invariant, no worked failure example needed.

## Verification Note
Confirmed by direct read of requestSchema.ts and cross-checked against suspenseBridge.ts's buildSuspenseBridgeLeg, which indeed always builds a credit-direction leg.

## Source Evidence
- microservices/payment-component/src/validation/requestSchema.ts lines 92-98 (debitLegs.min(1) and its inline comment explaining why, citing suspenseBridge.ts's always-credit generation)
- microservices/payment-component/src/domain/suspenseBridge.ts (buildSuspenseBridgeLeg always returns accountType:'SUSPENSE' credit-direction, confirmed by direct read)

## Related Knowledge
- [[Request Validation]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
