---
knowledge_id: POSTING-RULE-045
title: "suspenseBridge.debitEntries vs creditEntries: both always generate a credit-direction leg; the choice depends on which real leg the charge is conceptually netted against"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - accounting
  - confirmed
---

# POSTING-RULE-045 — suspenseBridge.debitEntries vs creditEntries: both always generate a credit-direction leg; the choice depends on which real leg the charge is conceptually netted against

## Status
CONFIRMED

## Business Rule
Both debitEntries and creditEntries always generate a credit-direction leg. Which list to use is decided by which side's real leg the charge/liability entry is conceptually netted against: debitEntries when the bridged amount is added to a debit leg; creditEntries when it reduces (or wholly substitutes for) a credit leg.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
Use Case 1 (fee collection): creditLegs empty, suspenseBridge.creditEntries generates the sole Cr Suspense-Credit leg.

## Verification Note
Directly corroborated by code read this pass — `credit.push(leg)` is unconditional for both the debitEntries-sourced and creditEntries-sourced legs in expandSuspenseBridge's loop.

## Source Evidence
- PaymentComponentProposedUseCases-EN.docx.txt, 'How to read each use case' section (cited)
- Directly corroborated this pass by expandSuspenseBridge/buildSuspenseBridgeLeg's code (read in full) — both accountNo='Suspense - Debit' and accountNo='Suspense - Credit' entries are always pushed to the `credit` array unconditionally

## Related Knowledge
- [[Accounting Model]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
