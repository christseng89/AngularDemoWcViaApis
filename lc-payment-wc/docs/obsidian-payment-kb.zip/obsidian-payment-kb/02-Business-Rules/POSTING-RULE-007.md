---
knowledge_id: POSTING-RULE-007
title: "formatMonetaryAmount rounds to a given currency scale using ROUND_HALF_UP; omitting scale leaves existing precision untouched"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - accounting
  - confirmed
---

# POSTING-RULE-007 — formatMonetaryAmount rounds to a given currency scale using ROUND_HALF_UP; omitting scale leaves existing precision untouched

## Status
CONFIRMED

## Business Rule
formatMonetaryAmount(value, scale) rounds to `scale` decimal places using Decimal.ROUND_HALF_UP when scale is passed. When scale is omitted, the Decimal's current precision is preserved unchanged. The formatted string is re-validated against MONETARY_AMOUNT_PATTERN and throws InvalidMonetaryAmountError if it no longer fits.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
formatMonetaryAmount(new Decimal('1000.6'), 0) -> '1001'

## Verification Note
Confirmed directly against source: `const out = scale === undefined ? value : value.toDecimalPlaces(scale, Decimal.ROUND_HALF_UP);` matches exactly, including the re-validation throw.

## Source Evidence
- src/money.ts lines 48-66, read in full

## Related Knowledge
- [[Accounting Model]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
