---
knowledge_id: CLASS-RULE-025
title: "One internal doc (COMMON-PaymentComponent-Cross-Reference.md) states the classification rule with a different, non-equivalent term count (2-term merged-Nostro XOR) than the authoritative 3-term Rev.2 rule used everywhere else"
domain: Payment
category: Business Rule
status: CONFLICT
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - classification
  - conflict
---

# CLASS-RULE-025 — One internal doc (COMMON-PaymentComponent-Cross-Reference.md) states the classification rule with a different, non-equivalent term count (2-term merged-Nostro XOR) than the authoritative 3-term Rev.2 rule used everywhere else

## Status
CONFLICT

## Business Rule
The Calculation Validation doc and the classification.ts/OAS/FSD-zh sources state the rule as THREE independent XOR terms: CUSTOMER, NOSTRO, and VOSTRO each compared separately (Rev. 2, the currently-implemented and currently-documented-as-authoritative rule). COMMON-PaymentComponent-Cross-Reference.md's 'Rule Recap' instead states it as TWO XOR terms: (Dr Current Account XOR Cr Current Account) OR (Dr Nostro XOR Cr Nostro), explicitly defining 'Nostro' as CPYT_*_AC_TYPE = NOSTRO OR VOSTRO combined into one term — this is the discarded pre-Rev.2 merged-bucket version that the FSD's own §2.3 revision note (and the Calculation Validation doc's §8.3/§13.1 scenario 5/6 tests) explicitly superseded because it incorrectly excludes genuine Nostro-vs-Vostro postings. These are NOT algebraically equivalent in general.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Unresolved in the source material itself — the classify() implementation, its tests, the OAS, and both FSD docs all consistently implement/describe the 3-term Rev.2 rule, so that is the version actually running in code; the 2-term version appears only in this one cross-reference document and does not match the live implementation.

## Example
Dr has NOSTRO only, Cr has VOSTRO only: 3-term version -> nostroXor=true (Dr has it, Cr doesn't) AND vostroXor=true (Cr has it, Dr doesn't) -> paymentComponentRelated=true. Under the 2-term merged-Nostro rule, both sides 'have Nostro' (since VOSTRO folds into the same bucket as NOSTRO), so the merged Nostro-XOR term is FALSE -> paymentComponentRelated=false under that rule — a genuine disagreement between the two documented rules for this input.

## Conflict Note
> [!warning] Sources disagree
> Directly confirmed the cross-reference doc's 2-term wording (lines 9-18) genuinely differs from the classify() implementation and every other source, which all use the 3-term Rev.2 rule. Since classify() (executable business logic, highest evidence priority) unambiguously implements the 3-term rule, and it is also what every FSD doc and the OAS state as current/authoritative, this CONFLICT is effectively resolved in practice (the 3-term rule is what runs and what nearly every doc describes) — but is kept as CONFLICT per the instructions since two source documents genuinely disagree, and the cross-reference doc itself does not flag its own statement as superseded/stale the way the FSD docs flag the pre-Rev.2 merged-bucket version elsewhere.

## Verification Note
Directly confirmed the cross-reference doc's 2-term wording (lines 9-18) genuinely differs from the classify() implementation and every other source, which all use the 3-term Rev.2 rule. Since classify() (executable business logic, highest evidence priority) unambiguously implements the 3-term rule, and it is also what every FSD doc and the OAS state as current/authoritative, this CONFLICT is effectively resolved in practice (the 3-term rule is what runs and what nearly every doc describes) — but is kept as CONFLICT per the instructions since two source documents genuinely disagree, and the cross-reference doc itself does not flag its own statement as superseded/stale the way the FSD docs flag the pre-Rev.2 merged-bucket version elsewhere.

## Source Evidence
- converted/analysis__Payment_Component_Calculation_Validation.docx.txt §4 lines 80-88
- analysis/COMMON-PaymentComponent-Cross-Reference.md 'Rule Recap' section lines 9-18
- microservices/payment-component/src/domain/classification.ts (the live, running implementation — confirmed 3-term Rev.2)

## Related Knowledge
- [[Payment Instruction Classification]]
- [[Business-Rule-Index]]
- [[Knowledge-Gaps]]
- [[Payment-Traceability-Matrix]]
