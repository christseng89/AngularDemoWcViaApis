---
knowledge_id: CLASS-RULE-001
title: "RTGS modeled as a 6th distinct AccountType enum value (early docs, v1.1.0/v1.2.0) vs. accountType=NOSTRO + rtgsIndicator flag (current OAS, v1.3.0+)"
domain: Payment
category: Business Rule
status: CONFLICT
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - conflict
  - conflict
---

# CLASS-RULE-001 — RTGS modeled as a 6th distinct AccountType enum value (early docs, v1.1.0/v1.2.0) vs. accountType=NOSTRO + rtgsIndicator flag (current OAS, v1.3.0+)

## Status
CONFLICT

## Business Rule
Two document generations genuinely disagree, and the disagreement is explicitly self-documented in the current source of truth rather than silently resolved: (1) the zh FSD (analysis__PaymentComponent-Microservice-FSD-zh.docx.txt) and the Payment_Mapping_Functions report (analysis__Payment_Mapping_Functions.docx.txt) — both describing OAS v1.1.0/v1.2.0 — state AccountType has 6 enum values including RTGS as its own value, scoped to originModule RPFM, selecting a distinct GL account (19511609 vs NOSTRO's 12011101). (2) The current, authoritative OAS schema (BOTH Payment_component.yaml and payment-instructions-post.yaml, which are otherwise supposed to be kept in lockstep) states in its own AccountType description that v1.3.0 REMOVED RTGS as a distinct enum value ('RTGS never drove any classification or message-routing branch differently from NOSTRO... It is now represented as accountType=NOSTRO plus rtgsIndicator=true, scoped to originModule RPFM only') and the enum itself is now only 5 values: [CUSTOMER, NOSTRO, VOSTRO, SUSPENSE, INTERNAL]. The later en FSD (analysis__Payment-OAS-FSD-en.docx.txt) independently corroborates this: its Appendix B changelog records 'v1.3.0 | Removed RTGS as a distinct AccountType — replaced with accountType=NOSTRO + a new rtgsIndicator flag, since no legacy logic ever branched on it separately,' and its own rtgsIndicator field description (line 177) matches. Per this task's evidence priority (current executable OAS schema > historical design docs) AND per the OAS's own internal versioning narrative, this is a RESOLVED version-evolution conflict, not a live ambiguity: the current, authoritative model is accountType=NOSTRO + rtgsIndicator=true for RPFM-only domestic RTGS legs. Downstream consumers should treat the 6-value-enum description in the zh FSD / Mapping Functions report as historical (accurate as of v1.1.0/v1.2.0, superseded by v1.3.0), not as describing current behavior. This is consistent with — not contradicted by — the many other CONFIRMED cross-domain rules already stating 'RTGS is modeled as NOSTRO + rtgsIndicator flag, not a distinct AccountType' (e.g. rtgs-modeled-as-nostro-flag, rtgs-remodeled-as-nostro-flag, rtgs-modeled-as-nostro-flag-not-account-type, rtgs-modeled-as-nostro-flag-not-distinct-type) — all of those describe the current (post-v1.3.0) state correctly; only the two earlier documents disagree, and their disagreement is itself acknowledged and explained by the current OAS's own doc comments.

## Conditions
Applies specifically to originModule RPFM; RTGS/rtgsIndicator is never valid for any other module.

## Result
Current schema (v1.3.0+, confirmed against both Payment_component.yaml line 424 and payment-instructions-post.yaml): AccountType enum has exactly 5 values (CUSTOMER, NOSTRO, VOSTRO, SUSPENSE, INTERNAL). RTGS is a separate optional boolean rtgsIndicator flag, valid only on a NOSTRO-type leg, scoped to originModule RPFM. It does not change the leg's classification (still counts as NOSTRO for XOR classification purposes) — only its voucher-description TypeChar ('R' instead of NOSTRO's 'N') and GL account routing.

## Example
GL account selection: 19511609 for an RTGS-flagged NOSTRO leg vs. 12011101 for a plain NOSTRO leg, in the same IDR-currency-driven branch (per the zh FSD's v1.1.0-era description, still cited as the underlying business fact in the current OAS's doc comment).

## Conflict Note
> [!warning] Sources disagree
> Re-opened all four cited files plus both live OAS YAML sources (not just the analysis .txt conversions). Confirmed the zh FSD and Mapping Functions report do state a 6-value enum including RTGS as of v1.1.0/v1.2.0. Confirmed the en FSD's Appendix B changelog and the actual OAS YAML schema (checked in both Payment_component.yaml and payment-instructions-post.yaml, not just the en FSD's narrative about it) show the enum was reduced back to 5 values in v1.3.0, with RTGS replaced by a NOSTRO+rtgsIndicator flag. Original candidate's claim holds up fully — no downgrade needed. Kept status as CONFLICT (per this domain's definition, both sides of the disagreement must be described rather than silently resolved) but added explicit clarification that this conflict is a resolved version-evolution artifact self-documented in the current OAS, not an open ambiguity — this distinguishes it from other CONFLICT items in the cross-domain list (e.g. voucher-type-enum-stale-after-v160-removal, swiftmessage-schema-diverges-between-two-oas-files, use-case-4-eplc-discount-conflict) which describe genuinely unresolved or currently-inconsistent states. No near-duplicates found within this domain's candidate set (only one rule was supplied). Cross-checked against cross-domain titles: consistent with (not contradicted by) at least 4 other CONFIRMED rules asserting the same post-v1.3.0 NOSTRO+flag model, confirming this is the correct current-state conclusion, not an unresolved dispute Claude picked a side on arbitrarily.

## Verification Note
Re-opened all four cited files plus both live OAS YAML sources (not just the analysis .txt conversions). Confirmed the zh FSD and Mapping Functions report do state a 6-value enum including RTGS as of v1.1.0/v1.2.0. Confirmed the en FSD's Appendix B changelog and the actual OAS YAML schema (checked in both Payment_component.yaml and payment-instructions-post.yaml, not just the en FSD's narrative about it) show the enum was reduced back to 5 values in v1.3.0, with RTGS replaced by a NOSTRO+rtgsIndicator flag. Original candidate's claim holds up fully — no downgrade needed. Kept status as CONFLICT (per this domain's definition, both sides of the disagreement must be described rather than silently resolved) but added explicit clarification that this conflict is a resolved version-evolution artifact self-documented in the current OAS, not an open ambiguity — this distinguishes it from other CONFLICT items in the cross-domain list (e.g. voucher-type-enum-stale-after-v160-removal, swiftmessage-schema-diverges-between-two-oas-files, use-case-4-eplc-discount-conflict) which describe genuinely unresolved or currently-inconsistent states. No near-duplicates found within this domain's candidate set (only one rule was supplied). Cross-checked against cross-domain titles: consistent with (not contradicted by) at least 4 other CONFIRMED rules asserting the same post-v1.3.0 NOSTRO+flag model, confirming this is the correct current-state conclusion, not an unresolved dispute Claude picked a side on arbitrarily.

## Source Evidence
- analysis__PaymentComponent-Microservice-FSD-zh.docx.txt line 441 (enum: [CUSTOMER, NOSTRO, VOSTRO, SUSPENSE, INTERNAL, RTGS]), line 1008 (enum reference table), line 200/208 (v1.1.0/v1.2.0 changelog entries)
- analysis__Payment_Mapping_Functions.docx.txt line 25 (AccountType enum: 6 values, RTGS scoped to RPFM), line 142 (domain-check table), lines 53/69-72 (R3 fix narrative)
- analysis__Payment-OAS-FSD-en.docx.txt line 177 (rtgsIndicator field description), lines 294-296 (Appendix B changelog: v1.1.0 added RTGS, v1.3.0 removed RTGS replaced with accountType=NOSTRO+rtgsIndicator)
- /mnt/user-data/uploads/lc-payment-wc/analysis/Payment_component.yaml lines 393-424 (AccountType schema: enum now 5 values; doc comment explicitly narrates v1.1.0 add -> v1.2.0 correction -> v1.3.0 removal)
- /mnt/user-data/uploads/lc-payment-wc/analysis/payment-instructions-post.yaml lines 402-432 (identical AccountType schema and doc comment, confirming the two OAS files agree on this point even though other findings note they've diverged elsewhere)

## Related Knowledge
- [[Payment Instruction Classification]]
- [[Business-Rule-Index]]
- [[Knowledge-Gaps]]
- [[Payment-Traceability-Matrix]]
