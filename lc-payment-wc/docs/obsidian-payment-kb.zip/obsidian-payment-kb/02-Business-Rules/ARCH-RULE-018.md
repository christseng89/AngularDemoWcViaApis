---
knowledge_id: ARCH-RULE-018
title: "FxRateService deliberately reuses the pre-existing GET /api/fx/rates endpoint rather than introducing a new FX data source"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - architecture
  - confirmed
---

# ARCH-RULE-018 — FxRateService deliberately reuses the pre-existing GET /api/fx/rates endpoint rather than introducing a new FX data source

## Status
CONFIRMED

## Business Rule
FxRateService reuses the SAME /api/fx/rates endpoint the original (pre-existing) lc-payment-wc web components already called, proxied via the existing /api proxy entry with no new wiring, per an explicit user request to fetch rates 'same as the original Angular Project' rather than the Payment Component Simulator inventing its own FX data source.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
n/a — architectural rationale only

## Verification Note
Confirmed verbatim against the file. Unchanged.

## Source Evidence
- src/app/payment-component/fx-rate.service.ts lines 6-15, directly re-read: 'Reuses the SAME GET /api/fx/rates endpoint the original lc-payment-wc web components already call ... proxied via the existing `/api` proxy entry, no new wiring needed ... per the user's request to fetch exchange rates "same as the original Angular Project"'

## Related Knowledge
- [[Payment Architecture]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
