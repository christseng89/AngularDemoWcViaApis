---
knowledge_id: FX-RULE-004
title: "Currency minor-unit (decimal places) master table drives rounding; falls back to 2dp for unlisted currencies"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - fx
  - confirmed
---

# FX-RULE-004 — Currency minor-unit (decimal places) master table drives rounding; falls back to 2dp for unlisted currencies

## Status
CONFIRMED

## Business Rule
CURRENCY_MINOR_UNITS hardcodes USD/EUR/GBP/CNY/HKD/SGD/AUD = 2dp; JPY/TWD/IDR = 0dp. minorUnitsForCurrency() falls back to 2 for any currency absent from the table. This table duplicates lc-payment-wc/backend/data/currencies.json because the microservice is independently deployable with no currency-master data source of its own — must be kept manually in sync or a client-computed and server-computed amount for 'the same' quantity can round to different values and break the exact-equality V8 check by a minor unit.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
minorUnitsForCurrency('JPY') === 0; minorUnitsForCurrency('XYZ') === 2 (unknown fallback)

## Verification Note
Read money.ts in full; table and fallback logic exactly as claimed. Test file confirms the cited test names exist. No status change.

## Source Evidence
- money.ts lines 100-115 (CURRENCY_MINOR_UNITS table, minorUnitsForCurrency)
- test/unit/money.test.ts 'returns 0 for JPY/TWD/IDR', 'falls back to 2 for a currency not in the table'

## Related Knowledge
- [[FX Processing]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
