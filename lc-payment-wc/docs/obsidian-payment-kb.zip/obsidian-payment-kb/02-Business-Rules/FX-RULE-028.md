---
knowledge_id: FX-RULE-028
title: "Cross rates between two non-TWD currencies are derived by bridging both currencies' TWD-quoted rates, not looked up directly"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - fx
  - confirmed
---

# FX-RULE-028 — Cross rates between two non-TWD currencies are derived by bridging both currencies' TWD-quoted rates, not looked up directly

## Status
CONFIRMED

## Business Rule
The demo backend's FX rate table is TWD-quoted only. FxRateService.crossRate(rates, from, to) computes any from->to multiplier by converting both currencies to a common TWD basis (toTwd()) and dividing: fromTwd/toTwd. TWD itself is hardcoded to always equal 1. If either currency direction is entirely absent from the table, crossRate returns null rather than defaulting to 1.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
crossRate({'USD/TWD':32.5,'EUR/TWD':35.2}, 'USD','EUR') = 32.5/35.2 ≈ 0.9233.

## Verification Note
Confirmed by direct code read; the from===to shortcut (returns 1), toTwd's direct/inverse lookup, and the null-on-unknown behavior are all exactly as claimed. No status change.

## Source Evidence
- fx-rate.service.ts crossRate()/toTwd() lines 42-57 (read in full)

## Related Knowledge
- [[FX Processing]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
