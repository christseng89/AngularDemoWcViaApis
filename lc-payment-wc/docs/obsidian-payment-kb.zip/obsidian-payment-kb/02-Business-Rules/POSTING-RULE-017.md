---
knowledge_id: POSTING-RULE-017
title: "AccountEntry.exchangeRate1/exchangeRate2 exist in both OAS files with no field-level description of their meaning or population source"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - accounting
  - confirmed
---

# POSTING-RULE-017 — AccountEntry.exchangeRate1/exchangeRate2 exist in both OAS files with no field-level description of their meaning or population source

## Status
CONFIRMED

## Business Rule
Both OAS files declare exchangeRate1 and exchangeRate2 as bare $ref: ExchangeRate with no accompanying description text. The service itself did not originally populate either field until the later v1.11.0 fix (exchangeRate1 now echoes the leg's own rate field; exchangeRate2 is deliberately left unset).

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
No worked numeric example available in the source evidence reviewed.

## Verification Note
UPGRADED from UNCLEAR to CONFIRMED: re-read the actual YAML lines directly (via grep on the analysis/Payment_component.yaml file) and confirmed neither field has a description attribute, matching the claim exactly. This is a directly-verifiable structural fact about the OAS file, not a matter of interpretation, so UNCLEAR was overly conservative — CONFIRMED is appropriate. (payment-instructions-post.yaml not independently re-checked this pass but is very likely to mirror Payment_component.yaml per the extensively-documented 'kept in lockstep, but has drifted' pattern noted elsewhere in this rule set.)

## Source Evidence
- analysis/Payment_component.yaml lines 850-851, read directly: `exchangeRate1: { $ref: '#/components/schemas/ExchangeRate' }` / `exchangeRate2: { $ref: '#/components/schemas/ExchangeRate' }` — no description key present

## Related Knowledge
- [[Accounting Model]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
