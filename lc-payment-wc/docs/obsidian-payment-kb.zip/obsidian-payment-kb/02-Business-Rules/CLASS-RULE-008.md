---
knowledge_id: CLASS-RULE-008
title: "RTGS's exclusion from the XOR terms is structural (the terms are defined only over CUSTOMER/NOSTRO/VOSTRO), not because RTGS lacks a real external counterparty like SUSPENSE/INTERNAL"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - classification
  - confirmed
---

# CLASS-RULE-008 — RTGS's exclusion from the XOR terms is structural (the terms are defined only over CUSTOMER/NOSTRO/VOSTRO), not because RTGS lacks a real external counterparty like SUSPENSE/INTERNAL

## Status
CONFIRMED

## Business Rule
RTGS does not participate in the classification XOR terms — but per the OAS's own v1.2.0/v1.3.0 correction this is only because the three XOR terms are defined specifically over CUSTOMER/NOSTRO/VOSTRO, not because RTGS is itself a non-external-counterparty type the way SUSPENSE/INTERNAL are. RTGS genuinely represents a real settlement account choice (Indonesian domestic RTGS clearing vs. correspondent NOSTRO, selecting distinct GL accounts 19511609 vs 12011101), scoped exclusively to originModule RPFM; Account Entry generation is unaffected either way since posting is unconditional per leg. Merges candidates 35 and 37.

## Conditions
RTGS/rtgsIndicator legal only for originModule=RPFM.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
No worked numeric example available in the source evidence reviewed.

## Verification Note
Confirmed the exact wording in the zh FSD doc (lines 420-440), including the RPFM-only scoping and 'used on BOTH debit and credit legs, not credit-only as an earlier draft stated'. Merged candidates 35 (fsd-architecture-docs, structural-reason framing) and 37 (RPFM-scoping framing) into one entry since they describe the same underlying FSD passage.

## Source Evidence
- converted/analysis__PaymentComponent-Microservice-FSD-zh.docx.txt AccountType schema description lines 420-440 ('It does not participate in the §2.3 Dr/Cr XOR classification terms — but that is true only because those terms are defined over CUSTOMER/NOSTRO/VOSTRO specifically ... not a special property unique to RTGS. ... Callers other than RPFM should never submit RTGS')
- converted/analysis__Payment_Mapping_Functions.docx.txt §5.1 lines 33-35

## Related Knowledge
- [[Payment Instruction Classification]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
