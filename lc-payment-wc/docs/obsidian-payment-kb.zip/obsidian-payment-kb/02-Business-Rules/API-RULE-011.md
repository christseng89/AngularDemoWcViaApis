---
knowledge_id: API-RULE-011
title: "All confirm()/classify() HTTP errors are normalized into a single PaymentComponentApiError with a flat human-readable message, regardless of backend error shape"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - api
  - confirmed
---

# API-RULE-011 — All confirm()/classify() HTTP errors are normalized into a single PaymentComponentApiError with a flat human-readable message, regardless of backend error shape

## Status
CONFIRMED

## Business Rule
PaymentComponentApiService.rethrow() inspects the HttpErrorResponse body: if it structurally matches {code, message}, the thrown error's message is '`${code}: ${message}`'; otherwise it falls back to the raw HttpErrorResponse.message. Both confirm() and classify() share this rethrow path, so callers get one consistent error shape regardless of which endpoint failed.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
409 body {code:'LEGS_UNBALANCED', message:'legs do not balance'} -> thrown message 'LEGS_UNBALANCED: legs do not balance', status 409. Plain-text 500 body 'boom' -> falls back to the raw HttpErrorResponse.message.

## Verification Note
Re-read payment-component-api.service.ts directly; rethrow() implementation matches exactly. No change to status.

## Source Evidence
- src/app/payment-component/payment-component-api.service.ts: rethrow() (lines 72-78), PaymentComponentApiError class (lines 13-18)
- payment-component-api.service.spec.ts 'rethrows a structured API error body as PaymentComponentApiError' and 'falls back to the raw HttpErrorResponse message...' tests

## Related Knowledge
- [[Payment Instructions API]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
