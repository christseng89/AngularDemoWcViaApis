---
knowledge_id: CLASS-RULE-015
title: "A GAP (RPFM) business case's live preview calls the classify-only endpoint, never Confirm, and never sends suspenseBridge"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - classification
  - confirmed
---

# CLASS-RULE-015 — A GAP (RPFM) business case's live preview calls the classify-only endpoint, never Confirm, and never sends suspenseBridge

## Status
CONFIRMED

## Business Rule
For a case whose verdict is 'GAP', runPreview() calls api.classify(debitLegs, creditLegs) instead of api.confirm(). No Confirm button is rendered for a non-PASS case (template *ngIf="sc.verdict === 'PASS'"). Any Suspense Debit/Credit entries the user has entered are simply not incorporated into a GAP-case preview, since POST /payment-instructions/classify has no suspenseBridge field in its schema.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
No worked numeric example available in the source evidence reviewed.

## Verification Note
Confirmed directly in both the .ts and .html files — the branch structure and *ngIf gating match exactly as claimed.

## Source Evidence
- src/app/payment-component/business-case-runner.component.ts lines 734, 772-777 ('GAP (RPFM)' comment block and api.classify(...) call at line 777)
- src/app/payment-component/business-case-runner.component.html line 121 `<div class="action-row" *ngIf="sc.verdict === 'PASS'">`

## Related Knowledge
- [[Payment Instruction Classification]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
