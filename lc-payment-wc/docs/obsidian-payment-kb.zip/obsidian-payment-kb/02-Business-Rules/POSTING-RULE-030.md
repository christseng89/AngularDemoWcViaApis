---
knowledge_id: POSTING-RULE-030
title: "LC margin pledge is always held and released in the LC's own transaction currency, regardless of what currency the customer actually pays other charges in"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - accounting
  - confirmed
---

# POSTING-RULE-030 — LC margin pledge is always held and released in the LC's own transaction currency, regardless of what currency the customer actually pays other charges in

## Status
CONFIRMED

## Business Rule
At LC Issue (A1), the Cr Margin Pledge leg is unconditionally booked in lcCurrency even when the customer pays the margin's TWD-equivalent in TWD. The same 'transaction-currency margin' convention carries through A2 (release) and A3.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
No worked numeric example available in the source evidence reviewed.

## Verification Note
Directly confirmed by reading the exact backend/server.js lines this pass — code and comments match the claim exactly.

## Source Evidence
- backend/server.js lines 90-99 and 175-190, read directly: comment 'Cr Margin — ALWAYS in lcCurrency (transaction currency), regardless of how customer paid' and the code `entries.push(entry('Cr', 'Margin Pledge A/C', 'Margin', lcCurrency, marginLcAmt, marginTwd, ...))`
- backend/server.js line ~230, read directly: 'Margin is released in transaction currency (billCurrency).'

## Related Knowledge
- [[Accounting Model]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
