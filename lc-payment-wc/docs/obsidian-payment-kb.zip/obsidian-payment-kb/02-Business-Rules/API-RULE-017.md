---
knowledge_id: API-RULE-017
title: "All four GET endpoints are read-only inquiry/audit lookups, explicitly NOT part of the confirm flow"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - api
  - confirmed
---

# API-RULE-017 — All four GET endpoints are read-only inquiry/audit lookups, explicitly NOT part of the confirm flow

## Status
CONFIRMED

## Business Rule
GET /payment-instructions (search by originModule+mainRef), GET /payment-instructions/{id}, GET .../{id}/account-entries, and GET .../{id}/swift-messages are all documented as read-only inquiry/audit lookups (citing FSD §6.1) — not steps of the confirm flow. The account-entries and swift-messages GETs return the SAME data already embedded in the original POST response, existing only for later reconciliation/reprint/status-polling access.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
No worked numeric example available in the source evidence reviewed.

## Verification Note
Re-read the OAS paths section directly (lines 189-335); confirmed all four descriptions state exactly this. No change to status.

## Source Evidence
- analysis/Payment_component.yaml: GET /payment-instructions description (lines 251-254), GET /{instructionId} (276-279), GET .../account-entries (294-299), GET .../swift-messages (313-325)
- microservices/payment-component/src/routes/paymentInstructions.ts: top-of-file doc comment (lines 1-5) matches this framing exactly

## Related Knowledge
- [[Payment Instructions API]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
