---
knowledge_id: VALIDATION-RULE-039
title: "[STALE, superseded] Submitted leg amounts are not validated against the currency's minor units — cited as an open gap by an older expert-review doc, but this is NO LONGER true in the current code"
domain: Payment
category: Business Rule
status: CONFLICT
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - validation
  - conflict
---

# VALIDATION-RULE-039 — [STALE, superseded] Submitted leg amounts are not validated against the currency's minor units — cited as an open gap by an older expert-review doc, but this is NO LONGER true in the current code

## Status
CONFLICT

## Business Rule
The candidate rule (sourced from docs/payment-component-expert-review.md, dated 2026-08-09) states: 'MonetaryAmount input is validated only against the generic pattern... The service enforces currency scale on amounts it computes internally... but never validates amounts the caller submits... Recommended fix: cross-validate each leg amount's decimal places against minorUnitsForCurrency(leg.currency).' This is DIRECTLY CONTRADICTED by the current requestSchema.ts, which already implements exactly this recommended fix via checkScale() — confirmed by direct read (see the merged h2-currency-minor-unit-scale entry above, and the FSD Appendix B / Calculation-Validation doc's own 'Spec Sync — 2026-08 Hardening Review' section listing H-2 as an implemented, unit-tested hardening change). The gap-analysis doc accurately described the code state AS OF 2026-08-09, but the hardening review (same or later date) closed exactly this gap — the candidate rule as originally worded ('is not validated', present tense) no longer matches the current codebase.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
The doc's own example (JPY 100.50, EUR 1.234) is now REJECTED by the current code — verified directly against requestSchema.ts's checkScale logic and its test file's own 'rejects amountTxCcy with more decimals than the transaction currency allows (JPY = 0)' test.

## Conflict Note
> [!warning] Sources disagree
> Downgraded from the original CONFIRMED (as extracted by the other agent, who evidently only read the expert-review doc without cross-checking current code) to CONFLICT. Executable code (highest evidence priority) and the FSD's own Hardening-Review changelog both show H-2 IS implemented; only the older expert-review doc claims otherwise. This is a genuine temporal conflict between two sources in the repo, not a fabricated rule — the correct current-state fact is captured in the merged 'h2-currency-minor-unit-scale' entry above, which supersedes this one.

## Verification Note
Downgraded from the original CONFIRMED (as extracted by the other agent, who evidently only read the expert-review doc without cross-checking current code) to CONFLICT. Executable code (highest evidence priority) and the FSD's own Hardening-Review changelog both show H-2 IS implemented; only the older expert-review doc claims otherwise. This is a genuine temporal conflict between two sources in the repo, not a fabricated rule — the correct current-state fact is captured in the merged 'h2-currency-minor-unit-scale' entry above, which supersedes this one.

## Source Evidence
- docs/payment-component-expert-review.md lines 129-139 ('H-2. Submitted leg amounts are not validated against the currency's minor units', dated 2026-08-09 per the doc's own header)
- microservices/payment-component/src/validation/requestSchema.ts lines 127-146, 173-201 (checkScale, fully implemented and applied to every leg/Suspense amount — DIRECTLY CONTRADICTS the doc's 'never validates amounts the caller submits' claim)
- analysis__Payment_Component_Calculation_Validation.docx.txt lines 372-379 ('Spec Sync — 2026-08 Hardening Review', H-2 listed as an implemented, unit-tested change, '261 unit tests, 100% coverage')

## Related Knowledge
- [[Request Validation]]
- [[Business-Rule-Index]]
- [[Knowledge-Gaps]]
- [[Payment-Traceability-Matrix]]
