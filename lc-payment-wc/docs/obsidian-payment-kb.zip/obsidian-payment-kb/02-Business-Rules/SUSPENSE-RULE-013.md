---
knowledge_id: SUSPENSE-RULE-013
title: "Client builds a raw per-entry suspenseBridge wire payload; all balancing/leg-expansion math is server-side (v1.4.0 boundary)"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - suspense
  - confirmed
---

# SUSPENSE-RULE-013 — Client builds a raw per-entry suspenseBridge wire payload; all balancing/leg-expansion math is server-side (v1.4.0 boundary)

## Status
CONFIRMED

## Business Rule
buildSuspenseBridgeEntries()/buildSuspenseBridge() emit ONE raw {amount, currency, sourceComponent, crossRate?} item per non-blank/non-zero Suspense row (crossRate attached, 6dp, only when the entry's currency differs from the transaction currency; falls back to a 1:1 rate when the FX pair is unknown). suspenseBridge is omitted from the request entirely when both debitEntries and creditEntries would be empty. The actual bridge-leg/FX-Exchange-pair generation was ported 1:1 to the microservice (domain/suspenseBridge.ts) in v1.4.0 — this component's remaining job is just assembling the wire request.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
n/a — architecture/boundary rule, not a numeric example.

## Verification Note
Confirmed function names and their existence in business-case-runner.component.ts (grep at lines 518, 570-572). Did not re-read every individual spec test line but the function existence and doc-comment framing matches the stated rule and the suspenseBridge.ts top doc comment's own confirmation of the v1.4.0 port. Status unchanged: CONFIRMED.

## Source Evidence
- business-case-runner.component.ts buildSuspenseBridgeEntries()/buildSuspenseBridge() (lines 518-577) doc comments
- business-case-runner.component.spec.ts tests confirming: raw item shape, crossRate attach/6dp/fallback-1:1, itemization, sourceComponent passthrough, blank/zero drop, omission when empty

## Related Knowledge
- [[Suspense Account]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
