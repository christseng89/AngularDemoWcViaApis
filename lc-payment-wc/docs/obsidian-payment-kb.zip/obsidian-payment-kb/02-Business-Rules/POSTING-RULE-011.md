---
knowledge_id: POSTING-RULE-011
title: "A Suspense entry that resolves to a zero amount (before or after FX conversion/rounding) produces no leg at all — never a zero-value posting"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - accounting
  - confirmed
---

# POSTING-RULE-011 — A Suspense entry that resolves to a zero amount (before or after FX conversion/rounding) produces no leg at all — never a zero-value posting

## Status
CONFIRMED

## Business Rule
buildSuspenseBridgeLeg returns null both for a same-currency zero-amount entry and for a cross-currency entry whose rounded trx-equivalent is exactly 0. expandSuspenseBridge silently omits the leg.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
No worked numeric example available in the source evidence reviewed.

## Verification Note
Directly confirmed by reading suspenseBridge.ts's buildSuspenseBridgeLeg and expandSuspenseBridge functions in full.

## Source Evidence
- src/domain/suspenseBridge.ts: buildSuspenseBridgeLeg — `if (rawAmount.isZero()) return null;` (same-currency branch) and `if (Number(roundedTrxEquivalent) === 0) return null;` (cross-currency branch), both read directly
- src/domain/suspenseBridge.ts expandSuspenseBridge: `const leg = buildSuspenseBridgeLeg(...); if (leg) { credit.push(leg); ... }`, read directly

## Related Knowledge
- [[Accounting Model]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
