---
knowledge_id: CLASS-RULE-023
title: "Import components model the LC applicant (importer/buyer); Export components model the LC beneficiary (exporter/seller) — same customer master list serves both roles"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - classification
  - confirmed
---

# CLASS-RULE-023 — Import components model the LC applicant (importer/buyer); Export components model the LC beneficiary (exporter/seller) — same customer master list serves both roles

## Status
CONFIRMED

## Business Rule
Every Import LC element's form uses an 'applicantId' field (客戶 Customer) while every Export LC element uses 'beneficiaryId' (出口商 Beneficiary) — reflecting the LC's two counterparties. Both roles are populated from the identical CUSTOMERS/DDA_ACCTS mock master data in shared.ts, meaning this demo does not model applicant and beneficiary as distinct customer pools (a real bank's beneficiary is typically not its own deposit customer at all) — a modeling simplification worth flagging for anyone extending this toward a real Export LC flow.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
No worked numeric example available in the source evidence reviewed.

## Verification Note
Confirmed directly — all three files match as cited; both applicantId and beneficiaryId dropdowns draw from the same CUSTOMERS constant in shared.ts.

## Source Evidence
- src/app/web-components/import/lc-issue.element.ts line 33 (applicantId: 'C-001') and lines 74-76 ('客戶 Customer' label, CUSTOMERS dropdown)
- src/app/web-components/export/lc-nego.element.ts line 31 (beneficiaryId: 'C-001') and lines 75-76 ('出口商 Beneficiary' label, CUSTOMERS dropdown)
- src/app/web-components/shared.ts line 113 (single CUSTOMERS list used by both)

## Related Knowledge
- [[Payment Instruction Classification]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
