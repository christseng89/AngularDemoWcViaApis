---
knowledge_id: API-RULE-002
title: "dryRun:true is a preview mode that skips both idempotency lookup and persistence and always returns HTTP 200, even for a brand-new natural key"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - api
  - confirmed
---

# API-RULE-002 — dryRun:true is a preview mode that skips both idempotency lookup and persistence and always returns HTTP 200, even for a brand-new natural key

## Status
CONFIRMED

## Business Rule
The dryRun request extension field forces the route to respond 200 regardless of created/existing status. Inside confirmPaymentInstruction, dryRun skips Step 0 (idempotency lookup, so it never collides with or replays a real Confirm) and skips the final store.save (line 215-217: `if (options.dryRun) { return { instruction, created: false }; }` — store.save is never reached). This mechanism, previously only inferable from the route layer, is directly confirmed by reading confirmPaymentInstruction.ts itself.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
POST with mainRef='REF-DRY-RUN' (never used before) + dryRun:true -> 200, not 201.

## Verification Note
Upgraded confidence: original candidate rule flagged the non-persistence mechanism as 'not directly verifiable from these files' since confirmPaymentInstruction.ts was outside that agent's read set. I read confirmPaymentInstruction.ts directly and confirmed both the idempotency-skip and store.save-skip mechanisms explicitly. Status remains CONFIRMED (now on stronger evidence).

## Source Evidence
- microservices/payment-component/src/routes/paymentInstructions.ts: RequestExtensions.dryRun doc comment (line 26); `res.status(ext.dryRun ? 200 : result.created ? 201 : 200)` (line 51)
- microservices/payment-component/src/domain/confirmPaymentInstruction.ts: ConfirmPaymentInstructionOptions.dryRun doc comment (lines 85-94); `if (!options.dryRun) { ... idempotency lookup ... }` (line 116); `if (options.dryRun) { return { instruction, created: false }; }` before store.save (lines 215-219)
- microservices/payment-component/test/unit/routes/paymentInstructions.test.ts: 'dryRun:true always returns 200, even for a brand-new natural key' (line 45, mainRef:'REF-DRY-RUN')

## Related Knowledge
- [[Payment Instructions API]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
