---
knowledge_id: UI-RULE-006
title: "v1.12.3 leg-rebalancing 'waterfall': every non-last row edit always offsets against the LAST row directly (merged with duplicate rules 23/26)"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - ui
  - confirmed
---

# UI-RULE-006 — v1.12.3 leg-rebalancing 'waterfall': every non-last row edit always offsets against the LAST row directly (merged with duplicate rules 23/26)

## Status
CONFIRMED

## Business Rule
For both % editing (applyPctWaterfall) and Amount editing (applyAmountWaterfall), once a side has more than one row: (1) increasing a non-last row decreases the LAST row by the same amount, capped at what the last row has; (2) decreasing a non-last row increases the LAST row by the exact freed amount (always fully absorbed); (3) decreasing the LAST row itself auto-creates a brand-new trailing row holding exactly the freed difference, Account No. defaulting to DEFAULT_ACCOUNT_NO_BY_TYPE (chains on repeated decreases); (4) increasing the LAST row itself draws backward from the row(s) before it, cascading further back as needed, each donor capped at 0 (never negative). This supersedes an earlier v1.12.0 'adjacent neighbor' model and removes the old 'increasing the first row is rejected' boundary case. Money only ever moves between existing rows (or into a newly-created one under rule 3), so Σ Amount / Σ % is preserved by construction. The identical 4-rule shape is mirrored for % editing, additionally constrained to whole-percentage-point (1%) granularity via step="1" and rounding in onPctInput.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
4-row USD split 2000/1000/2000/3000: increasing row0 by +2000 decreases last row by 2000 (rule 1); decreasing row1 by -2000 increases last row by 2000 (rule 2); decreasing last row 5000->2000 opens new 4th row of 3000 (rule 3); increasing that new last row 3000->8000 cascades backward draining earlier rows (rule 4).

## Verification Note
MERGED three near-duplicate candidates (id_hints amount-percent-waterfall-4-rule-v1123, amount-waterfall-4-rules, amount-waterfall-4-rule-model, and pct-waterfall-whole-percent-only) into this one entry — all described the identical v1.12.3 mechanism from slightly different angles (component-level vs. user-manual vs. CLAUDE.md citations). Directly verified against the live leg-allocator.component.ts source: applyAmountWaterfall and applyPctWaterfall both branch on index===lastIndex exactly as described, and the non-last branch unconditionally targets rows[rows.length-1], never an adjacent row. Confirmed unchanged.

## Source Evidence
- applyAmountWaterfall() lines 806-920 (doc comment + body) — branches on index===lastIndex first, non-last branch always reads/writes rows[rows.length-1]
- applyPctWaterfall() lines 653-741 mirroring the same 4 rules for row.pct
- leg-allocator.component.html lines 53-67, 61-89 (step="1" spinner, blur-commit) confirming whole-percentage-point-only for %

## Related Knowledge
- [[Payment Component Simulator UI]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
