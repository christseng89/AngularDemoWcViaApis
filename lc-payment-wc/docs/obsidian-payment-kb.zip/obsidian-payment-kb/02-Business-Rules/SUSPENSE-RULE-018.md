---
knowledge_id: SUSPENSE-RULE-018
title: "FSD §7.8 documents a 'chargeComponentBridge' boolean flag gating empty creditLegs, and a diff-based (not gross) FX sizing for the Charge Component fee-collection pattern — this CONFLICTS with the actual implemented code"
domain: Payment
category: Business Rule
status: CONFLICT
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - suspense
  - conflict
---

# SUSPENSE-RULE-018 — FSD §7.8 documents a 'chargeComponentBridge' boolean flag gating empty creditLegs, and a diff-based (not gross) FX sizing for the Charge Component fee-collection pattern — this CONFLICTS with the actual implemented code

## Status
CONFLICT

## Business Rule
FSD §7.8 states: creditLegs may be empty ONLY when a chargeComponentBridge boolean extension flag is true AND suspenseBridge.creditEntries is non-empty; and that FX Exchange sizing for this pattern computes the DIFFERENCE between the Suspense Credit amount and the matching (opposite-side) debit legs' amount in that currency, generating an FX entry only for the residual, never gross. NEITHER of these is what the actual code does: (a) grep of the entire microservice src/ tree finds ZERO occurrences of 'chargeComponentBridge' — the actual gating (requestSchema.ts lines 100-122) checks only whether suspenseBridge itself contributes a credit leg, no flag involved (matches the CONFIRMED rule 'creditlegs-may-be-empty-with-bridge' above); and (b) the actual v1.9.0 diff-netting logic in suspenseBridge.ts applies ONLY to a debitEntries bucket netted against same-side debitLegs — a creditEntries bucket (which is what the LC-issue fee-collection scenario actually uses, per CLAUDE.md's own worked example) is NEVER netted against opposite-side debitLegs; it always posts gross Suspense amounts with up to two independent, non-netted FX pairs (the CONFIRMED 'credit-bucket-fx-not-netted' rule above). No test anywhere (confirmPaymentInstruction.test.ts's REF-SB-NET-CREDIT-1, the closest match) demonstrates opposite-side (creditEntries vs debitLegs) diff-netting — that test instead proves the gross, two-independent-pairs behavior.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
FSD's stated worked scenario (a Suspense Credit netted against an opposite-side real debit leg to a residual) has no corresponding implementation or test; the actual code always posts the Suspense Credit entry at its full gross amount regardless of any debitLegs the caller submits.

## Conflict Note
> [!warning] Sources disagree
> Downgraded from CONFIRMED to CONFLICT. The original candidate cited only the FSD/architecture docs as evidence and never cross-checked against the actual implemented server code. On verification, the FSD's documented design (a chargeComponentBridge flag; diff-based FX sizing for the opposite-side Charge-Bridge case) does not match what suspenseBridge.ts/requestSchema.ts actually implement. This appears to be FSD documentation that predates or was never reconciled with the v1.8.0-v1.9.0 code evolution documented in suspenseBridge.ts's own top-of-file history comment. Flagged as a genuine, previously-unnoted FSD-vs-code conflict, distinct from the already-known 'charge-liability-voucher-removed' and 'oas-info-version-lags-implementation' staleness items in the cross-domain list.

## Verification Note
Downgraded from CONFIRMED to CONFLICT. The original candidate cited only the FSD/architecture docs as evidence and never cross-checked against the actual implemented server code. On verification, the FSD's documented design (a chargeComponentBridge flag; diff-based FX sizing for the opposite-side Charge-Bridge case) does not match what suspenseBridge.ts/requestSchema.ts actually implement. This appears to be FSD documentation that predates or was never reconciled with the v1.8.0-v1.9.0 code evolution documented in suspenseBridge.ts's own top-of-file history comment. Flagged as a genuine, previously-unnoted FSD-vs-code conflict, distinct from the already-known 'charge-liability-voucher-removed' and 'oas-info-version-lags-implementation' staleness items in the cross-domain list.

## Source Evidence
- analysis__Payment-OAS-FSD-en.docx.txt lines 74-77 (§7.8, both the chargeComponentBridge flag claim and the diff-sizing claim)
- grep across microservices/payment-component/src/ for 'chargeComponentBridge' returns zero matches (only found in docs/payment-component-expert-review*.md, not source code)
- src/validation/requestSchema.ts lines 100-122 (actual gating logic, flag-free)
- src/domain/suspenseBridge.ts lines 341-397 (creditEntries branch never reads debitLegs/opposite-side legs at all — only reads sideLegs === creditLegs)
- test/unit/domain/confirmPaymentInstruction.test.ts lines 386-416 (REF-SB-NET-CREDIT-1 — the closest existing test to this FSD scenario, and it proves gross/non-netted behavior, not diff-sizing)

## Related Knowledge
- [[Suspense Account]]
- [[Business-Rule-Index]]
- [[Knowledge-Gaps]]
- [[Payment-Traceability-Matrix]]
