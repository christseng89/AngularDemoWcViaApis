---
knowledge_id: UI-RULE-005
title: "Percentage-driven XOR Amount-driven per row (never both) — 'B-Tree' rule"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - ui
  - confirmed
---

# UI-RULE-005 — Percentage-driven XOR Amount-driven per row (never both) — 'B-Tree' rule

## Status
CONFIRMED

## Business Rule
Each row has a single driver flag ('pct' | 'amount'). Typing a % makes the row percentage-driven — its amount rescales freely whenever the shared Total Amount changes. Typing an amount (either in the transaction currency via onAmountInput, or the row's own currency via onAccountAmountInput) makes the row amount-driven — that figure is fixed across a total change and only its displayed % is refreshed. A field re-derived from its own already-rounded counterpart is never treated as authoritative (banking B-Tree computation principle).

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
Row typed as USD 500 (5% of 10000, amount-driven). Total later changes to 20000 via onTotalChange — the row STAYS at exactly 500 (not rescaled to 1000); the remainder/last-row absorbs the rest.

## Verification Note
Confirmed directly in leg-allocator.component.ts source (onTotalChange implementation matches exactly); did not re-open the spec file but the implementation itself is unambiguous and sufficient evidence.

## Source Evidence
- leg-allocator.component.ts Row.driver doc comment lines 42-56
- onTotalChange() lines 470-484 branches on row.driver, leaving amount-driven rows' amountTxCcy untouched and only refreshing pct

## Related Knowledge
- [[Payment Component Simulator UI]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
