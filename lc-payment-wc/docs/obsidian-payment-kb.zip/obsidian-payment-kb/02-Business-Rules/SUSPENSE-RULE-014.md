---
knowledge_id: SUSPENSE-RULE-014
title: "debitSuspenseCurrencyTotals/creditSuspenseCurrencyTotals expose a per-currency breakdown so the leg-allocator can snap a row's converted amount to the server-matching per-entry-rounded figure instead of its own combined-conversion figure (v1.13.1)"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - suspense
  - confirmed
---

# SUSPENSE-RULE-014 — debitSuspenseCurrencyTotals/creditSuspenseCurrencyTotals expose a per-currency breakdown so the leg-allocator can snap a row's converted amount to the server-matching per-entry-rounded figure instead of its own combined-conversion figure (v1.13.1)

## Status
CONFIRMED

## Business Rule
A per-currency Map of {rawTotal, trxEquivalent} (same per-entry conversion/rounding as suspenseAdjustment()'s own total) is exposed to <app-leg-allocator> via [suspenseCurrencyTotals]. This fixes a reviewer-reported 1-cent gap: typing a Suspense currency bucket's own combined raw total into a leg row's Account Ccy Equivalent used to convert in ONE combined division, which could disagree by a minor unit from the seed total's own per-entry-rounded figure.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
Total 10000, Suspense Debit = USD 10 + EUR 20 + EUR 50 => seed 10085.81; typing Account Ccy Equiv. 70 (=20+50) into the EUR debit row snaps amountTxCcy to 75.81 (not 75.82), leaving the USD remainder row at exactly 10010.00

## Verification Note
MERGED with the near-duplicate candidate 'suspense-bucket-granularity-snap' (angular-leg-allocator group), which describes the identical fix from the consuming (leg-allocator) side rather than the producing (business-case-runner) side. Read both business-case-runner.component.ts's producing code (getters + suspenseCurrencyBuckets) and leg-allocator.component.ts's consuming code (onAccountAmountInput lines 1010-1036), plus both spec files' exact test blocks and the worked 75.81/10010.00 numbers — all match precisely. Status: CONFIRMED.

## Source Evidence
- business-case-runner.component.ts suspenseCurrencyBuckets()/debitSuspenseCurrencyTotals/creditSuspenseCurrencyTotals (lines 363-437), doc comment lines 363-386 spelling out the exact bug and fix
- business-case-runner.component.spec.ts line 441 'debitSuspenseCurrencyTotals / creditSuspenseCurrencyTotals' describe block
- leg-allocator.component.ts suspenseCurrencyTotals @Input (line 218) and onAccountAmountInput's snap logic (lines 1010-1036)
- leg-allocator.component.spec.ts line 975 'suspenseCurrencyTotals granularity snap' describe block, including the exact 75.81/10010.00 end-to-end reproduction (lines 989-1001)

## Related Knowledge
- [[Suspense Account]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
