---
knowledge_id: UI-RULE-001
title: "Formly header fields (Unit Code / Main Ref / Sequence / Voucher Prefix) are generated only for PASS cases"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - ui
  - confirmed
---

# UI-RULE-001 — Formly header fields (Unit Code / Main Ref / Sequence / Voucher Prefix) are generated only for PASS cases

## Status
CONFIRMED

## Business Rule
buildHeaderFields returns an empty array for any non-PASS verdict (GAP or N_A); GAP cases only ever hit the /payment-instructions/classify endpoint (legs only, no header), so header input fields are meaningless for them and are not rendered.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
buildHeaderFields(config with verdict GAP) === [] and same for N_A.

## Verification Note
Re-read business-case-fields.ts in full and the matching spec test; code and test match the claim exactly. CONFIRMED unchanged.

## Source Evidence
- business-case-fields.ts:52-54 (buildHeaderFields ternary on config.verdict === 'PASS')
- business-case-fields.ts:37-40 doc comment
- business-case-fields.spec.ts: "returns [] for a non-PASS verdict" — asserts [] for both GAP and N_A

## Related Knowledge
- [[Payment Component Simulator UI]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
