---
knowledge_id: UI-RULE-024
title: "SuspenseEntry.sourceComponent captures the offsetting-leg source (Charge vs Balance/Liability) as a simple UI dropdown, defaulting to CHARGE"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - ui
  - confirmed
---

# UI-RULE-024 — SuspenseEntry.sourceComponent captures the offsetting-leg source (Charge vs Balance/Liability) as a simple UI dropdown, defaulting to CHARGE

## Status
CONFIRMED

## Business Rule
SuspenseEntriesComponent's sourceComponent field is a UI-friendly Charge/Liability dropdown using the same wire values as SuspenseBridgeEntry.sourceComponent ('CHARGE' for Charge, 'BALANCE' for Liability — there is no 'LIABILITY' wire value, since a Balance Component books the Liability leg). Defaults to 'CHARGE' for a new row.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
n/a

## Verification Note
New rule surfaced during verification of this file (was not one of the 26 candidates but is directly load-bearing evidence encountered while verifying suspense-currency-seed-not-retroactive / suspense-entries-stable-rowid-tracking). Added for completeness rather than silently omitted; directly confirmed against source.

## Source Evidence
- suspense-entries.component.ts lines 11-20 (SuspenseEntry.sourceComponent doc comment)
- addRow() line 69: `sourceComponent: 'CHARGE'` default

## Related Knowledge
- [[Payment Component Simulator UI]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
