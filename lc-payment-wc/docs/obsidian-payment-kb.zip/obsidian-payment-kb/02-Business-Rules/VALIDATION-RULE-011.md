---
knowledge_id: VALIDATION-RULE-011
title: "All Suspense entries sharing a currency within one bucket must resolve to the exact same crossRate; a mismatch is rejected"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - validation
  - confirmed
---

# VALIDATION-RULE-011 — All Suspense entries sharing a currency within one bucket must resolve to the exact same crossRate; a mismatch is rejected

## Status
CONFIRMED

## Business Rule
resolveBucketRate collects the distinct crossRate values across a currency bucket's entries (via a Set) and throws RequestValidationError if more than one distinct value is present — each currency pair should resolve to one deterministic FX rate per request, so a mismatch signals a caller-side inconsistency.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
Two EUR entries in the same bucket with crossRate '1.08' and '1.09' -> RequestValidationError naming both values.

## Verification Note
Confirmed exactly by direct read of suspenseBridge.ts lines 243-253.

## Source Evidence
- microservices/payment-component/src/domain/suspenseBridge.ts lines 243-253 (resolveBucketRate, the `if (rates.size > 1) throw` check)
- test/unit/domain/suspenseBridge.test.ts lines 249-256 ('throws RequestValidationError when same-currency entries carry different crossRate values')

## Related Knowledge
- [[Request Validation]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
