---
knowledge_id: FX-RULE-030
title: "transactionCurrency is an explicit wire field representing the deal's actual currency, deliberately independent of any individual leg's own settlement currency"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - fx
  - confirmed
---

# FX-RULE-030 — transactionCurrency is an explicit wire field representing the deal's actual currency, deliberately independent of any individual leg's own settlement currency

## Status
CONFIRMED

## Business Rule
Merged with 'transaction-currency-explicit-field' (id_hint 39) below — both describe the identical PaymentInstructionConfirmRequest.transactionCurrency field from two near-identical sources (the Angular client's own duplicated types.ts doc comment vs. the OAS yaml's doc comment), which are themselves near-verbatim copies of each other.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
A side whose sole leg is fully paid in JPY, with the deal's true transaction currency USD: transactionCurrency must be sent as 'USD' explicitly, else the legacy fallback infers JPY from debitLegs[0].currency.

## Verification Note
Confirmed the server-side implementation this doc comment describes (requestSchema.ts line 172, already verified above under 'amount-tx-ccy-denomination-transactionCurrency'). Flagged as a near-duplicate of rule 39 in this list — both cite the same field from parallel doc sources (client types.ts vs OAS yaml); merged conceptually, kept as separate list entries per the original candidate IDs since they cite technically different files, but the substance is identical. No status downgrade.

## Source Evidence
- payment-component.types.ts PaymentInstructionConfirmRequest.transactionCurrency doc comment
- Payment_component.yaml / payment-instructions-post.yaml v1.10.0 changelog entries

## Related Knowledge
- [[FX Processing]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
