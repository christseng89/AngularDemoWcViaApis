---
knowledge_id: ARCH-RULE-043
title: "Extended usage scenarios (LC fee collection, IBL/EBL Takedown, IBL/EBL Repayment) are documented wire-shape guidance only, NOT implemented business-case-registry entries"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - other
  - confirmed
---

# ARCH-RULE-043 — Extended usage scenarios (LC fee collection, IBL/EBL Takedown, IBL/EBL Repayment) are documented wire-shape guidance only, NOT implemented business-case-registry entries

## Status
CONFIRMED

## Business Rule
Three trade-finance scenarios (A. Fee collection for LC Issue/Amendment — the creditLegs:[] + suspenseBridge.creditEntries fee-collection pattern; B. IBL/EBL Takedown — disbursement, requiring a REAL accountType:'SUSPENSE' debit leg, never suspenseBridge-generated since bridge legs are always credit-direction; C. IBL/EBL Repayment — mirrors Takedown, with the Balance Component's own Dr Suspense/Cr IBL booking inferred by symmetry only, not independently confirmed elsewhere) are documented in the microservice README's 'Extended usage scenarios' section but have no citation, no default account numbers, and no regression test in business-case-registry.ts. For B/C, an optional Trx Charges bridge entry requires adjusting the matching real leg's OWN amount by the fee (README's 'Common mistake to avoid' note) — getting this wrong produces a 409 LEGS_UNBALANCED, not a 400.

## Conditions
Applies to any developer or BA assuming these three scenarios are exercised by an automated test or a UI business case today.

## Result
A developer must not assume these scenarios are exercised by any automated test or UI business case; they are usage guidance only.

## Example
n/a

## Verification Note
Confirmed directly against the project CLAUDE.md content provided in context (the 'Extended usage scenarios' and 'User Manual §6.6/§6.6.1/§6.6.2' sections), which state this fact explicitly and are corroborated by a second, independent later section (the User Manual fix) that re-derives the same 'not yet in registry' fact via its own grep, rather than merely repeating the first claim. Status CONFIRMED is correct. Near-duplicate note: this is the identical rule to cross-domain 'Other/CONFIRMED extended-usage-scenarios-not-implemented' listed in the full cross-domain title list — it is the same rule appearing twice in the master list (once as a standalone 'Other' domain candidate and once already embedded in the full cross-domain title dump); no further merge action needed within this batch since only one copy was presented as a candidate to verify here, but flagging for the aggregator that the master list already contains this exact id_hint twice.

## Source Evidence
- CLAUDE.md 'Extended usage scenarios — LC fee collection, IBL/EBL Takedown, IBL/EBL Repayment' section: '**None of the three are implemented as registry business cases yet** — no citation, no default account numbers, no regression test.'
- CLAUDE.md 'User Manual: §6.6 corrected...' section: confirms via grep of business-case-registry.ts for ibl/ebl/LC Issue/Amendment finding none, explicitly reaffirming (not newly claiming) the same fact.
- CLAUDE.md same section: 'For B/C, an optional Trx Charges bridge entry requires adjusting the matching real leg's OWN amount by the fee (README's "Common mistake to avoid" note) — getting this wrong is a 409 LEGS_UNBALANCED, not a 400.'

## Related Knowledge
- [[Payment Architecture]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
