---
knowledge_id: SWIFT-RULE-007
title: "AccountEntry carries exchangeRate1/exchangeRate2 fields whose semantics are only partially populated by this service"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - swift
  - confirmed
---

# SWIFT-RULE-007 — AccountEntry carries exchangeRate1/exchangeRate2 fields whose semantics are only partially populated by this service

## Status
CONFIRMED

## Business Rule
The AccountEntry interface (both the microservice's own types.ts and the Angular app's independently-maintained payment-component.types.ts duplicate) defines both exchangeRate1 and exchangeRate2 as optional ExchangeRate fields on every posted account entry. The microservice's accountEntries.ts populates exchangeRate1 from the leg's own rate field matching its side (drRate ?? drBuyRate for DEBIT, crBuyRate ?? sellRate for CREDIT) and deliberately leaves exchangeRate2 unset, since neither OAS source documents its meaning and a leg only ever carries one rate value on the wire.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
n/a — field existence and one-sided population behavior both directly confirmed in code.

## Verification Note
Re-read both types files and accountEntries.ts. The original candidate framed the population behavior as 'out of scope for this group's files' (angular-services group only had the types file) but the actual microservice source (in scope for this SWIFT-domain verification pass) does confirm the population logic directly, so this can be stated as CONFIRMED rather than merely 'field existence confirmed, population behavior out of scope'. Upgraded confidence accordingly — not a downgrade.

## Source Evidence
- src/app/payment-component/payment-component.types.ts AccountEntry interface lines 176-193 — exchangeRate1?: ExchangeRate; exchangeRate2?: ExchangeRate;
- microservices/payment-component/src/types.ts lines 227-228 — same two optional fields on the server-side AccountEntry
- microservices/payment-component/src/domain/accountEntries.ts lines 73-104 — doc comment plus 'const exchangeRate1 = side === 'DEBIT' ? (leg.drRate ?? leg.drBuyRate) : (leg.crBuyRate ?? leg.sellRate);' and exchangeRate2 deliberately never set

## Related Knowledge
- [[SWIFT Messaging and Vouchers]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
