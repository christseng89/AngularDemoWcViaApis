---
knowledge_id: FX-RULE-033
title: "Charge Component Bridge FX sizing — FX Exchange entry sized to the residual difference, not the gross amount"
domain: Payment
category: Business Rule
status: INFERRED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - fx
  - inferred
---

# FX-RULE-033 — Charge Component Bridge FX sizing — FX Exchange entry sized to the residual difference, not the gross amount

## Status
INFERRED

## Business Rule
The FSD (§7.8) describes a 'Charge Component Bridge' pattern gated by a `chargeComponentBridge` boolean wire-extension flag, under which the FX Exchange entry between Suspense Credit and matching debit legs is sized to the residual difference (never the gross amount), with none generated when the difference is exactly zero. The substantive residual-sizing behavior IS confirmed as shipped — it is exactly the general v1.9.0 DEBIT-side netting logic in suspenseBridge.ts (rule 'debit-bucket-fx-netting-v1.9.0'), which applies unconditionally to every debitEntries bucket, not gated behind any special flag.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
Scenario table: Debit legs exactly match Suspense Credit per currency → no FX Exchange entries; partial cover → FX pair sized to just the residual; debit legs exceed Suspense Credit → opposite-direction pair sized to just the excess.

## Verification Note
Downgraded from CONFIRMED to INFERRED. The FSD's specific framing — a named `chargeComponentBridge` boolean flag gating this behavior for a narrow 'no-credit-leg LC issuance' scenario — does not correspond to any field or gate in the actual shipped code; I grepped the microservice source and both OAS yaml files for 'chargeComponentBridge' and found no occurrences anywhere. The underlying BUSINESS BEHAVIOR (FX sized to residual, not gross) IS genuinely implemented, but as the unconditional, general v1.9.0 debit-bucket netting rule (see 'debit-bucket-fx-netting-v1.9.0'), not as a flag-gated special case. A separate architecture doc (Trade_Finance_Payment_Component_Architecture_v4-cn) even uses a THIRD, different name for a related concept ('chargeBridge: true', referencing a business-case-registry entry 'iplc-issue-charge-bridge') — so there are three different flag names across three docs (chargeComponentBridge / chargeBridge / none-at-all-in-code) for what appears to be the same underlying idea, none of which match the shipped contract's actual mechanism. Treat rule 43's citation to FSD §7.8 as describing DESIGN INTENT/history, not the literal current wire contract.

## Source Evidence
- analysis__Payment-OAS-FSD-en.docx.txt §7.8 line 77 and scenario table lines 195-202
- grep of 'chargeComponentBridge' across microservices/payment-component/src/ and both OAS yaml files returned ZERO matches — the flag does not exist in the implemented contract
- suspenseBridge.ts's actual v1.9.0 DEBIT-side netting (already fully verified above) achieves the identical residual-sizing behavior WITHOUT any such flag

## Related Knowledge
- [[FX Processing]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
