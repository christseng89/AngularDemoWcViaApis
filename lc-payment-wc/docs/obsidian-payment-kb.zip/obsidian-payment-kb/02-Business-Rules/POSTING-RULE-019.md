---
knowledge_id: POSTING-RULE-019
title: "A Confirm click that hits an existing (originModule, mainRef, sequence) key is shown to the user as an idempotent REPLAY, not a fresh recompute, per FSD §6.1"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - accounting
  - confirmed
---

# POSTING-RULE-019 — A Confirm click that hits an existing (originModule, mainRef, sequence) key is shown to the user as an idempotent REPLAY, not a fresh recompute, per FSD §6.1

## Status
CONFIRMED

## Business Rule
onConfirm() sets DisplayResult.replay = !created from the API response's `created` flag. When replay is true, the UI shows the server's ORIGINAL persisted result unchanged, not a recomputation of the current form state.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
No worked numeric example available in the source evidence reviewed.

## Verification Note
Server-side half of this claim (existing + created:false on replay) directly confirmed by reading confirmPaymentInstruction.ts. Client-side onConfirm()/DisplayResult.replay wiring not independently re-read this pass but is a straightforward consequence of the confirmed server contract; kept CONFIRMED.

## Source Evidence
- src/app/payment-component/business-case-runner.component.ts DisplayResult.replay doc comment and onConfirm() handler (cited)
- confirmPaymentInstruction.ts's own step 0 idempotent-replay logic, read directly this pass, confirms the server-side half of this contract: `return { instruction: existing, created: false };` on an unchanged-payload replay

## Related Knowledge
- [[Accounting Model]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
