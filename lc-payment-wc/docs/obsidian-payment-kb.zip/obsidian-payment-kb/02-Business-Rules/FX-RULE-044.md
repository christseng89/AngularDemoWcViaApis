---
knowledge_id: FX-RULE-044
title: "creditEntries bucket netting is deliberately NOT applied (asymmetric from debitEntries)"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - fx
  - confirmed
---

# FX-RULE-044 — creditEntries bucket netting is deliberately NOT applied (asymmetric from debitEntries)

## Status
CONFIRMED

## Business Rule
Duplicate of 'credit-bucket-fx-not-netted-v1.8.0' above — same rule, sourced from CLAUDE.md's decision log plus the zh test-cases doc's Case #2 narrative rather than the code directly.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
Case #2: creditLegs split into EUR 1083.08 + USD 8881.92 (same total as Case #1's single USD 9965.00 leg); suspenseBridge.creditEntries has only a 35 USD entry (no EUR) → no additional FX pair generated for the new EUR leg.

## Verification Note
Merged with 'credit-bucket-fx-not-netted-v1.8.0' and 'suspense-bridge-credit-side-independent-of-unrelated-legs' — all three describe the same asymmetric non-netting behavior on the credit side, from three different source documents that all agree. No status change; strongly CONFIRMED given triple-source agreement plus direct code confirmation.

## Source Evidence
- CLAUDE.md v1.9.0 section
- Payment-Component-Suspense-FX-Test-Cases-zh.md Case #2 (already verified above)

## Related Knowledge
- [[FX Processing]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
