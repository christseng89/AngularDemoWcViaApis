---
knowledge_id: POSTING-RULE-035
title: "CONFLICT: zh FSD (v1.2.0 OAS) describes THREE parallel voucher streams (Settlement/Charge/Liability) still live; en FSD (v1.8.0 OAS) and the actual current source code state Charge/Liability generation was removed entirely in v1.6.0 — current implementation matches the en FSD / code, not the zh FSD"
domain: Payment
category: Business Rule
status: CONFLICT
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - accounting
  - conflict
---

# POSTING-RULE-035 — CONFLICT: zh FSD (v1.2.0 OAS) describes THREE parallel voucher streams (Settlement/Charge/Liability) still live; en FSD (v1.8.0 OAS) and the actual current source code state Charge/Liability generation was removed entirely in v1.6.0 — current implementation matches the en FSD / code, not the zh FSD

## Status
CONFLICT

## Business Rule
The earlier zh FSD (PaymentComponent-Microservice-FSD-zh.docx, §4.1/§4.1.1/§5.4/AccountEntry.voucherType schema) describes an AccountEntry.voucherType enum of [SETTLEMENT, CHARGE, LIABILITY] and three parallel generation streams as the target design. The later en FSD (Payment-OAS-FSD-en.docx §6.3/§7.4/§2.2/Appendix B v1.6.0 changelog) and the LIVE source code (confirmPaymentInstruction.ts, accountEntries.ts) both state this was a deliberate v1.6.0 architecture decision removing Charge/Liability generation entirely — the service now only ever produces SETTLEMENT AccountEntry rows. Per evidence priority (code > tests > API/data model > docs), the code is authoritative for CURRENT behavior; the zh FSD's three-stream design is superseded design intent, not current behavior.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Current implementation: only SETTLEMENT AccountEntry rows produced; Charge/Liability booking is the caller's/Charge Component's own responsibility.

## Example
No worked numeric example available in the source evidence reviewed.

## Conflict Note
> [!warning] Sources disagree
> Directly confirmed both sides of the conflict by grepping/reading both the zh and en FSD text files, plus independently confirming via the live source code (which matches the en FSD / removal side). Status kept CONFLICT because the two DOCUMENTS genuinely disagree and both are legitimate historical evidence, but noted explicitly in the statement that code confirms the en-FSD/removed side is what's actually current — this is the correct way to report a doc-vs-doc conflict where the code independently breaks the tie for 'what's true now' without pretending the older doc doesn't exist or was never valid design intent.

## Verification Note
Directly confirmed both sides of the conflict by grepping/reading both the zh and en FSD text files, plus independently confirming via the live source code (which matches the en FSD / removal side). Status kept CONFLICT because the two DOCUMENTS genuinely disagree and both are legitimate historical evidence, but noted explicitly in the statement that code confirms the en-FSD/removed side is what's actually current — this is the correct way to report a doc-vs-doc conflict where the code independently breaks the tie for 'what's true now' without pretending the older doc doesn't exist or was never valid design intent.

## Source Evidence
- /home/claude/payment-kb/converted/analysis__PaymentComponent-Microservice-FSD-zh.docx.txt line 683 (voucherType enum incl. CHARGE, LIABILITY) and lines 931-934, 1014, read directly via grep this pass
- /home/claude/payment-kb/converted/analysis__Payment-OAS-FSD-en.docx.txt lines 21, 63, 299, read directly via grep this pass: 'v1.6.0 | Removed Charge Voucher/Liability Voucher generation entirely — this service now only ever produces SETTLEMENT entries.'
- microservices/payment-component/src/domain/confirmPaymentInstruction.ts top comment and accountEntries.ts top comment, read in full this pass — both independently corroborate the en FSD / removed-in-v1.6.0 side of the conflict, which is also the side actually implemented in code

## Related Knowledge
- [[Accounting Model]]
- [[Business-Rule-Index]]
- [[Knowledge-Gaps]]
- [[Payment-Traceability-Matrix]]
