---
knowledge_id: CLASS-RULE-013
title: "transactionCurrency is an explicit, user/case-controlled value, decoupled from any individual leg's own settlement currency (v1.10.0)"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - classification
  - confirmed
---

# CLASS-RULE-013 — transactionCurrency is an explicit, user/case-controlled value, decoupled from any individual leg's own settlement currency (v1.10.0)

## Status
CONFIRMED

## Business Rule
The displayed and wire-level Transaction Currency (transactionCurrency getter, sent as PaymentInstructionConfirmRequest.transactionCurrency) is derived ONLY from transactionCurrencyOverride (if the user set it via the header Transaction Currency select) or the selected case's own DEBIT-leg registry default, falling back to 'USD'. It does NOT track debitLegs[0].currency. Before v1.10.0 it did track the first debit leg's currency, which caused editing an individual leg's own settlement currency to silently flip the whole deal's Transaction Currency too — an explicitly reviewer-rejected behavior. Merges with candidate 16 which describes the related but distinct fact that a single override seeds both sides.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
No worked numeric example available in the source evidence reviewed.

## Verification Note
Read the full doc comment and getter implementation directly — matches exactly, including the explicit statement that it 'no longer falls back to this.debitLegs[0]?.currency at all'.

## Source Evidence
- src/app/payment-component/business-case-runner.component.ts transactionCurrency getter, lines 224-254 (doc comment) and implementation lines 248-254

## Related Knowledge
- [[Payment Instruction Classification]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
