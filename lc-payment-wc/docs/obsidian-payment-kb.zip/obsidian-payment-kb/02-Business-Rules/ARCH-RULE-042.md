---
knowledge_id: ARCH-RULE-042
title: "Known source-code defect: EPLC Liability Voucher credit-leg description field is never actually set due to a .valuee typo"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - other
  - confirmed
---

# ARCH-RULE-042 — Known source-code defect: EPLC Liability Voucher credit-leg description field is never actually set due to a .valuee typo

## Status
CONFIRMED

## Business Rule
TrxSys.js:5908 reads document.MAINFORM.TEMP_AC_VCH_DESC2.valuee = 'EPLC03CONTNULLNULLI' — 'valuee' (extra 'e'), not '.value'. This assigns a stray JS property rather than the DOM field's actual value, so TEMP_AC_VCH_DESC2 (the Liability Voucher's credit-leg description, for EPLC Pay/Accept, Pay at Maturity, and SettlePartial) is never set by this line in the legacy production codebase. Whether to replicate this defect byte-for-byte in the microservice or fix it is flagged as a genuine business decision requiring module-owner sign-off, not a silent correctness fix. Note: this is now largely moot for the current microservice specifically, since v1.6.0 removed Liability Voucher (§6.3) generation from the Payment Component entirely (per CLAUDE.md's 'Charge Component ↔ Payment Component boundary' section and the cross-domain rule 'charge-liability-streams-removed-v1.6.0') — there is no live Liability Voucher stream left to replicate this typo into.

## Conditions
Applies specifically to EPLC's Pay/Accept, Pay at Maturity, and SettlePartial functions (TrxSys.js:5902-5908), for the Liability Voucher's credit-leg description only — the Debit-leg description (TEMP_AC_VCH_DESC1, set correctly two lines earlier at line ~5905) is unaffected.

## Result
TEMP_AC_VCH_DESC2 (Cr LIAB_ACNO description) is left unset/blank rather than 'EPLC03CONTNULLNULLI' in the legacy system, for these three EPLC functions specifically.

## Example
Dr ASSET_ACNO = STL_AMT (desc "EPLC03CONTNULLNULLI", correctly set) / Cr LIAB_ACNO = STL_AMT (desc: intended to be "EPLC03CONTNULLNULLI" but never actually written due to the typo).

## Verification Note
Re-opened Payment_Component_Calculation_Validation.docx.txt and confirmed both §6.3.2 (lines 179-180) and the §11 Anomaly A1 table row (line 478) verbatim, matching the candidate rule's statement exactly including the precise 'valuee' vs '.value' distinction. Status CONFIRMED is correct — this is a directly-quoted, precisely-line-numbered source-code defect finding, tier-1/tier-3 hybrid evidence (a legacy source line reported through an analysis document, but the specific defect — property-name typo — is unambiguous and independently checkable by anyone with the legacy source). Added a note connecting this to the v1.6.0 Liability Voucher removal (cross-domain rule 'charge-liability-streams-removed-v1.6.0') since that context materially changes whether this open 'business decision' still matters for the current microservice — worth surfacing to a reader so they don't think this is a live open decision needing resolution today.

## Source Evidence
- analysis/Payment_Component_Calculation_Validation.docx (converted .txt) §6.3.2, lines 179-180: 'Source-code defect found this pass: line 5908 reads document.MAINFORM.TEMP_AC_VCH_DESC2.valuee = ...note "valuee", not "value"...never actually set by this line...Confirm with the module owner whether to replicate this defect...or fix it...See §11.'
- analysis/Payment_Component_Calculation_Validation.docx (converted .txt) §11 Anomaly A1 table row, line 478: 'A1 | EPLC Pay/Accept, Pay at Maturity, SettlePartial | .valuee typo (TrxSys.js:5908) means TEMP_AC_VCH_DESC2 is never actually set for the Liability Voucher credit leg | Decide: replicate...or fix...— business decision, not a silent correctness fix | §6.3.2'

## Related Knowledge
- [[Payment Architecture]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
