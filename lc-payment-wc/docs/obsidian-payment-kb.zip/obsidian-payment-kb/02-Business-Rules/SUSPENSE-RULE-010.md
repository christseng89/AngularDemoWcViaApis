---
knowledge_id: SUSPENSE-RULE-010
title: "Leg #1 seed formula is deliberately blind to any already-entered live leg in the same currency (v1.7.4, reverting v1.7.3's attempt to net against a live leg)"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - suspense
  - confirmed
---

# SUSPENSE-RULE-010 — Leg #1 seed formula is deliberately blind to any already-entered live leg in the same currency (v1.7.4, reverting v1.7.3's attempt to net against a live leg)

## Status
CONFIRMED

## Business Rule
A live Debit/Credit leg the user has typed in a currency matching a Suspense entry's currency has NO effect on the seed calculation — only the Suspense entries' own gross amounts (independently converted) feed the seed. An earlier v1.7.3 attempt tried netting the seed against a matching live leg but broke the server's aggregate V8 check by 0.01 in a traced worked example (409 LEGS_UNBALANCED). The gross-only seed is what the server's own FX Exchange pair generation (identical trx-equivalent on both sides, cancelling out of the aggregate sum unconditionally) actually expects.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
Total 10000, Suspense Credit EUR 200 (rate 1.083077) => seed = 10000 - round(200*1.083077,2) = 9783.38, unaffected by a live EUR 100 leg the user later adds; the full leg set proven to balance aggregate V8 exactly.

## Verification Note
Read the full doc comment (lines 297-361) explaining the v1.7.3->v1.7.4 history and confirmed the cited spec describe block exists. Status unchanged: CONFIRMED.

## Source Evidence
- business-case-runner.component.ts suspenseAdjustment() doc comment lines 297-361 (v1.7.4 section explaining the v1.7.3 regression and revert)
- business-case-runner.component.spec.ts line 297 'v1.7.4: the seed formula stays gross-only, deliberately blind to any live leg in the same currency'

## Related Knowledge
- [[Suspense Account]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
