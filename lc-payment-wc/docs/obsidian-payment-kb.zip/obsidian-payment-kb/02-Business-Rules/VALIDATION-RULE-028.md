---
knowledge_id: VALIDATION-RULE-028
title: "creditLegs may be submitted empty specifically when suspenseBridge will contribute its own credit-direction leg; debitLegs has no such exception"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - validation
  - confirmed
---

# VALIDATION-RULE-028 — creditLegs may be submitted empty specifically when suspenseBridge will contribute its own credit-direction leg; debitLegs has no such exception

## Status
CONFIRMED

## Business Rule
PaymentInstructionConfirmRequest.creditLegs's doc comment (v1.10.1) states it may be empty when suspenseBridge (debitEntries or creditEntries, either non-empty) will generate its own credit-side leg — the pure fee-collection pattern (Dr Customer A/C / Cr Suspense - Credit with no other real credit leg). This is enforced server-side by requestSchema.ts's superRefine (not a plain minItems, since it's conditional): `data.creditLegs.length === 0 && !bridgeContributesCreditLeg` adds a validation issue. Otherwise creditLegs is still required (min 1). debitLegs remains unconditionally required with no such carve-out, since the server never generates a debit-direction leg from suspenseBridge. Merges 3 near-duplicate id_hints (credit-legs-may-be-empty-with-suspense-bridge from angular-services, creditlegs-conditionally-optional from api-contracts, creditlegs-optional-when-bridge-supplies-credit from root-context) all describing this identical rule.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
creditLegs: [] with suspenseBridge.creditEntries: [{amount:'250', currency:'USD', sourceComponent:'CHARGE'}] and a real debitLegs: [{accountNo:'CUST-ACC', ...amountTxCcy:'250'}] is a valid request — the server derives the offsetting Cr Suspense - Credit leg from the bridge entry.

## Verification Note
Confirmed by direct read of requestSchema.ts's actual superRefine logic (the most authoritative evidence — executable code) and cross-checked against the OAS yaml and types.ts doc comments, all in exact agreement. Merged 3 duplicate id_hints describing the identical rule from different files/groups.

## Source Evidence
- microservices/payment-component/src/validation/requestSchema.ts lines 99-104, 110-125 (the superRefine bridgeContributesCreditLeg check, doc comments)
- src/app/payment-component/payment-component.types.ts PaymentInstructionConfirmRequest.debitLegs/creditLegs doc comments (lines 140-143)
- analysis/payment-instructions-post.yaml lines 505-527 (debitLegs/creditLegs schema descriptions, v1.10.1 note about the superRefine, not minItems)
- CLAUDE.md 'creditLegs may be empty when suspenseBridge contributes its own credit-side leg (v1.10.1)' section

## Related Knowledge
- [[Request Validation]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
