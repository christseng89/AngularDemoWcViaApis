---
knowledge_id: SUSPENSE-RULE-003
title: "A suspense-bridge leg (from either debitEntries or creditEntries) always posts on the CREDIT side, unconditionally"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - suspense
  - confirmed
---

# SUSPENSE-RULE-003 — A suspense-bridge leg (from either debitEntries or creditEntries) always posts on the CREDIT side, unconditionally

## Status
CONFIRMED

## Business Rule
Every SuspenseEntry — whether it came from bridge.debitEntries or bridge.creditEntries — is converted into a PaymentLegInput and pushed into expandSuspenseBridge's own credit[] array. There is no request flag or condition that flips this to debit. This mirrors the external Charge/Balance Component posting Dr Suspense-Debit / Dr Suspense-Credit against its own contra account; this module's job is to generate the offsetting Cr leg on the Payment Component's own books, for either direction of Suspense entry.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
debitEntries: [{amount:'10',currency:'USD'}], creditEntries:[{amount:'20',currency:'USD'}] -> result.credit = [Suspense-Debit 10, Suspense-Credit 20], result.debit = []

## Verification Note
Read suspenseBridge.ts in full (402 lines) and suspenseBridge.test.ts in full (332 lines). Confirmed code (line 306-310: credit.push(leg) for both accountNo variants) and the cited test exactly. Status unchanged: CONFIRMED.

## Source Evidence
- suspenseBridge.ts lines 92-101 (buildSuspenseBridgeLeg doc comment, balance-identity derivation)
- suspenseBridge.ts lines 300-311 (expandSuspenseBridge: credit.push(leg) unconditionally for every entry in both sides)
- suspenseBridge.test.ts lines 127-139 'every debitEntries/creditEntries entry lands on the CREDIT side as its own bridge leg'

## Related Knowledge
- [[Suspense Account]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
