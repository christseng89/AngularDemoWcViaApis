---
knowledge_id: FX-RULE-029
title: "crossRate()'s return value is defined as 'units of `to` per 1 unit of `from`' — the exact multiplier convention PaymentLegInput.drBuyRate/crBuyRate expect"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - fx
  - confirmed
---

# FX-RULE-029 — crossRate()'s return value is defined as 'units of `to` per 1 unit of `from`' — the exact multiplier convention PaymentLegInput.drBuyRate/crBuyRate expect

## Status
CONFIRMED

## Business Rule
crossRate's doc comment explicitly ties its output semantics to money.ts's convertTxCcyToAccountCcy convention (amountAccountCcy = amountTxCcy × rate), so the UI must not accidentally invert the rate when populating drBuyRate/crBuyRate.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
No worked numeric example available in the source evidence reviewed.

## Verification Note
Confirmed the doc comment states this exactly, and independently verified the arithmetic is self-consistent: crossRate(USD,EUR)=fromTwd/toTwd gives 'EUR per 1 USD' which matches money.ts's amountAccountCcy=amountTxCcy×rate direction. No status change.

## Source Evidence
- fx-rate.service.ts crossRate() doc comment lines 34-41

## Related Knowledge
- [[FX Processing]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
