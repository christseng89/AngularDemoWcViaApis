---
knowledge_id: FX-RULE-008
title: "Cross-currency Suspense conversion rounds to the TRANSACTION currency's own minor-unit scale (ROUND_HALF_UP), not a fixed 2dp and not the entry's own currency's scale"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - fx
  - confirmed
---

# FX-RULE-008 — Cross-currency Suspense conversion rounds to the TRANSACTION currency's own minor-unit scale (ROUND_HALF_UP), not a fixed 2dp and not the entry's own currency's scale

## Status
CONFIRMED

## Business Rule
trxEquivalent = entry.amount × crossRate, rounded via formatMonetaryAmount to minorUnitsForCurrency(transactionCurrency) decimal places, ROUND_HALF_UP (formatMonetaryAmount uses Decimal.ROUND_HALF_UP per money.ts).

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
No worked numeric example available in the source evidence reviewed.

## Verification Note
Confirmed directly. No status change.

## Source Evidence
- suspenseBridge.ts lines 138-141 (rate parse, trxEquivalent, scale=minorUnitsForCurrency(transactionCurrency))
- money.ts formatMonetaryAmount (Decimal.ROUND_HALF_UP)

## Related Knowledge
- [[FX Processing]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
