---
knowledge_id: VALIDATION-RULE-012
title: "Cross-field SWIFT validation fails fast on the FIRST violating leg and reports its index and account number"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - validation
  - confirmed
---

# VALIDATION-RULE-012 — Cross-field SWIFT validation fails fast on the FIRST violating leg and reports its index and account number

## Status
CONFIRMED

## Business Rule
validateSwiftCrossField iterates credit legs in array order (creditLegs.forEach) and throws on the first violation found, with the error message naming both the leg's array index (leg[n]) and its accountNo — legs after the first violation are not evaluated in that same call.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
legs=[{payCoverMsgType:'MT202',accountNo:'OK-LEG'}, {payCoverMsgType:'MT202COV',accountNo:'BAD-LEG'}] -> throws naming leg[1] / BAD-LEG only.

## Verification Note
Confirmed exactly by direct read of swiftMessages.ts lines 32-39.

## Source Evidence
- microservices/payment-component/src/domain/swiftMessages.ts line 32 (creditLegs.forEach((leg, index) => {...}), lines 37-39 (throw naming leg[${index}] and accountNo=${leg.accountNo})
- test/unit/domain/swiftMessages.test.ts: 'reports the correct index when a later leg in a multi-leg array violates the rule' — OK-LEG at index 0 passes, BAD-LEG at index 1 fails, error names 'leg[1]' and 'BAD-LEG'

## Related Knowledge
- [[Request Validation]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
