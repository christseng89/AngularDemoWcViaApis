---
knowledge_id: POSTING-RULE-009
title: "Summing monetary amounts uses exact decimal arithmetic with no floating-point drift"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - accounting
  - confirmed
---

# POSTING-RULE-009 — Summing monetary amounts uses exact decimal arithmetic with no floating-point drift

## Status
CONFIRMED

## Business Rule
sumMonetaryAmounts() reduces an array of wire MonetaryAmount strings via Decimal.plus(), never native JS number addition. Propagates InvalidMonetaryAmountError if any entry is malformed.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
sumMonetaryAmounts(['0.1','0.2']).toFixed() === '0.3'

## Verification Note
Confirmed directly.

## Source Evidence
- src/money.ts lines 76-79: `return values.reduce((acc: Decimal, v) => acc.plus(parseMonetaryAmount(v)), new Decimal(0));`

## Related Knowledge
- [[Accounting Model]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
