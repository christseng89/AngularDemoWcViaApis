---
knowledge_id: SWIFT-RULE-012
title: "Legacy system originally populated SWIFT settlement amount (32A) and instructed amount (33B) from the identical source field, never independently — a defect later fixed by H-3"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - swift
  - confirmed
---

# SWIFT-RULE-012 — Legacy system originally populated SWIFT settlement amount (32A) and instructed amount (33B) from the identical source field, never independently — a defect later fixed by H-3

## Status
CONFIRMED

## Business Rule
The legacy source (X103_SETT_CCY_32A, X103_SETT_AMT_32A, X103_INSTR_CCY_33B, X103_INSTR_AMT_33B) were all direct copies of CPYT_CR_CCY / CPYT_CR_AMT_CRCCY — the two SWIFT fields were never independently computed even though MT103 semantically allows them to differ (e.g. correspondent charges deducted en route). This was flagged as anomaly A3 in the Calculation Validation doc (an open item at the time) and independently identified as finding H-3 in the expert-review doc, both predating and driving the H-3 fix verified above (now implemented and CONFIRMED as its own separate, current-state rule).

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
n/a

## Verification Note
Merged near-duplicate candidates id_hint swift-32a-33b-same-source-legacy (validation-gap-docs), swift-32a-33b-equal-cross-currency-defect (expert-reviews-manuals) into this one statement documenting the pre-fix legacy/defect state. Distinct from, and explicitly cross-referenced against, the separate 'h3-swift-32a-33b-hardened-and-uetr' rule above which documents the CURRENT, fixed, code-verified behavior — kept as two rules rather than merged into one because they describe genuinely different points in time (legacy defect vs. implemented fix), and collapsing them would obscure that the defect these sources describe has already been remediated in the code this session verified directly. Re-read all three source passages; content matches exactly. CONFIRMED as an accurate historical/legacy-defect description.

## Source Evidence
- analysis__Payment_Component_Calculation_Validation.docx.txt §7.1 (lines 211-212, 437-440) — 'X103_SETT_AMT_32A = CPYT_CR_AMT_CRCCY; X103_INSTR_AMT_33B = CPYT_CR_AMT_CRCCY' direct copies
- analysis__Payment_Component_Calculation_Validation.docx.txt §11 Anomaly A3 (line 480) and §12.5 (line 333) — 'Confirm whether this is an accepted simplification or a gap to close in the microservice'
- docs/payment-component-expert-review.md H-3 (lines 141-155) — 'buildAdviceMessage sets settlementAmount and instructedAmount to the same leg field ... emitting them equal is a message-correctness defect'

## Related Knowledge
- [[SWIFT Messaging and Vouchers]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
