---
knowledge_id: ARCH-RULE-009
title: "GAP: the voucher-prefix-selecting function/screen identifier (sourceFunctionCode) is NOT part of the official OAS request body — must be supplied out-of-band"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - architecture
  - confirmed
---

# ARCH-RULE-009 — GAP: the voucher-prefix-selecting function/screen identifier (sourceFunctionCode) is NOT part of the official OAS request body — must be supplied out-of-band

## Status
CONFIRMED

## Business Rule
PaymentInstructionConfirmRequest (OAS v1.2.0) carries only originModule, not a per-function/screen identifier, yet the correct voucher code prefix depends on both (e.g. IPLC03 vs IPLC06 for two different IPLC functions). resolveVoucherCodePrefix requires an explicit sourceFunctionCode parameter that the HTTP layer does not currently accept as a formal OAS field; callers of confirmPaymentInstruction() must supply it out-of-band until the OAS is extended. This is documented as the same open gap recorded in Payment_Mapping_Functions.docx §10, not a newly discovered one.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
No worked numeric example available in the source evidence reviewed.

## Verification Note
Confirmed verbatim against the file, including the two-different-prefixes-per-module example (IPLC03/IPLC06) visible in the same file's VOUCHER_CODE_PREFIXES table just below the doc comment.

## Source Evidence
- microservices/payment-component/src/domain/voucherDescription.ts lines 1-23 top doc comment, directly re-read: 'KNOWN GAP, FLAGGED NOT GUESSED ... PaymentInstructionConfirmRequest (OAS v1.2.0) carries only originModule, not a function/screen identifier ... This module resolves it from an explicit sourceFunctionCode parameter that the HTTP layer does NOT currently accept as a formal OAS field ... This is the same gap already recorded in Payment_Mapping_Functions.docx §10'

## Related Knowledge
- [[Payment Architecture]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
