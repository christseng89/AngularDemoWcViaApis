---
knowledge_id: FX-RULE-001
title: "A DEBIT-side Suspense bucket nets against a matching-currency real debit leg before generating an FX pair (v1.9.0) — at most one pair for the residual"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - fx
  - confirmed
---

# FX-RULE-001 — A DEBIT-side Suspense bucket nets against a matching-currency real debit leg before generating an FX pair (v1.9.0) — at most one pair for the residual

## Status
CONFIRMED

## Business Rule
For suspenseBridge.debitEntries specifically, the gross Suspense amount for a foreign currency is netted (plain Decimal subtraction of two already-rounded figures) against the caller's own matching-currency debitLegs amount (both native amount via sumLegsInCurrency and trx-ccy amount via sumLegsTrxCcy). Exact match (diffNative===0) generates zero FX pair legs. Suspense exceeding the real leg (diffNative>0) generates a CREDIT-anchored, '- Suspense'-suffixed residual pair. The real leg exceeding Suspense (diffNative<0) generates a DEBIT-anchored, unsuffixed residual pair. This works because a debitEntries Suspense leg always lands CREDIT while the matching debitLegs are DEBIT — opposite actual placement, i.e. genuinely the same money.

## Conditions
side === 'DEBIT' bucket only; currency !== transactionCurrency

## Result
At most one FX Exchange pair per foreign-currency DEBIT bucket, sized to the net residual

## Example
EUR debit leg 200 (216.62 USD-eq) vs Suspense debitEntries EUR 12 (13.00 USD-eq): diffNative=12-200=-188 -> DEBIT-anchored (Leg-anchored) pair only, sized 188 EUR / 203.62 USD. EUR debit leg exactly matching gross Suspense: diffNative=0 -> no FX pair lines at all.

## Verification Note
Directly re-read suspenseBridge.ts in full (lines 1-402). The code exactly matches the claimed logic: diffNative=grossSuspense.minus(oppositeNative), diffTrx=suspenseTrxEq.minus(oppositeTrx), branching on diffNative.greaterThan(0)/lessThan(0) with buildFxPair called once per branch. Cross-checked the worked example against Payment-Component-Suspense-FX-Test-Cases-zh.md's Case #1 (12 EUR vs 200 EUR -> diffNative=-188, diffTrx=13.00-216.62=-203.62) — arithmetic confirmed exactly. Status unchanged: CONFIRMED.

## Source Evidence
- microservices/payment-component/src/domain/suspenseBridge.ts lines 280-373 (expandSuspenseBridge, side==='DEBIT' branch, sumLegsInCurrency/sumLegsTrxCcy)
- test/unit/domain/confirmPaymentInstruction.test.ts 'v1.9.0' describe block (a real EUR debit leg netting against Suspense; exact-match skip)
- Payment-Component-Suspense-FX-Test-Cases-zh.md Case #1 worked example (12 EUR Suspense vs 200 EUR real leg -> 188 EUR residual pair)

## Related Knowledge
- [[FX Processing]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
