---
knowledge_id: API-RULE-001
title: "enrichLegs computes exactly four server-derived fields per submitted leg (legId, legSide, accountDesc, accountCategory) and otherwise passes the caller's leg input through unchanged"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - api
  - confirmed
---

# API-RULE-001 — enrichLegs computes exactly four server-derived fields per submitted leg (legId, legSide, accountDesc, accountCategory) and otherwise passes the caller's leg input through unchanged

## Status
CONFIRMED

## Business Rule
enrichLegs maps every PaymentLegInput to a PaymentLeg by spreading the original input fields and adding: a freshly generated unique legId (leg-{timestamp}-{counter}), the legSide passed in by the caller (uniform for the whole array), accountDesc via accountDescFor, and accountCategory via accountCategoryFor. No other transformation; returns [] for empty input.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
enrichLegs([{accountNo:'CUST-1',accountType:'CUSTOMER',...},{accountNo:'NOSTRO-1',accountType:'NOSTRO',rtgsIndicator:true,...}], 'DEBIT', 'IPLC03NULLNULLNULL') -> leg0.accountDesc='IPLC03NULLNULLNULLC', accountCategory='CUSTOMER'; leg1.accountDesc='IPLC03NULLNULLNULLR' (RTGS char), accountCategory='NOSTRO_FAMILY'

## Verification Note
Directly re-read voucherDescription.ts source and its three cited tests; statement matches implementation exactly. No change to status.

## Source Evidence
- microservices/payment-component/src/domain/voucherDescription.ts: enrichLegs (lines 122-134), accountDescFor (85-88), accountCategoryFor (98-109), nextLegId (111-115)
- microservices/payment-component/test/unit/domain/voucherDescription.test.ts: 'adds legId, legSide, accountDesc, accountCategory while preserving original fields' (line 81), 'assigns a unique legId per leg' (97), 'returns an empty array for an empty input' (106)

## Related Knowledge
- [[Payment Instructions API]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
