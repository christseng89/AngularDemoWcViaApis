---
knowledge_id: SWIFT-RULE-002
title: "A SWIFT message is generated per credit leg only when its own message-type field is set and not the literal 'None'; a request whose credit legs carry no such field yields swiftMessages: []"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - swift
  - confirmed
---

# SWIFT-RULE-002 — A SWIFT message is generated per credit leg only when its own message-type field is set and not the literal 'None'; a request whose credit legs carry no such field yields swiftMessages: []

## Status
CONFIRMED

## Business Rule
buildSwiftMessages emits an advice SwiftMessage when leg.payAdviceMsgType is truthy and !== 'None', and independently emits a cover SwiftMessage when leg.payCoverMsgType is truthy and !== 'None'. A leg can therefore produce 0, 1, or 2 messages; messages from multiple legs are aggregated into one flat array in leg order. This is corroborated by both OAS documents' endpoint description and the FSD's step-5 wording ('resolves to a non-None value').

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
creditLeg({payAdviceMsgType:'MT103',payCoverMsgType:'None'}) -> exactly 1 message (advice only); creditLeg({payAdviceMsgType:'None',payCoverMsgType:'None'}) or no fields set -> 0 messages

## Verification Note
Merged near-duplicate candidates id_hint swift-messages-conditional-on-msgtype, swift-message-only-generated-when-msg-type-resolves (api-contracts), and swift-message-generation-per-credit-leg (fsd-architecture-docs) into this one statement — all four described the identical rule from code, OAS description, and FSD text respectively. Re-read swiftMessages.ts and confirmed the exact gating logic and test coverage. CONFIRMED.

## Source Evidence
- src/domain/swiftMessages.ts lines 124-133 — buildSwiftMessages loop: 'if (leg.payAdviceMsgType && leg.payAdviceMsgType !== 'None') push advice; if (leg.payCoverMsgType && ... !== 'None') push cover'
- test/unit/domain/swiftMessages.test.ts — 'produces only an advice message...', 'produces only a cover message...', 'produces both messages when both types are set', 'produces no messages when both types are None or absent', 'aggregates messages across multiple legs'
- test/unit/domain/confirmPaymentInstruction.test.ts line 32 — happy-path test asserts result.instruction.swiftMessages toEqual([]) when no msgType is set
- analysis/Payment_component.yaml paths./payment-instructions.post.description (lines ~208-212) and payment-instructions-post.yaml equivalent — 'SWIFT/ISO 20022 message record creation when a credit leg's payAdviceMsgType/payCoverMsgType resolves to a non-None value'
- analysis__Payment-OAS-FSD-en.docx.txt §7.5 (line ~65) and §4.1 — 'For each credit leg, if payAdviceMsgType or payCoverMsgType resolves to a real value (not None), the corresponding outbound message is generated'

## Related Knowledge
- [[SWIFT Messaging and Vouchers]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
