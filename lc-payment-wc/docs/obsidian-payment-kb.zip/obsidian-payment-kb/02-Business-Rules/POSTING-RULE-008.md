---
knowledge_id: POSTING-RULE-008
title: "Transaction direction is expressed exclusively via the Dr/Cr side, never via a negative amount sign — the only exception is the server-computed FX Exchange side-swap"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - accounting
  - confirmed
---

# POSTING-RULE-008 — Transaction direction is expressed exclusively via the Dr/Cr side, never via a negative amount sign — the only exception is the server-computed FX Exchange side-swap

## Status
CONFIRMED

## Business Rule
isNegativeAmount() rejects negative caller-submitted amounts (M-1). The only 'negative' concept in the ledger is the FX Exchange Dr/Cr side-swap, performed by the SERVER choosing the side with a positive amount — never emitting a literal negative — after this validation runs. '-0'/'-0.00' are treated as zero, not negative.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
isNegativeAmount('-0.00') === false; isNegativeAmount('-0.01') === true

## Verification Note
Confirmed directly against source; doc comment and implementation match exactly.

## Source Evidence
- src/money.ts lines 146-159, read in full — `return value.startsWith('-') && /[1-9]/.test(value);`

## Related Knowledge
- [[Accounting Model]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
