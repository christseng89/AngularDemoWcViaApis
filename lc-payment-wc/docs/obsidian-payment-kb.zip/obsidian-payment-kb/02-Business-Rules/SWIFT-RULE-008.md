---
knowledge_id: SWIFT-RULE-008
title: "Payment Component's SWIFT/ISO20022 scope is bounded by SWIFT message CATEGORY (Category 1 MT1xx + Category 2 MT2xx + pacs.008.*/pacs.009.*), not by the specific enum values currently observed"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - swift
  - confirmed
---

# SWIFT-RULE-008 — Payment Component's SWIFT/ISO20022 scope is bounded by SWIFT message CATEGORY (Category 1 MT1xx + Category 2 MT2xx + pacs.008.*/pacs.009.*), not by the specific enum values currently observed

## Status
CONFIRMED

## Business Rule
payAdviceMsgType (credit legs only) is scoped to MT103/PACS008/None (Category 1/pacs.008); the source data-object dropdown also allows MT400/MT756 (Category 4/7) but those are explicitly out of scope, owned instead by the main IPLC/EPLC/IMCO/EXCO transaction. payCoverMsgType (credit legs only) is scoped to MT202/MT202COV/PACS009COV/None (Category 2/pacs.009.*); MT200 (also Category 2) is in-scope by the same category rule but is currently handled separately by legacy SYF_PYMT_ProcessMT200.js, not through this endpoint. This is a general category-level rule so any other MT1xx/MT2xx value found elsewhere is automatically in-scope by the same reasoning without individual re-adjudication; the bank's own dropdown fields mix in-scope and out-of-scope values purely for UI-field-reuse convenience, not because the legacy system treats them as one bounded context.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
n/a

## Verification Note
Merged near-duplicate candidates id_hint swift-message-scope-category-1-2-only (api-contracts) and swift-category-scope-boundary (fsd-architecture-docs) into this one statement — both describe the identical scope decision from the OAS and FSD sides respectively. Re-read both YAML files' relevant sections and the zh FSD §4.2.3 text directly; all agree. CONFIRMED.

## Source Evidence
- analysis/Payment_component.yaml lines 760-780 — PaymentLegInput.payAdviceMsgType and payCoverMsgType descriptions, exact scope-rule wording
- analysis/payment-instructions-post.yaml — equivalent PaymentLegInput.payAdviceMsgType/payCoverMsgType descriptions
- Payment_component.yaml SwiftMessage.messageType description (lines 863-869) — same category rule, MT200 noted as in-scope-by-category but not currently produced
- analysis__PaymentComponent-Microservice-FSD-zh.docx.txt §4.2.3 (lines 100-109) — full Chinese-language statement of the same decision, including the SSSS_PaymentCredit.js:1892-1901 per-module default citation explaining why the legacy dropdown mixes in/out-of-scope values

## Related Knowledge
- [[SWIFT Messaging and Vouchers]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
