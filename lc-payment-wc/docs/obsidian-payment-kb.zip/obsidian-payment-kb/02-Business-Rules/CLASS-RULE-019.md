---
knowledge_id: CLASS-RULE-019
title: "The viewer infers 'transaction currency' from entries[0].currency, which is stale relative to the server's v1.10.0 explicit transactionCurrency field"
domain: Payment
category: Business Rule
status: CONFLICT
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - classification
  - conflict
---

# CLASS-RULE-019 — The viewer infers 'transaction currency' from entries[0].currency, which is stale relative to the server's v1.10.0 explicit transactionCurrency field

## Status
CONFLICT

## Business Rule
groupedSettlementEntries derives its own transactionCurrency as `entries[0]!.currency`, with an inline comment stating this 'mirrors the server's own request.debitLegs[0]!.currency'. Per this repo's own documented v1.10.0 decision, the SERVER itself moved away from exactly that proxy because it silently breaks whenever a side's legs are ALL denominated in a foreign currency (the 'Full pay in JPY' bug) — the server now reads `request.transactionCurrency ?? request.debitLegs[0]!.currency` from an explicit wire field. The Angular response-viewer component has no such @Input and still infers purely from the first response entry's currency. None of this component's tests construct a fully-foreign-currency scenario, so it is genuinely unresolved whether groupedSettlementEntries' Debit/Credit attribution for FX pairs still works correctly once a side is entirely in a non-transaction currency, or whether it would misattribute pairs the same way the pre-v1.10.0 server bug did.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
No worked numeric example available in the source evidence reviewed.

## Conflict Note
> [!warning] Sources disagree
> Verified directly: response-viewer.component.ts line 190 does read `entries[0]!.currency` with exactly the doc comment claimed. Confirmed via grep that response-viewer.component.spec.ts has zero references to 'transactionCurrency' or 'entries[0]', supporting the claim that no test covers this. This is a genuine, currently-live architectural inconsistency between the server's v1.10.0 fix and the client component that was never updated to match — kept as CONFLICT since it represents two parts of the same codebase disagreeing on how to determine transaction currency, with no test evidence either way to resolve it.

## Verification Note
Verified directly: response-viewer.component.ts line 190 does read `entries[0]!.currency` with exactly the doc comment claimed. Confirmed via grep that response-viewer.component.spec.ts has zero references to 'transactionCurrency' or 'entries[0]', supporting the claim that no test covers this. This is a genuine, currently-live architectural inconsistency between the server's v1.10.0 fix and the client component that was never updated to match — kept as CONFLICT since it represents two parts of the same codebase disagreeing on how to determine transaction currency, with no test evidence either way to resolve it.

## Source Evidence
- src/app/payment-component/response-viewer.component.ts lines 186-190 (doc comment + implementation of transactionCurrency: `const transactionCurrency = entries[0]!.currency;`)
- project CLAUDE.md 'transactionCurrency — explicit wire field, independent of any leg's own currency... (v1.10.0)' section
- response-viewer.component.spec.ts — grepped for 'transactionCurrency' and 'entries[0]' with no matches, confirming no test exercises this scenario

## Related Knowledge
- [[Payment Instruction Classification]]
- [[Business-Rule-Index]]
- [[Knowledge-Gaps]]
- [[Payment-Traceability-Matrix]]
