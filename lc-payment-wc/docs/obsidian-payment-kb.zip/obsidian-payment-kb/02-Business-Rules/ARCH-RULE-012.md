---
knowledge_id: ARCH-RULE-012
title: "The default payment instruction store is an in-memory Map — explicitly documented as demonstration/testing-only, unsafe for production or multi-instance deployment"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - architecture
  - confirmed
---

# ARCH-RULE-012 — The default payment instruction store is an in-memory Map — explicitly documented as demonstration/testing-only, unsafe for production or multi-instance deployment

## Status
CONFIRMED

## Business Rule
createInMemoryPaymentInstructionStore() backs the natural-key idempotency guarantee with three in-process JS Maps (byNaturalKey, byId, fingerprintByNaturalKey). Its own doc comment states this does not survive a process restart and does not work across multiple service instances, and mandates that a real deployment replace it with a persistent store backed by a UNIQUE constraint on (origin_module, main_ref, sequence) written via an atomic upsert. createApp() defaults to this store when none is injected, meaning the service is NOT idempotency-safe under horizontal scaling or restarts out of the box.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
No worked numeric example available in the source evidence reviewed.

## Verification Note
Confirmed directly against both files. Unchanged.

## Source Evidence
- microservices/payment-component/src/store/paymentInstructionStore.ts lines 1-63, directly re-read in full: 'PRODUCTION NOTE: this is an in-memory Map for demonstration/testing only — it does not survive a process restart and does not work across multiple service instances. A real deployment MUST replace this...'
- microservices/payment-component/src/app.ts line 9: `export function createApp(store: PaymentInstructionStore = createInMemoryPaymentInstructionStore()): Express`

## Related Knowledge
- [[Payment Architecture]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
