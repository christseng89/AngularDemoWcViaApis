---
knowledge_id: FX-RULE-032
title: "Each Suspense entry converts and posts ALONE (gross, per-entry) — never merged with another entry or a matching real leg — for the Suspense bridge leg itself"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - fx
  - confirmed
---

# FX-RULE-032 — Each Suspense entry converts and posts ALONE (gross, per-entry) — never merged with another entry or a matching real leg — for the Suspense bridge leg itself

## Status
CONFIRMED

## Business Rule
The Suspense bridge leg(s) are unconditionally posted at each SuspenseEntry's own full gross amount, converted per entry, never bucket-summed-then-converted-once and never combined with a same-currency real leg's amount before the Suspense leg itself is built. Proven necessary by the v1.7.3/v1.7.4 history: combining a foreign-currency Suspense bucket with a matching real leg before conversion broke aggregate V8 balance by exactly one minor unit in a worked example (client-side attempt, reverted same day).

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
v1.7.4 counter-example: real EUR 100 Payment Leg (client trx-equivalent 108.31) + Suspense Credit EUR 200 (service trx-equivalent 216.62), combined by v1.7.3 into one pair at trx-equivalent 324.92, but the correct aggregate total is 10324.92 — v1.7.3 produced 10324.93, a 1-unit V8 failure.

## Verification Note
Confirmed both the OAS yaml changelog text (v1.7.3/v1.7.4 history, matching the cited 108.31/216.62/324.92 figures exactly) and the current code's per-entry loop in expandSuspenseBridge (`for (const entry of bucket) { const leg = buildSuspenseBridgeLeg(...) }` — each entry converted independently). No status change. Note this v1.7.3/v1.7.4 history was CLIENT-SIDE only per the yaml's own text ('this service and contract UNCHANGED') — worth noting the server-side module (suspenseBridge.ts) implements the same gross-per-entry approach natively, consistent with, not merely inherited from, that client-side lesson.

## Source Evidence
- payment-instructions-post.yaml v1.7.3/v1.7.4 changelog (lines ~176-222) and SuspenseBridge description IMPORTANT note
- suspenseBridge.ts buildSuspenseBridgeLeg — each entry independently converted, no bucket-summing before conversion

## Related Knowledge
- [[FX Processing]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
