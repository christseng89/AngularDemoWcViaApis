---
knowledge_id: CHARGE-RULE-008
title: "Foreign Bank Charges (FBC) deducted by the correspondent before wiring funds are collected from the customer as a pure pass-through, never booked to a bank Income account — distinct from commission/fee lines which ARE bank income"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - charges
  - confirmed
---

# CHARGE-RULE-008 — Foreign Bank Charges (FBC) deducted by the correspondent before wiring funds are collected from the customer as a pure pass-through, never booked to a bank Income account — distinct from commission/fee lines which ARE bank income

## Status
CONFIRMED

## Business Rule
Across A2/A3 (corr bank charges) and B4/B5 (FBC), the correspondent's own deduction is recovered from the counterparty via a Dr/Cr CA leg only — no matching 'FBC Income' credit exists anywhere in the codebase, unlike every commission/fee (Commission, SWIFT Fee, Advising Commission, Confirming Commission, Nego Fee, Discount, Settlement Commission, Collection Fee), each of which books an explicit *_Income GL leg. Nostro is booked net of FBC (bill + FBC, paid gross to correspondent) in every case that has FBC, reflecting the correspondent already deducted/will deduct it.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
No worked numeric example available in the source evidence reviewed.

## Verification Note
Fully re-verified via direct grep for all 'Income' GL account strings in server.js — count and names match exactly what was claimed, and no FBC/Corr-Charges equivalent exists. No change to status.

## Source Evidence
- backend/server.js: grep for entry('Cr', '*Income'...) across the whole file finds exactly 8 distinct Income lines (Commission, SWIFT Fee, Advising Commission, Confirming Commission, Nego Fee, Discount, Settlement Commission, Collection Fee Income) — no FBC/Corr-Charges Income line exists anywhere
- backend/server.js lines 375, 676, 719, 828 ('pass-through to correspondent' / 'Correspondent bank charges collected' comments, all on Dr CA legs only, never paired with an Income credit)
- backend/server.js A2 endpoint (lines 229-310) and A3 endpoint (lines 324-401): confirmed no Income-type leg appears at all in either

## Related Knowledge
- [[Charge Integration]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
