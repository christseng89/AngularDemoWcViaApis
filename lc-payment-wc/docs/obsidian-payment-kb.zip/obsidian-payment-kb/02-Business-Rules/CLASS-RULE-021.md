---
knowledge_id: CLASS-RULE-021
title: "Import LC components model a 3-stage event chain: Issue (A1) → IBL Lodgement (A3) → IBL Settlement/Repayment (A4), with an alternative direct-Settlement path (A2)"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - classification
  - confirmed
---

# CLASS-RULE-021 — Import LC components model a 3-stage event chain: Issue (A1) → IBL Lodgement (A3) → IBL Settlement/Repayment (A4), with an alternative direct-Settlement path (A2)

## Status
CONFIRMED

## Business Rule
The four import-side components carry explicit stage labels (A1–A4) and cross-referencing comments describing a lifecycle: A1 (lc-issue.element.ts) issues the LC and collects Margin+Commission+SWIFT; A3 (lc-sight-payment.element.ts, 'IBL Lodgement') books the bill as an Import Bill Loan net of margin already held, using the margin pledge to fund the Nostro payment to the correspondent bank; A4 (lc-sight-settlement.element.ts, 'IBL Settlement') is the customer's later repayment of that net IBL balance (Dr CA / Cr IBL), explicitly noting 'Margin was consumed in A3'. A2 (lc-settlement.element.ts, 'Settlement (Sight/Usance)') is a parallel, alternative path that settles Bill + Corr Charges − Margin Released directly against the customer's CA in one step, without ever creating an IBL.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
No worked numeric example available in the source evidence reviewed.

## Verification Note
Read all three cited files directly — every quoted comment matches verbatim (with a one-line offset on lc-sight-settlement.element.ts's hint text, found at line 84 not 83, immaterial).

## Source Evidence
- src/app/web-components/import/lc-sight-payment.element.ts lines 7-9 ('A3 — Import LC Sight Payment (IBL Lodgement) ... IBL = Bill Amount − Margin')
- src/app/web-components/import/lc-sight-settlement.element.ts lines 7-10 ('A4 — Import LC Sight Settlement (IBL → Customer) ... Margin was consumed in A3 ... iblAmount = Bill − Margin (net from A3)') and line 84 ('= Bill Amount − Margin (from A3)')
- src/app/web-components/import/lc-settlement.element.ts line 116 ('Margin held in transaction currency released against gross payment. Net = Bill + Corr − Margin.')

## Related Knowledge
- [[Payment Instruction Classification]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
