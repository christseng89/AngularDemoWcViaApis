---
knowledge_id: POSTING-RULE-003
title: "Settlement Vouchers leg ordering places the FX Exchange pair adjacent, between normal debits/credits, for accounting-review readability (v1.7.1), superseded/matches 'fx-pair-ordering-adjacent-block'"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - accounting
  - confirmed
---

# POSTING-RULE-003 — Settlement Vouchers leg ordering places the FX Exchange pair adjacent, between normal debits/credits, for accounting-review readability (v1.7.1), superseded/matches 'fx-pair-ordering-adjacent-block'

## Status
CONFIRMED

## Business Rule
The assembled debit/credit leg arrays are deliberately ordered: Normal Debits -> FX Debit leg(s) -> FX Credit leg(s) -> Normal Credits -> Suspense Credit leg(s). On the credit side, FX-pair legs (accountType INTERNAL) are split from Suspense legs so FX ones lead and Suspense ones trail after the caller's own creditLegs.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
debitLegs order: ['CUST-ACC','FX Exchange USD - Suspense','FX Exchange USD']; creditLegs order: ['FX Exchange EUR - Suspense','FX Exchange EUR','NOSTRO-ACC','NOSTRO-ACC','Suspense - Credit']

## Verification Note
Directly confirmed in confirmPaymentInstruction.ts: the code builds bridgeFxCredit/bridgeSuspenseCredit and assembles creditLegsInput = [...bridgeFxCredit, ...request.creditLegs, ...bridgeSuspenseCredit], matching the claim exactly. Near-duplicate of the api-contracts group's 'fx-pair-ordering-adjacent-block' (same rule, OAS-doc-sourced) — noted but not merged since that one cites a different evidence source (OAS changelog) and is listed separately in the cross-domain title list; kept as one entry here since both describe the identical rule.

## Source Evidence
- src/domain/confirmPaymentInstruction.ts lines 154-167, read in full and confirmed matches the exact ordering logic described

## Related Knowledge
- [[Accounting Model]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
