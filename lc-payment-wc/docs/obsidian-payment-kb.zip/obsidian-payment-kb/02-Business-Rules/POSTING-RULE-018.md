---
knowledge_id: POSTING-RULE-018
title: "Suspense-adjustment summation uses arbitrary-precision Decimal end-to-end, not plain JS number arithmetic, to avoid IEEE-754 ULP drift in the wire amount"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - accounting
  - confirmed
---

# POSTING-RULE-018 — Suspense-adjustment summation uses arbitrary-precision Decimal end-to-end, not plain JS number arithmetic, to avoid IEEE-754 ULP drift in the wire amount

## Status
CONFIRMED

## Business Rule
suspenseAdjustment()/sideDefaults() accumulate each already-rounded per-entry trx-equivalent via decimal.js (Decimal), performing exactly one final rounding pass, rather than summing as plain JS numbers.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
No worked numeric example available in the source evidence reviewed.

## Verification Note
Partially re-verified: confirmed suspenseAdjustment() and suspenseCurrencyBuckets() exist as described and that suspenseAdjustment delegates to suspenseCurrencyBuckets (grep-confirmed call graph). Did not re-open the full Decimal-summation implementation line-by-line this pass; kept CONFIRMED based on structural confirmation plus the extensive, consistent documentation of this exact mechanism throughout CLAUDE.md's v1.13.1 section (independently corroborated by seed-total-per-entry-rounding-vs-combined below).

## Source Evidence
- src/app/payment-component/business-case-runner.component.ts lines 351-365 (suspenseAdjustment/suspenseCurrencyBuckets), function signatures and doc comments read directly via grep+targeted read
- spec.ts tests (cited, not independently re-read)

## Related Knowledge
- [[Accounting Model]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
