---
knowledge_id: ARCH-RULE-022
title: "LC web components call a separate legacy mock API, not the Payment Component microservice"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - architecture
  - confirmed
---

# ARCH-RULE-022 — LC web components call a separate legacy mock API, not the Payment Component microservice

## Status
CONFIRMED

## Business Rule
Every *.element.ts in the web-components group calls its own bank-officer calculation endpoint (e.g. POST /api/import/issue/calc, /api/export/nego/calc) via shared.ts's ApiServiceClass, whose base URL is '/api'. These endpoints are the 'legacy Import/Export LC mock API' served by backend/server.js — a completely separate Node service from microservices/payment-component/. The DrCrEntry model these components render (leg/account/accountType/ccy/amount/amountTwd/description) is a self-contained, simpler bookkeeping shape unique to this legacy mock, unrelated to PaymentLegInput/debitLegs/creditLegs/suspenseBridge.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
No worked numeric example available in the source evidence reviewed.

## Verification Note
Confirmed directly. DrCrEntry shape and ApiServiceClass base URL match exactly. Unchanged.

## Source Evidence
- src/app/web-components/shared.ts lines 1-11 (DrCrEntry interface — leg/account/accountType/ccy/amount/amountTwd/description) and lines 121-124 (ApiServiceClass, `private readonly base = '/api';`), both directly re-read
- project CLAUDE.md standing test-surface list (given in this task's own context): 'cd lc-payment-wc/backend && npm test # legacy Import/Export LC mock API — passing required, no coverage floor currently enforced'

## Related Knowledge
- [[Payment Architecture]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
