---
knowledge_id: SWIFT-RULE-003
title: "A COV-type cover message requires a compatible advice message on the same credit leg (payCoverMsgType in {MT202COV, PACS009COV} forces payAdviceMsgType into {MT103, PACS008})"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - swift
  - confirmed
---

# SWIFT-RULE-003 — A COV-type cover message requires a compatible advice message on the same credit leg (payCoverMsgType in {MT202COV, PACS009COV} forces payAdviceMsgType into {MT103, PACS008})

## Status
CONFIRMED

## Business Rule
Per credit leg: if payCoverMsgType is MT202COV or PACS009COV, then payAdviceMsgType MUST be present and in {MT103, PACS008} — otherwise the request is rejected with BusinessValidationError code SWIFT_ADV_COV_MISMATCH (-> HTTP 409). A plain (non-COV) cover type such as MT202, or an absent payCoverMsgType, is exempt from this check entirely. This is credit-leg only (the same fields exist on the debit-leg schema but are never read there), and traces to the legacy CPYT_PAY_ADV_MSG()/CPYT_PAY_COV_MSG() onChange handlers enforcing the identical constraint from either direction.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
creditLeg({payCoverMsgType:'MT202COV'}) with no payAdviceMsgType set -> throws BusinessValidationError code SWIFT_ADV_COV_MISMATCH with message 'Credit leg[0] (accountNo=...): The Payment Advice Message should be MT103 or PACS008, while the Payment Cover Message is MT202COV or PACS009COV.'

## Verification Note
Merged near-duplicate candidates id_hint swift-adv-cov-cross-field-mismatch (code-level, clearest), payadvice-paycover-cross-validation and swift-cross-field-msg-type-constraint (FSD/validation-gap-docs, same rule from legacy source) into this one statement. Re-read swiftMessages.ts, its unit tests, and both docx conversions; all agree exactly. CONFIRMED.

## Source Evidence
- src/domain/swiftMessages.ts lines 20-45 — ADV_REQUIRES_COVER_ADVICE=['MT103','PACS008'], COVER_REQUIRES_ADVICE=['MT202COV','PACS009COV'], validateSwiftCrossField throws BusinessValidationError('SWIFT_ADV_COV_MISMATCH', 'Credit leg[N] (accountNo=...): The Payment Advice Message should be MT103 or PACS008, while the Payment Cover Message is MT202COV or PACS009COV.')
- test/unit/domain/swiftMessages.test.ts — 'passes when a COV cover type is paired with an in-scope advice type'; 'throws BusinessValidationError SWIFT_ADV_COV_MISMATCH when the advice type is missing'; 'throws when the advice type is present but not in the required set'; 'does not throw when payCoverMsgType is not a COV-requiring type (e.g. plain MT202)'; 'does not throw when payCoverMsgType is absent entirely'; 'reports the correct index when a later leg in a multi-leg array violates the rule'
- analysis__Payment_Component_Calculation_Validation.docx.txt line 457 — Consolidated Validation Rule Table V4: 'payCoverMsgType in {MT202COV, PACS009COV} => payAdviceMsgType in {MT103, PACS008}' citing SSSS_PaymentCredit.js:344-400, 409 (recommended)
- analysis__PaymentComponent-Microservice-FSD-zh.docx.txt line 123 (§5.4) and lines 889-891 — same rule stated, '于建立腿位/确认时强制验证,违反时回传 409'

## Related Knowledge
- [[SWIFT Messaging and Vouchers]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
