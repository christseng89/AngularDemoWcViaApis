---
knowledge_id: ARCH-RULE-002
title: "previewClassification produces only the Settlement Account Entry stream — no Charge, Liability, or SWIFT streams — because RPFM has no traceable voucher-assembly path in source"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - architecture
  - confirmed
---

# ARCH-RULE-002 — previewClassification produces only the Settlement Account Entry stream — no Charge, Liability, or SWIFT streams — because RPFM has no traceable voucher-assembly path in source

## Status
CONFIRMED

## Business Rule
previewClassification (classifyPreview.ts) runs only §3 balance totals, §4 classification, and the §6.1 Settlement stream (the one stream that does not depend on a voucher-code prefix). It deliberately excludes Charge/Liability streams (removed from the service entirely, and would in any case need caller-supplied context this preview doesn't collect) and SWIFT messages (§7 needs enriched legs from Step 3, which this preview skips). The documented reason is that RPFM's 4 Confirm functions never call a Payment Component voucher-assembly routine — no 'RPFM##NULLNULLNULL' voucher-prefix pattern exists anywhere in the codebase — so running RPFM through the full confirmPaymentInstruction flow would fabricate a prefix that doesn't exist in source. It also never throws on imbalance (a live-preview design choice, distinct from the real Confirm's validateDrCrBalance).

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
n/a

## Verification Note
Directly re-read classifyPreview.ts in full; every clause of the statement (stream scope, RPFM rationale, never-throws behavior) is textually present in the doc comment and code. CONFIRMED unchanged.

## Source Evidence
- microservices/payment-component/src/domain/classifyPreview.ts full file read (57 lines): top doc comment states the RPFM/no-voucher-prefix rationale verbatim; the function body only imports/calls sumMonetaryAmounts, classify(), and buildSettlementEntries() — no voucherDescription/swiftMessages/enrichLegs imports at all; balanced is computed via difference.abs().lessThanOrEqualTo(toleranceAbs), never a throw

## Related Knowledge
- [[Payment Architecture]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
