---
knowledge_id: TEST-RULE-005
title: "Confirming the same Main Ref + Sequence twice returns the original unchanged result (idempotent replay), badged distinctly in the UI"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - testscenario
  - confirmed
---

# TEST-RULE-005 — Confirming the same Main Ref + Sequence twice returns the original unchanged result (idempotent replay), badged distinctly in the UI

## Status
CONFIRMED

## Business Rule
For PASS cases, the Confirm button issues a real dryRun:false POST that persists to the microservice's in-memory store. business-case-runner.component.ts defines a `replay: boolean` field on its DisplayResult interface, documented as: 'True when a Confirm click hit an existing (originModule, mainRef, sequence) — the server replayed the ORIGINAL result (FSD §6.1 idempotency), NOT a recompute of what's currently in the form. Shown explicitly so a replay is never mistaken for the edited data going unsaved/ignored.' It is set via `replay: !created` from the server's response. The template renders two visually distinct badges: a plain '✓ Confirmed' badge when `!result.replay`, and a separate '.replay-badge' variant reading '↺ Idempotent replay (HTTP 200) — this Main Ref + Sequence was already confirmed earlier. The server returned that original result unchanged, per FSD §6.1 — it did NOT recompute from what's currently in the form above. Change Main Ref or Sequence to confirm a new instruction.' when `result.replay` is true — so a replay showing old (possibly stale-looking) data does not read as a bug.

## Conditions
A Confirm click (dryRun:false) targets a (originModule, mainRef, sequence) natural key that was already confirmed previously.

## Result
The server returns the ORIGINAL persisted result unchanged (HTTP 200, not 201); the UI shows the distinct replay-badge instead of the ordinary confirmed-badge.

## Example
business-case-runner.component.html:145-147 renders `<div class="confirmed-badge" *ngIf="result?.confirmed && !result?.replay">✓ Confirmed...</div>` and `<div class="confirmed-badge replay-badge" *ngIf="result?.confirmed && result?.replay">↺ Idempotent replay (HTTP 200)...</div>`.

## Verification Note
Upgraded from doc-only citation to direct code verification: read business-case-runner.component.ts's DisplayResult interface and confirm-handling logic, and business-case-runner.component.html's badge markup, both of which match the claim exactly, including the specific HTTP 200 vs 201 framing and the FSD §6.1 citation embedded in the UI copy itself. No changes needed.

## Source Evidence
- src/app/payment-component/business-case-runner.component.ts:26-35 (DisplayResult.replay field + doc comment)
- business-case-runner.component.ts:689 (`replay: !created`)
- business-case-runner.component.html:145-147 (the two distinct badge elements, confirmed via direct file read)
- docs__LC-Payment-WC-User-Manual-en.docx.txt §6.3 (original candidate's cited corroborating doc source)

## Related Knowledge
- [[Testing Methodology and Coverage]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
