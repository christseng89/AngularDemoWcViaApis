---
knowledge_id: SUSPENSE-RULE-021
title: "Suspense bridge legs are always credit-direction regardless of source bucket (documentation-layer restatement of the code-verified rule above)"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - suspense
  - confirmed
---

# SUSPENSE-RULE-021 — Suspense bridge legs are always credit-direction regardless of source bucket (documentation-layer restatement of the code-verified rule above)

## Status
CONFIRMED

## Business Rule
Whether a suspense entry comes from suspenseBridge.debitEntries or .creditEntries, the leg it generates always lands on the CREDIT side of the instruction — documented consistently across the microservice README, the root CLAUDE.md's Extended usage scenarios section, and the standalone Payment-Component-Suspense-FX-Test-Cases-zh.md. This is what keeps the instruction balanced with no further caller-side logic; a debit-direction suspense-funded transaction (e.g. IBL/EBL Takedown disbursement) CANNOT use suspenseBridge and must instead submit a real accountType:'SUSPENSE' leg.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
n/a

## Verification Note
This is a documentation-layer duplicate of the code-verified 'suspense-leg-always-credit' rule above (same underlying fact, different evidence tier — docs rather than source+tests). Kept as a separate entry per the task's per-candidate reporting requirement, but noted here as effectively the same rule restated at the documentation layer; both are consistent with each other and with the code. Verified all three cited quotes exist verbatim at the cited locations. Status unchanged: CONFIRMED. NOTE: the README passage read in context (lines 139-179) is itself describing v1.7.0/v1.7.1's superseded 'Net_C'/'Combined_C' mechanism, which is stale relative to the current v1.8.0/v1.9.0 code in suspenseBridge.ts — see gaps_found.

## Source Evidence
- microservices/payment-component/README.md lines 152-169 ('always credit-direction (this is v1.7.1's correction...)')
- CLAUDE.md line 408 ('Dr Legs (Suspense) must be a REAL accountType: SUSPENSE leg, never suspenseBridge-generated, since bridge legs are always credit-direction')
- Payment-Component-Suspense-FX-Test-Cases-zh.md line 86 ('suspenseBridge 產生的 leg 不分來源，一律是 credit 方向')

## Related Knowledge
- [[Suspense Account]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
