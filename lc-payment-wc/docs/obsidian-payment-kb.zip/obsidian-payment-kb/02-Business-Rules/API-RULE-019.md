---
knowledge_id: API-RULE-019
title: "IWGT Settle Inward Claim's Liability Voucher condition (method of issuance) has no representation in the OAS request schema"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - api
  - confirmed
---

# API-RULE-019 — IWGT Settle Inward Claim's Liability Voucher condition (method of issuance) has no representation in the OAS request schema

## Status
CONFIRMED

## Business Rule
Whether IWGT Settle Inward Claim produces a Liability Voucher entry depends on MTHD_OF_ISS ('Issue' vs. Advice-received) — a field absent from PaymentInstructionConfirmRequest and PaymentLegInput entirely (confirmed: requestSchema.ts's paymentLegInputSchema and paymentInstructionConfirmRequestSchema have no such field). Either the calling module must decide server-side whether to omit the liability-stream expectation for non-Issue guarantees, or a new input field is needed. Note this is now somewhat moot in one sense — v1.6.0 removed all Liability Voucher generation from this service entirely — but the gap as originally documented (in the calculation-validation doc, describing the pre-v1.6.0/conceptual legacy behavior) is accurately characterized.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Open item, not resolved in this document

## Example
No worked numeric example available in the source evidence reviewed.

## Verification Note
Re-read the calculation-validation doc §6.3.5/§12.4 directly and cross-checked against requestSchema.ts's actual field list — confirmed no such field exists. Worth flagging (see gaps_found) that this is a legacy-behavior gap description, now superseded in relevance by the v1.6.0 removal of Liability Voucher generation altogether, but the rule as stated is still accurate to what the source document says. No change to status.

## Source Evidence
- converted/analysis__Payment_Component_Calculation_Validation.docx.txt §6.3.5 (lines 198-201, IF MTHD_OF_ISS == 'Issue' branch) and §12.4 (line 332): 'whether IWGT Settle Inward Claim produces a Liability Voucher entry depends on MTHD_OF_ISS ("Issue" vs. Advice-received) — a field not present anywhere in PaymentInstructionConfirmRequest or PaymentLegInput'
- microservices/payment-component/src/validation/requestSchema.ts: paymentLegInputSchema (lines 45-61) and paymentInstructionConfirmRequestSchema (82-109) — confirmed no MTHD_OF_ISS-equivalent field exists anywhere in the schema

## Related Knowledge
- [[Payment Instructions API]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
