---
knowledge_id: VALIDATION-RULE-015
title: "M-1: strictly negative caller-submitted amounts are rejected; direction is expressed only by Dr/Cr side, never sign"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - validation
  - confirmed
---

# VALIDATION-RULE-015 — M-1: strictly negative caller-submitted amounts are rejected; direction is expressed only by Dr/Cr side, never sign

## Status
CONFIRMED

## Business Rule
Every caller-submitted monetary amount (debitLegs[].amountTxCcy/amountAccountCcy, creditLegs[] equivalents, suspenseBridge debit/credit entry amounts) must be >= 0 (checkNonNegative, using money.ts's isNegativeAmount). A negative value is rejected with a message stating direction is set by the Dr/Cr side, not sign — preventing a leg from 'balancing' V8 via numeric cancellation. The one legitimate ledger negative-swap concept (FX Exchange Dr/Cr side-swap) is never expressed as a caller-submitted negative; the server generates that pair on the opposite side with a POSITIVE amount AFTER this validation runs. Merges 3 near-duplicate id_hints (m1-negative-amounts-rejected from validation-gap-docs, negative-amount-rejection-m1 from fsd-architecture-docs) describing the identical rule.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
amountTxCcy: '-100' -> 400 'amount "-100" is negative; ... must be >= 0'. amountTxCcy: '-0.00' -> accepted (treated as zero).

## Verification Note
Confirmed by direct read of requestSchema.ts and money.ts, cross-checked against both FSD docs, all in exact agreement. Merged two duplicate FSD-doc entries describing the identical M-1 rule.

## Source Evidence
- microservices/payment-component/src/validation/requestSchema.ts lines 149-165 (checkNonNegative and its M-1 comment block), lines 187-201 (applied to every leg and Suspense entry)
- microservices/payment-component/src/money.ts lines 146-159 (isNegativeAmount)
- test/unit/validation/requestSchema.test.ts describe 'negative amount rejection (M-1)': rejects negative amountTxCcy, negative amountAccountCcy, negative Suspense debit/credit entry amount; 'accepts zero and "-0"/"-0.00" (which are zero, not negative)'
- analysis__Payment_Component_Calculation_Validation.docx.txt 'Spec Sync — 2026-08 Hardening Review' M-1 (line 377)
- analysis__Payment-OAS-FSD-en.docx.txt Appendix B, M-1 (line 136)

## Related Knowledge
- [[Request Validation]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
