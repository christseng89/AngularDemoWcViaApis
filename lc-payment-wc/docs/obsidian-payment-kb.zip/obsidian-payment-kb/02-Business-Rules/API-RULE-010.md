---
knowledge_id: API-RULE-010
title: "runPreview() always calls the API with dryRun:true; the explicit Confirm button click always calls with dryRun:false (persists) — the same endpoint serves both, distinguished only by this request-body flag"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - api
  - confirmed
---

# API-RULE-010 — runPreview() always calls the API with dryRun:true; the explicit Confirm button click always calls with dryRun:false (persists) — the same endpoint serves both, distinguished only by this request-body flag

## Status
CONFIRMED

## Business Rule
business-case-runner.component.ts's runPreview() PASS branch calls this.api.confirm(request, true) (line 749); onConfirm() calls this.api.confirm(request, false) (line 680). The Confirm button label explicitly states '(persists — real POST, dryRun:false)'. PaymentComponentApiService.confirm(request, dryRun) always POSTs to the same /payment-instructions endpoint, merging {...request, dryRun} into the body — dryRun:true is documented as safe to call on every keystroke and never persisted; dryRun:false performs the real, persisted Confirm.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
confirm(minimalRequest, true) POSTs {...minimalRequest, dryRun: true}.

## Verification Note
Merged two near-duplicate candidate rules ('confirm-always-persists-preview-always-dryrun' from angular-runner and 'confirm-dryrun-vs-real-confirm' from angular-services) into one, since they describe the same fact from two ends (component call sites vs. service implementation) with no meaningful difference. Re-read business-case-runner.component.ts (lines 663-680, 702-750), its .html template, and payment-component-api.service.ts directly; all citations confirmed exactly, including line numbers and literal text. No change to status.

## Source Evidence
- src/app/payment-component/business-case-runner.component.ts: onConfirm() `this.api.confirm(request, false)` (line 680); runPreview() `this.api.confirm(request, true)` (line 749)
- src/app/payment-component/business-case-runner.component.html: 'Confirm (persists — real POST, dryRun:false)' (line 123)
- src/app/payment-component/payment-component-api.service.ts: confirm() doc comment (lines 40-44) and implementation (45-52), merging `{...request, dryRun}`

## Related Knowledge
- [[Payment Instructions API]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
