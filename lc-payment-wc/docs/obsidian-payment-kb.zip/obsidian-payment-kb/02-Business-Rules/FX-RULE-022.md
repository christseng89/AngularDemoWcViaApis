---
knowledge_id: FX-RULE-022
title: "Client-computed FX Conversion Pair closes the per-currency (V8) balance gap left by a single mismatched-currency leg"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - fx
  - confirmed
---

# FX-RULE-022 — Client-computed FX Conversion Pair closes the per-currency (V8) balance gap left by a single mismatched-currency leg

## Status
CONFIRMED

## Business Rule
For each row whose currency differs from the transaction currency (and pct>0), the fxPairs getter produces TWO entries: a same-native-direction 'Trx Ccy site' entry (amount=amountTxCcy, currency=transactionCurrency) and an opposite-direction 'Other Ccy site' entry (amount=accountCcyAmount(row), currency=row.currency, carrying the row's rate). Together they net to zero in both currencies.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
DEBIT side, USD transaction, EUR row (amountTxCcy 100 USD-equivalent, rate 1.1): pair 1 = D 'FX Exchange EUR' 100 USD; pair 2 = C 'FX Exchange USD' accountCcyAmount(row) EUR, rate 1.1 shown.

## Verification Note
Confirmed by reading the fxPairs getter in full: nativeDrCr/oppositeDrCr direction logic, the two pushed entries (Trx Ccy site using amountTxCcy, Other Ccy site using accountCcyAmount(row) with rate), and the pct<=0/needsRate skip condition all match exactly. No status change.

## Source Evidence
- leg-allocator.component.ts fxPairs getter, lines 598-635 (read in full)

## Related Knowledge
- [[FX Processing]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
