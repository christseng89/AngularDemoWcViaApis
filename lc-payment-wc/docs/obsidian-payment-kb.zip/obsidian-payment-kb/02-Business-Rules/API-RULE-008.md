---
knowledge_id: API-RULE-008
title: "dryRun=true always recomputes fresh and never touches the persistence store, even when reusing the same natural key across multiple dryRun calls"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - api
  - confirmed
---

# API-RULE-008 — dryRun=true always recomputes fresh and never touches the persistence store, even when reusing the same natural key across multiple dryRun calls

## Status
CONFIRMED

## Business Rule
The live-preview mode (dryRun:true) always returns 200 (never 201), always recomputes from the submitted amounts (no idempotency caching — two dryRun calls with the same key but different amounts return different, correctly-recomputed amounts), and issues a distinct instructionId on every call. A genuine (non-dryRun) POST using the same natural key afterward still returns 201, proving no prior dryRun call was persisted or reserved the key.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
dryRun call 1: amountTxCcy=100.00 -> response '100.00'. dryRun call 2, same mainRef/sequence, amountTxCcy=250.00 -> response '250.00' (not cached at 100.00). Subsequent dryRun:false POST with same key -> 201.

## Verification Note
Re-read the regression.ts test block directly; all four cited assertions confirmed verbatim. Also now backed by the confirmPaymentInstruction.ts source mechanism directly read (see dryrun-preview-never-persists entry). No change to status.

## Source Evidence
- microservices/payment-component/test/regression.ts runHttpSmokeTest() dryRun block (lines ~182-230): 'dryRun POST returns 200 (never 201)' (202), 'second dryRun ... is NOT cached — recomputes fresh' (215), 'dryRun calls get distinct instructionIds' (219), 'a real (non-dryRun) POST with the same natural key after N dryRuns still returns 201' (227)
- microservices/payment-component/src/domain/confirmPaymentInstruction.ts: dryRun skips both idempotency lookup (line 116) and store.save (lines 215-219) — the mechanism underlying this observable behavior

## Related Knowledge
- [[Payment Instructions API]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
