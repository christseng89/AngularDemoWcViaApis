---
knowledge_id: VALIDATION-RULE-002
title: "dryRun mode skips idempotency lookup and persistence; every dryRun call recomputes fresh"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - validation
  - confirmed
---

# VALIDATION-RULE-002 — dryRun mode skips idempotency lookup and persistence; every dryRun call recomputes fresh

## Status
CONFIRMED

## Business Rule
When ConfirmPaymentInstructionOptions.dryRun is true, Step 0 (idempotency lookup) is skipped entirely (the `if (!options.dryRun)` guard) and store.save is never called (the `if (options.dryRun) return {...}` short-circuit before the save line) — every dryRun call runs Steps 1-5 fresh against current input, returns created:false, and is never persisted. A later real (non-dryRun) confirm using the same natural key still creates for real.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
Two dryRun calls with amountTxCcy 100 then 200 return distinct instructionIds and neither persists (store.find('IPLC','REF-1',1) is undefined); a subsequent real confirm() creates and persists normally.

## Verification Note
Confirmed exactly as stated by direct read of the two short-circuit lines and their surrounding doc comment.

## Source Evidence
- microservices/payment-component/src/domain/confirmPaymentInstruction.ts lines 85-94 (doc comment), lines 116, 215-217 (the two short-circuits)
- test/unit/domain/confirmPaymentInstruction.test.ts describe('dryRun'): 'recomputes fresh on every call and is never persisted', 'a real (non-dryRun) confirm after N dryRuns still creates for real'

## Related Knowledge
- [[Request Validation]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
