---
knowledge_id: ARCH-RULE-005
title: "buildSettlementEntries accepts a raw PaymentLegInput (accountDesc optional) so it can be reused for RPFM classify-only preview"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - architecture
  - confirmed
---

# ARCH-RULE-005 — buildSettlementEntries accepts a raw PaymentLegInput (accountDesc optional) so it can be reused for RPFM classify-only preview

## Status
CONFIRMED

## Business Rule
The function is typed to accept legs without accountDesc so it can be reused by classifyPreview.ts for RPFM, which never runs the Step 3 voucher-description assembly (needs a {MODULE}{FuncCode} prefix not present in source for RPFM). When accountDesc is absent, a placeholder string explicitly stating no voucher-code prefix exists is substituted rather than a fabricated description.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
No worked numeric example available in the source evidence reviewed.

## Verification Note
Directly re-read accountEntries.ts in full (115 lines). Statement and constant text match exactly. CONFIRMED unchanged.

## Source Evidence
- microservices/payment-component/src/domain/accountEntries.ts line 22: `const NO_VOUCHER_PREFIX_DESC = '(no Payment Component voucher code prefix exists in source for this module/function — description omitted, not fabricated)';`
- same file lines 55-77 doc comment on buildSettlementEntries explaining the RPFM/classifyPreview reuse rationale; line 103-ish: `leg.accountDesc ?? NO_VOUCHER_PREFIX_DESC`

## Related Knowledge
- [[Payment Architecture]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
