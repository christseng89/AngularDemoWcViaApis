---
knowledge_id: VALIDATION-RULE-042
title: "transactionCurrency must be sent explicitly; falling back to debitLegs[0].currency misclassifies when leg 0 is foreign"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - validation
  - confirmed
---

# VALIDATION-RULE-042 — transactionCurrency must be sent explicitly; falling back to debitLegs[0].currency misclassifies when leg 0 is foreign

## Status
CONFIRMED

## Business Rule
Pre-v1.10.0 the server inferred transaction currency from debitLegs[0].currency. This silently breaks when a side's legs are ALL in a currency other than the true transaction currency. v1.10.0 adds explicit request.transactionCurrency, falling back to debitLegs[0].currency only when omitted (confirmed directly in confirmPaymentInstruction.ts line 151: `request.transactionCurrency ?? request.debitLegs[0]!.currency`, and requestSchema.ts line 172 for the H-2 check's own resolution).

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
Debit Legs[0] = EUR 216.62; without explicit transactionCurrency='USD', server misreads transaction ccy as EUR and 400s the correctly-formatted USD amounts elsewhere in the request.

## Verification Note
Confirmed by direct read of both the exact fallback lines in confirmPaymentInstruction.ts and requestSchema.ts — matches the CLAUDE.md and test-case doc's description precisely.

## Source Evidence
- microservices/payment-component/src/domain/confirmPaymentInstruction.ts line 151 (the ?? fallback, with its surrounding doc comment)
- microservices/payment-component/src/validation/requestSchema.ts line 172 (identical fallback pattern for the H-2 scale check)
- CLAUDE.md 'transactionCurrency — explicit wire field' v1.10.0 section, full pay-in-JPY regression example
- Payment-Component-Suspense-FX-Test-Cases-zh.md: 'transactionCurrency 一定要明確帶 USD。Debit Legs 第一筆剛好是 EUR，如果不明確帶這個欄位，service 會退回用 debitLegs[0].currency 當交易幣別，誤判成 EUR'

## Related Knowledge
- [[Request Validation]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
