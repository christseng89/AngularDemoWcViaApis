---
knowledge_id: VALIDATION-RULE-031
title: "Server refuses to start if any currency in the currency master lacks a TWD FX rate in either direction"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - validation
  - confirmed
---

# VALIDATION-RULE-031 — Server refuses to start if any currency in the currency master lacks a TWD FX rate in either direction

## Status
CONFIRMED

## Business Rule
At module load time, the server iterates every currency in CURRENCIES (except TWD) and throws a fatal startup error if neither `{code}/TWD` nor `TWD/{code}` exists as a key in RATES — a fail-fast guard against the currency dropdown offering a currency the FX calculators can't rate.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
n/a — startup guard, no runtime failure example applicable.

## Verification Note
Confirmed exactly by direct read of backend/server.js lines 26-33.

## Source Evidence
- backend/server.js lines 26-33 (the guard loop and its throw, with the exact comment 'ensure all currency being used has an exchange rate captured')

## Related Knowledge
- [[Request Validation]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
