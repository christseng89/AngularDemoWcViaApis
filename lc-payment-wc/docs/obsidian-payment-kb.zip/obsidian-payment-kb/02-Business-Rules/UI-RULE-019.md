---
knowledge_id: UI-RULE-019
title: "A newly-added Suspense entry row's currency is one-time-seeded from defaultCurrency, never retroactively applied to existing rows"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - ui
  - confirmed
---

# UI-RULE-019 — A newly-added Suspense entry row's currency is one-time-seeded from defaultCurrency, never retroactively applied to existing rows

## Status
CONFIRMED

## Business Rule
addRow() sets a new row's currency to whatever @Input() defaultCurrency currently holds (the parent passes the running transactionCurrency), purely as a starting value the user can still change per row. If defaultCurrency changes afterward, previously-added rows keep whatever currency they already have; they are never rewritten.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
n/a

## Verification Note
Confirmed exactly against source: addRow is the only place defaultCurrency is read, and there is no ngOnChanges or subscription that would retroactively update existing rows.

## Source Evidence
- suspense-entries.component.ts line 52 (doc comment), addRow() lines 67-71: `{ id: rowIdCounter, amount: '', currency: this.defaultCurrency, sourceComponent: 'CHARGE' }` — only fires on addRow, no watcher/effect on defaultCurrency changes

## Related Knowledge
- [[Payment Component Simulator UI]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
