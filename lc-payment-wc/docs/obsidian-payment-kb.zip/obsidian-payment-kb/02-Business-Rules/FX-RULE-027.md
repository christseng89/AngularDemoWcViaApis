---
knowledge_id: FX-RULE-027
title: "Every currency offered in the Currency dropdown is guaranteed to have an FX rate"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - fx
  - confirmed
---

# FX-RULE-027 — Every currency offered in the Currency dropdown is guaranteed to have an FX rate

## Status
CONFIRMED

## Business Rule
CurrencyService.codes()/options() sources its list from GET /api/currencies, and the demo backend asserts at startup that every currency in currencies.json is also present in fx-rates.json.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
No worked numeric example available in the source evidence reviewed.

## Verification Note
Confirmed both sides directly: currency.service.ts's doc comment states the guarantee, and server.js's startup loop (`for (const c of CURRENCIES) { if (!(...) && !(...)) throw ... }`) independently enforces it. No status change.

## Source Evidence
- currency.service.ts doc comment lines 24-28
- backend/server.js lines 26-34 (startup guard, throws if a currency has no TWD rate)

## Related Knowledge
- [[FX Processing]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
