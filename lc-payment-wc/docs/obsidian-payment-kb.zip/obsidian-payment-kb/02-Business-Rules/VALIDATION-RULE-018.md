---
knowledge_id: VALIDATION-RULE-018
title: "Every PASS case resolves its voucher prefix through exactly one of two mutually-exclusive mechanisms"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - validation
  - confirmed
---

# VALIDATION-RULE-018 — Every PASS case resolves its voucher prefix through exactly one of two mutually-exclusive mechanisms

## Status
CONFIRMED

## Business Rule
Every PASS BusinessCaseConfig supplies either a fixed sourceFunctionCode or a dualPrefixOptions list (never neither), and buildConfirmRequest branches on config.dualPrefixOptions to decide which of the two supplies the actual wire value, always leaving the other undefined.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
For a plain PASS case (no dualPrefixOptions), sourceFunctionCode='PayAccept' is sent and voucherCodePrefixOverride is undefined; for a dual-prefix case, the reverse.

## Verification Note
Confirmed by direct read of business-case-request.ts lines 19-32 — the exact ternary pair is present verbatim.

## Source Evidence
- src/app/payment-component/business-case-request.ts lines 30-31 (the exact ternary: `sourceFunctionCode: config.dualPrefixOptions ? undefined : config.sourceFunctionCode, voucherCodePrefixOverride: config.dualPrefixOptions ? model['voucherPrefix'] : undefined`)
- business-case-registry.spec.ts 'every PASS case can resolve a voucher prefix — sourceFunctionCode xor dualPrefixOptions'

## Related Knowledge
- [[Request Validation]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
