---
knowledge_id: ARCH-RULE-025
title: "OAS info.version (1.10.1) does not reflect all documented changes — self-acknowledged staleness"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - architecture
  - confirmed
---

# ARCH-RULE-025 — OAS info.version (1.10.1) does not reflect all documented changes — self-acknowledged staleness

## Status
CONFIRMED

## Business Rule
Both OAS files declare version 1.10.1 in info.version, but payment-instructions-post.yaml's own SwiftMessage schema references a 'v-H3' change not mentioned in either file's top-level changelog narrative (which stops narrating at v1.10.1). This confirms the OAS documented version number under-counts at least one real schema change (the H-3 SwiftMessage settlement/instructed currency split).

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
No worked numeric example available in the source evidence reviewed.

## Verification Note
Confirmed directly — both OAS files' info.version and the v-H3 SwiftMessage field annotations were read and match the statement exactly.

## Source Evidence
- analysis/Payment_component.yaml line 180: `version: "1.10.1"`
- analysis/payment-instructions-post.yaml line 326: `version: "1.10.1"`; lines 922-923, directly re-read: instructedCurrency/instructedAmount fields both say 'Added v-H3 ... No longer forced equal to 32A (H-3)' with no corresponding top-level changelog bump

## Related Knowledge
- [[Payment Architecture]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
