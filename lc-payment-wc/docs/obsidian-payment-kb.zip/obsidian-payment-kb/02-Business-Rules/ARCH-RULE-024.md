---
knowledge_id: ARCH-RULE-024
title: "Current OAS idempotency key model has NOT yet been migrated to the confirmed structured Reference/Event design"
domain: Payment
category: Business Rule
status: CONFLICT
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - architecture
  - conflict
---

# ARCH-RULE-024 — Current OAS idempotency key model has NOT yet been migrated to the confirmed structured Reference/Event design

## Status
CONFLICT

## Business Rule
Both OAS files still model the idempotency key as flat (originModule, mainRef, sequence: integer) fields on PaymentInstructionConfirmRequest, with sequence typed as a plain integer. This conflicts with the CLAUDE.md-recorded, reviewer-confirmed decision (D-1 through D-8, RDD-oas-reference-event-model.md) that the real business key should be (originModule, bankContractRef, eventSeq) with eventSeq/edition as string+pattern codes (not integers), mainRef/sequence retained only as derived legacy aliases. The OAS files show NO trace of the new transactionReference/event block, customerRef, or edition fields — the decision is confirmed but plainly not yet implemented in these contracts.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
No worked numeric example available in the source evidence reviewed.

## Conflict Note
> [!warning] Sources disagree
> Re-read both OAS files' sequence field definitions directly and confirmed neither has been updated — both still `type: integer` with the same description text word-for-word in both files. CONFIRMED as a genuine, still-open CONFLICT between current-state and planned-state documentation (this is a legitimate CONFLICT status, not a defect to resolve — it correctly flags that the decision is recorded but unimplemented).

## Verification Note
Re-read both OAS files' sequence field definitions directly and confirmed neither has been updated — both still `type: integer` with the same description text word-for-word in both files. CONFIRMED as a genuine, still-open CONFLICT between current-state and planned-state documentation (this is a legitimate CONFLICT status, not a defect to resolve — it correctly flags that the decision is recorded but unimplemented).

## Source Evidence
- analysis/Payment_component.yaml lines 465-477 (PaymentInstructionConfirmRequest.sequence: `type: integer`, required) and line 675 (PaymentInstruction.sequence), directly re-read
- analysis/payment-instructions-post.yaml lines 475-486 (identical sequence:integer field), directly re-read
- CLAUDE.md 'Confirmed Requirement — OAS structured Reference / Event model' section (provided in this task's own context), decisions D-1..D-8, and expert-review.md's own 'Agreed idempotency-field design' subsection (lines ~68-83) restating the same planned design

## Related Knowledge
- [[Payment Architecture]]
- [[Business-Rule-Index]]
- [[Knowledge-Gaps]]
- [[Payment-Traceability-Matrix]]
