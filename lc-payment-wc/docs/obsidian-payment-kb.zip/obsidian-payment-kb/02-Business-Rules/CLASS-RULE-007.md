---
knowledge_id: CLASS-RULE-007
title: "accountCategory (CUSTOMER / NOSTRO_FAMILY / INTERNAL_SUSPENSE) is a UI-behavior grouping only — never used for leg classification or gating Account Entry generation"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - classification
  - confirmed
---

# CLASS-RULE-007 — accountCategory (CUSTOMER / NOSTRO_FAMILY / INTERNAL_SUSPENSE) is a UI-behavior grouping only — never used for leg classification or gating Account Entry generation

## Status
CONFIRMED

## Business Rule
accountCategoryFor maps CUSTOMER→CUSTOMER, {NOSTRO,VOSTRO}→NOSTRO_FAMILY, {SUSPENSE,INTERNAL}→INTERNAL_SUSPENSE. Per the FSD this is explicitly a readOnly OAS field used only for UI-behavior bucketing, and is never consulted for the separate §4 classification logic or the §6 Account Entry generation gate. An RTGS-flagged NOSTRO leg categorizes identically to a plain NOSTRO leg (both NOSTRO_FAMILY) — the rtgsIndicator distinction that DOES affect the voucher TypeChar (accountDescFor) does NOT affect accountCategory. Merges with candidates 31 and 36 (OAS/FSD statements of the same rule).

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
No worked numeric example available in the source evidence reviewed.

## Verification Note
Read voucherDescription.ts directly — accountCategoryFor implementation and doc comment match exactly. Also confirmed the OAS yaml and zh FSD §6.4 both state this grouping is UI-only and superseded an earlier draft that used it for classification. Merged candidates 31 (api-contracts) and 36 (fsd-architecture-docs) into this entry as duplicates.

## Source Evidence
- microservices/payment-component/src/domain/voucherDescription.ts lines 90-109 (doc comment above accountCategoryFor, and the function itself)
- test/unit/domain/voucherDescription.test.ts 'maps CUSTOMER to CUSTOMER', 'maps NOSTRO and VOSTRO to NOSTRO_FAMILY', 'maps SUSPENSE and INTERNAL to INTERNAL_SUSPENSE'
- analysis/Payment_component.yaml AccountCategory schema lines 426-436
- converted/analysis__PaymentComponent-Microservice-FSD-zh.docx.txt §6.4 lines 143-145 '關於 AccountCategory 的說明'

## Related Knowledge
- [[Payment Instruction Classification]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
