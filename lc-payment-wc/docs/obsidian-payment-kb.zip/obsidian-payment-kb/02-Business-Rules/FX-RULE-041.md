---
knowledge_id: FX-RULE-041
title: "A foreign-currency CUSTOMER leg on a side uses existing amountAccountCcy/drRate fields and never triggers the suspenseBridge FX Exchange mechanism — but must still respect that currency's own minor-unit scale (H-2)"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - fx
  - confirmed
---

# FX-RULE-041 — A foreign-currency CUSTOMER leg on a side uses existing amountAccountCcy/drRate fields and never triggers the suspenseBridge FX Exchange mechanism — but must still respect that currency's own minor-unit scale (H-2)

## Status
CONFIRMED

## Business Rule
A foreign-currency CUSTOMER leg (e.g. margin held in EUR while the transaction currency is USD) uses fields the wire contract already supports (amountAccountCcy, drRate/crBuyRate) and does not itself trigger the suspenseBridge FX Exchange pair mechanism, which only fires for bridge-generated (Suspense) legs. Aggregate V8 balance is checked on amountTxCcy only. The caveat: every non-USD account leg must still resolve to a minorUnitsForCurrency-correct scale.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
Sub Use Case 1b: CUST-EUR-ACC EUR 4,616.48 = USD 5,000.00 equivalent @ drRate 0.923295; V8 balances on the USD 5,000.00 amountTxCcy figure.

## Verification Note
Confirmed the proposal-doc text exactly as cited, and independently corroborated the structural claim ('does not trigger the suspenseBridge FX Exchange mechanism') against the actual expandSuspenseBridge code already read in full — a plain CUSTOMER leg with no corresponding SuspenseEntry never enters buildFxPair. However, this rule's evidence is entirely from a PROPOSED use-cases document, not from any executed test or actual registry business case — CLAUDE.md itself confirms these use cases are 'NOT yet in the business-case-registry'. No status change (CONFIRMED as a documented, code-consistent claim), but flagged in gaps_found that no live test actually exercises this end-to-end.

## Source Evidence
- PaymentComponentProposedUseCases-EN.docx.txt Sub Use Case 1b (lines 39-45) and the 'Cross-cutting Open Questions Summary' item (line 176)
- suspenseBridge.ts's code structure (a caller-submitted CUSTOMER leg is never itself passed through buildFxPair — only Suspense buckets and their matching legs are — already confirmed by the full expandSuspenseBridge read above)

## Related Knowledge
- [[FX Processing]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
