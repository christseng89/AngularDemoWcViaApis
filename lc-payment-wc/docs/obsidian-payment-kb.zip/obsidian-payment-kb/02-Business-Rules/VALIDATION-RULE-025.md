---
knowledge_id: VALIDATION-RULE-025
title: "A side is only 'valid' when every emitted leg has a non-empty Account No. and a positive amount, and the side is not over-allocated"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - validation
  - confirmed
---

# VALIDATION-RULE-025 — A side is only 'valid' when every emitted leg has a non-empty Account No. and a positive amount, and the side is not over-allocated

## Status
CONFIRMED

## Business Rule
emit()'s validChange output is true only when: at least one leg is emitted, isOverAllocated is false, and every emitted leg has accountNo.trim().length > 0 and Number(amountTxCcy) > 0. isOverAllocated fires when totalPct exceeds 100.001 (a small epsilon above 100). Emitted alongside legsChange/scaleErrorsChange so business-case-runner can gate its own preview calls.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
n/a — gating logic, verified via cited spec tests.

## Verification Note
Confirmed exactly by direct read of both the validChange emit line and the isOverAllocated getter.

## Source Evidence
- src/app/payment-component/leg-allocator.component.ts line 1291-1293 (validChange emit logic — legs.length > 0 && !isOverAllocated && legs.every(accountNo/amount check))
- leg-allocator.component.ts lines 370-376 (isOverAllocated getter: `this.totalPct > 100.001`)
- leg-allocator.component.spec.ts 'validChange' describe block: false on missing account no, false when over-allocated, true for a fully-allocated single row

## Related Knowledge
- [[Request Validation]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
