---
knowledge_id: CHARGE-RULE-007
title: "LC issuance and confirming commissions are both calculated on 'LC Balance' = LC Amount × (1 + Tolerance%), not on the bare LC Amount"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - charges
  - confirmed
---

# CHARGE-RULE-007 — LC issuance and confirming commissions are both calculated on 'LC Balance' = LC Amount × (1 + Tolerance%), not on the bare LC Amount

## Status
CONFIRMED

## Business Rule
Both A1 (Import LC Issue) and B2 (Export LC Confirmed) independently compute the same 'LC Balance' concept — LC Amount inflated by the documentary-credit tolerance percentage — and use that inflated figure as the commission base, reflecting that UCP-style tolerance headroom is itself part of the bank's fee-bearing exposure.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
A1: lcBalance = round(lcAmount * (1 + tolerancePct/100), dp(lcCurrency)); rawCommTwd = round(lcBalance * r * (commRate/100), 0). B2: lcBalance = round(lcAmount * (1 + tolerancePct/100), dp(lcCurrency)); rawTwd = round(lcBalance * r * (confRate/100) * quarters, 0).

## Verification Note
Re-verified both code blocks line-by-line; formulas match exactly as claimed, both independently re-deriving the same lcBalance expression. Kept distinct from the merged rule above (that one is scoped to B2's quarter-ceiling+minimum specifically; this one is the cross-product LC-Balance-as-base insight spanning A1 and B2). No change to status.

## Source Evidence
- backend/server.js lines 124-128 (A1: lcBalance computation and rawCommTwd)
- backend/server.js lines 519-523 (B2: identical lcBalance computation, then multiplied by quarters)

## Related Knowledge
- [[Charge Integration]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
