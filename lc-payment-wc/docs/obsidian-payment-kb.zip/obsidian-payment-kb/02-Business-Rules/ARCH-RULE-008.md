---
knowledge_id: ARCH-RULE-008
title: "The FX pair generation strategy evolved through three iterations (v1.7.0/1 combined-pair -> v1.8.0 per-source independent pairs -> v1.9.0 DEBIT-side netting), each fixing a specific rounding/decorative-line defect the prior approach had"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - architecture
  - confirmed
---

# ARCH-RULE-008 — The FX pair generation strategy evolved through three iterations (v1.7.0/1 combined-pair -> v1.8.0 per-source independent pairs -> v1.9.0 DEBIT-side netting), each fixing a specific rounding/decorative-line defect the prior approach had

## Status
CONFIRMED

## Business Rule
v1.7.0/v1.7.1 combined a bucket's Suspense + real-leg magnitudes into ONE FX pair, re-converted once — not guaranteed to balance BY CURRENCY when the caller's own already-rounded leg amount disagreed by a minor unit from a fresh reconversion. v1.8.0 replaced this with up to TWO independent pairs per bucket (one Suspense-sourced, one leg-sourced), each reusing an already-rounded figure verbatim — fixed the per-currency balance problem but produced decorative/redundant FX lines when a same-currency real leg already exactly funded the Suspense entry. v1.9.0 added netting for the DEBIT side only, collapsing the two pairs into at most one, sized to the residual.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
No worked numeric example available in the source evidence reviewed.

## Verification Note
Read the entire top-of-file doc comment directly; every clause of the 3-iteration history is present verbatim. CONFIRMED unchanged.

## Source Evidence
- microservices/payment-component/src/domain/suspenseBridge.ts top doc comment, lines ~1-77, directly re-read in full: contains the complete v1.7.0/1 -> v1.8.0 -> v1.9.0 narrative exactly as stated, including the algebraic justification for why netting is safe only on the debitEntries side

## Related Knowledge
- [[Payment Architecture]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
