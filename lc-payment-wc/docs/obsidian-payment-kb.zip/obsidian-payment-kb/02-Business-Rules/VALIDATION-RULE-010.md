---
knowledge_id: VALIDATION-RULE-010
title: "knownMinorUnitsForCurrency distinguishes a genuinely-known currency scale from an unknown one, to avoid wrongly rejecting/accepting over-precise amounts"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - validation
  - confirmed
---

# VALIDATION-RULE-010 — knownMinorUnitsForCurrency distinguishes a genuinely-known currency scale from an unknown one, to avoid wrongly rejecting/accepting over-precise amounts

## Status
CONFIRMED

## Business Rule
Unlike minorUnitsForCurrency (always falls back to 2 for arithmetic rounding), knownMinorUnitsForCurrency returns undefined for a currency absent from CURRENCY_MINOR_UNITS. This lets requestSchema.ts's H-2 check SKIP the decimal-scale check entirely for an unknown currency, rather than wrongly assuming 2dp — which would incorrectly reject a legitimate 3-minor-unit currency (e.g. BHD/KWD/OMR) or incorrectly accept an over-precise amount for a currency that is really 0dp.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
knownMinorUnitsForCurrency('BHD') === undefined (not 2, not 3 — genuinely unknown to this service's table, even though BHD is a real 3dp currency in ISO 4217)

## Verification Note
Confirmed exactly by direct read of money.ts lines 113-133.

## Source Evidence
- microservices/payment-component/src/money.ts lines 100-133 (CURRENCY_MINOR_UNITS table, minorUnitsForCurrency vs knownMinorUnitsForCurrency, doc comment)
- test/unit/money.test.ts: 'returns undefined (NOT a fallback of 2) for a currency not in the master' (BHD, XYZ)

## Related Knowledge
- [[Request Validation]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
