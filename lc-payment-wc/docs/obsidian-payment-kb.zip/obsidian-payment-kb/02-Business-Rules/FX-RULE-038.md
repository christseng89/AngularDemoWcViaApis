---
knowledge_id: FX-RULE-038
title: "chargeComponentBridge [i.e. the v1.9.0 debit-side netting] diff-pair gating can diverge between diffNative's sign and diffTrx's sign, risking a negative-amount FX leg"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - fx
  - confirmed
---

# FX-RULE-038 — chargeComponentBridge [i.e. the v1.9.0 debit-side netting] diff-pair gating can diverge between diffNative's sign and diffTrx's sign, risking a negative-amount FX leg

## Status
CONFIRMED

## Business Rule
The DEBIT-side netting branch gates on diffNative's sign (greaterThan(0)/lessThan(0)) but sizes the transaction-currency leg using the independently-computed diffTrx. Across multiple partly-offsetting legs, independent rounding can make diffNative>0 while diffTrx<=0 (or vice versa); buildFxPair would then be called with a trxCcyAmount whose sign disagrees with the branch's own direction assumption, potentially emitting a pair carrying a negative or zero amountTxCcy. The result stays aggregate-balanced (self-cancelling) so V8 would not catch it, but a negative-amount FX leg on the voucher is nonsensical for reconciliation.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
No worked numeric example available in the source evidence reviewed.

## Verification Note
Re-read the exact code this finding targets (lines 352-372, already fully quoted above). Confirmed the structural gap is real: the `diffNative.greaterThan(0)` branch passes `diffTrx` to buildFxPair WITHOUT taking `.abs()` or independently checking its sign, whereas the `lessThan(0)` branch does take `.abs()` on both diffNative and diffTrx. So if diffTrx happened to be negative while diffNative is positive, buildFxPair would receive a negative trxCcyAmount in the first branch. No unit test was found (in the file set available to this review) that specifically constructs a case where diffNative and diffTrx disagree in sign, so whether this is practically reachable (given both are derived from the same set of already-rounded, minor-unit-scale inputs) versus purely theoretical is unresolved — flagged in gaps_found. Status kept CONFIRMED for the code-structure observation itself (verified directly), not for whether the scenario is empirically reachable.

## Source Evidence
- payment-component-expert-review.md M-3 (suspenseBridge.ts:337-355)
- suspenseBridge.ts lines 352-372 (the actual DEBIT-side branch: `if (diffNative.greaterThan(0)) { buildFxPair(..., diffNative, diffTrx, ...) } else if (diffNative.lessThan(0)) { buildFxPair(..., diffNative.abs(), diffTrx.abs(), ...) }` — diffTrx is NOT independently sign-checked against diffNative in the greaterThan(0) branch)

## Related Knowledge
- [[FX Processing]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
