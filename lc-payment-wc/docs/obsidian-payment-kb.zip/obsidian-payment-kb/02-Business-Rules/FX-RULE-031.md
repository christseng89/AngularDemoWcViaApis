---
knowledge_id: FX-RULE-031
title: "SuspenseBridgeEntry.crossRate / SuspenseEntry.crossRate is required only when the entry's own currency differs from the request's transaction currency, and is ignored/not required otherwise"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - fx
  - confirmed
---

# FX-RULE-031 — SuspenseBridgeEntry.crossRate / SuspenseEntry.crossRate is required only when the entry's own currency differs from the request's transaction currency, and is ignored/not required otherwise

## Status
CONFIRMED

## Business Rule
Merged with 'suspense-entry-crossrate-required-when-foreign' (id_hint 40) — identical rule sourced from payment-component.types.ts's doc comment and the parallel OAS yaml doc comment (Payment_component.yaml / payment-instructions-post.yaml). Both are documentation-of-contract claims that are independently confirmed by the actual server-side enforcement code (buildSuspenseBridgeLeg throws RequestValidationError only in the entry.currency !== transactionCurrency branch when crossRate is missing).

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
transactionCurrency='USD', a SuspenseBridgeEntry with currency='EUR' must include crossRate; a SuspenseBridgeEntry with currency='USD' may omit crossRate.

## Verification Note
Merged two near-duplicate candidates (id_hints 31 and 40) into one entry, since they describe the identical field/rule sourced from parallel documentation files. Independently cross-checked against the actual server enforcement in suspenseBridge.ts (already fully read above), which matches this documented contract exactly. No status change; CONFIRMED for both the doc claim and the enforcing code.

## Source Evidence
- payment-component.types.ts SuspenseBridgeEntry.crossRate doc comment
- Payment_component.yaml / payment-instructions-post.yaml SuspenseEntry.crossRate doc comments
- suspenseBridge.ts lines 122-137 (buildSuspenseBridgeLeg: crossRate only checked in the currency-mismatch branch)

## Related Knowledge
- [[FX Processing]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
