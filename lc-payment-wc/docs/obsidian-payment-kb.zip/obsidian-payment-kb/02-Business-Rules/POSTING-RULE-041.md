---
knowledge_id: POSTING-RULE-041
title: "All monetary arithmetic is funneled through a single decimal.js choke point (money.ts) — never IEEE-754 floating point"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - accounting
  - confirmed
---

# POSTING-RULE-041 — All monetary arithmetic is funneled through a single decimal.js choke point (money.ts) — never IEEE-754 floating point

## Status
CONFIRMED

## Business Rule
All monetary arithmetic goes through decimal.js rather than native floating point, funneled through a single choke point in money.ts that enforces the OAS decimal-string patterns.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
No worked numeric example available in the source evidence reviewed.

## Verification Note
Directly confirmed by reading money.ts's top doc comment this pass — exact match to the claim.

## Source Evidence
- microservices/payment-component/src/money.ts top doc comment (lines 1-11), read in full this pass: 'This module is the only place in the service allowed to construct a Decimal from a wire string — every other module should go through here rather than touching Decimal directly, so the pattern is enforced at a single choke point.'

## Related Knowledge
- [[Accounting Model]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
