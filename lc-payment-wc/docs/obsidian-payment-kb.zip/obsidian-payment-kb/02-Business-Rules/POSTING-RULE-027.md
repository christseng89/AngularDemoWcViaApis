---
knowledge_id: POSTING-RULE-027
title: "Currency View's Balanced/Unbalanced flag is computed at each currency's own minor-unit precision using Decimal arithmetic, never native float equality"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - accounting
  - confirmed
---

# POSTING-RULE-027 — Currency View's Balanced/Unbalanced flag is computed at each currency's own minor-unit precision using Decimal arithmetic, never native float equality

## Status
CONFIRMED

## Business Rule
currencyGroups sums each currency's own Debit and Credit entries using decimal.js, and a currency is flagged 'Balanced' only when Debit−Credit rounds to zero at that currency's own decimal places (currencyDecimals input, falling back to 2).

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
No worked numeric example available in the source evidence reviewed.

## Verification Note
Directly confirmed by reading the full currencyGroups getter this pass — code matches the claim exactly.

## Source Evidence
- src/app/payment-component/response-viewer.component.ts currencyGroups getter, read directly this pass (lines ~284-320): `const dp = this.currencyDecimals[currency] ?? 2; ... balanced: difference.toDecimalPlaces(dp, Decimal.ROUND_HALF_UP).isZero()`

## Related Knowledge
- [[Accounting Model]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
