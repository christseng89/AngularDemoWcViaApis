---
knowledge_id: FX-RULE-035
title: "IMCO-specific exchange rate type selection based on a converted-amount threshold, with direction-dependent inversion"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - fx
  - confirmed
---

# FX-RULE-035 — IMCO-specific exchange rate type selection based on a converted-amount threshold, with direction-dependent inversion

## Status
CONFIRMED

## Business Rule
For IMCO module only: convertedAmt = CPYT_DR_TTL_AMT_TTLCCY × CPYT_DR_PER (or via calcExchAmt for foreign-to-local). For local→foreign: rateType = Buying Rate if convertedAmt ≤ 50,000 else Selling Rate. For foreign→local: the same threshold is used but INVERTED. All other confirmed modules use a generic 'Booking Rate' unconditionally via a fallback path.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
No worked numeric example available in the source evidence reviewed.

## Verification Note
Confirmed by reading the doc text directly: the 50,000 threshold, the Buying/Selling assignment and its inversion for foreign→local, and the 'generic fallback for ALL modules' comment are all present exactly as claimed at lines 250-286. No status change.

## Source Evidence
- analysis__Payment_Component_Calculation_Validation.docx.txt §8.1 lines 250-286 (Debit_ExchangingRate(), SSSS_PaymentDebit.js:392-454)

## Related Knowledge
- [[FX Processing]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
