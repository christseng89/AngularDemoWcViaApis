---
knowledge_id: CLASS-RULE-004
title: "RTGS is not a distinct account type — it is NOSTRO + rtgsIndicator flag (v1.3.0), and folds into the same nostroXor bucket as plain NOSTRO"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - classification
  - confirmed
---

# CLASS-RULE-004 — RTGS is not a distinct account type — it is NOSTRO + rtgsIndicator flag (v1.3.0), and folds into the same nostroXor bucket as plain NOSTRO

## Status
CONFIRMED

## Business Rule
Since v1.3.0, RTGS settlement (RPFM only) is represented as accountType='NOSTRO' plus a boolean rtgsIndicator field, not as its own AccountType enum value. An RTGS-flagged NOSTRO leg folds into nostroXor exactly like a plain NOSTRO leg — a Dr NOSTRO+rtgs vs a Cr plain NOSTRO cancels the XOR out (both sides just 'have NOSTRO'), and it never creates a second independent classification bucket. Merges near-duplicate candidates 3, 9, 11, 19, 20, 32 (same fact restated across classification/api-validation/regression/angular-leg-allocator/angular-services/api-contracts source groups) into one entry, and also folds in candidate 7's rationale detail.

## Conditions
rtgsIndicator is meaningful only when accountType is NOSTRO and is scoped to originModule RPFM.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
classify('id-7', [NOSTRO+rtgsIndicator=true], [NOSTRO]) -> nostroXor=false, paymentComponentRelated=false. In leg-allocator UI, makeRow() forces rtgsIndicator false for any non-NOSTRO row; onAccountTypeChange clears it on switching away from NOSTRO; on the wire it is included only for a NOSTRO row with the flag true, omitted otherwise.

## Verification Note
Re-read classification.ts, types.ts, business-case-registry.ts/.spec.ts, and the OAS yaml — all consistent. Note: the zh FSD doc (converted__PaymentComponent-Microservice-FSD-zh) itself still shows an OLDER v1.2.0 schema snippet with `enum: [CUSTOMER, NOSTRO, VOSTRO, SUSPENSE, INTERNAL, RTGS]` (a 6th distinct value) immediately followed by its own v1.3.0 correction note removing it — this is the source of the separately-tracked cross-domain CONFLICT 'rtgs-vs-accounttype-schema-evolution', not a defect in this merged rule itself. Merged 6 near-duplicate candidates (3, 9, 11, 19, 20, 32) into one; folded candidate 7's rationale (no legacy branch differs RTGS vs NOSTRO) into evidence.

## Source Evidence
- microservices/payment-component/src/domain/classification.ts top comment lines 14-18
- microservices/payment-component/src/types.ts ACCOUNT_TYPES doc comment lines 29-40 and rtgsIndicator doc comment line 89
- test/unit/domain/classification.test.ts 'a NOSTRO leg with rtgsIndicator still folds into nostroXor like plain NOSTRO' and 'rtgsIndicator does not create a second independent bucket'
- src/app/payment-component/business-case-registry.ts rtgsLeg() helper and doc comment; business-case-registry.spec.ts 'no leg offers RTGS as a selectable AccountType' and 'every RTGS-flagged leg defaults to accountType NOSTRO'
- leg-allocator.component.ts Row.rtgsIndicator doc comment, makeRow(), onAccountTypeChange(), emit(); leg-allocator.component.spec.ts 'RTGS indicator threading' describe block
- analysis/Payment_component.yaml AccountType description v1.3.0 note lines 416-424
- converted/analysis__PaymentComponent-Microservice-FSD-zh.docx.txt AccountType schema description lines 424-440 (v1.2.0 6th-enum-value predecessor, later removed per this same doc's own v1.3.0 note)

## Related Knowledge
- [[Payment Instruction Classification]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
