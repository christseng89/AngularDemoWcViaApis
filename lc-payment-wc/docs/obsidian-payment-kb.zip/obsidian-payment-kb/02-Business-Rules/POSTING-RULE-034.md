---
knowledge_id: POSTING-RULE-034
title: "debitEntries genuinely NET against same-currency real debitLegs (opposite polarity); creditEntries only ever COMBINE with same-currency real creditLegs (same polarity) — deliberate, not a bug"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - accounting
  - confirmed
---

# POSTING-RULE-034 — debitEntries genuinely NET against same-currency real debitLegs (opposite polarity); creditEntries only ever COMBINE with same-currency real creditLegs (same polarity) — deliberate, not a bug

## Status
CONFIRMED

## Business Rule
Because the Suspense bridge leg is unconditionally CREDIT-direction, a debitEntries bucket is opposite-polarity to the bridge leg and can net to a smaller/zero FX exposure, while a creditEntries bucket is SAME polarity and can only ever add. v1.7.0 got this wrong (one symmetric formula for both sides); v1.7.1/v1.9.0 fixed it with genuinely different formulas.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
No worked numeric example available in the source evidence reviewed.

## Verification Note
Directly and thoroughly confirmed by reading suspenseBridge.ts's full top doc comment and the expandSuspenseBridge function doc comment this pass — the asymmetric debit-nets/credit-combines-only design is stated explicitly and unambiguously in the source.

## Source Evidence
- src/domain/suspenseBridge.ts lines 1-100+ (top doc comment through the v1.9.0 section), read in full this pass — the v1.9.0 doc-comment block explicitly states: 'a debitEntries bucket ONLY (side === "DEBIT") nets its gross amount against matching-currency debitLegs' and 'a creditEntries bucket (side CREDIT) is unaffected by v1.9.0 and keeps the original v1.8.0 behavior... see this branch's own inline comment for why netting is unsafe here'
- expandSuspenseBridge's own function doc comment (lines ~275-297), read directly, states the same asymmetry precisely

## Related Knowledge
- [[Accounting Model]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
