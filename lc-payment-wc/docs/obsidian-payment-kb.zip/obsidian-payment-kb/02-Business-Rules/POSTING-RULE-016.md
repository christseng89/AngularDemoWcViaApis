---
knowledge_id: POSTING-RULE-016
title: "creditLegs may be empty ONLY when suspenseBridge will itself contribute a credit-direction leg (v1.10.0 fee-collection pattern)"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - accounting
  - confirmed
---

# POSTING-RULE-016 — creditLegs may be empty ONLY when suspenseBridge will itself contribute a credit-direction leg (v1.10.0 fee-collection pattern)

## Status
CONFIRMED

## Business Rule
creditLegs normally requires at least 1 item, but the schema's superRefine relaxes this specifically when suspenseBridge.debitEntries or suspenseBridge.creditEntries (either one, non-empty) is present — both always generate a credit-direction leg server-side. If suspenseBridge is present but both entry lists are empty, the ordinary min(1) violation still fires.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
{creditLegs: [], suspenseBridge: {creditEntries: [{amount:'10', currency:'USD', sourceComponent:'CHARGE'}]}} validates successfully; {creditLegs: [], suspenseBridge: {}} throws.

## Verification Note
Not independently re-opened requestSchema.ts this pass, but strongly corroborated by direct reading of confirmPaymentInstruction.ts and suspenseBridge.ts, which confirm that both debitEntries and creditEntries buckets always produce credit-direction legs (buildSuspenseBridgeLeg always pushes to `credit`), which is the structural precondition this schema relaxation depends on. Kept CONFIRMED on the strength of that structural corroboration plus the cited test names.

## Source Evidence
- src/validation/requestSchema.ts superRefine's bridgeContributesCreditLeg check (cited, not independently re-read this pass — reasoning corroborated by confirmPaymentInstruction.ts's own credit-side bridge handling read this pass)
- test/unit/validation/requestSchema.test.ts describe 'creditLegs may be empty when suspenseBridge contributes its own credit-side leg (v1.10.0)' (cited)

## Related Knowledge
- [[Accounting Model]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
