---
knowledge_id: SUSPENSE-RULE-016
title: "Suspense Debit/Credit entry rows capture the raw material for the Charge/Balance Component <-> Payment Component accounting bridge"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - suspense
  - confirmed
---

# SUSPENSE-RULE-016 — Suspense Debit/Credit entry rows capture the raw material for the Charge/Balance Component <-> Payment Component accounting bridge

## Status
CONFIRMED

## Business Rule
SuspenseEntriesComponent is a repeatable amount+currency+sourceComponent row list (deliberately not a Formly repeat field, since this app never registers one) whose emitted SuspenseEntry[] feeds the parent's buildSuspenseBridge(), which the microservice's suspenseBridge.ts domain logic expands server-side into generated 'Suspense - Debit'/'Suspense - Credit' clearing legs. sourceComponent is a UI-only label ('CHARGE' or 'BALANCE') recording which upstream component already booked the entry's offsetting leg — the dropdown shows 'Liability' for the BALANCE wire value specifically because there is no 'LIABILITY' wire value.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
n/a

## Verification Note
Read suspense-entries.component.ts (first 45 lines) and suspense-entries.component.html directly — both match the stated rule exactly, including the 'no LIABILITY wire value' reasoning and the Formly-repeat-avoidance rationale. Status unchanged: CONFIRMED.

## Source Evidence
- suspense-entries.component.ts lines 1-45 (SuspenseEntry interface doc comment, component-level doc comment about not using Formly repeat)
- suspense-entries.component.html line 19 (`<option value="BALANCE">Liability</option>`)

## Related Knowledge
- [[Suspense Account]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
