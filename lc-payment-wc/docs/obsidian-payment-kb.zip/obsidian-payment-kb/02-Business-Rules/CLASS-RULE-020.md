---
knowledge_id: CLASS-RULE-020
title: "A fixed 7-type GL account taxonomy underlies every LC journal entry (legacy web-components, distinct from the Payment Component microservice's 5-type AccountType)"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - classification
  - confirmed
---

# CLASS-RULE-020 — A fixed 7-type GL account taxonomy underlies every LC journal entry (legacy web-components, distinct from the Payment Component microservice's 5-type AccountType)

## Status
CONFIRMED

## Business Rule
Every DrCrEntry.accountType in the legacy LC web-components mock is one of exactly 7 values: CA (Customer Account), Nostro, IBL (Import Bill Loan), EBL (Export Bill Loan / negotiated advance), Margin, Income, FX. journal-entry.element.ts colour-codes each with a fixed badge palette, implying these are the only account classes this legacy LC mock ever posts to — no Suspense, Vostro, or GL-clearing account type exists in this component's vocabulary (unlike the Payment Component microservice, which has a distinct 5-type AccountType including Suspense/Vostro).

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
No worked numeric example available in the source evidence reviewed.

## Verification Note
Confirmed directly — both files match the claim exactly, including all 7 type names.

## Source Evidence
- src/app/web-components/journal-entry.element.ts lines 3-11 (ACCOUNT_TYPE_COLORS map)
- src/app/web-components/shared.ts line 6 (DrCrEntry.accountType union type: 'CA' | 'Nostro' | 'IBL' | 'EBL' | 'Margin' | 'Income' | 'FX')

## Related Knowledge
- [[Payment Instruction Classification]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
