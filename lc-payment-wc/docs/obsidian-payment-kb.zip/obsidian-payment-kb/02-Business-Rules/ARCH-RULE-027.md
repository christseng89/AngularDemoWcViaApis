---
knowledge_id: ARCH-RULE-027
title: "AML/sanctions screening and authN/authZ explicitly out of scope, delegated upstream"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - architecture
  - confirmed
---

# ARCH-RULE-027 — AML/sanctions screening and authN/authZ explicitly out of scope, delegated upstream

## Status
CONFIRMED

## Business Rule
AML/sanctions screening and authentication/authorisation are explicitly out of scope per the OAS's own v1.2.0 changelog, assumed handled by an upstream gateway or calling module. In the zh FSD, sanctions/AML screening of parties (SWIFT 50/56/59 and narrative) is performed by the enterprise compliance layer before messages reach the SWIFT network; the Payment Component only consumes a blockStatus result via GET /payment-routing. AuthN/authZ (OAuth2/mTLS) is enforced uniformly by the API gateway, so this service's own OpenAPI contract does not redefine securitySchemes.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
No AML/authN logic inside this service; /payment-routing.blockStatus is the only sanctions-adjacent signal consumed

## Example
No worked numeric example available in the source evidence reviewed.

## Verification Note
Confirmed against both the en and zh source documents directly. Unchanged.

## Source Evidence
- converted/analysis__Payment-OAS-FSD-en.docx.txt line 19, directly re-read
- converted/analysis__PaymentComponent-Microservice-FSD-zh.docx.txt §8.2, lines 165-166, directly re-read (Chinese text confirms sanctions/AML delegated to enterprise compliance layer, blockStatus via /payment-routing, authN/authZ via API gateway)

## Related Knowledge
- [[Payment Architecture]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
