---
knowledge_id: POSTING-RULE-002
title: "Charge Voucher (§6.2) and Liability Voucher (§6.3) generation were removed entirely in v1.6.0 — this service posts ONLY Settlement entries (merged with duplicate 'charge-liability-voucher-removed-v160')"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - accounting
  - confirmed
---

# POSTING-RULE-002 — Charge Voucher (§6.2) and Liability Voucher (§6.3) generation were removed entirely in v1.6.0 — this service posts ONLY Settlement entries (merged with duplicate 'charge-liability-voucher-removed-v160')

## Status
CONFIRMED

## Business Rule
The Payment Component never generates Charge or Liability Account Entries under any circumstance, including when a suspenseBridge entry carries sourceComponent provenance metadata. Every accountEntry this service produces has voucherType SETTLEMENT. A separate Charge/Balance Component is expected to post its own Charge/Liability entries on its own books; this service only books its own offsetting Suspense leg.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
n/a — structural/negative rule (absence of Charge/Liability entries)

## Verification Note
Merged id_hint=charge-liability-streams-removed-v1.6.0 and id_hint=charge-liability-voucher-removed-v160 (near-duplicate, identical claim). Directly confirmed by reading confirmPaymentInstruction.ts and accountEntries.ts in full — both source files' code and doc comments match exactly.

## Source Evidence
- src/domain/confirmPaymentInstruction.ts top comment (lines 1-23), read in full — explains the v1.6.0 architecture decision
- src/domain/accountEntries.ts top comment (lines 1-17) and buildSettlementEntries() (lines 87-107), read in full — only ever constructs voucherType 'SETTLEMENT'
- test/unit/domain/confirmPaymentInstruction.test.ts (cited, not independently re-read this pass)

## Related Knowledge
- [[Accounting Model]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
