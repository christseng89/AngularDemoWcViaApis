---
knowledge_id: FX-RULE-005
title: "Account-currency amount = transaction-currency amount × leg's own buy rate (§8.2 formula, symmetric for Dr and Cr)"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - fx
  - confirmed
---

# FX-RULE-005 — Account-currency amount = transaction-currency amount × leg's own buy rate (§8.2 formula, symmetric for Dr and Cr)

## Status
CONFIRMED

## Business Rule
convertTxCcyToAccountCcy(amountTxCcy, rate) = amountTxCcy × rate, implementing §8.2 of the Calculation-Validation doc: CPYT_DR_AMT_DRCCY = CPYT_DR_AMT_TXCCY × CPYT_DR_BUY_RATE for debit, and the symmetric formula for credit, ported from SSSS_PaymentDebit.js/SSSS_PaymentCredit.js.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
convertTxCcyToAccountCcy(100, 1.5) = 150

## Verification Note
Confirmed directly in money.ts. No status change.

## Source Evidence
- money.ts lines 174-182 (convertTxCcyToAccountCcy + doc comment citing §8.2)
- test/unit/money.test.ts 'multiplies amount by rate' (100×1.5=150)

## Related Knowledge
- [[FX Processing]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
