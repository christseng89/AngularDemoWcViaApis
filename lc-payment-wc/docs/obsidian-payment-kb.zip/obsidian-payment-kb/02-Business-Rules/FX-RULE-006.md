---
knowledge_id: FX-RULE-006
title: "A zero FX rate must be rejected (M-2) because it would silently zero out and drop a suspense-bridge leg with no error"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - fx
  - confirmed
---

# FX-RULE-006 — A zero FX rate must be rejected (M-2) because it would silently zero out and drop a suspense-bridge leg with no error

## Status
CONFIRMED

## Business Rule
isZeroRate() is a pure string test for an all-zero ExchangeRate string. Used to reject a zero crossRate: since ExchangeRate is unsigned (no leading '-' permitted by pattern), zero is the only non-positive value to guard against. The doc comment explains why: a zero rate makes buildSuspenseBridgeLeg's converted amount 0, silently dropping a real charge with no error surfaced (buildSuspenseBridgeLeg returns null when Number(roundedTrxEquivalent)===0).

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
isZeroRate('0.0000000001') === false; isZeroRate('00') === true

## Verification Note
Confirmed both the isZeroRate implementation and the downstream buildSuspenseBridgeLeg null-return-on-zero behavior it protects against, by reading suspenseBridge.ts directly. No status change.

## Source Evidence
- money.ts lines 161-172 (isZeroRate)
- suspenseBridge.ts lines 142 (Number(roundedTrxEquivalent)===0 -> return null)
- test/unit/money.test.ts isZeroRate describe block

## Related Knowledge
- [[FX Processing]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
