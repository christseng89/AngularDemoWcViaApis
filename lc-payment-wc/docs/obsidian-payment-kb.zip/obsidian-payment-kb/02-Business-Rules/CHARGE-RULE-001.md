---
knowledge_id: CHARGE-RULE-001
title: "Margin/pledge DDA accounts are hidden from ordinary fee/charge payment account pickers by default"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - charges
  - confirmed
---

# CHARGE-RULE-001 — Margin/pledge DDA accounts are hidden from ordinary fee/charge payment account pickers by default

## Status
CONFIRMED

## Business Rule
ddaAcctsByCcy(appId, ccy, includePledge=false) filters out any DdaAcct with pledge=true unless explicitly asked to include them. Every charge-collection/payment-account dropdown in this component group (renderChargeSection's payAcct selects, renderPaymentDetails) calls ddaAcctsByCcy without the includePledge flag, so a customer's margin/pledge account (e.g. Acme's 'A1-U2 美元保證金帳戶') is never offered as a source to pay commissions, SWIFT fees, or corr-bank charges from.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
C-001/USD returns ['A1-U1','A1-FX'] by default (A1-U2 pledge account excluded); with includePledge=true it also returns A1-U2.

## Verification Note
Fully re-verified against source and spec. All cited call sites confirmed to omit the includePledge argument. No change to status.

## Source Evidence
- shared.ts lines 86-110 (DDA_ACCTS pledge=true on A1-U2; ddaAcctsByCcy signature/filter)
- shared.ts line 314 (renderChargeSection calls ddaAcctsByCcy(appId, g.ccy), no 3rd arg)
- shared.ts line 407 (renderPaymentDetails calls ddaAcctsByCcy(appId, payCcy), no 3rd arg)
- shared.spec.ts lines 44-61 (ddaAcctsByCcy tests: default excludes A1-U2, includePledge=true includes it, unknown appId falls back to _default, unmatched currency returns [])

## Related Knowledge
- [[Charge Integration]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
