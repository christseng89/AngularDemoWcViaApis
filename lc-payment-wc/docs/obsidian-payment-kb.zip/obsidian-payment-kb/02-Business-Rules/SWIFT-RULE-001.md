---
knowledge_id: SWIFT-RULE-001
title: "SWIFT cross-field validation on credit legs runs before message generation and blocks persistence on violation"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - swift
  - confirmed
---

# SWIFT-RULE-001 — SWIFT cross-field validation on credit legs runs before message generation and blocks persistence on violation

## Status
CONFIRMED

## Business Rule
Step 5 of the Confirm flow calls validateSwiftCrossField(creditLegs) before buildSwiftMessages; a cross-field violation (e.g. payCoverMsgType='MT202COV' present without a valid payAdviceMsgType) throws BusinessValidationError('SWIFT_ADV_COV_MISMATCH', ...) which propagates out of confirmPaymentInstruction() before store.save() is ever reached, so nothing is persisted.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
creditLegs=[{...,payCoverMsgType:'MT202COV'}] with payAdviceMsgType omitted -> BusinessValidationError thrown, nothing persisted.

## Verification Note
Re-read confirmPaymentInstruction.ts in full and confirmed the exact call order (validateSwiftCrossField before buildSwiftMessages, both before store.save). Re-read the cited test and confirmed store.find returns undefined after the throw. CONFIRMED as originally stated.

## Source Evidence
- src/domain/confirmPaymentInstruction.ts lines 195-197 — 'validateSwiftCrossField(creditLegs); const swiftMessages = buildSwiftMessages(...)' runs as Step 5, after account entries (step 4) and before the final store.save() at line 219
- test/unit/domain/confirmPaymentInstruction.test.ts line ~200-215 — mainRef 'REF-SWIFT-BAD' test asserts store.find('IPLC','REF-SWIFT-BAD',1) is undefined after the throw

## Related Knowledge
- [[SWIFT Messaging and Vouchers]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
