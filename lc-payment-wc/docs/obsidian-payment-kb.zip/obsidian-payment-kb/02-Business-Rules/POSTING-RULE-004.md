---
knowledge_id: POSTING-RULE-004
title: "exchangeRate1 is echoed on accountEntries for FX-rated legs (both suspenseBridge-generated FX pairs and caller's own foreign-currency legs, v1.11.0); exchangeRate2 is deliberately left unset"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - accounting
  - confirmed
---

# POSTING-RULE-004 — exchangeRate1 is echoed on accountEntries for FX-rated legs (both suspenseBridge-generated FX pairs and caller's own foreign-currency legs, v1.11.0); exchangeRate2 is deliberately left unset

## Status
CONFIRMED

## Business Rule
accountEntries.ts's buildSettlementEntries sets exchangeRate1 = (drRate ?? drBuyRate) for a DEBIT leg, (crBuyRate ?? sellRate) for a CREDIT leg — one code path covering both a caller's own foreign-currency legs AND suspenseBridge-generated FX Exchange pair legs (since suspenseBridge.ts sets drBuyRate/crBuyRate directly on those before they reach this function). exchangeRate2 is never populated anywhere. A leg with none of these rate fields (e.g. a same-currency leg) leaves exchangeRate1 undefined.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
suspenseBridge.debitEntries=[{17,EUR,crossRate:'1.1'}] -> accountEntries for glAccount 'FX Exchange USD' and 'FX Exchange EUR' both have exchangeRate1='1.1'; glAccount 'CUST-ACC' entry has exchangeRate1 undefined.

## Verification Note
Directly confirmed by reading accountEntries.ts in full — the doc comment (lines 73-86) and implementation (line 95, line 104) match the claim precisely, including the 'never populated exchangeRate2' detail. Slightly broadened the title from the original ('...for suspenseBridge-generated FX Exchange pair legs') since the code confirms this applies to ANY leg carrying a rate field, not only bridge-generated ones — this is a clarification, not a downgrade.

## Source Evidence
- src/domain/accountEntries.ts lines 73-107, read in full — exchangeRate1 computed as `side === 'DEBIT' ? (leg.drRate ?? leg.drBuyRate) : (leg.crBuyRate ?? leg.sellRate)`, only spread into the entry `{ ...(exchangeRate1 ? { exchangeRate1 } : {}) }`; exchangeRate2 never referenced anywhere in the file
- analysis/Payment_component.yaml lines 850-851 confirm exchangeRate1/exchangeRate2 exist as bare $ref with no description (corroborating why exchangeRate2 was left unset)

## Related Knowledge
- [[Accounting Model]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
