---
knowledge_id: UI-RULE-002
title: "Main Ref default follows a fixed `${module}-${id}-0001` convention"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - ui
  - confirmed
---

# UI-RULE-002 — Main Ref default follows a fixed `${module}-${id}-0001` convention

## Status
CONFIRMED

## Business Rule
When a PASS case's header form is built, the Main Ref field's default value is programmatically derived as `${config.module}-${config.id}-0001`, giving every business case a distinct, predictable starting reference the user can edit before Confirm.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
module IPLC, id pay-accept -> default Main Ref 'IPLC-pay-accept-0001'.

## Verification Note
Confirmed by direct read of business-case-fields.ts line 14 and the corresponding spec assertion expecting exactly 'IPLC-pay-accept-0001'.

## Source Evidence
- business-case-fields.ts:14 (`defaultValue: `${config.module}-${config.id}-0001``)
- business-case-fields.spec.ts: 'builds the unitCode/mainRef/sequence row... mainRef defaulted from module+id' — expects 'IPLC-pay-accept-0001'

## Related Knowledge
- [[Payment Component Simulator UI]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
