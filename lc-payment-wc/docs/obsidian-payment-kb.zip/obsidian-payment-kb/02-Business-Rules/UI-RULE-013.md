---
knowledge_id: UI-RULE-013
title: "Zero-amount settlement legs are hidden from both Settlement Voucher views"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - ui
  - confirmed
---

# UI-RULE-013 — Zero-amount settlement legs are hidden from both Settlement Voucher views

## Status
CONFIRMED

## Business Rule
settlementEntries (the shared source for both Posting View and Currency View) excludes any SETTLEMENT-voucherType AccountEntry whose numeric amount is exactly 0 — even though such a leg can legitimately reach the server (onConfirm() doesn't gate on debitValid/creditValid, so a Suspense Credit bridge entry that fully offsets a real credit leg on the same account can arrive as a real 0.00 wire entry). This filter runs upstream of groupedSettlementEntries and currencyGroups, so a zero-amount leg never appears as a spurious line in either view, but it never touches the authoritative `balance` Input (the server's own V8 result over the full ledger).

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
Dr CUST-ACC USD 150.00 (shown), Cr Suspense-Credit USD 0.00 (hidden), Cr Suspense-Credit USD 150.00 (shown) — only 2 of 3 wire entries display.

## Verification Note
Confirmed exactly against source lines 137-139.

## Source Evidence
- response-viewer.component.ts lines 122-139 (settlementEntries getter + doc comment): `.filter((e) => e.voucherType === 'SETTLEMENT' && Number(e.amount) !== 0)`

## Related Knowledge
- [[Payment Component Simulator UI]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
