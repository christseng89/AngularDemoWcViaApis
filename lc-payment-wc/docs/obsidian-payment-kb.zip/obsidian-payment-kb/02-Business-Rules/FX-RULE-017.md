---
knowledge_id: FX-RULE-017
title: "A creditEntries Suspense bucket generates its FX pair(s) purely from ITS OWN currency buckets — an unrelated real credit leg in a currency the Suspense bridge never mentions gets no auto-generated FX pair at all"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - fx
  - confirmed
---

# FX-RULE-017 — A creditEntries Suspense bucket generates its FX pair(s) purely from ITS OWN currency buckets — an unrelated real credit leg in a currency the Suspense bridge never mentions gets no auto-generated FX pair at all

## Status
CONFIRMED

## Business Rule
Curl case 2 changes only the creditLegs shape (splitting the single USD Nostro leg into EUR+USD) while keeping suspenseBridge.creditEntries unchanged (35 USD only). Because the credit-side FX-pair logic is driven by grouping suspenseBridge entries by currency (not by scanning creditLegs), the EUR Nostro leg has no matching Suspense currency bucket and triggers no FX Exchange pair — it settles as a plain, independent real leg.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
case1 creditLegs=[USD 9965.00]; case2 creditLegs=[EUR 1083.08, USD 8881.92] — both produce identical suspense-bridge-generated additions and both balance to 10246.62/10246.62.

## Verification Note
Confirmed by direct code read of groupByCurrency's iteration source (bridge entries, not the caller's legs) and cross-checked against the zh test-cases doc's Case #2 narrative. No status change.

## Source Evidence
- suspenseBridge.ts line 301 (`for (const [currency, bucket] of groupByCurrency(entries))` — entries is the SuspenseEntry list, not sideLegs)
- Payment-Component-Suspense-FX-Test-Cases-zh.md 'Case #2' section, confirming no additional FX pair for the EUR leg

## Related Knowledge
- [[FX Processing]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
