---
knowledge_id: ARCH-RULE-014
title: "Dedicated Liability/Charge Voucher context Formly panels were removed from the header-fields builder in v1.6.0"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - architecture
  - confirmed
---

# ARCH-RULE-014 — Dedicated Liability/Charge Voucher context Formly panels were removed from the header-fields builder in v1.6.0

## Status
CONFIRMED

## Business Rule
buildHeaderFields previously also built a second slice of checkbox-gated 'Include Liability Voucher context (§6.3)' / 'Include Charge Voucher context (§6.2)' fields (driven by BusinessCaseConfig.liability/.charge). These were removed together with the microservice's own §6.2/§6.3 generation streams — a Balance/Charge Component that needs to bridge a leg through Suspense now tags the relevant row in the separate <app-suspense-entries> component (Charge/Liability dropdown) instead of filling a dedicated context panel.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
No worked numeric example available in the source evidence reviewed.

## Verification Note
Confirmed directly against the file. Unchanged.

## Source Evidence
- src/app/payment-component/business-case-fields.ts lines 35-48, directly re-read: doc comment states 'this file previously also built a second slice of "tail" fields — the checkbox-gated "Include Liability Voucher context (§6.3)" / "Include Charge Voucher context (§6.2)" panels ... Removed along with the microservice's own §6.2/§6.3 generation'
- buildHeaderFields function body (same file) confirmed to return only the unitCode/mainRef/sequence row plus optional voucherPrefix select for PASS cases, [] otherwise — no liability/charge fields present

## Related Knowledge
- [[Payment Architecture]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
