---
knowledge_id: POSTING-RULE-046
title: "Proposed Export LC Usance Negotiation (Use Case 4) conflicts in direction with the already-registered eplc-discount case"
domain: Payment
category: Business Rule
status: CONFLICT
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - accounting
  - conflict
---

# POSTING-RULE-046 — Proposed Export LC Usance Negotiation (Use Case 4) conflicts in direction with the already-registered eplc-discount case

## Status
CONFLICT

## Business Rule
The already-registered EPLC:Discount business case defaults to Dr CUSTOMER / Cr NOSTRO (money flowing FROM the customer). The proposed Use Case 4 models money flowing OUT TO the customer, the opposite direction. Unclear whether the underlying legacy function posts a single leg pair matching the registered default or a fuller multi-leg voucher including the payout leg.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
eplc-discount registered default: Dr CUSTOMER / Cr NOSTRO. Use Case 4 proposed shape: Dr Suspense(real) / Cr Customer A/C + Cr Suspense-Credit (bridge).

## Conflict Note
> [!warning] Sources disagree
> The existence of the eplc-discount registry entry (EPLC:Discount -> EPLC07NULLNULLNULL) was directly confirmed in voucherDescription.ts this pass, corroborating that this is a real conflict between an actual implemented case and a proposal, not a hypothetical. The proposal document itself not independently re-opened. Kept CONFLICT as originally stated.

## Verification Note
The existence of the eplc-discount registry entry (EPLC:Discount -> EPLC07NULLNULLNULL) was directly confirmed in voucherDescription.ts this pass, corroborating that this is a real conflict between an actual implemented case and a proposal, not a hypothetical. The proposal document itself not independently re-opened. Kept CONFLICT as originally stated.

## Source Evidence
- PaymentComponentProposedUseCases-EN.docx.txt, Use Case 4 'Open items for review'; Traceability table row 4 (cited, not independently re-opened this pass)
- voucherDescription.ts VOUCHER_CODE_PREFIXES table, read directly this pass, confirms 'EPLC:Discount': 'EPLC07NULLNULLNULL' exists as a registered function, corroborating that eplc-discount is indeed a real, currently-implemented registry entry that a conflicting proposal would need to reconcile against

## Related Knowledge
- [[Accounting Model]]
- [[Business-Rule-Index]]
- [[Knowledge-Gaps]]
- [[Payment-Traceability-Matrix]]
