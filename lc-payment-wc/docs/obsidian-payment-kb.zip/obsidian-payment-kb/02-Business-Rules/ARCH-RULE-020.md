---
knowledge_id: ARCH-RULE-020
title: "The Charge Voucher / Liability Voucher UI sections likely never render any data in the current architecture"
domain: Payment
category: Business Rule
status: INFERRED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - architecture
  - inferred
---

# ARCH-RULE-020 — The Charge Voucher / Liability Voucher UI sections likely never render any data in the current architecture

## Status
INFERRED

## Business Rule
Per the project's own architecture decision (Charge Component boundary), the microservice's §6.2 Charge Voucher / §6.3 Liability Voucher generation streams were removed from the payment-component service entirely in v1.6.0, since charge/liability posting now belongs to separate Charge/Balance Components. Since chargeEntries/liabilityEntries in response-viewer.component.ts filter on voucherType 'CHARGE'/'LIABILITY' from the SAME accountEntries response the microservice now never populates with those voucher types, these two UI sections are inferred to be effectively dead/legacy display paths kept only for backward compatibility with the AccountEntry.voucherType enum — this cannot be fully confirmed from code inspection alone (it proves the filters exist and would work correctly against a constructed fixture, not that the server has never sent, or could never in the future send, such entries via some other caller-supplied path).

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
No worked numeric example available in the source evidence reviewed.

## Verification Note
Confirmed the filters exist exactly as described; kept as INFERRED (not CONFIRMED) per the original tag since no test or server code path was found that ever actually produces a CHARGE/LIABILITY voucherType entry to feed these getters — appropriately conservative.

## Source Evidence
- src/app/payment-component/response-viewer.component.ts lines 322-327, directly re-read: `get chargeEntries(): AccountEntry[] { return (this.accountEntries ?? []).filter((e) => e.voucherType === 'CHARGE'); } get liabilityEntries(): AccountEntry[] { return (this.accountEntries ?? []).filter((e) => e.voucherType === 'LIABILITY'); }`
- corroborated by accountEntries.ts's own confirmed doc comment (this service 'only ever produces SETTLEMENT entries')

## Related Knowledge
- [[Payment Architecture]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
