---
knowledge_id: ARCH-RULE-031
title: "The Payment Component is a shared Dr/Cr settlement layer invoked by other modules' Confirm functions, not a product in its own right"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - architecture
  - confirmed
---

# ARCH-RULE-031 — The Payment Component is a shared Dr/Cr settlement layer invoked by other modules' Confirm functions, not a product in its own right

## Status
CONFIRMED

## Business Rule
The Payment Component owns exactly the logic currently duplicated per-function in IPLC/EPLC/EXCO (SYF_*_CAL_PAYMENT_AC_DESC) and centralized in IMCO (SYM_IMCO_SetPaymentVchDesc): classify Dr/Cr legs, assemble voucher description codes, and trigger two downstream outputs (Account Entry, SWIFT/ISO 20022 message). It does NOT own trade-instrument logic itself (LC balance, tolerance, collection conditions) — that stays in the calling module, which calls this service rather than directly consuming the PaymentDebit/PaymentCredit DOs in-line.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Single atomic POST /payment-instructions replaces in-line DO consumption across the confirmed-user modules

## Example
No worked numeric example available in the source evidence reviewed.

## Verification Note
Confirmed the core claim and the IPLC/EPLC/EXCO/IMCO attribution directly against the zh FSD §5.1 text. The candidate rule's additional claim that GTEE/IWGT ALSO have their own centralized SYM_*_SetPaymentVchDesc implementation was NOT found verbatim in the sections read (only an aggregate 'IPLC/EPLC/EXCO/IMCO/GTEE/IWGT have consistent capability' statement at a different location, §5.1's remediation-option text) — downgrading this one sub-detail's confidence in a gaps_found note while keeping the overall rule CONFIRMED, since its main thrust is solidly evidenced.

## Source Evidence
- converted/analysis__Payment-OAS-FSD-en.docx.txt §1, line 10, directly re-read: 'The Payment Component is not a product in its own right; it is the shared Dr/Cr settlement layer that every trade finance module's Confirm-button function calls into...'
- converted/analysis__PaymentComponent-Microservice-FSD-zh.docx.txt §5.1, line 114, directly re-read: names IPLC/EPLC/EXCO (SYF_*_CAL_PAYMENT_AC_DESC, duplicated) and IMCO (SYM_IMCO_SetPaymentVchDesc, centralized) explicitly

## Related Knowledge
- [[Payment Architecture]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
