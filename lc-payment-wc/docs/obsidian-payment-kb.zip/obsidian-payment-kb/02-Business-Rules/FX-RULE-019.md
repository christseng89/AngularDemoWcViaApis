---
knowledge_id: FX-RULE-019
title: "transactionCurrency is sent as an explicit, independent wire field, never inferred from a leg's own currency"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - fx
  - confirmed
---

# FX-RULE-019 — transactionCurrency is sent as an explicit, independent wire field, never inferred from a leg's own currency

## Status
CONFIRMED

## Business Rule
buildConfirmRequest takes transactionCurrency as its own parameter and always populates PaymentInstructionConfirmRequest.transactionCurrency from it, regardless of what currency any individual leg is denominated in — avoiding the pre-v1.10.0 server bug where transaction currency was inferred as debitLegs[0].currency.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
debitLegs=[{currency:'JPY',amountTxCcy:'10000.00'}], transactionCurrency param='USD' → request.transactionCurrency==='USD' while request.debitLegs[0].currency==='JPY'.

## Verification Note
Confirmed by grepping business-case-runner.component.ts directly: transactionCurrency getter and its use at lines 677/740 in the confirm/preview call sites confirm it's always passed explicitly, independent of any leg. No status change.

## Source Evidence
- business-case-request.ts (transactionCurrency param, always populated) — line references ~16, 26-29
- business-case-runner.component.ts get transactionCurrency() at line 248 confirms this is always sent

## Related Knowledge
- [[FX Processing]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
