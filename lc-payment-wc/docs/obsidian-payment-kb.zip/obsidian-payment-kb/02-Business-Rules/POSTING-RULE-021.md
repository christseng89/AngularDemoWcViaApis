---
knowledge_id: POSTING-RULE-021
title: "Rows always sum to exactly 100% / the exact Total Amount via one auto-computed remainder row; remainder routing is decided by AMOUNT (exact), not by % (which can drift under repeating fractions)"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - accounting
  - confirmed
---

# POSTING-RULE-021 — Rows always sum to exactly 100% / the exact Total Amount via one auto-computed remainder row; remainder routing is decided by AMOUNT (exact), not by % (which can drift under repeating fractions)

## Status
CONFIRMED

## Business Rule
At most one row at a time is marked isRemainder; its amount is computed as an exact subtraction (totalAmount − Σ every other row's own amount), guaranteeing the side's rows always sum to exactly the protected total. Whether a remainder row is spawned/kept is decided by AMOUNT, not %.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
Total 0.35, 30% fixed row -> 0.11 (0.105 rounds up); remainder row is exactly 0.35−0.11=0.24, summing to exactly 0.35.

## Verification Note
Directly confirmed by reading the ensureRemainderRow() code — the amount-based routing decision (amountRemaining, not a %-based 'remaining') exactly matches the claim, including the v1.12.1 amount-vs-percent routing fix.

## Source Evidence
- src/app/payment-component/leg-allocator.component.ts lines ~1180-1234 (ensureRemainderRow), read directly this pass: `const amountRemaining = money(this.totalAmount.minus(fixedAmountSum), this.scaleFor(this.transactionCurrency)); if (amountRemaining.greaterThan(0)) { ... remainderRow.amountTxCcy = amountRemaining; ...}`

## Related Knowledge
- [[Accounting Model]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
