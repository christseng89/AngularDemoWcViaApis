---
knowledge_id: POSTING-RULE-024
title: "A row's FX rate is emitted on the wire as drBuyRate for DEBIT-side legs, crBuyRate for CREDIT-side legs — never both"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - accounting
  - confirmed
---

# POSTING-RULE-024 — A row's FX rate is emitted on the wire as drBuyRate for DEBIT-side legs, crBuyRate for CREDIT-side legs — never both

## Status
CONFIRMED

## Business Rule
emit() sets leg.drBuyRate when this.side === 'DEBIT' and leg.crBuyRate otherwise, for any row that needsRate().

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
No worked numeric example available in the source evidence reviewed.

## Verification Note
Directly confirmed by reading the exact emit() code this pass.

## Source Evidence
- src/app/payment-component/leg-allocator.component.ts emit() function, read directly: `if (this.side === 'DEBIT') leg.drBuyRate = r.rate.toFixed(6); else leg.crBuyRate = r.rate.toFixed(6);`

## Related Knowledge
- [[Accounting Model]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
