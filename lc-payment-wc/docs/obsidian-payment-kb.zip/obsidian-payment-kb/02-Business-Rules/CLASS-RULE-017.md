---
knowledge_id: CLASS-RULE-017
title: "FX Conversion Pair legs are identified purely by a GL-account naming convention, not an explicit pair id on the wire"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - classification
  - confirmed
---

# CLASS-RULE-017 — FX Conversion Pair legs are identified purely by a GL-account naming convention, not an explicit pair id on the wire

## Status
CONFIRMED

## Business Rule
Neither AccountEntry nor the wire response carries an explicit FX-pair identifier, so the UI infers which two legs form a pair by parsing the glAccount string pattern 'FX Exchange {ccy}' (optionally suffixed '- Suspense') via parseFxAccount(), then matching one leg's own currency against the other's referencedCurrency with opposite Dr/Cr indicators and matching Suspense-flag. An FX-named entry with no matching partner found is defensively dropped from display rather than causing a crash.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
No worked numeric example available in the source evidence reviewed.

## Verification Note
Read response-viewer.component.ts directly — parseFxAccount and the pairing loop match the description exactly, including the `if (!partner) continue;` defensive drop at line 202.

## Source Evidence
- src/app/payment-component/response-viewer.component.ts lines 51-59 (parseFxAccount) and lines 192-206 (the pairing loop)
- response-viewer.component.spec.ts 'an FX entry with no matching partner is defensively dropped rather than crashing'

## Related Knowledge
- [[Payment Instruction Classification]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
