---
knowledge_id: CLASS-RULE-006
title: "transactionCurrency (v1.10.0) — explicit wire field, independent of any leg's own currency — drives suspenseBridge FX classification and SWIFT instructedCurrency; falls back to debitLegs[0].currency only when omitted"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - classification
  - confirmed
---

# CLASS-RULE-006 — transactionCurrency (v1.10.0) — explicit wire field, independent of any leg's own currency — drives suspenseBridge FX classification and SWIFT instructedCurrency; falls back to debitLegs[0].currency only when omitted

## Status
CONFIRMED

## Business Rule
request.transactionCurrency, when present, is used as the deal's transaction currency for both suspenseBridge expansion (deciding whether a Suspense entry is same-currency or cross-currency, i.e. whether crossRate is required) and for the SWIFT message's instructedCurrency. Only when the field is omitted does the server fall back to inferring the transaction currency from debitLegs[0].currency (the pre-v1.10.0 behavior, which breaks when the debit side is entirely in a foreign currency).

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
debitLegs/creditLegs both JPY (10050/10000), transactionCurrency='USD', suspenseBridge.debitEntries=[{50,USD}] (no crossRate needed since USD matches transactionCurrency) -> swiftMessages[0].instructedCurrency='USD'.

## Verification Note
Re-read confirmPaymentInstruction.ts line 151 and the full cited test (lines 486-516) — code and test both confirm exactly the stated behavior including the worked JPY/USD example. No changes needed.

## Source Evidence
- microservices/payment-component/src/domain/confirmPaymentInstruction.ts line 151: `const transactionCurrency = request.transactionCurrency ?? request.debitLegs[0]!.currency;`
- test/unit/domain/confirmPaymentInstruction.test.ts describe('transactionCurrency (v1.10.0)') lines 486-516, 'drives suspenseBridge expansion and SWIFT instructedCurrency instead of debitLegs[0].currency — Full pay in JPY against a USD transaction'

## Related Knowledge
- [[Payment Instruction Classification]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
