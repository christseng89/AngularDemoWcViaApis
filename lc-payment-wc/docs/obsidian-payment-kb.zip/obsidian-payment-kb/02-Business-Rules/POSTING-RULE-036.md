---
knowledge_id: POSTING-RULE-036
title: "One SETTLEMENT Account Entry posted per submitted leg, unconditionally (FSD-doc-sourced; corroborates the code-sourced 'settlement-entry-per-leg-unconditional' rule above)"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - accounting
  - confirmed
---

# POSTING-RULE-036 — One SETTLEMENT Account Entry posted per submitted leg, unconditionally (FSD-doc-sourced; corroborates the code-sourced 'settlement-entry-per-leg-unconditional' rule above)

## Status
CONFIRMED

## Business Rule
One AccountEntry is generated per submitted leg (debit and credit), unconditionally — independent of whether the transaction classified as Payment Component related.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
len(accountEntries) == len(debitLegs)+len(creditLegs) after suspenseBridge expansion

## Example
No worked numeric example available in the source evidence reviewed.

## Verification Note
This is the FSD-doc-sourced restatement of the same fact already confirmed directly in code (see 'settlement-entry-per-leg-unconditional'); kept as a separate entry per the candidate list's own id_hint distinction, but effectively the same verified fact from two evidence sources.

## Source Evidence
- analysis__Payment-OAS-FSD-en.docx.txt §6.3 line 48; §7.4 line 63 (cited)
- Independently corroborated by direct code read of accountEntries.ts's buildSettlementEntries() this pass (see the code-sourced version of this rule above)

## Related Knowledge
- [[Accounting Model]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
