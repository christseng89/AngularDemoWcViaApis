---
knowledge_id: POSTING-RULE-037
title: "Voucher description code format {MODULE}{FuncCode}NULLNULLNULL{TypeChar} (FSD-doc-sourced; corroborates the code-sourced formula above)"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - accounting
  - confirmed
---

# POSTING-RULE-037 — Voucher description code format {MODULE}{FuncCode}NULLNULLNULL{TypeChar} (FSD-doc-sourced; corroborates the code-sourced formula above)

## Status
CONFIRMED

## Business Rule
Every leg's GL posting carries an assembled description code of the form {MODULE}{FuncCode}NULLNULLNULL{TypeChar}.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
AccountEntry.description / PaymentLeg.accountDesc

## Example
IPLC Pay/Accept debit leg → IPLC03NULLNULLNULLC

## Verification Note
Same underlying fact as the code-sourced 'voucher-desc-per-leg-formula' entry above, restated from FSD docs; kept separate per candidate id but effectively merged in substance.

## Source Evidence
- analysis__Payment-OAS-FSD-en.docx.txt §7.3 lines 33,61; analysis__PaymentComponent-Microservice-FSD-zh.docx.txt §3.2 line 51 (cited)
- Independently corroborated by direct code read of voucherDescription.ts's accountDescFor() this pass

## Related Knowledge
- [[Accounting Model]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
