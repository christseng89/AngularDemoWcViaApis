---
knowledge_id: CLASS-RULE-010
title: "The registry never offers RTGS as a selectable AccountType — RTGS routing is expressed purely via the rtgsLeg() helper, defaulting accountType to NOSTRO"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - classification
  - confirmed
---

# CLASS-RULE-010 — The registry never offers RTGS as a selectable AccountType — RTGS routing is expressed purely via the rtgsLeg() helper, defaulting accountType to NOSTRO

## Status
CONFIRMED

## Business Rule
No LegSpec ever offers 'RTGS' as a selectable accountType option, and any leg with defaultRtgsIndicator: true always defaults its accountType to 'NOSTRO'. RTGS-routed settlement (used only by the RPFM GAP cases in this registry) is represented purely via the rtgsLeg() helper, which sets accountType NOSTRO plus rtgsIndicator=true.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
rpfm-process-grantor's debit leg: rtgsLeg('DEBIT','RTGS-ACC','IDR','5000000') → accountType 'NOSTRO', rtgsIndicator true.

## Verification Note
Re-read business-case-registry.ts and business-case.model.ts directly — matches. This is largely the same underlying fact as the merged 'rtgs-modeled-as-nostro-flag' entry above but scoped specifically to the registry-level UI-selectability claim (candidate 11), so kept as its own entry rather than folded in, since its evidence and claim (no selectable option) is distinct from the classification-folding claim.

## Source Evidence
- src/app/payment-component/business-case-registry.ts lines 42-44 (rtgsLeg helper, doc comment)
- src/app/payment-component/business-case.model.ts line 12 (defaultRtgsIndicator doc comment)
- src/app/payment-component/business-case-registry.spec.ts 'no leg offers RTGS as a selectable AccountType' and 'every RTGS-flagged leg defaults to accountType NOSTRO'

## Related Knowledge
- [[Payment Instruction Classification]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
