---
knowledge_id: API-RULE-015
title: "C-2 — payload-aware idempotency: same natural key + DIFFERENT request payload returns 409 IDEMPOTENCY_KEY_CONFLICT instead of silently replaying the original stored result; an identical resend still replays with 200"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - api
  - confirmed
---

# API-RULE-015 — C-2 — payload-aware idempotency: same natural key + DIFFERENT request payload returns 409 IDEMPOTENCY_KEY_CONFLICT instead of silently replaying the original stored result; an identical resend still replays with 200

## Status
CONFIRMED

## Business Rule
A repeat POST on the same natural key but with a DIFFERENT request payload returns 409 IDEMPOTENCY_KEY_CONFLICT instead of silently replaying the original result; an identical resend still replays with 200. A canonical request fingerprint (SHA-256) is stored as a system/control field alongside the instruction (the OAS response body itself is unchanged). The related concurrency race (H-1) is closed at the DB layer via UNIQUE(origin_module, main_ref, sequence) plus an atomic upsert comparing the fingerprint (this DB-layer closure is itself a documented recommendation, not something directly verifiable in the in-memory-store implementation this repo actually ships).

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
200 replay (identical payload) / 409 IDEMPOTENCY_KEY_CONFLICT (different payload) / 201 (new key)

## Example
No worked numeric example available in the source evidence reviewed.

## Verification Note
Merged two near-identical candidate rules ('idempotency-payload-fingerprint-conflict-c2' from fsd-architecture-docs and 'c2-payload-aware-idempotency' from validation-gap-docs) — both quote the exact same source sentence verbatim from two different converted docs. Went further than the original candidates by re-reading confirmPaymentInstruction.ts directly and confirming the 409 IDEMPOTENCY_KEY_CONFLICT throw is actually implemented in code (lines 128-137), not just documented in the FSD/validation docs — upgrading this from a doc-only claim to code-verified. Status stays CONFIRMED, now on stronger (code + test-adjacent) evidence.

## Source Evidence
- converted/analysis__Payment-OAS-FSD-en.docx.txt Appendix B, C-2/H-1 (re-read directly at lines 133 and again at line 374 of the Calculation_Validation doc — identical wording): 'a repeat POST on the same natural key ... with a DIFFERENT request payload now returns 409 IDEMPOTENCY_KEY_CONFLICT instead of silently replaying the original; an identical resend still replays (200)'
- converted/analysis__Payment_Component_Calculation_Validation.docx.txt 'Spec Sync — 2026-08 Hardening Review' C-2 (line 374, word-for-word same text as the FSD doc)
- microservices/payment-component/src/domain/confirmPaymentInstruction.ts: fingerprint computed via requestFingerprint(request) (line 111); priorFingerprint comparison and `throw new BusinessValidationError('IDEMPOTENCY_KEY_CONFLICT', ...)` (lines 128-137) directly confirms this is actually implemented, not just documented

## Related Knowledge
- [[Payment Instructions API]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
