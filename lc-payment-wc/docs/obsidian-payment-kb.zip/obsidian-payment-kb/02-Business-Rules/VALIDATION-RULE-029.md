---
knowledge_id: VALIDATION-RULE-029
title: "Suspense entry Amount is force-normalized from a runtime JS number back to a string before emission"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - validation
  - confirmed
---

# VALIDATION-RULE-029 — Suspense entry Amount is force-normalized from a runtime JS number back to a string before emission

## Status
CONFIRMED

## Business Rule
The Amount <input type="number"> bound via ngModel goes through Angular's NumberValueAccessor, which writes an actual JS number into row.amount at runtime despite SuspenseEntry.amount being typed string. emit() calls String(amount) on every row before emitting so downstream consumers can trust the value is genuinely a string — a bare JS number sent as JSON would fail the microservice's MonetaryAmount zod pattern with 'Expected string, received number'.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
n/a — type-coercion fix, verified via cited spec test.

## Verification Note
Confirmed exactly by direct read of suspense-entries.component.ts lines 82-101.

## Source Evidence
- src/app/payment-component/suspense-entries.component.ts lines 82-101 (doc comment and emit() implementation, `String(amount)`)
- suspense-entries.component.spec.ts 'normalizes a real JS number (as NumberValueAccessor writes for input[type=number]) back to a string on emit'

## Related Knowledge
- [[Request Validation]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
