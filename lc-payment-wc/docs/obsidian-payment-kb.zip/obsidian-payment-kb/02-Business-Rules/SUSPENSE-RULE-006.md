---
knowledge_id: SUSPENSE-RULE-006
title: "v1.9.0's netting is deliberately NOT applied to a creditEntries bucket — a same-currency real credit leg is treated as an independent exposure, not 'the same money', so up to TWO independent gross-sized FX pairs are generated instead of one netted pair"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - suspense
  - confirmed
---

# SUSPENSE-RULE-006 — v1.9.0's netting is deliberately NOT applied to a creditEntries bucket — a same-currency real credit leg is treated as an independent exposure, not 'the same money', so up to TWO independent gross-sized FX pairs are generated instead of one netted pair

## Status
CONFIRMED

## Business Rule
For a foreign-currency creditEntries bucket, TWO independent, gross-sized, self-balancing FX pairs are generated unconditionally: (1) a Suspense-anchored pair sized to the bucket's own itemized Suspense legs' total, always suffixed ' - Suspense'; (2) if a matching-currency real credit leg exists, a separate, unsuffixed 'Leg' pair sized to that leg's own submitted total. These two pairs are never netted against each other. A real Nostro settlement leg that happens to share a currency with a Charge/Balance Component's Suspense-Credit bridge amount is a genuinely independent exposure (both land CREDIT), so netting would silently break per-currency balance even though it would remain aggregate-V8-safe.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
Suspense Credit EUR 200 + real Credit Leg EUR 100 -> Suspense-anchored pair (216.62) and Leg-anchored pair (108.31) both generated independently, neither netted; full aggregate V8 check confirms balance both in aggregate and per currency.

## Verification Note
Read the full CREDIT-side branch (lines 374-397) and the full 'v1.8.0 CREDIT side' test describe block including the worked EUR100+EUR100 example with its aggregate V8 sum assertion. Confirmed exactly as stated. Status unchanged: CONFIRMED.

## Source Evidence
- suspenseBridge.ts lines 70-76 (top doc comment), 341-397 (expandSuspenseBridge's CREDIT-side branch and its own inline doc comment explaining why netting is unsafe here)
- suspenseBridge.test.ts lines 259-317 'v1.8.0 CREDIT side... reviewer-confirmed EUR100+EUR100 scenario', 4 tests including the full aggregate-and-per-currency V8 balance proof

## Related Knowledge
- [[Suspense Account]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
