---
knowledge_id: POSTING-RULE-023
title: "A change to the Total Amount HEADER field (not a per-leg edit) absorbs entirely into the LAST row, a distinct mechanism from the per-leg waterfall"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - accounting
  - confirmed
---

# POSTING-RULE-023 — A change to the Total Amount HEADER field (not a per-leg edit) absorbs entirely into the LAST row, a distinct mechanism from the per-leg waterfall

## Status
CONFIRMED

## Business Rule
When totalAmount changes and the side is fully amount-driven, absorbTotalDeltaIntoLastRow() resolves the gap: an INCREASE adds the full delta directly to the last row only; a DECREASE subtracts from the last row and cascades backward if insufficient, capped at 0 per row.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
Rows 3000/3000/4000 (10000 total). Total header raised to 13000: only the last row changes, 4000->7000.

## Verification Note
Function's existence and general wiring corroborated by grep of the file (amountRemaining/ensureRemainderRow context read directly), but the absorbTotalDeltaIntoLastRow() body itself was not independently re-opened this pass. Given the very detailed, self-consistent, and testable description in CLAUDE.md's own confirmed-decisions log (which this KB treats as reviewer-confirmed ground truth per the system prompt), and no contradicting evidence found, kept CONFIRMED rather than downgraded.

## Source Evidence
- leg-allocator.component.ts absorbTotalDeltaIntoLastRow() doc comment and body (cited, not independently re-opened this pass — grep confirmed the function exists and is called from onTotalChange, but full body not read line-by-line)
- spec.ts 'onTotalChange absorbs into the LAST row when fully amount-driven (v1.12.2)' (cited)

## Related Knowledge
- [[Accounting Model]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
