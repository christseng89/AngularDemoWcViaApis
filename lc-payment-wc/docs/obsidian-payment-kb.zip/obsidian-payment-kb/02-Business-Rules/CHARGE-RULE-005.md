---
knowledge_id: CHARGE-RULE-005
title: "Export LC Confirming Commission is charged per quarter of tenor (rounded up), applied to the tolerance-adjusted LC balance, with a TWD 1,000 minimum"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - charges
  - confirmed
---

# CHARGE-RULE-005 — Export LC Confirming Commission is charged per quarter of tenor (rounded up), applied to the tolerance-adjusted LC balance, with a TWD 1,000 minimum

## Status
CONFIRMED

## Business Rule
The Confirming Commission (B2) is computed on 'LC Balance' = LC Amount × (1 + Tolerance%), at a rate expressed per 90-day quarter, with tenor converted to quarters via ceiling division (Math.ceil(tenorDays/90)) — any partial quarter, even 1 day into a new 90-day block, is billed as a full additional quarter. A TWD 1,000 minimum commission floor applies (MIN_COMM, shared with A1 — see the merged minimum-fee-constants rule below).

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
Default form: LC Amount 500,000 USD, tolerance 0%, tenorDays 90 → quartersPreview = Math.ceil(90/90) = 1 quarter; confRate 0.2% applied once to the LC Balance. Server: quarters=Math.ceil(tenorDays/90); rawTwd=lcBalance*r*(confRate/100)*quarters; confCommTwd=Math.max(rawTwd, MIN_COMM=1000).

## Verification Note
Merged with candidate #8 ('confirming-commission-charged-per-quarter-ceiling'), which is a near-duplicate covering only the server-side half of this same rule (the Math.ceil(tenorDays/90) quarter-ceiling mechanic). Kept this fuller statement (UI + server + LC Balance base + TWD1000 floor) as the merged rule; both original evidence sets folded in. Re-verified all citations against source — accurate.

## Source Evidence
- lc-confirmed.element.ts line 66 (quartersPreview = Math.ceil(f.tenorDays / 90))
- lc-confirmed.element.ts lines 101-106 (summary rendering: 'LC Balance...', 'Confirming Rate ... per quarter', 'Min Applied? Yes (min TWD 1,000)')
- backend/server.js lines 516-524 (app.post /api/export/confirmed/calc: lcBalance, quarters=Math.ceil(tenorDays/90), rawTwd, confCommTwd=Math.max(rawTwd, MIN_COMM))

## Related Knowledge
- [[Charge Integration]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
