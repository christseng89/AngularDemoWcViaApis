---
knowledge_id: ARCH-RULE-028
title: "RPFM is a partial-integration case: data model classified correctly but never wired to Confirm-time posting"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - architecture
  - confirmed
---

# ARCH-RULE-028 — RPFM is a partial-integration case: data model classified correctly but never wired to Confirm-time posting

## Status
CONFIRMED

## Business Rule
All four RPFM Confirm functions (Process Grantor, Repay Grantor, Process Participant, Settle Participant) correctly populate classified Debit/Credit legs (including RPFM-specific RTGS/rtgsIndicator) during the screen's onChange lifecycle, but their ConfirmBusinessCall never calls a voucher-description-assembly / Payment Component posting routine. This is a documented GAP, not a defect. For 3 of the 4 functions, a deeper trace found NO other posting mechanism exists in the legacy baseline for the funded/real-money case either — a genuine gap in the legacy system itself, independent of Payment Component integration; only Process Grantor's event is confirmed fully posted today via a separate working non-Payment-Component voucher template.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
RPFM functions classified as GAP (process only) — schema-ready, Confirm-time integration missing

## Example
No worked numeric example available in the source evidence reviewed.

## Verification Note
Confirmed directly, with additional detail recovered (which specific function is/isn't posted) beyond the original summary. Unchanged in substance.

## Source Evidence
- converted/analysis__Payment-OAS-FSD-en.docx.txt §8 RPFM section, lines 109-114, directly re-read: confirms all 4 functions, the RTGS detail, the GAP-not-defect framing, and the per-function posting-mechanism trace (Process Grantor fully posted; Repay Grantor/Process Participant/Settle Participant apparently have no working mechanism)

## Related Knowledge
- [[Payment Architecture]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
