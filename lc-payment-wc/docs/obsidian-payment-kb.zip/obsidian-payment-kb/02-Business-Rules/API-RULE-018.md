---
knowledge_id: API-RULE-018
title: "SwiftMessage schema has materially diverged between the two OAS files despite both claiming to be 'kept in lockstep' — Payment_component.yaml is stale relative to payment-instructions-post.yaml"
domain: Payment
category: Business Rule
status: CONFLICT
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - api
  - conflict
---

# API-RULE-018 — SwiftMessage schema has materially diverged between the two OAS files despite both claiming to be 'kept in lockstep' — Payment_component.yaml is stale relative to payment-instructions-post.yaml

## Status
CONFLICT

## Business Rule
Payment_component.yaml's description explicitly states component schemas are 'kept in lockstep' with payment-instructions-post.yaml, with the latter authoritative for anything both define. In practice, the two files' SwiftMessage schemas have diverged: payment-instructions-post.yaml has an additional field, instructedCurrency ('field 33B currency ... Added v-H3: distinct from settlementCurrency for a cross-currency payment (32A != 33B)'), and its settlementAmount/instructedAmount descriptions note 'No longer forced equal to 32A (H-3)'. Payment_component.yaml's SwiftMessage schema has NEITHER the instructedCurrency field NOR any H-3 note on settlementAmount/instructedAmount, despite both files declaring the same version (1.10.1). This means Payment_component.yaml's GET endpoints (only defined there) return a PaymentInstruction whose embedded SwiftMessage shape is out of date relative to the more current schema in payment-instructions-post.yaml.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
No worked numeric example available in the source evidence reviewed.

## Conflict Note
> [!warning] Sources disagree
> Re-read both OAS files' SwiftMessage schemas directly via targeted grep and confirmed the exact divergence: Payment_component.yaml (lines 854-878) has only settlementAmount/instructedAmount with plain field-33B/32A descriptions and no H-3/instructedCurrency mention anywhere; payment-instructions-post.yaml (lines 902-927) has the added instructedCurrency field and explicit 'Added v-H3'/'No longer forced equal to 32A (H-3)' notes. The CONFLICT status is confirmed as genuinely load-bearing, not merely cosmetic — a client relying on the 'authoritative' Payment_component.yaml GET-endpoint schemas would be unaware of the instructedCurrency field that payment-instructions-post.yaml (and, per the H-3 rule elsewhere in this domain list, the actual server implementation) both use. Status unchanged: CONFLICT.

## Verification Note
Re-read both OAS files' SwiftMessage schemas directly via targeted grep and confirmed the exact divergence: Payment_component.yaml (lines 854-878) has only settlementAmount/instructedAmount with plain field-33B/32A descriptions and no H-3/instructedCurrency mention anywhere; payment-instructions-post.yaml (lines 902-927) has the added instructedCurrency field and explicit 'Added v-H3'/'No longer forced equal to 32A (H-3)' notes. The CONFLICT status is confirmed as genuinely load-bearing, not merely cosmetic — a client relying on the 'authoritative' Payment_component.yaml GET-endpoint schemas would be unaware of the instructedCurrency field that payment-instructions-post.yaml (and, per the H-3 rule elsewhere in this domain list, the actual server implementation) both use. Status unchanged: CONFLICT.

## Source Evidence
- analysis/Payment_component.yaml: info.description scope note (lines 17-29) claiming lockstep; SwiftMessage schema (lines 854-878) — confirmed directly re-read: `settlementAmount` (873) and `instructedAmount` (874) present, NO instructedCurrency field, NO H-3 mention anywhere in the schema
- analysis/payment-instructions-post.yaml: SwiftMessage schema (lines 902-927) — confirmed directly re-read: `instructedCurrency` (line 922, 'Added v-H3: distinct from settlementCurrency for a cross-currency payment (32A != 33B)') and 'No longer forced equal to 32A (H-3)' on instructedAmount (line 923)

## Related Knowledge
- [[Payment Instructions API]]
- [[Business-Rule-Index]]
- [[Knowledge-Gaps]]
- [[Payment-Traceability-Matrix]]
