---
knowledge_id: UI-RULE-014
title: "Settlement Vouchers Posting View re-groups raw wire entries into a fixed audit-readable section order"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - ui
  - confirmed
---

# UI-RULE-014 — Settlement Vouchers Posting View re-groups raw wire entries into a fixed audit-readable section order

## Status
CONFIRMED

## Business Rule
groupedSettlementEntries reorders the flat, as-received AccountEntry[] into a fixed sequence: Customer/Debit Legs, then each FX Leg Pair / FX Suspense Pair as an adjacent Dr/Cr block, then Settlement/Credit Legs, then Suspense Clearing last. This is purely a client-side re-grouping for readability — it never mutates accountEntries or the underlying wire response, and no accounting entry is regenerated.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
Section order: ['Customer / Debit Legs', 'FX Debit Leg Pair', 'FX Debit Suspense Pair', 'FX Credit Suspense Pair', 'FX Credit Leg Pair', 'Settlement / Credit Legs', 'Suspense Clearing']

## Verification Note
Confirmed exactly — section-push order in source matches the claimed sequence verbatim.

## Source Evidence
- response-viewer.component.ts lines 141-237 (v1.8.1 doc comment and implementation) — section push order at lines 228-235: Customer/Debit Legs, FX Debit Leg Pair, FX Debit Suspense Pair, FX Credit Suspense Pair, FX Credit Leg Pair, Settlement/Credit Legs, Suspense Clearing

## Related Knowledge
- [[Payment Component Simulator UI]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
