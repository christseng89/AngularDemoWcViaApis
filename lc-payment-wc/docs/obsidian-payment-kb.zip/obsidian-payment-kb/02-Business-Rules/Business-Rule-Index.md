---
knowledge_id: Business-Rule-Index
title: "Business Rule Index"
domain: Payment
category: Index
snapshot_date: 2026-08-22
tags:
  - payment
  - index
---

# Business Rule Index

304 traceable business rules extracted and adversarially verified from the LC Payment Component repository (288 CONFIRMED, 5 INFERRED, 11 CONFLICT). 89 additional items — UNCLEAR rules, cross-source conflicts, and verification-flagged gaps — are catalogued in [[Knowledge-Gaps]] instead of getting a standalone rule file.

See also: [[Payment-Traceability-Matrix]], [[Payment Component Overview]], [[Payment-Knowledge-Home]].

> [!note] Domain grouping note
> The `CONFLICT` and `Other` sections below preserve the exact domain tag an extraction/verification agent assigned when a rule didn't cleanly fit one of the eleven primary domains. Their rule IDs were still filed under a sensible prefix (`CLASS-RULE-*` for the RTGS/AccountType schema-evolution conflict, `ARCH-RULE-*` for the `Other`-tagged items) so they remain fully cross-linked from [[Payment Instruction Classification]] / [[Payment Architecture]] — this section header is a provenance label, not a second taxonomy.

## API (20)

See also: [[Payment Instructions API]]

| ID | Title | Status |
|---|---|---|
| [[API-RULE-001]] | enrichLegs computes exactly four server-derived fields per submitted leg (legId, legSide, accountDesc, accountCategory) and otherwise passes the caller's leg input through unchanged | ✅ CONFIRMED |
| [[API-RULE-002]] | dryRun:true is a preview mode that skips both idempotency lookup and persistence and always returns HTTP 200, even for a brand-new natural key | ✅ CONFIRMED |
| [[API-RULE-003]] | sourceFunctionCode / voucherCodePrefixOverride / dryRun are accepted alongside the strict OAS body but are NOT part of the formal validated schema | ✅ CONFIRMED |
| [[API-RULE-004]] | POST /payment-instructions/classify is an unofficial, non-OAS preview endpoint requiring BOTH debitLegs and creditLegs to be non-empty (stricter than the confirm endpoint) | ✅ CONFIRMED |
| [[API-RULE-005]] | GET /payment-instructions?originModule=<invalid> is silently treated as 'no filter' rather than a 400 | ✅ CONFIRMED |
| [[API-RULE-006]] | account-entries and swift-messages are read-only sub-resources of a persisted PaymentInstruction, never independently queryable, and 404 identically to the parent when the id is unknown | ✅ CONFIRMED |
| [[API-RULE-007]] | Resubmitting a Confirm request with the same natural key (originModule+mainRef+sequence) is a no-op replay returning 200 with the same instructionId, not a new 201 | ✅ CONFIRMED |
| [[API-RULE-008]] | dryRun=true always recomputes fresh and never touches the persistence store, even when reusing the same natural key across multiple dryRun calls | ✅ CONFIRMED |
| [[API-RULE-009]] | The /payment-instructions/classify preview endpoint never throws on an unbalanced or otherwise invalid Dr/Cr pairing — it always returns 200 with classification + balance + account-entry results | ✅ CONFIRMED |
| [[API-RULE-010]] | runPreview() always calls the API with dryRun:true; the explicit Confirm button click always calls with dryRun:false (persists) — the same endpoint serves both, distinguished only by this request-body flag | ✅ CONFIRMED |
| [[API-RULE-011]] | All confirm()/classify() HTTP errors are normalized into a single PaymentComponentApiError with a flat human-readable message, regardless of backend error shape | ✅ CONFIRMED |
| [[API-RULE-012]] | GET /api/currencies is guaranteed by the startup guard to be exactly the set of currencies every FX calculator can successfully rate against TWD | 🟡 INFERRED |
| [[API-RULE-013]] | POST /payment-instructions is a single atomic create+classify+post+message endpoint, replacing an earlier multi-call draft design (header-create/per-leg-add/classify-preview/confirm) | ✅ CONFIRMED |
| [[API-RULE-014]] | Idempotency key = (originModule, mainRef, sequence); a resubmission with the identical natural key replays the ORIGINAL result unchanged (200), a new key creates a new instruction (201); sequence is required specifically because a partial payment against the same transaction must not be misidentified as a resubmission | ✅ CONFIRMED |
| [[API-RULE-015]] | C-2 — payload-aware idempotency: same natural key + DIFFERENT request payload returns 409 IDEMPOTENCY_KEY_CONFLICT instead of silently replaying the original stored result; an identical resend still replays with 200 | ✅ CONFIRMED |
| [[API-RULE-016]] | GET /payment-routing is a documented but entirely unimplemented aspirational endpoint | ✅ CONFIRMED |
| [[API-RULE-017]] | All four GET endpoints are read-only inquiry/audit lookups, explicitly NOT part of the confirm flow | ✅ CONFIRMED |
| [[API-RULE-018]] | SwiftMessage schema has materially diverged between the two OAS files despite both claiming to be 'kept in lockstep' — Payment_component.yaml is stale relative to payment-instructions-post.yaml | ⚠️ CONFLICT |
| [[API-RULE-019]] | IWGT Settle Inward Claim's Liability Voucher condition (method of issuance) has no representation in the OAS request schema | ✅ CONFIRMED |
| [[API-RULE-020]] | Multiple CUSTOMER legs on one side (e.g. margin from a separate account) require no new server or OAS capability — the wire contract already supports arrays | ✅ CONFIRMED |

## Accounting (47)

See also: [[Accounting Model]]

| ID | Title | Status |
|---|---|---|
| [[POSTING-RULE-001]] | M-7: exact Dr=Cr balance (zero tolerance) required for EVERY originModule including RPFM — legacy ±0.01 RPFM slack removed | ✅ CONFIRMED |
| [[POSTING-RULE-002]] | Charge Voucher (§6.2) and Liability Voucher (§6.3) generation were removed entirely in v1.6.0 — this service posts ONLY Settlement entries (merged with duplicate 'charge-liability-voucher-removed-v160') | ✅ CONFIRMED |
| [[POSTING-RULE-003]] | Settlement Vouchers leg ordering places the FX Exchange pair adjacent, between normal debits/credits, for accounting-review readability (v1.7.1), superseded/matches 'fx-pair-ordering-adjacent-block' | ✅ CONFIRMED |
| [[POSTING-RULE-004]] | exchangeRate1 is echoed on accountEntries for FX-rated legs (both suspenseBridge-generated FX pairs and caller's own foreign-currency legs, v1.11.0); exchangeRate2 is deliberately left unset | ✅ CONFIRMED |
| [[POSTING-RULE-005]] | One Settlement AccountEntry per submitted leg, generated unconditionally (merged with 'account-entry-unconditional-per-leg') | ✅ CONFIRMED |
| [[POSTING-RULE-006]] | Settlement entry amount prefers amountAccountCcy over amountTxCcy | ✅ CONFIRMED |
| [[POSTING-RULE-007]] | formatMonetaryAmount rounds to a given currency scale using ROUND_HALF_UP; omitting scale leaves existing precision untouched | ✅ CONFIRMED |
| [[POSTING-RULE-008]] | Transaction direction is expressed exclusively via the Dr/Cr side, never via a negative amount sign — the only exception is the server-computed FX Exchange side-swap | ✅ CONFIRMED |
| [[POSTING-RULE-009]] | Summing monetary amounts uses exact decimal arithmetic with no floating-point drift | ✅ CONFIRMED |
| [[POSTING-RULE-010]] | Settlement entry amount is parsed/re-formatted with NO scale override — preserves the input leg string's own precision rather than forcing a fixed 2dp | ✅ CONFIRMED |
| [[POSTING-RULE-011]] | A Suspense entry that resolves to a zero amount (before or after FX conversion/rounding) produces no leg at all — never a zero-value posting | ✅ CONFIRMED |
| [[POSTING-RULE-012]] | Multiple Suspense entries in the same currency stay individually itemized legs — never merged into one combined posting | ✅ CONFIRMED |
| [[POSTING-RULE-013]] | Voucher description (accountDesc) = fixed per-function code prefix + single TypeChar derived from the leg's own accountType (merged with 'voucher-description-formula' and 'voucher-desc-code-assembly') | ✅ CONFIRMED |
| [[POSTING-RULE-014]] | The voucher code prefix is keyed by (originModule, sourceFunctionCode) pair, not by originModule alone | ✅ CONFIRMED |
| [[POSTING-RULE-015]] | Two FSD rows (EPLC Pay/Accept, EXCO Settlement at Maturity) record TWO possible voucher prefixes without stating the selecting condition — deliberately left unresolved, requiring caller override | ✅ CONFIRMED |
| [[POSTING-RULE-016]] | creditLegs may be empty ONLY when suspenseBridge will itself contribute a credit-direction leg (v1.10.0 fee-collection pattern) | ✅ CONFIRMED |
| [[POSTING-RULE-017]] | AccountEntry.exchangeRate1/exchangeRate2 exist in both OAS files with no field-level description of their meaning or population source | ✅ CONFIRMED |
| [[POSTING-RULE-018]] | Suspense-adjustment summation uses arbitrary-precision Decimal end-to-end, not plain JS number arithmetic, to avoid IEEE-754 ULP drift in the wire amount | ✅ CONFIRMED |
| [[POSTING-RULE-019]] | A Confirm click that hits an existing (originModule, mainRef, sequence) key is shown to the user as an idempotent REPLAY, not a fresh recompute, per FSD §6.1 | ✅ CONFIRMED |
| [[POSTING-RULE-020]] | Mixed-Payment-LC style leg splitting: Amount = Total × Percent ÷ 100 | ✅ CONFIRMED |
| [[POSTING-RULE-021]] | Rows always sum to exactly 100% / the exact Total Amount via one auto-computed remainder row; remainder routing is decided by AMOUNT (exact), not by % (which can drift under repeating fractions) | ✅ CONFIRMED |
| [[POSTING-RULE-022]] | Once every row is amount-driven (no floating remainder), the LAST row's displayed % is forced to the exact complement, not independently rounded | ✅ CONFIRMED |
| [[POSTING-RULE-023]] | A change to the Total Amount HEADER field (not a per-leg edit) absorbs entirely into the LAST row, a distinct mechanism from the per-leg waterfall | ✅ CONFIRMED |
| [[POSTING-RULE-024]] | A row's FX rate is emitted on the wire as drBuyRate for DEBIT-side legs, crBuyRate for CREDIT-side legs — never both | ✅ CONFIRMED |
| [[POSTING-RULE-025]] | amountTxCcy is always denominated in the deal's Transaction Currency, never the row's own currency — the single field the wire/%-split/V8-balance math all operate on | ✅ CONFIRMED |
| [[POSTING-RULE-026]] | Currency minor-unit decimal places (decimals()) are the single source of truth for currency-correct rounding of computed amounts | ✅ CONFIRMED |
| [[POSTING-RULE-027]] | Currency View's Balanced/Unbalanced flag is computed at each currency's own minor-unit precision using Decimal arithmetic, never native float equality | ✅ CONFIRMED |
| [[POSTING-RULE-028]] | The FX overlay and any real server-generated FX leg pair are contractually never both shown for the same currency, but this component does not itself enforce that dedup | ✅ CONFIRMED |
| [[POSTING-RULE-029]] | Journal Entry viewer enforces Debit=Credit balance in TWD (functional currency), with a sub-1-TWD rounding tolerance | ✅ CONFIRMED |
| [[POSTING-RULE-030]] | LC margin pledge is always held and released in the LC's own transaction currency, regardless of what currency the customer actually pays other charges in | ✅ CONFIRMED |
| [[POSTING-RULE-031]] | 'Charge embedding' rule: a pass-through/fee charge denominated in the SAME currency as the customer's main settlement (Cr CA) leg is netted directly into that leg instead of being booked as its own separate Dr CA entry | ✅ CONFIRMED |
| [[POSTING-RULE-032]] | All monetary amounts and FX rates are exact decimal strings, never binary floats — server arithmetic must use BigDecimal | ✅ CONFIRMED |
| [[POSTING-RULE-033]] | Monetary amount decimal scale (minor units) is currency-driven, not fixed at 2dp | ✅ CONFIRMED |
| [[POSTING-RULE-034]] | debitEntries genuinely NET against same-currency real debitLegs (opposite polarity); creditEntries only ever COMBINE with same-currency real creditLegs (same polarity) — deliberate, not a bug | ✅ CONFIRMED |
| [[POSTING-RULE-035]] | CONFLICT: zh FSD (v1.2.0 OAS) describes THREE parallel voucher streams (Settlement/Charge/Liability) still live; en FSD (v1.8.0 OAS) and the actual current source code state Charge/Liability generation was removed entirely in v1.6.0 — current implementation matches the en FSD / code, not the zh FSD | ⚠️ CONFLICT |
| [[POSTING-RULE-036]] | One SETTLEMENT Account Entry posted per submitted leg, unconditionally (FSD-doc-sourced; corroborates the code-sourced 'settlement-entry-per-leg-unconditional' rule above) | ✅ CONFIRMED |
| [[POSTING-RULE-037]] | Voucher description code format {MODULE}{FuncCode}NULLNULLNULL{TypeChar} (FSD-doc-sourced; corroborates the code-sourced formula above) | ✅ CONFIRMED |
| [[POSTING-RULE-038]] | A GAP verdict (no Payment-Component voucher call) does not imply the underlying accounting event goes unposted in the real system | ✅ CONFIRMED |
| [[POSTING-RULE-039]] | Suspense currency bucket seed totals round PER ENTRY, not once on the combined amount — deliberately, to match the server | ✅ CONFIRMED |
| [[POSTING-RULE-040]] | Account Ccy Equivalent and Amount (Tx Ccy) are independently-typed, never re-derived from each other's rounded value ('B-Tree' banking math principle) | ✅ CONFIRMED |
| [[POSTING-RULE-041]] | All monetary arithmetic is funneled through a single decimal.js choke point (money.ts) — never IEEE-754 floating point | ✅ CONFIRMED |
| [[POSTING-RULE-042]] | Charge Component vs Payment Component boundary is cleanly separated via the Suspense-Credit clearing account — no duplicated charge posting | ✅ CONFIRMED |
| [[POSTING-RULE-043]] | Per-currency balance is hard-enforced via the FX Exchange account as a self-balancing pair — an earlier finding that this was ungoverned was withdrawn | ✅ CONFIRMED |
| [[POSTING-RULE-044]] | The Suspense Debit/Suspense Credit entries UI is explicitly a Simulator-only modeling extension, NOT sourced from the FSD | ✅ CONFIRMED |
| [[POSTING-RULE-045]] | suspenseBridge.debitEntries vs creditEntries: both always generate a credit-direction leg; the choice depends on which real leg the charge is conceptually netted against | ✅ CONFIRMED |
| [[POSTING-RULE-046]] | Proposed Export LC Usance Negotiation (Use Case 4) conflicts in direction with the already-registered eplc-discount case | ⚠️ CONFLICT |
| [[POSTING-RULE-047]] | sourceComponent tagging (CHARGE vs BALANCE) for Nego-style discount/interest is ambiguous by precedent between two parts of the codebase | ⚠️ CONFLICT |

## Architecture (41)

See also: [[Payment Architecture]]

| ID | Title | Status |
|---|---|---|
| [[ARCH-RULE-001]] | Confirm flow executes in a fixed, FSD-traced step order with suspenseBridge expansion inserted before balance validation | ✅ CONFIRMED |
| [[ARCH-RULE-002]] | previewClassification produces only the Settlement Account Entry stream — no Charge, Liability, or SWIFT streams — because RPFM has no traceable voucher-assembly path in source | ✅ CONFIRMED |
| [[ARCH-RULE-003]] | previewClassification generates a clearly-namespaced, non-persisted 'preview-' prefixed ID on every call, distinct from a real instructionId | ✅ CONFIRMED |
| [[ARCH-RULE-004]] | Payment Component never generates Charge Voucher (§6.2) / Liability Voucher (§6.3) postings, and never calculates or posts individual charge lines — a clean, permanent v1.6.0 architecture boundary with the Charge Component | ✅ CONFIRMED |
| [[ARCH-RULE-005]] | buildSettlementEntries accepts a raw PaymentLegInput (accountDesc optional) so it can be reused for RPFM classify-only preview | ✅ CONFIRMED |
| [[ARCH-RULE-006]] | All wire monetary/rate strings must be parsed via money.ts's Decimal-based parser — the sole allowed choke point for constructing a Decimal from a wire string | ✅ CONFIRMED |
| [[ARCH-RULE-007]] | The suspense bridge module only ever ADDS Suspense/FX legs — it never modifies a caller's own submitted debitLegs/creditLegs amounts | ✅ CONFIRMED |
| [[ARCH-RULE-008]] | The FX pair generation strategy evolved through three iterations (v1.7.0/1 combined-pair -> v1.8.0 per-source independent pairs -> v1.9.0 DEBIT-side netting), each fixing a specific rounding/decorative-line defect the prior approach had | ✅ CONFIRMED |
| [[ARCH-RULE-009]] | GAP: the voucher-prefix-selecting function/screen identifier (sourceFunctionCode) is NOT part of the official OAS request body — must be supplied out-of-band | ✅ CONFIRMED |
| [[ARCH-RULE-010]] | Idempotency key is the composite natural key (originModule, mainRef, sequence) — the CURRENT implementation, distinct from the planned bankContractRef/eventSeq design | ✅ CONFIRMED |
| [[ARCH-RULE-011]] | Any non-ApiError thrown deep in the stack is masked as a generic 500, never leaked to the client | ✅ CONFIRMED |
| [[ARCH-RULE-012]] | The default payment instruction store is an in-memory Map — explicitly documented as demonstration/testing-only, unsafe for production or multi-instance deployment | ✅ CONFIRMED |
| [[ARCH-RULE-013]] | Every non-N_A business case is modeled as exactly one fixed Debit leg and one fixed Credit leg, not a dynamic repeater | ✅ CONFIRMED |
| [[ARCH-RULE-014]] | Dedicated Liability/Charge Voucher context Formly panels were removed from the header-fields builder in v1.6.0 | ✅ CONFIRMED |
| [[ARCH-RULE-015]] | Any edit to the header form, leg allocators, or Suspense entries triggers a single shared 400ms-debounced live recompute (dryRun preview or classify) | ✅ CONFIRMED |
| [[ARCH-RULE-016]] | Selecting a business case (or module) fully resets every derived/transient piece of state so nothing leaks across cases | ✅ CONFIRMED |
| [[ARCH-RULE-017]] | The component only hard-resets to a single 100% row on a genuine business-case switch (caseKey change), never on a same-case re-seed of Total Amount/Currency | ✅ CONFIRMED |
| [[ARCH-RULE-018]] | FxRateService deliberately reuses the pre-existing GET /api/fx/rates endpoint rather than introducing a new FX data source | ✅ CONFIRMED |
| [[ARCH-RULE-019]] | payment-component.types.ts is a deliberately independent duplicate of the microservice's own types.ts, not a shared/imported module | ✅ CONFIRMED |
| [[ARCH-RULE-020]] | The Charge Voucher / Liability Voucher UI sections likely never render any data in the current architecture | 🟡 INFERRED |
| [[ARCH-RULE-021]] | Suspense entry rows deliberately carry no Account No./Account Type/percentage fields, unlike leg-allocator's rows | ✅ CONFIRMED |
| [[ARCH-RULE-022]] | LC web components call a separate legacy mock API, not the Payment Component microservice | ✅ CONFIRMED |
| [[ARCH-RULE-023]] | The /api/currencies ('Get Currency API') endpoint's conceptual lineage is traced to the legacy STAN core banking system's Currency Master function group, but its response shape is invented, not ported | ✅ CONFIRMED |
| [[ARCH-RULE-024]] | Current OAS idempotency key model has NOT yet been migrated to the confirmed structured Reference/Event design | ⚠️ CONFLICT |
| [[ARCH-RULE-025]] | OAS info.version (1.10.1) does not reflect all documented changes — self-acknowledged staleness | ✅ CONFIRMED |
| [[ARCH-RULE-026]] | FX rate resolution is explicitly out of scope — caller must supply already-resolved rates | ✅ CONFIRMED |
| [[ARCH-RULE-027]] | AML/sanctions screening and authN/authZ explicitly out of scope, delegated upstream | ✅ CONFIRMED |
| [[ARCH-RULE-028]] | RPFM is a partial-integration case: data model classified correctly but never wired to Confirm-time posting | ✅ CONFIRMED |
| [[ARCH-RULE-029]] | PYMT_IMLCPayment, REIM, CFNC, SBLC are confirmed non-users of the Payment Component | ✅ CONFIRMED |
| [[ARCH-RULE-030]] | Mixed Payment (Sight/Usance split) percentage/amount split happens in the calling module BEFORE this API is invoked | ✅ CONFIRMED |
| [[ARCH-RULE-031]] | The Payment Component is a shared Dr/Cr settlement layer invoked by other modules' Confirm functions, not a product in its own right | ✅ CONFIRMED |
| [[ARCH-RULE-032]] | [Proposed, NOT implemented] Charge Engine computes fees from Business Component's rate parameters; Payment Component only ever handles Collect Legs, never charge calculation | ✅ CONFIRMED |
| [[ARCH-RULE-033]] | [Proposed, NOT implemented] EBL and IBL share a Loan+Payment+Charge pattern that differs only in the external settlement endpoint | ✅ CONFIRMED |
| [[ARCH-RULE-034]] | [Proposed] Payment Component adoption should be scoped per PRODUCT+FUNCTION/EVENT, never declared wholesale per product | ✅ CONFIRMED |
| [[ARCH-RULE-035]] | Idempotent replay must compare the request payload, not just the natural key | ✅ CONFIRMED |
| [[ARCH-RULE-036]] | [Planned, not yet implemented] Idempotency key = (originModule, bankContractRef, eventSeq); customer LC number is never the key | ✅ CONFIRMED |
| [[ARCH-RULE-037]] | Check-then-act idempotency is not atomic across instances; must become an atomic DB upsert | ✅ CONFIRMED |
| [[ARCH-RULE-038]] | No auth, body-size cap, rate limiting, or request/trace correlation on the service — acceptable for demo, not for production | ✅ CONFIRMED |
| [[ARCH-RULE-039]] | Entry/leg/message IDs use module-global counters + Date.now() instead of UUIDs, unlike instructionId | ✅ CONFIRMED |
| [[ARCH-RULE-040]] | The 10 LC Payment widgets communicate purely via string HTML attributes, not framework-specific object props, for framework portability | ✅ CONFIRMED |
| [[ARCH-RULE-041]] | The Payment Component Simulator is deliberately excluded from the framework-free Web Components bundle and only exists inside the full Angular app | ✅ CONFIRMED |

## CONFLICT (1)

See also: [[Payment Instruction Classification]]

| ID | Title | Status |
|---|---|---|
| [[CLASS-RULE-001]] | RTGS modeled as a 6th distinct AccountType enum value (early docs, v1.1.0/v1.2.0) vs. accountType=NOSTRO + rtgsIndicator flag (current OAS, v1.3.0+) | ⚠️ CONFLICT |

## Charges (12)

See also: [[Charge Integration]]

| ID | Title | Status |
|---|---|---|
| [[CHARGE-RULE-001]] | Margin/pledge DDA accounts are hidden from ordinary fee/charge payment account pickers by default | ✅ CONFIRMED |
| [[CHARGE-RULE-002]] | Changing a charge's payment currency triggers a full server recalculation, not just client-side reformatting | ✅ CONFIRMED |
| [[CHARGE-RULE-003]] | Each fee type has a distinct default settlement currency and a bank-defined menu of alternatives — but the 'trade-amount vs bank-income' split does not extend to Export Collection's Bill Credit as originally claimed | ✅ CONFIRMED |
| [[CHARGE-RULE-004]] | Foreign/correspondent bank charges (and related fees) are embedded in the net settlement leg when paid in the same currency as that leg, else booked as a separate CA debit | ✅ CONFIRMED |
| [[CHARGE-RULE-005]] | Export LC Confirming Commission is charged per quarter of tenor (rounded up), applied to the tolerance-adjusted LC balance, with a TWD 1,000 minimum | ✅ CONFIRMED |
| [[CHARGE-RULE-006]] | Export Negotiation discount interest applies only to usance (deferred-payment) bills, never to sight bills, with a TWD 800 minimum on the nego fee | ✅ CONFIRMED |
| [[CHARGE-RULE-007]] | LC issuance and confirming commissions are both calculated on 'LC Balance' = LC Amount × (1 + Tolerance%), not on the bare LC Amount | ✅ CONFIRMED |
| [[CHARGE-RULE-008]] | Foreign Bank Charges (FBC) deducted by the correspondent before wiring funds are collected from the customer as a pure pass-through, never booked to a bank Income account — distinct from commission/fee lines which ARE bank income | ✅ CONFIRMED |
| [[CHARGE-RULE-009]] | A small number of TWD minimum-fee floors are reused verbatim across multiple, conceptually distinct charge types rather than each fee type having its own dedicated minimum | 🟡 INFERRED |
| [[CHARGE-RULE-010]] | No bank commission/fee income is charged at Import Sight Payment (IBL Lodgement, A3) or Sight Settlement (IBL repayment, A4) beyond pass-through correspondent charges — commission is charged once, upfront, at LC Issue (A1) | ✅ CONFIRMED |
| [[CHARGE-RULE-011]] | Export LC negotiation discount interest is computed on a 360-day-year convention | ✅ CONFIRMED |
| [[CHARGE-RULE-012]] | [Proposed, NOT implemented] Charge Settlement Policy (INDIVIDUAL/SUM_BY_CURRENCY/SUM_ALL/HYBRID) is bank-parameter-driven, not fixed logic | ✅ CONFIRMED |

## Classification (27)

See also: [[Payment Instruction Classification]]

| ID | Title | Status |
|---|---|---|
| [[CLASS-RULE-002]] | Payment Component Identification Rule (Rev 2) — XOR-based classification over CUSTOMER/NOSTRO/VOSTRO | ✅ CONFIRMED |
| [[CLASS-RULE-003]] | SUSPENSE and INTERNAL account types never participate in classification | ✅ CONFIRMED |
| [[CLASS-RULE-004]] | RTGS is not a distinct account type — it is NOSTRO + rtgsIndicator flag (v1.3.0), and folds into the same nostroXor bucket as plain NOSTRO | ✅ CONFIRMED |
| [[CLASS-RULE-005]] | Classification is informational only — it never blocks the Confirm flow or gates Account Entry generation | ✅ CONFIRMED |
| [[CLASS-RULE-006]] | transactionCurrency (v1.10.0) — explicit wire field, independent of any leg's own currency — drives suspenseBridge FX classification and SWIFT instructedCurrency; falls back to debitLegs[0].currency only when omitted | ✅ CONFIRMED |
| [[CLASS-RULE-007]] | accountCategory (CUSTOMER / NOSTRO_FAMILY / INTERNAL_SUSPENSE) is a UI-behavior grouping only — never used for leg classification or gating Account Entry generation | ✅ CONFIRMED |
| [[CLASS-RULE-008]] | RTGS's exclusion from the XOR terms is structural (the terms are defined only over CUSTOMER/NOSTRO/VOSTRO), not because RTGS lacks a real external counterparty like SUSPENSE/INTERNAL | ✅ CONFIRMED |
| [[CLASS-RULE-009]] | Every legacy module/function is classified PASS / GAP / N_A relative to Payment Component usage | ✅ CONFIRMED |
| [[CLASS-RULE-010]] | The registry never offers RTGS as a selectable AccountType — RTGS routing is expressed purely via the rtgsLeg() helper, defaulting accountType to NOSTRO | ✅ CONFIRMED |
| [[CLASS-RULE-011]] | N_A (non-user) modules carry no legs and must document the verification breadth behind the verdict | ✅ CONFIRMED |
| [[CLASS-RULE-012]] | All GAP-verdict cases belong to a single module, RPFM (Risk Participation Finance) | ✅ CONFIRMED |
| [[CLASS-RULE-013]] | transactionCurrency is an explicit, user/case-controlled value, decoupled from any individual leg's own settlement currency (v1.10.0) | ✅ CONFIRMED |
| [[CLASS-RULE-014]] | A single Transaction Currency/Amount override, when set, seeds BOTH sides' Leg #1 identically | ✅ CONFIRMED |
| [[CLASS-RULE-015]] | A GAP (RPFM) business case's live preview calls the classify-only endpoint, never Confirm, and never sends suspenseBridge | ✅ CONFIRMED |
| [[CLASS-RULE-016]] | An N_A (confirmed non-user) business case renders a static citation card only — no form, no API call, no live preview subscription | ✅ CONFIRMED |
| [[CLASS-RULE-017]] | FX Conversion Pair legs are identified purely by a GL-account naming convention, not an explicit pair id on the wire | ✅ CONFIRMED |
| [[CLASS-RULE-018]] | A Suspense-driven FX pair's Debit/Credit section attribution is a best-effort magnitude match with an accepted tie ambiguity | ✅ CONFIRMED |
| [[CLASS-RULE-019]] | The viewer infers 'transaction currency' from entries[0].currency, which is stale relative to the server's v1.10.0 explicit transactionCurrency field | ⚠️ CONFLICT |
| [[CLASS-RULE-020]] | A fixed 7-type GL account taxonomy underlies every LC journal entry (legacy web-components, distinct from the Payment Component microservice's 5-type AccountType) | ✅ CONFIRMED |
| [[CLASS-RULE-021]] | Import LC components model a 3-stage event chain: Issue (A1) → IBL Lodgement (A3) → IBL Settlement/Repayment (A4), with an alternative direct-Settlement path (A2) | ✅ CONFIRMED |
| [[CLASS-RULE-022]] | Export LC components model a 5-stage event set: Advise (B1) → optional Confirm (B2) → Negotiation (B3) → Settlement, either via EBL-clearing/Direct (B4) or On-Collection with no EBL (B5) | ✅ CONFIRMED |
| [[CLASS-RULE-023]] | Import components model the LC applicant (importer/buyer); Export components model the LC beneficiary (exporter/seller) — same customer master list serves both roles | ✅ CONFIRMED |
| [[CLASS-RULE-024]] | AccountType enum has exactly 5 values (CUSTOMER/NOSTRO/VOSTRO/SUSPENSE/INTERNAL) in the Payment Component microservice; RTGS is not one of them (v1.3.0) | ✅ CONFIRMED |
| [[CLASS-RULE-025]] | One internal doc (COMMON-PaymentComponent-Cross-Reference.md) states the classification rule with a different, non-equivalent term count (2-term merged-Nostro XOR) than the authoritative 3-term Rev.2 rule used everywhere else | ⚠️ CONFLICT |
| [[CLASS-RULE-026]] | Dr/Cr AccountType values are user-selected screen data, not hardcoded per function — the XOR rule is data-driven | ✅ CONFIRMED |
| [[CLASS-RULE-027]] | Which legacy module (EPLC vs EXCO) genuinely owns each of the export-side use cases (3-5) is unresolved | ✅ CONFIRMED |
| [[CLASS-RULE-028]] | Five proposed sourceFunctionCode values (Issue, Acceptance, Repayment, Negotiation, Reimbursement) have no entry in VOUCHER_CODE_PREFIXES today | ✅ CONFIRMED |

## FX (45)

See also: [[FX Processing]]

| ID | Title | Status |
|---|---|---|
| [[FX-RULE-001]] | A DEBIT-side Suspense bucket nets against a matching-currency real debit leg before generating an FX pair (v1.9.0) — at most one pair for the residual | ✅ CONFIRMED |
| [[FX-RULE-002]] | A CREDIT-side Suspense bucket is deliberately NOT netted against a matching real credit leg — each source gets its own independent gross FX pair (v1.8.0) | ✅ CONFIRMED |
| [[FX-RULE-003]] | A cross-currency Suspense entry with no matching real leg still generates Suspense-suffixed FX Exchange pair legs (v1.8.0/v1.9.0) | ✅ CONFIRMED |
| [[FX-RULE-004]] | Currency minor-unit (decimal places) master table drives rounding; falls back to 2dp for unlisted currencies | ✅ CONFIRMED |
| [[FX-RULE-005]] | Account-currency amount = transaction-currency amount × leg's own buy rate (§8.2 formula, symmetric for Dr and Cr) | ✅ CONFIRMED |
| [[FX-RULE-006]] | A zero FX rate must be rejected (M-2) because it would silently zero out and drop a suspense-bridge leg with no error | ✅ CONFIRMED |
| [[FX-RULE-007]] | A Suspense entry in the same currency as the transaction currency is posted verbatim, with no rounding and no FX pair | ✅ CONFIRMED |
| [[FX-RULE-008]] | Cross-currency Suspense conversion rounds to the TRANSACTION currency's own minor-unit scale (ROUND_HALF_UP), not a fixed 2dp and not the entry's own currency's scale | ✅ CONFIRMED |
| [[FX-RULE-009]] | An FX Exchange pair is always two self-balancing legs: an 'Other Ccy site' leg (foreign-currency-denominated, opposite direction to the source) and a 'Trx Ccy site' leg (transaction-currency-denominated, same direction as the source) | ✅ CONFIRMED |
| [[FX-RULE-010]] | An FX pair's amounts are always REUSED verbatim from an already-computed, already-on-the-wire figure — never freshly re-derived by multiplying a combined magnitude by a rate | ✅ CONFIRMED |
| [[FX-RULE-011]] | When sizing the real-leg side of an FX pair by native currency amount, the module reads each leg's amountAccountCcy, falling back to amountTxCcy only when amountAccountCcy is absent | ✅ CONFIRMED |
| [[FX-RULE-012]] | When sizing the transaction-currency side of a real-leg FX pair, the module always sums each matching leg's own already-submitted amountTxCcy verbatim — never re-derives it from a rate | ✅ CONFIRMED |
| [[FX-RULE-013]] | H-3 fix: MT103/PACS008 field 32A (settled amount) and 33B (instructed amount) are populated from DIFFERENT source fields and DIFFER for a cross-currency leg | ✅ CONFIRMED |
| [[FX-RULE-014]] | M-2: every exchange rate field must be strictly greater than zero | ✅ CONFIRMED |
| [[FX-RULE-015]] | amountTxCcy is denominated in the deal's transactionCurrency, not any leg's own settlement currency; amountAccountCcy is denominated in the leg's own currency | ✅ CONFIRMED |
| [[FX-RULE-016]] | Suspense-bridge DEBIT-side FX pair is sized to the NET shortfall/excess between the Suspense bucket and matching real debit legs in that currency, not the gross amount of either — demonstrated end-to-end by curl case 1 | ✅ CONFIRMED |
| [[FX-RULE-017]] | A creditEntries Suspense bucket generates its FX pair(s) purely from ITS OWN currency buckets — an unrelated real credit leg in a currency the Suspense bridge never mentions gets no auto-generated FX pair at all | ✅ CONFIRMED |
| [[FX-RULE-018]] | A Suspense bridge entry whose currency equals the transaction currency never generates an FX Exchange pair — it folds directly into the credit side at its own face amount | ✅ CONFIRMED |
| [[FX-RULE-019]] | transactionCurrency is sent as an explicit, independent wire field, never inferred from a leg's own currency | ✅ CONFIRMED |
| [[FX-RULE-020]] | The Debit/Credit FX Conversion Pair preview panel suppresses its naive per-row conversion for any currency that also has a matching-side Suspense entry | ✅ CONFIRMED |
| [[FX-RULE-021]] | A leg's own settlement currency can differ from the deal's Transaction Currency; two independent input surfaces converge on the same amountTxCcy | ✅ CONFIRMED |
| [[FX-RULE-022]] | Client-computed FX Conversion Pair closes the per-currency (V8) balance gap left by a single mismatched-currency leg | ✅ CONFIRMED |
| [[FX-RULE-023]] | The FX Conversion Pair table is a client-side preview only — never sent to or returned by the microservice | ✅ CONFIRMED |
| [[FX-RULE-024]] | A directly-typed Account Ccy Equiv. figure is stored raw and preferred over re-derivation, to avoid a precision-loss round-trip bug | ✅ CONFIRMED |
| [[FX-RULE-025]] | Exchange Account No. and Deal No. are reference-only fields, never sent to the microservice and never drive any calculation | ✅ CONFIRMED |
| [[FX-RULE-026]] | A row's FX rate is auto-populated from GET /api/fx/rates when its currency first diverges, but stays freely editable and is left untouched if no rate is found | ✅ CONFIRMED |
| [[FX-RULE-027]] | Every currency offered in the Currency dropdown is guaranteed to have an FX rate | ✅ CONFIRMED |
| [[FX-RULE-028]] | Cross rates between two non-TWD currencies are derived by bridging both currencies' TWD-quoted rates, not looked up directly | ✅ CONFIRMED |
| [[FX-RULE-029]] | crossRate()'s return value is defined as 'units of `to` per 1 unit of `from`' — the exact multiplier convention PaymentLegInput.drBuyRate/crBuyRate expect | ✅ CONFIRMED |
| [[FX-RULE-030]] | transactionCurrency is an explicit wire field representing the deal's actual currency, deliberately independent of any individual leg's own settlement currency | ✅ CONFIRMED |
| [[FX-RULE-031]] | SuspenseBridgeEntry.crossRate / SuspenseEntry.crossRate is required only when the entry's own currency differs from the request's transaction currency, and is ignored/not required otherwise | ✅ CONFIRMED |
| [[FX-RULE-032]] | Each Suspense entry converts and posts ALONE (gross, per-entry) — never merged with another entry or a matching real leg — for the Suspense bridge leg itself | ✅ CONFIRMED |
| [[FX-RULE-033]] | Charge Component Bridge FX sizing — FX Exchange entry sized to the residual difference, not the gross amount | 🟡 INFERRED |
| [[FX-RULE-034]] | [Proposed, NOT implemented] Multi-currency charge aggregation should round AFTER summing, not sum already-rounded individual amounts; rounding residual books to P&L, never left in Suspense | ✅ CONFIRMED |
| [[FX-RULE-035]] | IMCO-specific exchange rate type selection based on a converted-amount threshold, with direction-dependent inversion | ✅ CONFIRMED |
| [[FX-RULE-036]] | Transaction-currency to account-currency conversion is symmetric multiply/divide by the leg's own rate, on both Dr and Cr sides | ✅ CONFIRMED |
| [[FX-RULE-037]] | Exchange rate of zero is accepted [at the pattern level] and, absent the M-2 guard, would silently drop the resulting Suspense leg, losing a real charge | ✅ CONFIRMED |
| [[FX-RULE-038]] | chargeComponentBridge [i.e. the v1.9.0 debit-side netting] diff-pair gating can diverge between diffNative's sign and diffTrx's sign, risking a negative-amount FX leg | ✅ CONFIRMED |
| [[FX-RULE-039]] | sumLegsInCurrency's fallback treats transaction-currency amount as native currency, mixing currencies | ✅ CONFIRMED |
| [[FX-RULE-040]] | FX pair construction reuses already-on-the-wire, already-rounded amounts rather than re-multiplying by a rate a second time | ✅ CONFIRMED |
| [[FX-RULE-041]] | A foreign-currency CUSTOMER leg on a side uses existing amountAccountCcy/drRate fields and never triggers the suspenseBridge FX Exchange mechanism — but must still respect that currency's own minor-unit scale (H-2) | ✅ CONFIRMED |
| [[FX-RULE-042]] | Account Ccy Equiv. round-trips exactly as typed rather than being re-derived from the rounded Amount (Tx Ccy) figure | ✅ CONFIRMED |
| [[FX-RULE-043]] | Same Currency + Same Amount → Direct Settlement → No FX Pair (debit side only, v1.9.0) | ✅ CONFIRMED |
| [[FX-RULE-044]] | creditEntries bucket netting is deliberately NOT applied (asymmetric from debitEntries) | ✅ CONFIRMED |
| [[FX-RULE-045]] | A Suspense entry in a non-transaction currency must carry crossRate in the correct direction | ✅ CONFIRMED |

## Other (3)

See also: [[Payment Architecture]]

| ID | Title | Status |
|---|---|---|
| [[ARCH-RULE-042]] | Known source-code defect: EPLC Liability Voucher credit-leg description field is never actually set due to a .valuee typo | ✅ CONFIRMED |
| [[ARCH-RULE-043]] | Extended usage scenarios (LC fee collection, IBL/EBL Takedown, IBL/EBL Repayment) are documented wire-shape guidance only, NOT implemented business-case-registry entries | ✅ CONFIRMED |
| [[ARCH-RULE-044]] | Both Angular app and microservice enforce a 90% coverage floor (statements/branches/functions/lines); microservice has 100% coverage currently | ✅ CONFIRMED |

## SWIFT (15)

See also: [[SWIFT Messaging and Vouchers]]

| ID | Title | Status |
|---|---|---|
| [[SWIFT-RULE-001]] | SWIFT cross-field validation on credit legs runs before message generation and blocks persistence on violation | ✅ CONFIRMED |
| [[SWIFT-RULE-002]] | A SWIFT message is generated per credit leg only when its own message-type field is set and not the literal 'None'; a request whose credit legs carry no such field yields swiftMessages: [] | ✅ CONFIRMED |
| [[SWIFT-RULE-003]] | A COV-type cover message requires a compatible advice message on the same credit leg (payCoverMsgType in {MT202COV, PACS009COV} forces payAdviceMsgType into {MT103, PACS008}) | ✅ CONFIRMED |
| [[SWIFT-RULE-004]] | SWIFT message type selection is driven purely by the leg's own message-type fields, never by accountType or the RTGS flag | ✅ CONFIRMED |
| [[SWIFT-RULE-005]] | One gpi UETR is generated per credit leg and shared between that leg's advice and cover messages; different legs get different UETRs | ✅ CONFIRMED |
| [[SWIFT-RULE-006]] | A cover message (MT202/MT202COV/PACS009COV) carries only a settlement amount/currency (32A) and never an instructed amount/currency (33B) | ✅ CONFIRMED |
| [[SWIFT-RULE-007]] | AccountEntry carries exchangeRate1/exchangeRate2 fields whose semantics are only partially populated by this service | ✅ CONFIRMED |
| [[SWIFT-RULE-008]] | Payment Component's SWIFT/ISO20022 scope is bounded by SWIFT message CATEGORY (Category 1 MT1xx + Category 2 MT2xx + pacs.008.*/pacs.009.*), not by the specific enum values currently observed | ✅ CONFIRMED |
| [[SWIFT-RULE-009]] | MT400/MT756 intentionally excluded from payAdviceMsgType — owned by the main transaction, not a schema gap | ✅ CONFIRMED |
| [[SWIFT-RULE-010]] | SwiftMessage.status enum includes GENERATED/TRANSMITTED/FAILED but only PENDING is currently reachable; message-record creation is synchronous while actual SWIFT transmission is asynchronous and never implemented | ✅ CONFIRMED |
| [[SWIFT-RULE-011]] | H-3 (implemented): settlement amount (32A) and instructed amount (33B) are no longer forced equal for a cross-currency leg; a gpi UETR (v4 UUID) is populated on every generated message | ✅ CONFIRMED |
| [[SWIFT-RULE-012]] | Legacy system originally populated SWIFT settlement amount (32A) and instructed amount (33B) from the identical source field, never independently — a defect later fixed by H-3 | ✅ CONFIRMED |
| [[SWIFT-RULE-013]] | Unlike Account Entry generation (unconditional per leg), SWIFT message record creation is conditional on a credit leg's payAdviceMsgType/payCoverMsgType resolving to a non-None value | ✅ CONFIRMED |
| [[SWIFT-RULE-014]] | Idempotency key for LC/payment instructions is planned to become (originModule, bankContractRef, eventSeq) via a structured Reference/Event model — NOT yet implemented | ✅ CONFIRMED |
| [[SWIFT-RULE-015]] | event.type enum includes REVERSAL to give post-release corrections a legal bookable event — planned, NOT yet implemented | ✅ CONFIRMED |

## Suspense (21)

See also: [[Suspense Account]]

| ID | Title | Status |
|---|---|---|
| [[SUSPENSE-RULE-001]] | suspenseBridge expansion happens before the V8 balance check, so a caller must pre-fund the bridge amount in its own legs or the request is rejected as unbalanced | ✅ CONFIRMED |
| [[SUSPENSE-RULE-002]] | creditLegs may be submitted empty when suspenseBridge itself supplies a credit-direction leg (v1.10.0/v1.10.1 fee-collection pattern) — gated purely on suspenseBridge content, NOT any request flag | ✅ CONFIRMED |
| [[SUSPENSE-RULE-003]] | A suspense-bridge leg (from either debitEntries or creditEntries) always posts on the CREDIT side, unconditionally | ✅ CONFIRMED |
| [[SUSPENSE-RULE-004]] | SuspenseEntry.sourceComponent/balanceModule (server) and SuspenseBridgeEntry.sourceComponent/balanceModule (client wire type) are pure provenance/audit metadata — they never change leg expansion, have zero server-side validation/posting consequence, and never trigger Charge/Liability Voucher generation (that stream was removed entirely in v1.6.0) | ✅ CONFIRMED |
| [[SUSPENSE-RULE-005]] | v1.9.0: A debitEntries Suspense bucket nets its gross amount against the caller's matching-currency debitLegs before generating any FX pair — 'Same Currency + Same Amount -> Direct Settlement -> No FX Pair' | ✅ CONFIRMED |
| [[SUSPENSE-RULE-006]] | v1.9.0's netting is deliberately NOT applied to a creditEntries bucket — a same-currency real credit leg is treated as an independent exposure, not 'the same money', so up to TWO independent gross-sized FX pairs are generated instead of one netted pair | ✅ CONFIRMED |
| [[SUSPENSE-RULE-007]] | suspenseBridge is an optional, verbatim passthrough field on the client's Confirm request builder — present only when the caller supplies it | ✅ CONFIRMED |
| [[SUSPENSE-RULE-008]] | Debit Leg #1 seed = case Total Amount + Sigma(Suspense Debit entries, each independently FX-converted/rounded) | ✅ CONFIRMED |
| [[SUSPENSE-RULE-009]] | Credit Leg #1 seed = case Total Amount minus Sigma(Suspense Credit entries, each independently FX-converted/rounded) | ✅ CONFIRMED |
| [[SUSPENSE-RULE-010]] | Leg #1 seed formula is deliberately blind to any already-entered live leg in the same currency (v1.7.4, reverting v1.7.3's attempt to net against a live leg) | ✅ CONFIRMED |
| [[SUSPENSE-RULE-011]] | Suspense entries in the same foreign currency are FX-converted and rounded PER ENTRY, not summed-then-converted-once — mirrors the server's buildSuspenseBridgeLeg, which also rounds per entry | ✅ CONFIRMED |
| [[SUSPENSE-RULE-012]] | A Suspense entry's same-currency vs. cross-currency classification (and thus whether crossRate is attached) uses the EXPLICIT transaction currency, never a leg's own currency nor a stale registry default | ✅ CONFIRMED |
| [[SUSPENSE-RULE-013]] | Client builds a raw per-entry suspenseBridge wire payload; all balancing/leg-expansion math is server-side (v1.4.0 boundary) | ✅ CONFIRMED |
| [[SUSPENSE-RULE-014]] | debitSuspenseCurrencyTotals/creditSuspenseCurrencyTotals expose a per-currency breakdown so the leg-allocator can snap a row's converted amount to the server-matching per-entry-rounded figure instead of its own combined-conversion figure (v1.13.1) | ✅ CONFIRMED |
| [[SUSPENSE-RULE-015]] | (duplicate — see merged rule 'sourceComponent-provenance-only' above) | ✅ CONFIRMED |
| [[SUSPENSE-RULE-016]] | Suspense Debit/Credit entry rows capture the raw material for the Charge/Balance Component <-> Payment Component accounting bridge | ✅ CONFIRMED |
| [[SUSPENSE-RULE-017]] | General Suspense/Charge Component bridge — raw amounts expand into offsetting Suspense legs + FX Exchange pairs (per FSD §5.4/§7.7) | ✅ CONFIRMED |
| [[SUSPENSE-RULE-018]] | FSD §7.8 documents a 'chargeComponentBridge' boolean flag gating empty creditLegs, and a diff-based (not gross) FX sizing for the Charge Component fee-collection pattern — this CONFLICTS with the actual implemented code | ⚠️ CONFLICT |
| [[SUSPENSE-RULE-019]] | [Proposed, NOT implemented] Two distinct Payment Clearing posting-order patterns — Cash-First vs Accrual-First — carry materially different risk profiles | ✅ CONFIRMED |
| [[SUSPENSE-RULE-020]] | [Proposed, NOT implemented] Nine required financial/audit controls for any Payment Clearing/SUSPENSE intermediary account design | ✅ CONFIRMED |
| [[SUSPENSE-RULE-021]] | Suspense bridge legs are always credit-direction regardless of source bucket (documentation-layer restatement of the code-verified rule above) | ✅ CONFIRMED |

## TestScenario (5)

See also: [[Testing Methodology and Coverage]]

| ID | Title | Status |
|---|---|---|
| [[TEST-RULE-001]] | Registry leg defaults are either an exact reproduction of a cited FSD/regression scenario, or an illustrative BA-judgment starting point — distinguished per case in `note` | 🟡 INFERRED |
| [[TEST-RULE-002]] | Only shared.ts's pure helper functions have unit test coverage under web-components/ — none of the 9 LC *.element.ts files (nor journal-entry.element.ts) have their own spec file | ✅ CONFIRMED |
| [[TEST-RULE-003]] | Test coverage explicitly excludes the 9 vanilla custom elements and all .html templates from collectCoverageFrom | ✅ CONFIRMED |
| [[TEST-RULE-004]] | The Payment Component Simulator catalogs 23 real business cases traced to legacy functions, tagged PASS/GAP/N_A across 11 modules | ✅ CONFIRMED |
| [[TEST-RULE-005]] | Confirming the same Main Ref + Sequence twice returns the original unchanged result (idempotent replay), badged distinctly in the UI | ✅ CONFIRMED |

## UI (24)

See also: [[Payment Component Simulator UI]]

| ID | Title | Status |
|---|---|---|
| [[UI-RULE-001]] | Formly header fields (Unit Code / Main Ref / Sequence / Voucher Prefix) are generated only for PASS cases | ✅ CONFIRMED |
| [[UI-RULE-002]] | Main Ref default follows a fixed `${module}-${id}-0001` convention | ✅ CONFIRMED |
| [[UI-RULE-003]] | A failed or incomplete preview/Confirm always clears the previously displayed result rather than leaving a stale one on screen next to the new error | ✅ CONFIRMED |
| [[UI-RULE-004]] | A stale Confirm error banner self-clears the moment the debounced preview pipeline next runs, regardless of whether that preview itself succeeds | ✅ CONFIRMED |
| [[UI-RULE-005]] | Percentage-driven XOR Amount-driven per row (never both) — 'B-Tree' rule | ✅ CONFIRMED |
| [[UI-RULE-006]] | v1.12.3 leg-rebalancing 'waterfall': every non-last row edit always offsets against the LAST row directly (merged with duplicate rules 23/26) | ✅ CONFIRMED |
| [[UI-RULE-007]] | The % waterfall's backward cascade (rule 4) can never be under-supplied, unlike the Amount waterfall's equivalent | ✅ CONFIRMED |
| [[UI-RULE-008]] | A row is removed from the grid the instant it settles at exactly 0% AND 0 amount, for both waterfalls | ✅ CONFIRMED |
| [[UI-RULE-009]] | Switching a row's Account Type unconditionally resets its Account No. to that type's own default placeholder | ✅ CONFIRMED |
| [[UI-RULE-010]] | A row's position in the internal rows array never changes just because its remainder status flips | ✅ CONFIRMED |
| [[UI-RULE-011]] | The emitted (wire) leg array sorts a transaction-currency-matching leg first, independent of the internal row order | ✅ CONFIRMED |
| [[UI-RULE-012]] | % and Amount inputs commit on blur/Enter, not per keystroke, to avoid mid-type cascading recalculation | ✅ CONFIRMED |
| [[UI-RULE-013]] | Zero-amount settlement legs are hidden from both Settlement Voucher views | ✅ CONFIRMED |
| [[UI-RULE-014]] | Settlement Vouchers Posting View re-groups raw wire entries into a fixed audit-readable section order | ✅ CONFIRMED |
| [[UI-RULE-015]] | Currency View always lists Debit rows before Credit rows within each currency group, via an explicit stable sort | ✅ CONFIRMED |
| [[UI-RULE-016]] | A client-only FX Conversion Pair overlay is required in Currency View so a real foreign-currency leg doesn't display as falsely one-sided/Unbalanced | ✅ CONFIRMED |
| [[UI-RULE-017]] | Amount display formatting to the currency's own minor units is presentation-only and never mutates the underlying accounting data | ✅ CONFIRMED |
| [[UI-RULE-018]] | Charge Voucher and Liability Voucher sections are plain voucherType filters with none of Settlement's display enhancements | ✅ CONFIRMED |
| [[UI-RULE-019]] | A newly-added Suspense entry row's currency is one-time-seeded from defaultCurrency, never retroactively applied to existing rows | ✅ CONFIRMED |
| [[UI-RULE-020]] | Suspense entry rows are tracked by a monotonically-increasing row id, not array index, for stable rendering across add/remove | ✅ CONFIRMED |
| [[UI-RULE-021]] | Switching the applicant/beneficiary resets chosen payment accounts; switching the transaction currency resets in-progress charge selections entirely | ✅ CONFIRMED |
| [[UI-RULE-022]] | onConfirm() in the Simulator does not gate on debitValid/creditValid before allowing Confirm | ✅ CONFIRMED |
| [[UI-RULE-023]] | "Exchange A/C No" / FX Exchange label is a client-side-only preview field, never sent to or returned by the server | ✅ CONFIRMED |
| [[UI-RULE-024]] | SuspenseEntry.sourceComponent captures the offsetting-leg source (Charge vs Balance/Liability) as a simple UI dropdown, defaulting to CHARGE | ✅ CONFIRMED |

## Validation (43)

See also: [[Request Validation]]

| ID | Title | Status |
|---|---|---|
| [[VALIDATION-RULE-001]] | Idempotency key is the natural key (originModule, mainRef, sequence); C-2 payload-fingerprint conflict detection | ✅ CONFIRMED |
| [[VALIDATION-RULE-002]] | dryRun mode skips idempotency lookup and persistence; every dryRun call recomputes fresh | ✅ CONFIRMED |
| [[VALIDATION-RULE-003]] | Voucher code prefix must be resolvable via sourceFunctionCode or override, else RequestValidationError | ✅ CONFIRMED |
| [[VALIDATION-RULE-004]] | A cross-currency suspenseBridge entry with no crossRate throws RequestValidationError before the balance check runs | ✅ CONFIRMED |
| [[VALIDATION-RULE-005]] | previewClassification never throws on an unbalanced request — imbalance is a normal in-progress UI state | ✅ CONFIRMED |
| [[VALIDATION-RULE-006]] | previewClassification accepts an optional tolerance so a within-tolerance mismatch still reports balanced=true | ✅ CONFIRMED |
| [[VALIDATION-RULE-007]] | V8: exact Dr/Cr aggregate balance required in transaction currency; a mismatch throws BusinessValidationError LEGS_UNBALANCED (409) | ✅ CONFIRMED |
| [[VALIDATION-RULE-008]] | M-7: legacy RPFM ±0.01 tolerance no longer auto-applied — exact balance required for every originModule including RPFM | ✅ CONFIRMED |
| [[VALIDATION-RULE-009]] | MonetaryAmount/ExchangeRate are decimal STRINGS with fixed patterns, never binary floats — enforced at a single money.ts choke point | ✅ CONFIRMED |
| [[VALIDATION-RULE-010]] | knownMinorUnitsForCurrency distinguishes a genuinely-known currency scale from an unknown one, to avoid wrongly rejecting/accepting over-precise amounts | ✅ CONFIRMED |
| [[VALIDATION-RULE-011]] | All Suspense entries sharing a currency within one bucket must resolve to the exact same crossRate; a mismatch is rejected | ✅ CONFIRMED |
| [[VALIDATION-RULE-012]] | Cross-field SWIFT validation fails fast on the FIRST violating leg and reports its index and account number | ✅ CONFIRMED |
| [[VALIDATION-RULE-013]] | 400 (schema/shape) and 409 (business rule) errors are deliberately distinct classes, dispatched via a single ApiError base + central middleware | ✅ CONFIRMED |
| [[VALIDATION-RULE-014]] | debitLegs is unconditionally required (min 1); no mechanism can ever synthesize a debit leg | ✅ CONFIRMED |
| [[VALIDATION-RULE-015]] | M-1: strictly negative caller-submitted amounts are rejected; direction is expressed only by Dr/Cr side, never sign | ✅ CONFIRMED |
| [[VALIDATION-RULE-016]] | H-2: submitted amounts must not exceed the currency's own decimal-place precision (Currency-API master); unknown currencies are skipped | ✅ CONFIRMED |
| [[VALIDATION-RULE-017]] | An unresolved FSD ambiguity (two candidate voucher prefixes) is surfaced as a mandatory user choice, never guessed | ✅ CONFIRMED |
| [[VALIDATION-RULE-018]] | Every PASS case resolves its voucher prefix through exactly one of two mutually-exclusive mechanisms | ✅ CONFIRMED |
| [[VALIDATION-RULE-019]] | The header form's Sequence value is coerced to a number before being sent on the wire | ✅ CONFIRMED |
| [[VALIDATION-RULE-020]] | Client-side amount-precision guard blocks both live preview and Confirm before any server round-trip | ✅ CONFIRMED |
| [[VALIDATION-RULE-021]] | A live preview is withheld (previewIncomplete, no API call) until both sides' legs are structurally valid AND (for PASS) mainRef+unitCode are populated | ✅ CONFIRMED |
| [[VALIDATION-RULE-022]] | Every monetary figure in the leg-allocator rounds to ITS OWN currency's minor units, never a hardcoded 2dp | ✅ CONFIRMED |
| [[VALIDATION-RULE-023]] | H-2 companion check: a raw typed leg amount with more decimal places than its currency allows is flagged and blocks preview/Confirm | ✅ CONFIRMED |
| [[VALIDATION-RULE-024]] | Directly-typed % is whole-percentage-point only (1% granularity); Amount editing has no such restriction | ✅ CONFIRMED |
| [[VALIDATION-RULE-025]] | A side is only 'valid' when every emitted leg has a non-empty Account No. and a positive amount, and the side is not over-allocated | ✅ CONFIRMED |
| [[VALIDATION-RULE-026]] | HTTP 201 vs 200 on Confirm distinguishes a genuinely new instruction from an idempotent replay; the UI must surface this distinction | ✅ CONFIRMED |
| [[VALIDATION-RULE-027]] | The /payment-instructions/classify endpoint exists specifically for RPFM's GAP-verdict business cases | ✅ CONFIRMED |
| [[VALIDATION-RULE-028]] | creditLegs may be submitted empty specifically when suspenseBridge will contribute its own credit-direction leg; debitLegs has no such exception | ✅ CONFIRMED |
| [[VALIDATION-RULE-029]] | Suspense entry Amount is force-normalized from a runtime JS number back to a string before emission | ✅ CONFIRMED |
| [[VALIDATION-RULE-030]] | All web components render via raw innerHTML template literals with manual escapeHtml calls — currently safe only because interpolated values are fixed dropdowns/mock data | ✅ CONFIRMED |
| [[VALIDATION-RULE-031]] | Server refuses to start if any currency in the currency master lacks a TWD FX rate in either direction | ✅ CONFIRMED |
| [[VALIDATION-RULE-032]] | Every demo-backend monetary amount rounds to its OWN currency's minor-unit decimal places, not a hardcoded 2dp, with a 2dp fallback | ✅ CONFIRMED |
| [[VALIDATION-RULE-033]] | Fixed production bug: every B4 EBL-path settlement crashed with HTTP 500 ('crCaTwd is not defined') due to a const-scoping error, now fixed via hoisted let | ✅ CONFIRMED |
| [[VALIDATION-RULE-034]] | AccountEntry.voucherType enum still includes CHARGE and LIABILITY even though v1.6.0 removed the ability to generate them | ⚠️ CONFLICT |
| [[VALIDATION-RULE-035]] | AML/sanctions screening and authN/authZ are explicitly out of scope for this service (per FSD §8.2) | ✅ CONFIRMED |
| [[VALIDATION-RULE-036]] | [Legacy, pre-microservice] Debit leg sum must not exceed the shared target total (Debit_Chk_Total_Pct) | ✅ CONFIRMED |
| [[VALIDATION-RULE-037]] | [Legacy, pre-microservice] Credit leg sum must not exceed the shared target total (CHK_Total_Pct), wider CFNC tolerance | ✅ CONFIRMED |
| [[VALIDATION-RULE-038]] | M-2: exchange rate must be strictly greater than 0 | ✅ CONFIRMED |
| [[VALIDATION-RULE-039]] | [STALE, superseded] Submitted leg amounts are not validated against the currency's minor units — cited as an open gap by an older expert-review doc, but this is NO LONGER true in the current code | ⚠️ CONFLICT |
| [[VALIDATION-RULE-040]] | valueDate is optional and never validated against back-value tolerance or a currency/RTGS business-day calendar | ✅ CONFIRMED |
| [[VALIDATION-RULE-041]] | The classify preview endpoint still requires at least one credit leg, inconsistent with the relaxed Confirm rule | ✅ CONFIRMED |
| [[VALIDATION-RULE-042]] | transactionCurrency must be sent explicitly; falling back to debitLegs[0].currency misclassifies when leg 0 is foreign | ✅ CONFIRMED |
| [[VALIDATION-RULE-043]] | A foreign-currency leg must carry amountAccountCcy for debit-side FX netting to compare correctly | ✅ CONFIRMED |

