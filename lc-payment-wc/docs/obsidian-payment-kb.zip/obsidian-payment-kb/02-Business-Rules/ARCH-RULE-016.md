---
knowledge_id: ARCH-RULE-016
title: "Selecting a business case (or module) fully resets every derived/transient piece of state so nothing leaks across cases"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - architecture
  - confirmed
---

# ARCH-RULE-016 — Selecting a business case (or module) fully resets every derived/transient piece of state so nothing leaks across cases

## Status
CONFIRMED

## Business Rule
selectCase() unsubscribes any prior preview subscription and resets: result, previewError, previewIncomplete, confirmError, debitLegs/creditLegs, debitValid/creditValid, suspenseDebitEntries/suspenseCreditEntries, debitLegScaleErrors/creditLegScaleErrors, transactionCurrencyOverride/transactionAmountOverride, model, and the Formly form/headerFields — before rebuilding headerFields from the new case (if any) and (for non-N_A cases) re-opening the debounced preview subscription.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
No worked numeric example available in the source evidence reviewed.

## Verification Note
Confirmed by reading the exact selectCase() method body directly, field by field. Unchanged.

## Source Evidence
- src/app/payment-component/business-case-runner.component.ts selectCase() body, lines ~628-660, directly re-read: every field listed in the statement is explicitly reset in the function body, in the order given, before the merge()/debounceTime(400) subscription is (re-)opened for non-N_A cases

## Related Knowledge
- [[Payment Architecture]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
