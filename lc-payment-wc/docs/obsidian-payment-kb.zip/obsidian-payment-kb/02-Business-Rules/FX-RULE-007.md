---
knowledge_id: FX-RULE-007
title: "A Suspense entry in the same currency as the transaction currency is posted verbatim, with no rounding and no FX pair"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - fx
  - confirmed
---

# FX-RULE-007 — A Suspense entry in the same currency as the transaction currency is posted verbatim, with no rounding and no FX pair

## Status
CONFIRMED

## Business Rule
When entry.currency === transactionCurrency, buildSuspenseBridgeLeg passes entry.amount through as the original string (no Decimal round-trip beyond a zero check), and expandSuspenseBridge's per-bucket loop `continue`s immediately after building the Suspense leg ('case 1') — no FX Exchange pair is ever generated for this bucket.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
No worked numeric example available in the source evidence reviewed.

## Verification Note
Confirmed by direct code read; matches exactly. No status change.

## Source Evidence
- suspenseBridge.ts lines 122-130 (same-currency branch of buildSuspenseBridgeLeg)
- suspenseBridge.ts line 313 ('if (currency === transactionCurrency) continue; // case 1 — no FX pair, ever.')

## Related Knowledge
- [[FX Processing]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
