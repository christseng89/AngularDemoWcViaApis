---
knowledge_id: POSTING-RULE-047
title: "sourceComponent tagging (CHARGE vs BALANCE) for Nego-style discount/interest is ambiguous by precedent between two parts of the codebase"
domain: Payment
category: Business Rule
status: CONFLICT
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - accounting
  - conflict
---

# POSTING-RULE-047 — sourceComponent tagging (CHARGE vs BALANCE) for Nego-style discount/interest is ambiguous by precedent between two parts of the codebase

## Status
CONFLICT

## Business Rule
The README's IBL Takedown worked example tags its optional Trx Charges entry sourceComponent:'BALANCE' (attributing interest fee to the Balance Component). Use Case 4 instead tags the Export Nego discount/interest 'CHARGE', matching Use Cases 1-3's convention. sourceComponent has no functional effect on the system, but the correct attribution is unconfirmed.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
No worked numeric example available in the source evidence reviewed.

## Conflict Note
> [!warning] Sources disagree
> The 'sourceComponent has no functional effect' half of the claim is directly confirmed by code (accountEntries.ts/confirmPaymentInstruction.ts never branch on sourceComponent). The specific doc-vs-doc labeling conflict itself was not independently re-opened this pass. Kept CONFLICT as originally stated.

## Verification Note
The 'sourceComponent has no functional effect' half of the claim is directly confirmed by code (accountEntries.ts/confirmPaymentInstruction.ts never branch on sourceComponent). The specific doc-vs-doc labeling conflict itself was not independently re-opened this pass. Kept CONFLICT as originally stated.

## Source Evidence
- PaymentComponentProposedUseCases-EN.docx.txt, Use Case 4 'Open items for review', 3rd bullet (cited, not independently re-opened this pass)
- Corroborated this pass by confirming (via confirmPaymentInstruction.ts read) that sourceComponent genuinely has zero server-side processing consequence, consistent with the claim that this is a pure-labeling ambiguity with no functional stakes

## Related Knowledge
- [[Accounting Model]]
- [[Business-Rule-Index]]
- [[Knowledge-Gaps]]
- [[Payment-Traceability-Matrix]]
