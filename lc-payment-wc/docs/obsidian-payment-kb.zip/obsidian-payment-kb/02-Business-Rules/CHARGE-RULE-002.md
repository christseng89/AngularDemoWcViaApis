---
knowledge_id: CHARGE-RULE-002
title: "Changing a charge's payment currency triggers a full server recalculation, not just client-side reformatting"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - charges
  - confirmed
---

# CHARGE-RULE-002 — Changing a charge's payment currency triggers a full server recalculation, not just client-side reformatting

## Status
CONFIRMED

## Business Rule
Every LC element wires its per-charge currency <select> (charge-ccy-{id}) to call this._calc(true) on change — re-invoking the calculation with the current chargeSelections map (which re-derives the journal entries) rather than merely reformatting an already-fetched amount client-side. The charge currency choice is treated as changing the actual booked leg (its account, amount, and FX conversion), not a display preference.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
No worked numeric example available in the source evidence reviewed.

## Verification Note
Confirmed all three cited files wire the same change→_calc(true) pattern. Minor correction to the original statement: the handler is a local _calc() method, not a network re-POST framed as '_calculate' — same substance (re-derives the full journal, not a client-side reformat), just corrected the method name/description to match the actual code.

## Source Evidence
- lc-issue.element.ts lines 131-138: charge-ccy-{id} change handler sets c.ccy then calls this._calc(true) with comment 're-calc with current charge selections, no form reset'
- lc-nego.element.ts line 134 (same charge-ccy-{id} listener pattern) and its comment 're-calc so Cr CA ccy updates in journal'
- lc-settlement.element.ts (import) lines 136-139: same pattern, comment 're-calc to update journal entry Dr CA currency'

## Related Knowledge
- [[Charge Integration]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
