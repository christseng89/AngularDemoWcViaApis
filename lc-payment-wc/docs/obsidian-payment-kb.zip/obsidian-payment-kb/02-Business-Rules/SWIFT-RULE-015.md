---
knowledge_id: SWIFT-RULE-015
title: "event.type enum includes REVERSAL to give post-release corrections a legal bookable event — planned, NOT yet implemented"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - swift
  - confirmed
---

# SWIFT-RULE-015 — event.type enum includes REVERSAL to give post-release corrections a legal bookable event — planned, NOT yet implemented

## Status
CONFIRMED

## Business Rule
D-5 of the same planning record: event.type is planned as an enum including REVERSAL, allowing a correction after an instruction has been RELEASED (immutable) to be posted as its own distinct, auditable event rather than mutating history. Not yet present in the implemented types.ts/OAS schema this session verified (no event.type field or REVERSAL concept exists in the current PaymentInstruction/PaymentLeg/SwiftMessage types read this pass).

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
n/a

## Verification Note
Same domain-tagging caveat as the sibling rule above — this is an idempotency/event-model architecture decision, not a SWIFT messaging rule (unrelated to swiftMessages.ts). CLAUDE.md content matches as quoted; confirmed via this session's own code read that it is indeed not yet implemented (correctly framed as planned). CONFIRMED as a recorded decision.

## Source Evidence
- CLAUDE.md D-5 in the OAS Reference/Event model decision log
- src/types.ts (this session's own read of confirmPaymentInstruction.ts and its imports) confirms no event.type/REVERSAL field exists in the currently implemented PaymentInstruction interface

## Related Knowledge
- [[SWIFT Messaging and Vouchers]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
