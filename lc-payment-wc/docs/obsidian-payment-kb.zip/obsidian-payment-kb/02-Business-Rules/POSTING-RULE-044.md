---
knowledge_id: POSTING-RULE-044
title: "The Suspense Debit/Suspense Credit entries UI is explicitly a Simulator-only modeling extension, NOT sourced from the FSD"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - accounting
  - confirmed
---

# POSTING-RULE-044 — The Suspense Debit/Suspense Credit entries UI is explicitly a Simulator-only modeling extension, NOT sourced from the FSD

## Status
CONFIRMED

## Business Rule
The Suspense Debit/Suspense Credit repeaters in the Simulator UI are explicitly documented as a Simulator-only extension modeling the accounting bridge between an external Charge Component and this Payment Component. Multiple entries per side are allowed.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
No worked numeric example available in the source evidence reviewed.

## Verification Note
Directly corroborated by suspenseBridge.ts's own explicit 'NOT part of the legacy trace' statement, read this pass — matches the claim's 'NOT FSD-sourced' framing exactly.

## Source Evidence
- docs__LC-Payment-WC-User-Manual-en.docx.txt §6.6 (cited)
- Directly corroborated this pass by suspenseBridge.ts's own top doc comment: 'added v1.4.0. NOT part of the legacy trace (no §-section citation exists for this...)'

## Related Knowledge
- [[Accounting Model]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
