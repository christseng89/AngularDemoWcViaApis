---
knowledge_id: ARCH-RULE-007
title: "The suspense bridge module only ever ADDS Suspense/FX legs — it never modifies a caller's own submitted debitLegs/creditLegs amounts"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - architecture
  - confirmed
---

# ARCH-RULE-007 — The suspense bridge module only ever ADDS Suspense/FX legs — it never modifies a caller's own submitted debitLegs/creditLegs amounts

## Status
CONFIRMED

## Business Rule
debitLegs/creditLegs parameters are read-only inputs used solely to size the real-leg side of an FX pair; the function signature treats them as `readonly PaymentLegInput[]`, and no code path mutates or rewrites a caller-submitted leg. The full V8-balance responsibility for the caller's own legs remains the caller's own responsibility.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
No worked numeric example available in the source evidence reviewed.

## Verification Note
Confirmed; evidence line numbers adjusted slightly (283-284 vs cited 280-285) but same declaration, no substantive change.

## Source Evidence
- microservices/payment-component/src/domain/suspenseBridge.ts top doc comment (last paragraph, ~lines 78-84), directly re-read: 'only Suspense/FX legs are ever ADDED — a caller's own submitted debit/credit leg amounts are never modified'
- suspenseBridge.ts expandSuspenseBridge signature, confirmed via grep: `debitLegs: readonly PaymentLegInput[] = []` / `creditLegs: readonly PaymentLegInput[] = []` (function definition, ~line 283-284, not 280-285 as originally cited but same declaration)

## Related Knowledge
- [[Payment Architecture]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
