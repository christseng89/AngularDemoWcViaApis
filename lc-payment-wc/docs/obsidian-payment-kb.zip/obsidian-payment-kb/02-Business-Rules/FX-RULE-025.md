---
knowledge_id: FX-RULE-025
title: "Exchange Account No. and Deal No. are reference-only fields, never sent to the microservice and never drive any calculation"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - fx
  - confirmed
---

# FX-RULE-025 — Exchange Account No. and Deal No. are reference-only fields, never sent to the microservice and never drive any calculation

## Status
CONFIRMED

## Business Rule
row.exchangeAccountNo and row.dealNumber are never read anywhere in this component's own emit()/calculation logic besides applyFxRate() SETTING a default for exchangeAccountNo. The specific claim about the ORIGINAL legacy baseline screens (SSSS_PaymentDebit.js) is sourced from the code comment only (not independently verified against those external files here), but the claim that THIS component never reads either field into a calculation is directly confirmed.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
No worked numeric example available in the source evidence reviewed.

## Verification Note
Re-ran the grep myself: exchangeAccountNo/dealNumber appear only in declaration/assignment positions, never in a read/conditional context. Confirms the component-scope claim. The legacy-baseline sub-claim remains unverified against external files (correctly caveated already in the candidate). No status change.

## Source Evidence
- leg-allocator.component.ts: grep of every exchangeAccountNo/dealNumber occurrence — only set at lines 354-355 (init), 566 (reset), 588 (default), never read

## Related Knowledge
- [[FX Processing]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
