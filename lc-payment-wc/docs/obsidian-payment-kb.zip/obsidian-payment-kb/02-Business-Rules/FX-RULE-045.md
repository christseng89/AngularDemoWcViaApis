---
knowledge_id: FX-RULE-045
title: "A Suspense entry in a non-transaction currency must carry crossRate in the correct direction"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - fx
  - confirmed
---

# FX-RULE-045 — A Suspense entry in a non-transaction currency must carry crossRate in the correct direction

## Status
CONFIRMED

## Business Rule
A Suspense entry whose currency differs from the transaction currency needs its own crossRate field; the direction matters (USD→EUR vs EUR→USD are reciprocals and must not be confused). A same-currency-as-transaction Suspense entry does not need crossRate.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
Leg rate EUR→USD = 0.923295; Suspense entry's crossRate (USD→EUR direction) = 1.0831 (reciprocal).

## Verification Note
Confirmed the exact zh text cited exists verbatim in the source doc (lines 115-116). Cross-checked the reciprocal arithmetic: 1/0.923295 ≈ 1.0831, consistent with the claim. No status change.

## Source Evidence
- Payment-Component-Suspense-FX-Test-Cases-zh.md: '...是 leg 顯示的 0.923295 的倒數方向，USD→EUR vs EUR→USD 要對清楚方向...USD entry 因為跟交易幣別相同，不需要 crossRate' (read directly)

## Related Knowledge
- [[FX Processing]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
