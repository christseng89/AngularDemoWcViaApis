---
knowledge_id: CHARGE-RULE-012
title: "[Proposed, NOT implemented] Charge Settlement Policy (INDIVIDUAL/SUM_BY_CURRENCY/SUM_ALL/HYBRID) is bank-parameter-driven, not fixed logic"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - charges
  - confirmed
---

# CHARGE-RULE-012 — [Proposed, NOT implemented] Charge Settlement Policy (INDIVIDUAL/SUM_BY_CURRENCY/SUM_ALL/HYBRID) is bank-parameter-driven, not fixed logic

## Status
CONFIRMED

## Business Rule
Architecture v4 proposal: different banks require different fee-collection behavior, so the Payment Component should not fix a single deduction policy — Charge Settlement Policy (bank × product parameter, extensible to a 'customer segment' dimension) controls how Charge Legs convert to Collect Legs: INDIVIDUAL (each fee deducted separately, common in some European banks), SUM_BY_CURRENCY (aggregated by currency, most common in Asian banks), SUM_ALL (all converted to the payment currency and deducted once, common in some North American banks), or HYBRID (documented default sub-rule: bank's-own-income fees like Commission/Handling Fee/Interest Income aggregate SUM_BY_CURRENCY, while third-party pass-through fees like SWIFT Fee/Courier Fee/Correspondent Bank Charges stay INDIVIDUAL for reconciliation — tagged via a proposed chargeNature: BANK_INCOME | THIRD_PARTY_PASS_THROUGH attribute on the Charge Leg).

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Collect Legs generated per policy, feeding into the existing Payment Clearing (SUSPENSE) two-step posting

## Example
Charge Legs: USD Commission 50 + SWIFT Fee 20 + Handling Fee 10, HKD Courier Fee 100 → Individual: USD50/USD20/USD10/HKD100 (4 collect legs); Sum by Currency: USD80/HKD100 (2 legs); Sum All: single leg in payment currency

## Verification Note
Re-opened the source .docx.txt and confirmed the worked numeric example is verbatim in the document (not invented): 'Individual：USD 50、USD 20、USD 10、HKD 100' / 'Sum by Currency：USD 80、HKD 100' / 'Sum All：全部換算為付款幣別後一次扣款' at lines 108-114. Policy table (INDIVIDUAL/SUM_BY_CURRENCY/SUM_ALL/HYBRID with region annotations) confirmed at lines 171-174. No change to status. Noted in gaps_found that the actual demo backend (server.js) does NOT implement this policy — it uses simple per-fee currency-choice logic instead — so readers should not conflate the two.

## Source Evidence
- analysis__Trade_Finance_Payment_Component_Architecture_v4-cn.docx.txt §8.1 line 95 (HYBRID rule + chargeNature attribute definition)
- §8.4 lines 103-114 (Charge Legs example: USD Commission 50/SWIFT Fee 20/Handling Fee 10, HKD Courier Fee 100; Individual/Sum by Currency/Sum All results listed verbatim)
- policy table around lines 169-175 (INDIVIDUAL/SUM_BY_CURRENCY/SUM_ALL/HYBRID with regional-bank-practice annotations)

## Related Knowledge
- [[Charge Integration]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
