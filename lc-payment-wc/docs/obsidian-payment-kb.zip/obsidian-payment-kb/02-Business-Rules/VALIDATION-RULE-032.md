---
knowledge_id: VALIDATION-RULE-032
title: "Every demo-backend monetary amount rounds to its OWN currency's minor-unit decimal places, not a hardcoded 2dp, with a 2dp fallback"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - validation
  - confirmed
---

# VALIDATION-RULE-032 — Every demo-backend monetary amount rounds to its OWN currency's minor-unit decimal places, not a hardcoded 2dp, with a 2dp fallback

## Status
CONFIRMED

## Business Rule
dp(ccy) reads the per-currency decimals value from the currency master (DECIMALS, derived from currencies.json) and falls back to 2 if the currency code isn't found; fmtAmt/round apply this scale. Per the demo data: JPY, TWD, IDR round to whole units (0dp); USD, EUR, GBP, CNY, HKD, SGD, AUD round to 2dp.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
n/a — confirmed via direct code read.

## Verification Note
Confirmed exactly by direct read of backend/server.js lines 21-63.

## Source Evidence
- backend/server.js lines 21-22 (DECIMALS construction), lines 52-63 (dp(ccy), round(n,d), fmtAmt)
- backend/data/currencies.json (decimals field per currency)

## Related Knowledge
- [[Request Validation]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
