---
knowledge_id: UI-RULE-012
title: "% and Amount inputs commit on blur/Enter, not per keystroke, to avoid mid-type cascading recalculation"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - ui
  - confirmed
---

# UI-RULE-012 — % and Amount inputs commit on blur/Enter, not per keystroke, to avoid mid-type cascading recalculation

## Status
CONFIRMED

## Business Rule
Both the % input and the Amount (Tx Ccy)/Account Ccy Equiv. inputs bind (blur)/(keydown.enter) rather than (ngModelChange), because the waterfall recalculates OTHER rows on every call — firing per keystroke while typing a multi-digit value would run the handler multiple times with intermediate values, each cascading against neighbors. A forced DOM resync (input.value = ...) after the commit call is needed because a rejected/capped edit leaves the bound value unchanged, which Angular's dirty-check alone would not re-render.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
n/a

## Verification Note
Confirmed directly by reading leg-allocator.component.html: both inputs use (blur)/(keydown.enter) with explicit re-sync of the raw input.value, matching the claim exactly.

## Source Evidence
- leg-allocator.component.html lines 53-67 (pct input, blur/enter commit + explanatory comment), lines 85-89 (amount input, same pattern)

## Related Knowledge
- [[Payment Component Simulator UI]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
