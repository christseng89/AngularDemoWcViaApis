---
knowledge_id: FX-RULE-034
title: "[Proposed, NOT implemented] Multi-currency charge aggregation should round AFTER summing, not sum already-rounded individual amounts; rounding residual books to P&L, never left in Suspense"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - fx
  - confirmed
---

# FX-RULE-034 — [Proposed, NOT implemented] Multi-currency charge aggregation should round AFTER summing, not sum already-rounded individual amounts; rounding residual books to P&L, never left in Suspense

## Status
CONFIRMED

## Business Rule
Architecture v4 proposal §8.3: for SUM_BY_CURRENCY/SUM_ALL aggregation, summing several individually-rounded fees vs. rounding once after summing can produce slightly different results — this version recommends 'sum first, then round once', with the resulting rounding difference booked to bank P&L, never silently left in Payment Clearing/Suspense.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
No worked numeric example available in the source evidence reviewed.

## Verification Note
Confirmed the doc text exactly as cited, and confirmed the status label 'Proposed, NOT implemented' is accurate — this is a design-document recommendation with no corresponding implementation found anywhere in the microservice source (the actual implemented behavior, per 'suspense-bridge-per-entry-gross-conversion' above, is the OPPOSITE: per-entry rounding, not sum-then-round — deliberately, to match V8). No status change, but worth noting this proposal directly contradicts the ALREADY-SHIPPED per-entry-rounding design elsewhere in the same codebase, which is intentional per v1.7.4's own reasoning (see that rule) — this is a genuine, acknowledged architectural tension between an FSD-era design aspiration and the actually-shipped microservice, not a bug.

## Source Evidence
- analysis__Trade_Finance_Payment_Component_Architecture_v4-cn.docx.txt §8.3 lines 99-102 (read directly: '先加總、後捨入...捨入差額原則上計入銀行損益，不得默默留在 Payment Clearing 未清')

## Related Knowledge
- [[FX Processing]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
