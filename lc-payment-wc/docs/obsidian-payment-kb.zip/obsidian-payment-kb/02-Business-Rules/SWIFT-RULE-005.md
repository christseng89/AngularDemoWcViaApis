---
knowledge_id: SWIFT-RULE-005
title: "One gpi UETR is generated per credit leg and shared between that leg's advice and cover messages; different legs get different UETRs"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - swift
  - confirmed
---

# SWIFT-RULE-005 — One gpi UETR is generated per credit leg and shared between that leg's advice and cover messages; different legs get different UETRs

## Status
CONFIRMED

## Business Rule
buildSwiftMessages generates one randomUUID() (v4 UUID) per leg iteration and passes the same uetr value into both buildAdviceMessage and buildCoverMessage for that leg — modeling SWIFT gpi's rule that a cover message funding an MT103 carries that MT103's own UETR. A different leg gets an independently generated UETR.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
creditLeg({payAdviceMsgType:'MT103',payCoverMsgType:'MT202COV'}) -> 2 messages, messages[0].uetr === messages[1].uetr, both matching the v4 UUID pattern

## Verification Note
Re-read swiftMessages.ts and confirmed one randomUUID() per leg iteration shared across both builder calls. Re-read the cited tests. CONFIRMED.

## Source Evidence
- src/domain/swiftMessages.ts lines 125-131 — 'const uetr = randomUUID();' generated once per leg, before the advice/cover if-checks, passed to both builder calls
- src/domain/swiftMessages.ts doc comment above buildAdviceMessage (lines 69-72): 'The SAME uetr is shared by a leg's advice AND its cover message, per gpi'
- test/unit/domain/swiftMessages.test.ts — 'H-3: populates a v4 UETR on every generated message, shared between a leg's advice and its cover' (messages[0].uetr === messages[1].uetr); 'H-3: different legs get different UETRs'

## Related Knowledge
- [[SWIFT Messaging and Vouchers]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
