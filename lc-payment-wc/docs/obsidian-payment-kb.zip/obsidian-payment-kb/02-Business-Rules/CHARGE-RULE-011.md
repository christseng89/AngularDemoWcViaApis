---
knowledge_id: CHARGE-RULE-011
title: "Export LC negotiation discount interest is computed on a 360-day-year convention"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - charges
  - confirmed
---

# CHARGE-RULE-011 — Export LC negotiation discount interest is computed on a 360-day-year convention

## Status
CONFIRMED

## Business Rule
B3's optional discount interest leg (only booked when discountDays > 0) is calculated as billTwd × discountRate% × discountDays / 360 — the classic Actual/360 day-count convention, applied here to the negotiation discount.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
discountAmt = round(billTwd * (discountRate/100) * discountDays / 360, 0)

## Verification Note
Re-verified exact formula in source. No change to status.

## Source Evidence
- backend/server.js lines 573-575 (const discountAmt = discountDays > 0 ? round(billTwd * (discountRate/100) * discountDays / 360, 0) : 0;)

## Related Knowledge
- [[Charge Integration]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
