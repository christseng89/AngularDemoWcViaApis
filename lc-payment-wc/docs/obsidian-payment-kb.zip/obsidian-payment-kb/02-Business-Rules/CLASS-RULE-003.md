---
knowledge_id: CLASS-RULE-003
title: "SUSPENSE and INTERNAL account types never participate in classification"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - classification
  - confirmed
---

# CLASS-RULE-003 — SUSPENSE and INTERNAL account types never participate in classification

## Status
CONFIRMED

## Business Rule
Only CUSTOMER, NOSTRO, and VOSTRO account types are tested by the classification XOR terms; a leg of type SUSPENSE or INTERNAL never contributes to customerXor/nostroXor/vostroXor, so a request built entirely of SUSPENSE/INTERNAL legs is never flagged paymentComponentRelated — because they represent internal clearing/bridge postings with no real external counterparty. Merges candidates 2 and 34 (same rule, code vs. FSD statement).

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
classify('id-5', [SUSPENSE], [INTERNAL]) -> customerXor=false, nostroXor=false, vostroXor=false, paymentComponentRelated=false. FSD truth table: SUSPENSE vs SUSPENSE = ✗, SUSPENSE vs INTERNAL = ✗, SUSPENSE vs CUSTOMER = ✓.

## Verification Note
Confirmed directly in classification.ts and its test, plus the FSD truth table in the zh doc which shows the exact ✗/✗/✓ pattern cited. Merged candidate 34 (fsd-architecture-docs group) into this entry as a duplicate.

## Source Evidence
- microservices/payment-component/src/domain/classification.ts top comment line 14
- test/unit/domain/classification.test.ts 'SUSPENSE and INTERNAL never participate in any XOR term'
- converted/analysis__PaymentComponent-Microservice-FSD-zh.docx.txt §2.3 line 33 and truth table lines 774-781
- converted/analysis__Payment-OAS-FSD-en.docx.txt §7.2 lines 58-59

## Related Knowledge
- [[Payment Instruction Classification]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
