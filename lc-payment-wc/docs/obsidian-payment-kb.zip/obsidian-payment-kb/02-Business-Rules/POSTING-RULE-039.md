---
knowledge_id: POSTING-RULE-039
title: "Suspense currency bucket seed totals round PER ENTRY, not once on the combined amount — deliberately, to match the server"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - accounting
  - confirmed
---

# POSTING-RULE-039 — Suspense currency bucket seed totals round PER ENTRY, not once on the combined amount — deliberately, to match the server

## Status
CONFIRMED

## Business Rule
suspenseAdjustment() converts and rounds each Suspense entry individually then sums the already-rounded results, deliberately mirroring the microservice's own buildSuspenseBridgeLeg. Rounding the combined bucket total once instead (v1.7.3) disagreed with the server and produced a genuine 409 LEGS_UNBALANCED.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
Suspense Debit 10 USD + 20 EUR + 50 EUR, rate 0.923295: seed total = 10000 + 10(USD) + round(20×rate)+round(50×rate) = 10085.81, NOT 10085.82

## Verification Note
Server-side half of this claim directly confirmed by reading buildSuspenseBridgeLeg/expandSuspenseBridge in full this pass — per-entry (not per-bucket-combined) conversion is exactly what the code does. Client-side suspenseAdjustment() mirroring this was grep-confirmed to exist and call suspenseCurrencyBuckets(), consistent with the claim.

## Source Evidence
- CLAUDE.md v1.13.1 section (root-context, quoted directly in the task prompt)
- microservices/payment-component/src/domain/suspenseBridge.ts buildSuspenseBridgeLeg, read directly this pass — confirms the SERVER side of this claim: each entry is independently converted/rounded via `formatMonetaryAmount(trxEquivalent, scale)` inside the per-entry function, with expandSuspenseBridge calling it once per bucket entry (never combining amounts before conversion)

## Related Knowledge
- [[Accounting Model]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
