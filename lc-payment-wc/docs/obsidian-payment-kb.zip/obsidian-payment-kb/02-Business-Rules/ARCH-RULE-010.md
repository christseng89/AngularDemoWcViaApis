---
knowledge_id: ARCH-RULE-010
title: "Idempotency key is the composite natural key (originModule, mainRef, sequence) — the CURRENT implementation, distinct from the planned bankContractRef/eventSeq design"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - architecture
  - confirmed
---

# ARCH-RULE-010 — Idempotency key is the composite natural key (originModule, mainRef, sequence) — the CURRENT implementation, distinct from the planned bankContractRef/eventSeq design

## Status
CONFIRMED

## Business Rule
A payment instruction is uniquely identified for idempotency purposes by the triple (originModule, mainRef, sequence), not by any generated instructionId. Replaying the same natural key AND the same request payload returns the already-confirmed instruction (HTTP 200) instead of creating a new one; a genuinely new key creates a new record (HTTP 201). This matches FSD §6.1's stated rule. This is the CURRENT, implemented behavior — it has NOT yet been migrated to the reviewer-confirmed (originModule, bankContractRef, eventSeq) design recorded in CLAUDE.md's RDD section (see the response-shape-outdated-vs-planned-rdd CONFLICT).

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
POST with {originModule:'IPLC', mainRef:'REF-ROUTE-1', sequence:1, ...} twice: first call -> 201 with a new instructionId; second identical call -> 200 with the SAME instructionId as the first.

## Verification Note
Confirmed directly; also cross-checked against Payment_component.yaml/payment-instructions-post.yaml which both still model sequence as a flat integer (matches the CURRENT-state framing, not the planned RDD design) — see the CONFLICT with rule 24/37 noted separately.

## Source Evidence
- microservices/payment-component/src/store/paymentInstructionStore.ts lines 1-18 top doc comment and naturalKey() function, directly re-read: quotes FSD §6.1 verbatim ('重複送入已存在的付款指令,直接回傳既有的已確認結果(200)...')
- microservices/payment-component/src/domain/confirmPaymentInstruction.ts Step 0 (lines ~112-133), directly re-read: store.find() by (originModule, mainRef, sequence), with a C-2 fingerprint check layered on top before returning the 200 replay

## Related Knowledge
- [[Payment Architecture]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
