---
knowledge_id: SWIFT-RULE-011
title: "H-3 (implemented): settlement amount (32A) and instructed amount (33B) are no longer forced equal for a cross-currency leg; a gpi UETR (v4 UUID) is populated on every generated message"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - swift
  - confirmed
---

# SWIFT-RULE-011 — H-3 (implemented): settlement amount (32A) and instructed amount (33B) are no longer forced equal for a cross-currency leg; a gpi UETR (v4 UUID) is populated on every generated message

## Status
CONFIRMED

## Business Rule
As implemented, settlement amount (field 32A, settled/account currency, from leg.amountAccountCcy ?? leg.amountTxCcy) and instructed amount (field 33B, transaction currency, from leg.amountTxCcy) are no longer forced equal — they legitimately differ for a cross-currency payment. A new SwiftMessage.instructedCurrency field carries 33B's currency (transactionCurrency); same-currency payments are unaffected (both collapse to the identical currency+amount). A gpi UETR (v4 UUID, randomUUID()) is populated on every generated message, shared between a leg's advice message and its cover message (see the dedicated UETR rule above). serviceTypeId/isGpiMember remain a documented, unimplemented, config-driven follow-up.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
n/a

## Verification Note
Merged near-duplicate candidates id_hint h3-swift-32a-vs-33b-uetr (fsd-architecture-docs) and h3-32a-33b-decoupled-hardened (validation-gap-docs) into this one statement — both describe the exact same implemented fix, corroborated directly by the code and tests already read above. CONFIRMED against executable evidence (highest priority source).

## Source Evidence
- src/domain/swiftMessages.ts lines 53-88 (buildAdviceMessage) — doc comment describing the H-3 fix in detail; settlementCurrency: leg.currency, settlementAmount: leg.amountAccountCcy ?? leg.amountTxCcy, instructedCurrency: transactionCurrency, instructedAmount: leg.amountTxCcy
- test/unit/domain/swiftMessages.test.ts line 106-116 — 'H-3: for a CROSS-currency leg, 32A (settled, leg ccy) and 33B (instructed, transaction ccy) DIFFER': expect(m.instructedAmount).not.toBe(m.settlementAmount) style assertion via not.toBe
- test/unit/domain/confirmPaymentInstruction.test.ts lines 514-535 — instructedCurrency asserted 'USD' end-to-end
- analysis__Payment-OAS-FSD-en.docx.txt Appendix B, H-3 (line 135) and analysis__Payment_Component_Calculation_Validation.docx.txt line 376 (Spec Sync — 2026-08 Hardening Review, H-3) — identical description of the fix as delivered

## Related Knowledge
- [[SWIFT Messaging and Vouchers]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
