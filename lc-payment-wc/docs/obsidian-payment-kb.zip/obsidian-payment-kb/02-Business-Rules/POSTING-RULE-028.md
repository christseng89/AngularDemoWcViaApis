---
knowledge_id: POSTING-RULE-028
title: "The FX overlay and any real server-generated FX leg pair are contractually never both shown for the same currency, but this component does not itself enforce that dedup"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - accounting
  - confirmed
---

# POSTING-RULE-028 — The FX overlay and any real server-generated FX leg pair are contractually never both shown for the same currency, but this component does not itself enforce that dedup

## Status
CONFIRMED

## Business Rule
response-viewer.component.ts documents and its spec exercises the expectation that the parent template always binds debitFxPairs/creditFxPairs through a filterFxPairsNettedBySuspense step first, suppressing the overlay entirely for any currency the server already generated a real FX Exchange settlement leg pair for. This component's own test only SIMULATES that dedup rather than exercising filterFxPairsNettedBySuspense itself.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
No worked numeric example available in the source evidence reviewed.

## Verification Note
Directly confirmed the doc-comment language via full read of currencyGroups' surrounding comment block this pass.

## Source Evidence
- src/app/payment-component/response-viewer.component.ts lines 259-268 (doc comment on currencyGroups), read directly this pass — matches the claim's language about 'EITHER (1)'s real FX legs OR (2)'s overlay pair, never both'
- response-viewer.component.spec.ts (cited, not independently re-read)

## Related Knowledge
- [[Accounting Model]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
