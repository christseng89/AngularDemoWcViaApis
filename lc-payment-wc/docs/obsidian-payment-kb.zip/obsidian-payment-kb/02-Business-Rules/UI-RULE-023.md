---
knowledge_id: UI-RULE-023
title: "'Exchange A/C No' / FX Exchange label is a client-side-only preview field, never sent to or returned by the server"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - ui
  - confirmed
---

# UI-RULE-023 — "Exchange A/C No" / FX Exchange label is a client-side-only preview field, never sent to or returned by the server

## Status
CONFIRMED

## Business Rule
The leg-allocator's displayed exchangeAccountNo / FX Exchange label is not part of PaymentLegInput and has no corresponding OAS property — it is a same-page simulation preview computed client-side, distinct from the service's actual generated FX Exchange leg.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
n/a

## Verification Note
Confirmed directly: exchangeAccountNo/dealNumber are Row-only fields, never referenced anywhere inside emit()'s leg construction, matching the claim exactly.

## Source Evidence
- leg-allocator.component.ts Row interface doc comment lines 22-31: 'never sent to the microservice (not part of PaymentLegInput/the OAS)'
- emit() (lines 1251-1288): the constructed `leg: PaymentLegInput` object only ever sets accountNo, accountType, currency, amountTxCcy, rtgsIndicator, amountAccountCcy, drBuyRate/crBuyRate — exchangeAccountNo and dealNumber are never assigned onto it

## Related Knowledge
- [[Payment Component Simulator UI]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
