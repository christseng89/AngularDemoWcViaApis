---
knowledge_id: ARCH-RULE-038
title: "No auth, body-size cap, rate limiting, or request/trace correlation on the service — acceptable for demo, not for production"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - architecture
  - confirmed
---

# ARCH-RULE-038 — No auth, body-size cap, rate limiting, or request/trace correlation on the service — acceptable for demo, not for production

## Status
CONFIRMED

## Business Rule
createApp wires express.json() and the router with no authentication, no express.json({limit}) body size cap, no rate limiting, and no request/trace-id correlation. Explicitly called out as acceptable for a demo but a table-stakes production-hardening gap for anything posting to a general ledger.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
No worked numeric example available in the source evidence reviewed.

## Verification Note
Confirmed both the design-doc description AND the actual current app.ts (still true today, not just historically) directly. Doubly verified against executable code.

## Source Evidence
- docs/payment-component-expert-review.md M-8 section, lines 238-243, directly re-read
- microservices/payment-component/src/app.ts, full file directly re-read for rule #11 above: confirms `app.use(express.json())` with no limit option, no auth middleware, no rate-limiter, and no request-id middleware anywhere in the 31-line file

## Related Knowledge
- [[Payment Architecture]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
