---
knowledge_id: API-RULE-009
title: "The /payment-instructions/classify preview endpoint never throws on an unbalanced or otherwise invalid Dr/Cr pairing — it always returns 200 with classification + balance + account-entry results"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - api
  - confirmed
---

# API-RULE-009 — The /payment-instructions/classify preview endpoint never throws on an unbalanced or otherwise invalid Dr/Cr pairing — it always returns 200 with classification + balance + account-entry results

## Status
CONFIRMED

## Business Rule
Unlike the Confirm endpoint (409 on imbalance), classify is a pure preview/GAP-case tool: it returns 200 even when submitted legs are unbalanced, reporting balanced=false and the numeric difference. It also returns SETTLEMENT-type accountEntries for the submitted legs even with no sourceFunctionCode/voucher prefix, flagging in the description that no Payment Component voucher code prefix was applied rather than fabricating one.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
debitLegs=[{RTGS-ACC,NOSTRO,rtgsIndicator:true,IDR,500000}], creditLegs=[{CUST-ACC,CUSTOMER,IDR,499000}] -> 200, balance.balanced=false, balance.difference='1000', 2 SETTLEMENT accountEntries each with description including 'no Payment Component voucher code prefix'

## Verification Note
Re-read regression.ts lines 232-267 directly; confirmed all three checks match verbatim including the exact worked example numbers (500000/499000/difference 1000). No change to status.

## Source Evidence
- microservices/payment-component/test/regression.ts runHttpSmokeTest() classify block: 'classify endpoint returns 200 even when unbalanced' (line 252), 'classify: reports balanced=false with correct difference' (259), 'classify: returns SETTLEMENT accountEntries ... without fabricating a voucher prefix' (261-267)

## Related Knowledge
- [[Payment Instructions API]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
