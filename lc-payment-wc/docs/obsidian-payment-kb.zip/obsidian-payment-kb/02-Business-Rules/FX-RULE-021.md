---
knowledge_id: FX-RULE-021
title: "A leg's own settlement currency can differ from the deal's Transaction Currency; two independent input surfaces converge on the same amountTxCcy"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - fx
  - confirmed
---

# FX-RULE-021 — A leg's own settlement currency can differ from the deal's Transaction Currency; two independent input surfaces converge on the same amountTxCcy

## Status
CONFIRMED

## Business Rule
Row.currency is independent of transactionCurrency. needsRate(row) is true whenever they differ, exposing an editable FX rate and an 'Account Ccy Equiv.' input. amountTxCcy can be entered directly (onAmountInput) or derived from a typed row-currency amount divided by the row's rate (onAccountAmountInput).

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
Row currency EUR, rate 1.5, user types EUR 30 into Account Ccy Equiv. -> amountTxCcy = 30/1.5 = USD 20.

## Verification Note
Confirmed needsRate()'s exact implementation by direct read (lines 387-389: `!!row.currency && row.currency !== this.transactionCurrency`). onAccountAmountInput's division-based derivation was not re-read line-by-line in this pass but is corroborated by the accountCcyOverride mechanism (rule 24, directly confirmed) which exists specifically to fix a precision-loss bug in that same derivation path. No status change.

## Source Evidence
- leg-allocator.component.ts needsRate() lines 387-389
- leg-allocator.component.ts onAccountAmountInput() region ~996-1062

## Related Knowledge
- [[FX Processing]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
