---
knowledge_id: POSTING-RULE-040
title: "Account Ccy Equivalent and Amount (Tx Ccy) are independently-typed, never re-derived from each other's rounded value ('B-Tree' banking math principle)"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - accounting
  - confirmed
---

# POSTING-RULE-040 — Account Ccy Equivalent and Amount (Tx Ccy) are independently-typed, never re-derived from each other's rounded value ('B-Tree' banking math principle)

## Status
CONFIRMED

## Business Rule
Whichever field was actually typed by the user is authoritative and stored via an override (accountCcyOverride), never re-derived from its own already-rounded counterpart in the other currency.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
n/a

## Example
Account Ccy Equiv. 20000 JPY at rate 149.0825 → Amount (Tx Ccy) correctly shows rounded 134.15 USD, but the JPY field itself stays exactly 20000 as typed, not re-derived to 19999

## Verification Note
Partially re-verified via emit()'s use of accountCcyAmountDecimal() (a named method distinct from a raw re-derivation), which is consistent with the claimed override mechanism, though the accountCcyOverride field itself and accountCcyAmountDecimal()'s internal logic were not independently re-opened this pass. Kept CONFIRMED given the corroborating code structure and the very detailed, specific worked-example documentation in CLAUDE.md.

## Source Evidence
- CLAUDE.md 'Account Ccy Equiv. edits now round-trip exactly' section (quoted in task prompt)
- src/app/payment-component/leg-allocator.component.ts emit() code read directly this pass shows `this.accountCcyAmountDecimal(r).toFixed(rowScale)` used for the wire amountAccountCcy rather than a fresh `amountTxCcy × rate` re-derivation, consistent with the override-preference mechanism described

## Related Knowledge
- [[Accounting Model]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
