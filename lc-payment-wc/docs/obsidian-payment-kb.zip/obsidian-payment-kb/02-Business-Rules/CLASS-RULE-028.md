---
knowledge_id: CLASS-RULE-028
title: "Five proposed sourceFunctionCode values (Issue, Acceptance, Repayment, Negotiation, Reimbursement) have no entry in VOUCHER_CODE_PREFIXES today"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - classification
  - confirmed
---

# CLASS-RULE-028 — Five proposed sourceFunctionCode values (Issue, Acceptance, Repayment, Negotiation, Reimbursement) have no entry in VOUCHER_CODE_PREFIXES today

## Status
CONFIRMED

## Business Rule
None of the five proposed sourceFunctionCode values needed for the new use cases resolve via voucherDescription.ts's VOUCHER_CODE_PREFIXES table. Each needs either a Payment_Mapping_Functions.docx §6 lookup to find the real legacy prefix, or reconciliation with an existing registered function that may already cover the same real-world screen under a different name.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
No worked numeric example available in the source evidence reviewed.

## Verification Note
Cross-checked both the proposed-use-cases document's own summary and the actual VOUCHER_CODE_PREFIXES table in voucherDescription.ts — confirmed none of the 5 named proposed codes appear as keys (only PayAccept, PayAcceptWithDiscount, PaymentAtMaturity, PayAtMaturity, Discount, Payment, Process400, PrePayment, PaymentDP, SettlementDA, OutwardClaimSettlement, SettleInwardClaim exist).

## Source Evidence
- PaymentComponentProposedUseCases-EN.docx.txt (converted) line 170, 'Cross-cutting Open Questions Summary — Voucher-code prefixes'
- microservices/payment-component/src/domain/voucherDescription.ts VOUCHER_CODE_PREFIXES table lines 37-51 (no Issue/Acceptance/Repayment/Negotiation/Reimbursement keys present)

## Related Knowledge
- [[Payment Instruction Classification]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
