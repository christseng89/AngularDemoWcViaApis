---
knowledge_id: CHARGE-RULE-004
title: "Foreign/correspondent bank charges (and related fees) are embedded in the net settlement leg when paid in the same currency as that leg, else booked as a separate CA debit"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - charges
  - confirmed
---

# CHARGE-RULE-004 — Foreign/correspondent bank charges (and related fees) are embedded in the net settlement leg when paid in the same currency as that leg, else booked as a separate CA debit

## Status
CONFIRMED

## Business Rule
FBC recurs across Import Settlement, Import Sight Payment, Export Collection, and Export Settlement. The rule (stated in code comments AND implemented as actual conditional logic, not just documented intent): if the customer elects to pay/receive the FBC in the same currency as the main settlement leg (bill/CA currency), the FBC amount is netted directly into that Cr/Dr CA leg; if a different currency (typically TWD) is chosen, FBC is booked as its own separate CA leg. The same embedding logic applies to Collection Fee and Settlement Commission in Export Collection/Settlement.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
No worked numeric example available in the source evidence reviewed.

## Verification Note
Upgraded confidence: original evidence was UI comments only; re-verification found the actual server-side conditional embedding logic in backend/server.js (B4/B5 endpoints), confirming this is real implemented behavior, not just a design comment. Also note: this is the same underlying mechanism as the Accounting-domain candidate 'per-charge-currency-selection-with-embedding-rule' from another extraction group — both describe the identical code, not two separate findings (see conflicts_found).

## Source Evidence
- lc-collection.element.ts lines 8-10 (top comment: 'Dr CA (FBC) only if FBC ccy ≠ Cr CA ccy')
- lc-settlement.element.ts (export) lines 56-59 (comment: 'FBC charge: customer chooses billCcy (embedded in net Cr CA) or TWD (Dr CA separately)')
- lc-settlement.element.ts (import) lines 51-60 (_initCharges: single net charge row 'billAmount + corrCharges − marginHeld')
- backend/server.js lines 625-868: actual conditional logic — fbcEmbedded/commEmbedded/colFeeEmbedded booleans computed by comparing chosen ccy to net-leg ccy; 'Dr CA (FBC) — only when NOT embedded' comments at lines 715, 824; embedded[] array drives the Cr CA description text (lines 734-736, 838-841)

## Related Knowledge
- [[Charge Integration]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
