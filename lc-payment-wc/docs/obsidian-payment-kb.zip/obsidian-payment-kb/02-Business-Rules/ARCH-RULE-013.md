---
knowledge_id: ARCH-RULE-013
title: "Every non-N_A business case is modeled as exactly one fixed Debit leg and one fixed Credit leg, not a dynamic repeater"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - architecture
  - confirmed
---

# ARCH-RULE-013 — Every non-N_A business case is modeled as exactly one fixed Debit leg and one fixed Credit leg, not a dynamic repeater

## Status
CONFIRMED

## Business Rule
LegSpec is documented and tested as a fixed slot sized to the FSD's own worked example for that function, not a dynamic add/remove repeater — every PASS and GAP case in the registry has exactly 2 legs (one DEBIT, one CREDIT). The actual debit/credit leg arrays sent on the wire are built later by a separate leg-allocator UI component which can split a single LegSpec default into multiple posted legs; this registry-level model is only the seed/default, not the wire shape.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
iplc-pay-accept.legs = [leg('DEBIT','CUSTOMER','CUST-ACC','USD','10000'), leg('CREDIT','NOSTRO','NOSTRO-ACC','USD','10000')] — exactly 2 entries (registry pattern confirmed by the spec's own assertion).

## Verification Note
Confirmed directly against both files including the exact test assertion text. Unchanged.

## Source Evidence
- src/app/payment-component/business-case.model.ts line 5, directly re-read: 'One fixed leg slot in a business case's scenario. Sized to the FSD's own worked example for that function ... not a dynamic add/remove repeater'
- src/app/payment-component/business-case-registry.spec.ts lines 25-30, directly re-read: `it('every PASS/GAP case has exactly one DEBIT and one CREDIT leg', ...)` asserting `expect(c.legs).toHaveLength(2)` for every case with verdict !== 'N_A'

## Related Knowledge
- [[Payment Architecture]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
