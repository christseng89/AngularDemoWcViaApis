---
knowledge_id: VALIDATION-RULE-024
title: "Directly-typed % is whole-percentage-point only (1% granularity); Amount editing has no such restriction"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - validation
  - confirmed
---

# VALIDATION-RULE-024 — Directly-typed % is whole-percentage-point only (1% granularity); Amount editing has no such restriction

## Status
CONFIRMED

## Business Rule
onPctInput rounds every typed % to the nearest integer (Decimal.ROUND_HALF_UP, 0dp) before running the % waterfall — a split needing finer precision must switch to Amount editing instead. This rounding applies ONLY to a directly typed %; the % displayed for an Amount-driven row (derived from its own amount) remains non-integer (2dp) and is unaffected.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
n/a — rounding-boundary rule, verified via the cited spec test.

## Verification Note
Confirmed exactly by direct read of onPctInput() lines 761-773.

## Source Evidence
- src/app/payment-component/leg-allocator.component.ts lines 754-773 (onPctInput doc comment and body — clampPct(pct).toDecimalPlaces(0, Decimal.ROUND_HALF_UP))
- leg-allocator.component.spec.ts '% waterfall' test: 'a fractional typed % is rounded to the nearest whole percentage point (ROUND_HALF_UP) before the waterfall runs' — 12.6 rounds to 13 first

## Related Knowledge
- [[Request Validation]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
