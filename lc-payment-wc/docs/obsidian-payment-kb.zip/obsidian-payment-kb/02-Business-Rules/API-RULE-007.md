---
knowledge_id: API-RULE-007
title: "Resubmitting a Confirm request with the same natural key (originModule+mainRef+sequence) is a no-op replay returning 200 with the same instructionId, not a new 201"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - api
  - confirmed
---

# API-RULE-007 — Resubmitting a Confirm request with the same natural key (originModule+mainRef+sequence) is a no-op replay returning 200 with the same instructionId, not a new 201

## Status
CONFIRMED

## Business Rule
POST /payment-instructions is idempotent on its natural key: the first POST for a given key returns 201 Created; any subsequent POST with the identical key returns 200 with the SAME instructionId, not a duplicate.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
POST {originModule:'EXCO', mainRef:'EXCO-TEST-0001', sequence:1,...} -> 201, instructionId=X. Identical POST again -> 200, instructionId=X.

## Verification Note
Re-read regression.ts around lines 145-158; confirmed both checks exist and match the stated behavior. Merged conceptually with the near-duplicate FSD-doc-sourced rule (former id 'idempotency-natural-key' / #20 and #16) — see that entry below for the merge note; kept this one separate since it is grounded in executable test evidence (higher evidence priority) rather than doc text, per the evidence-priority ordering (executable tests > docs).

## Source Evidence
- microservices/payment-component/test/regression.ts runHttpSmokeTest(): 'resubmitting the same natural key returns 200 (idempotent replay)' (line 153), 'replay returns the same instructionId' (line 154)

## Related Knowledge
- [[Payment Instructions API]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
