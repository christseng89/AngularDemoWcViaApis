---
knowledge_id: ARCH-RULE-001
title: "Confirm flow executes in a fixed, FSD-traced step order with suspenseBridge expansion inserted before balance validation"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - architecture
  - confirmed
---

# ARCH-RULE-001 — Confirm flow executes in a fixed, FSD-traced step order with suspenseBridge expansion inserted before balance validation

## Status
CONFIRMED

## Business Rule
confirmPaymentInstruction() runs: Step 0 idempotency/fingerprint lookup (skipped in dryRun) -> suspenseBridge expansion (v1.4.0, not legacy-traced, runs before Step 1 so bridge legs participate in the balance check, with v1.7.1 FX-pair-adjacent leg reordering) -> Step 1 (§3) Dr/Cr V8 balance validation (tolerance defaults to 0, throws 409 LEGS_UNBALANCED on failure) -> Step 2 (§4) classification (informational) -> Step 3 (§5) voucher description/code assembly -> Step 4 (§6.1) Settlement Account Entry generation (unconditional) -> Step 5 (§7) SWIFT cross-field validation then message generation -> persist (unless dryRun).

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
n/a — structural/ordering rule spanning the whole function

## Verification Note
Re-read the full file directly. Statement matches exactly, including the M-7 tolerance-default and v1.7.1 leg-ordering detail embedded in the code comments. CONFIRMED unchanged.

## Source Evidence
- microservices/payment-component/src/domain/confirmPaymentInstruction.ts full function body read end-to-end (lines 1-219): top doc comment describing the order, Step 0 idempotency+C-2 fingerprint check, suspenseBridge expansion with v1.7.1 leg-splitting/reordering comment, tolerance default of 0 (M-7), Steps 2-5 in sequence, dryRun short-circuit before store.save

## Related Knowledge
- [[Payment Architecture]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
