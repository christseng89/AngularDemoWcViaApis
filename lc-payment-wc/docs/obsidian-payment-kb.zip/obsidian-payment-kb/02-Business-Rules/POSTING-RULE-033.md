---
knowledge_id: POSTING-RULE-033
title: "Monetary amount decimal scale (minor units) is currency-driven, not fixed at 2dp"
domain: Payment
category: Business Rule
status: CONFIRMED
source_repository: Payment Component (lc-payment-wc)
last_verified_commit: N/A - no git history in analyzed snapshot, see [[Source-to-Knowledge-Map]]
snapshot_date: 2026-08-22
tags:
  - payment
  - accounting
  - confirmed
---

# POSTING-RULE-033 — Monetary amount decimal scale (minor units) is currency-driven, not fixed at 2dp

## Status
CONFIRMED

## Business Rule
MonetaryAmount's description states scale is currency-driven: 2dp for EUR/USD, 0 for JPY, 3 for BHD/KWD. The wire-level pattern permits up to 3dp for ANY currency, but the actual permitted precision for a given amount is determined by its own currency's minor units — a business-rule check layered on top of the schema pattern.

## Conditions
Not separately stated beyond the Business Rule statement above.

## Result
Not separately stated beyond the Business Rule statement above.

## Example
No worked numeric example available in the source evidence reviewed.

## Verification Note
Directly corroborated via money.ts's live CURRENCY_MINOR_UNITS table and its doc comments (read in full this pass), which implement exactly this currency-driven-scale concept and explicitly discuss the gap between the wire pattern's ceiling and the true per-currency limit.

## Source Evidence
- analysis/Payment_component.yaml MonetaryAmount description (cited, not independently re-opened)
- microservices/payment-component/src/money.ts CURRENCY_MINOR_UNITS table (USD:2, JPY:0, etc.) and knownMinorUnitsForCurrency(), read directly this pass — confirms this is a live, implemented rule, not just an OAS description

## Related Knowledge
- [[Accounting Model]]
- [[Business-Rule-Index]]
- [[Payment-Traceability-Matrix]]
