---
knowledge_id: Posting-Direction-Decision-Table
title: "Posting Direction Decision Table"
domain: Payment
category: Decision Table
snapshot_date: 2026-08-22
tags:
  - payment
  - decision-table
  - accounting
---

# Posting Direction Decision Table

How `drCrIndicator` and amount validity are determined for a Settlement Account Entry. See [[Accounting Model]] and [[Settlement]].

| Input | drCrIndicator | Amount sign allowed? | Result |
|---|---|---|---|
| Leg appears in `debitLegs[]` | `D` | Must be **positive** (M-1) — direction comes from array membership, never from sign | One `SETTLEMENT` AccountEntry, debit |
| Leg appears in `creditLegs[]` | `C` | Must be **positive** (M-1) | One `SETTLEMENT` AccountEntry, credit |
| Leg has a negative `amountTxCcy` | — | **Rejected**, HTTP 400 | Request never reaches posting — this is what prevents "gaming" the V8 balance check with a sign trick |
| Leg's exchange rate is zero | — | **Rejected**, HTTP 400 (M-2) | Prevents a rate of 0 silently zero-converting and dropping a real leg with no error |
| Suspense-bridge-generated leg | `C` always | n/a (internally computed, never negative) | Always credit-direction regardless of source bucket — see [[Suspense Bucket Routing Decision Table]] |
| FX Exchange pair, foreign-currency side | matches the exposure's own direction | n/a | Self-balancing pair — see [[FX Trigger Decision Table]] |

## Why amount sign can never encode direction

If a negative amount were allowed to flip a leg's effective direction, a caller could submit a debit leg with a negative amount that arithmetically behaves like a credit — passing the aggregate V8 check while representing a nonsensical or fraudulent posting intent. Requiring direction to come exclusively from which array (`debitLegs` vs. `creditLegs`) a leg is submitted in closes this off entirely; it is one of the "M-1" hardening rules confirmed by both the expert review and the microservice's own validation tests.

## Source evidence

`microservices/payment-component/src/validation/requestSchema.ts`; `src/domain/accountEntries.ts`; `test/unit/validation/requestSchema.test.ts`; `test/unit/domain/accountEntries.test.ts`. See `POSTING-RULE-*` and `VALIDATION-RULE-*` entries in [[Business-Rule-Index]].
