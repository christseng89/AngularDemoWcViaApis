---
knowledge_id: Classification-XOR-Decision-Table
title: "Classification XOR Decision Table"
domain: Payment
category: Decision Table
snapshot_date: 2026-08-22
tags:
  - payment
  - decision-table
  - classification
---

# Classification XOR Decision Table

Worked truth table for [[Payment Instruction Classification]]. "D" = present on the debit side, "C" = present on the credit side, "-" = absent from that side.

| CUSTOMER (D) | CUSTOMER (C) | NOSTRO (D) | NOSTRO (C) | VOSTRO (D) | VOSTRO (C) | customerXor | nostroXor | vostroXor | paymentComponentRelated |
|---|---|---|---|---|---|---|---|---|---|
| ✓ | - | - | ✓ | - | - | true | true | false | **true** |
| ✓ | ✓ | - | - | - | - | false | false | false | **false** |
| - | - | ✓ | ✓ | - | - | false | false | false | **false** |
| - | - | - | - | ✓ | - | false | false | **true** | **true** |
| ✓ | - | ✓ | - | - | - | true | true | false | **true** (multiple terms can fire at once) |
| - | - | - | - | - | - | false | false | false | **false** (SUSPENSE/INTERNAL-only legs — these types never participate) |

## Reading the table

- Any single term (`customerXor`, `nostroXor`, `vostroXor`) firing is sufficient — the result is an OR across three independent XOR tests, not a single combined condition.
- A type on **both** sides cancels (row 2); a type on **neither** side never fires (row 6) — only a one-sided crossing counts.
- SUSPENSE and INTERNAL are structurally excluded from all three terms — see [[Account Types]].
- The result is informational only — see [[Confirm Payment Instruction Flow]] for confirmation that this never gates posting.

## Source evidence

`microservices/payment-component/src/domain/classification.ts`; `test/unit/domain/classification.test.ts`. See `CLASS-RULE-*` entries in [[Business-Rule-Index]] for the full rule set, including the RTGS-as-NOSTRO-flag CONFLICT.
