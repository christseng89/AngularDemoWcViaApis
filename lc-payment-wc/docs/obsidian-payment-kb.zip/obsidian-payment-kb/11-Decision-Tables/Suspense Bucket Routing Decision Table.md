---
knowledge_id: Suspense-Bucket-Routing-Decision-Table
title: "Suspense Bucket Routing Decision Table"
domain: Payment
category: Decision Table
snapshot_date: 2026-08-22
tags:
  - payment
  - decision-table
  - suspense
---

# Suspense Bucket Routing Decision Table

How a raw `SuspenseEntry` becomes a leg. See [[Suspense Account]] and [[Suspense Bridge Expansion Flow]].

| Input list | Amount | Currency vs. transaction currency | Generated leg direction | Generated account | FX pair? |
|---|---|---|---|---|---|
| `debitEntries` | 0 | any | **none** — zero-amount entries produce no leg | — | no |
| `debitEntries` | > 0 | same | CREDIT | `Suspense - Debit` | no |
| `debitEntries` | > 0 | foreign | CREDIT | `Suspense - Debit` | yes — see [[FX Trigger Decision Table]], DEBIT-side netting rule |
| `creditEntries` | 0 | any | **none** | — | no |
| `creditEntries` | > 0 | same | CREDIT | `Suspense - Credit` | no |
| `creditEntries` | > 0 | foreign | CREDIT | `Suspense - Credit` | yes — see [[FX Trigger Decision Table]], CREDIT-side independent-pairs rule |

## The one universal rule across both buckets

**Every generated Suspense leg lands in the CREDIT-direction output array, regardless of which input list (`debitEntries` or `creditEntries`) it came from.** This is easy to misread as a typo — it is not. `debitEntries` means "the Charge/Balance Component is debiting its own contra account and this module must generate the OFFSETTING credit," and the same logic applies symmetrically to `creditEntries`. See [[Charge Integration]] for the two-component posting pattern this implements.

## Source evidence

`buildSuspenseBridgeLeg` in `microservices/payment-component/src/domain/suspenseBridge.ts`; `test/unit/domain/suspenseBridge.test.ts`. See [[Suspense-Bridge-Test-Scenarios]] for the full worked-example table.
