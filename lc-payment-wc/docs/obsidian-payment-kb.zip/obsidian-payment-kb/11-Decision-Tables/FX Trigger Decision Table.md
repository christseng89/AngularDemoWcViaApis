---
knowledge_id: FX-Trigger-Decision-Table
title: "FX Trigger Decision Table"
domain: Payment
category: Decision Table
snapshot_date: 2026-08-22
tags:
  - payment
  - decision-table
  - fx
---

# FX Trigger Decision Table

When does an FX Exchange pair get generated, and how is it sized? See [[FX Processing]] and [[Suspense Bridge Expansion Flow]] for the narrative.

| Source of foreign-currency exposure | Bucket currency = transaction currency? | Side | Matching same-currency real leg? | Result |
|---|---|---|---|---|
| Suspense bridge entry | Yes | either | n/a | No FX pair — Suspense leg posted directly in transaction currency |
| Suspense bridge entry | No (foreign) | DEBIT | No matching real leg | One Suspense-anchored pair, sized to the full gross bucket amount |
| Suspense bridge entry | No (foreign) | DEBIT | Real leg amount = gross Suspense amount exactly | **No FX pair** — "Same Currency + Same Amount → Direct Settlement" |
| Suspense bridge entry | No (foreign) | DEBIT | Real leg amount < gross Suspense amount | One Suspense-anchored residual pair, sized to the shortfall |
| Suspense bridge entry | No (foreign) | DEBIT | Real leg amount > gross Suspense amount | One Leg-anchored residual pair, sized to the excess |
| Suspense bridge entry | No (foreign) | CREDIT | No matching real leg | One Suspense-anchored pair, full gross amount |
| Suspense bridge entry | No (foreign) | CREDIT | Real leg exists (any amount) | **TWO independent pairs** — Suspense-anchored (full gross) AND Leg-anchored (full real-leg amount) — never netted |
| A caller's own leg (leg-allocator UI) | No (foreign) | either | n/a | Client-side-only preview pair shown to the user; never sent to or received from the server |

## Why DEBIT and CREDIT differ

A DEBIT-bucket Suspense leg lands CREDIT while its matching real debit leg is DEBIT — opposite placement, i.e. genuinely the same money seen from two sides, so netting is safe and correct. A CREDIT-bucket Suspense leg and a matching real credit leg are the SAME direction (both CREDIT) — independent exposures that merely share a currency, so netting them would silently break per-currency balance. See [[Suspense Account]] for the full v1.7.0→v1.9.0 iteration history that established this.

## Source evidence

`microservices/payment-component/src/domain/suspenseBridge.ts`; `test/unit/domain/suspenseBridge.test.ts`; `test/unit/domain/confirmPaymentInstruction.test.ts` (`REF-SB-NET-1`/`REF-SB-NET-2`). See `SUSPENSE-RULE-*` and `FX-RULE-*` entries in [[Business-Rule-Index]].
