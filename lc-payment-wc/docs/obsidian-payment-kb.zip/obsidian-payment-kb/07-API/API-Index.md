---
knowledge_id: API-Index
title: "API Index"
domain: Payment
category: Index
snapshot_date: 2026-08-22
tags:
  - payment
  - index
---

# API Index

- [[Payment Instructions API]] — endpoints, request/response shape, idempotency HTTP semantics, the two-OpenAPI-documents divergence
- [[Payment Instruction (Data Model)]] — enums and interfaces, the `transactionCurrency` field's history
- [[Request Validation]] — the 400-vs-409 layering and its specific rules (M-1, M-2, H-2, C-2)
- [[Business-Rule-Index]] — 20 rules tagged API (`API-RULE-*`), 43 tagged Validation (`VALIDATION-RULE-*`)
- Source contracts: `analysis/Payment_component.yaml`, `analysis/payment-instructions-post.yaml` — see [[Source-to-Knowledge-Map]] for what each cites
