---
knowledge_id: Payment-Instructions-API
title: "Payment Instructions API"
domain: Payment
category: API
snapshot_date: 2026-08-22
tags:
  - payment
  - api
---

# Payment Instructions API

The Payment Component microservice (`microservices/payment-component/src/routes/paymentInstructions.ts`) exposes a small, synchronous REST surface centered on one write endpoint and several read-only companions.

## Endpoints

| Method | Path | Purpose |
|---|---|---|
| `POST` | `/payment-instructions` | The Confirm endpoint — see [[Confirm Payment Instruction Flow]]. Also serves preview via `dryRun:true`. |
| `POST` | `/payment-instructions/classify` | Unofficial, non-OAS preview endpoint. Requires **both** `debitLegs` and `creditLegs` non-empty (stricter than Confirm) and never persists. |
| `GET` | `/payment-instructions` | List/search, backed by `PaymentInstructionStore.search()`. An invalid `originModule` filter is silently treated as "no filter" rather than a 400. |
| `GET` | `/payment-instructions/{id}` | Retrieve one persisted instruction. |
| `GET` | `/payment-instructions/{id}/account-entries` | Read-only sub-resource — never independently queryable, 404s identically to the parent when `id` is unknown. |
| `GET` | `/payment-instructions/{id}/swift-messages` | Same shape as account-entries. Status is always `PENDING` — no transmission integration exists. |
| `GET` | `/payment-routing` | Present in the broader `Payment_component.yaml` contract only — not in the narrower `payment-instructions-post.yaml` extract. |

## Two OpenAPI documents that have materially diverged

`analysis/Payment_component.yaml` and `analysis/payment-instructions-post.yaml` both claim to describe this API, and `Payment_component.yaml` itself claims the two are "kept in lockstep." They are not: the `SwiftMessage` schema in `payment-instructions-post.yaml` includes a `v-H3` `instructedCurrency` field and a 32A/33B decoupling rule that `Payment_component.yaml`'s copy lacks entirely. This is recorded as a `VALIDATION-RULE`/`API-RULE` CONFLICT — a concrete, self-demonstrating instance of the staleness the broader document admits to in its own description. See [[Knowledge-Gaps]].

## Request/response shape at a glance

A Confirm request carries a natural key (`originModule`, `mainRef`, `sequence`), `debitLegs[]`/`creditLegs[]` (each a [[Payment Instruction (Data Model)|PaymentLegInput]]), an optional explicit `transactionCurrency`, and an optional `suspenseBridge`. The response embeds the leg list (enriched with server-derived `legId`/`legSide`/`accountDesc`/`accountCategory`), the [[Payment Instruction Classification|classification]] result, the generated `accountEntries[]`, and any `swiftMessages[]` — all in one atomic response, never split across follow-up calls.

## Idempotency semantics on the wire

`HTTP 201` = a genuinely new instruction was created. `HTTP 200` = an idempotent replay of an already-confirmed instruction (same natural key, same payload fingerprint). A same-key-different-payload request is `409 IDEMPOTENCY_KEY_CONFLICT`. `dryRun:true` requests skip the idempotency store entirely and always return `200` with `created:false`, even for a brand-new natural key that has never been confirmed.

## Related knowledge

- [[Confirm Payment Instruction Flow]]
- [[Request Validation]]
- [[Payment Instruction (Data Model)]]
- [[Business-Rule-Index]] — 20 rules tagged API (`API-RULE-*`)
