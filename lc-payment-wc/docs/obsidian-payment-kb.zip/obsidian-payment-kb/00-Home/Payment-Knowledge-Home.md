---
knowledge_id: Payment-Knowledge-Home
title: "Payment Knowledge Home"
domain: Payment
category: Home
snapshot_date: 2026-08-22
tags:
  - payment
  - home
---

# Payment Knowledge Home

This vault reverse-engineers the **lc-payment-wc** repository — a Trade Finance / Payment demo built around one real microservice (the **Payment Component**), an Angular simulator UI, a separate demo backend, and an extensive set of pre-existing FSDs, expert reviews, and manuals — into a traceable, AI- and human-readable knowledge base. It answers, in order: what the Payment Component does, why it does it, what rules govern it, how accounting/FX/suspense actually work, where each rule lives in code, and how each rule is tested.

**How this vault was built:** 18 parallel agents each read a bounded slice of the repository (microservice domain code, Angular UI, the demo backend, OpenAPI contracts, and every existing FSD/review/manual) and extracted candidate business rules tagged CONFIRMED / INFERRED / UNCLEAR / CONFLICT. A second wave of agents, grouped by domain, adversarially re-opened the cited evidence for every candidate rule, downgraded anything that didn't hold up, merged duplicates, and hunted for cross-source contradictions. UNCLEAR rules were routed to [[Knowledge-Gaps]] instead of being asserted as fact. See [[Knowledge-Quality-Report]] for the full methodology and self-scoring, and [[Source-to-Knowledge-Map]] for the freshness caveat (this snapshot has no `.git` history to pin a commit hash to).

## Start here

- [[Payment Component Overview]] — what this repo actually is, in one page
- [[Payment Architecture]] — the three moving parts (microservice, Angular UI, demo backend) and how they relate
- [[Payment]] · [[Settlement]] · [[Payment Instruction Classification]] — the core domain vocabulary
- [[Accounting Model]] · [[FX Processing]] · [[Suspense Account]] · [[Charge Integration]] — the four hardest, most rule-dense subsystems
- [[SWIFT Messaging and Vouchers]] · [[Request Validation]] · [[Payment Instructions API]]

## Navigate by kind of question

**"What business rules exist, and how confident are we?"**
→ [[Business-Rule-Index]] (304 traceable rules across 13 domains) · [[Knowledge-Gaps]] (89 UNCLEAR items, cross-source conflicts, and verification-flagged gaps)

**"How does a request flow through the system end to end?"**
→ [[Payment-Flow-Index]] — Confirm flow, Suspense bridge expansion, FX pair generation, SWIFT generation, the Angular preview/Confirm loop, and the nine legacy LC web-component events

**"What does the API actually accept/return, and how does that map to the OpenAPI spec?"**
→ [[API-Index]] · [[Payment Instructions API]] · [[Payment Instruction (Data Model)]]

**"What decision governs X given conditions Y and Z?"**
→ 11-Decision-Tables: classification XOR, FX trigger, Suspense bucket routing, Dr/Cr posting direction

**"What test proves this rule is real?"**
→ [[Test-Scenario-Index]] · [[Testing Methodology and Coverage]] · [[Payment-Traceability-Matrix]]

**"Where in the source code does this rule live, and what might go stale if that file changes?"**
→ [[Source-to-Knowledge-Map]]

## Scope and honesty notes

- This snapshot has **no git history** — there is no commit hash to cite. Every note's `last_verified_commit` frontmatter field says so explicitly; freshness is tracked by snapshot date and source file mtime instead (see [[Source-to-Knowledge-Map]]).
- The repository contains **two functionally separate backends**: the real `microservices/payment-component` TypeScript service (the actual "Payment Component"), and a `backend/` Express demo server that computes legacy Import/Export LC charge calculations for the nine `web-components/` LC elements. They do not call each other. Conflating them is a common source of confusion — see [[Payment Architecture]].
- Charge/commission/margin **calculation** is explicitly out of scope for the Payment Component microservice by architectural decision (owned by an external "Charge/Balance Component," reached only via the [[Suspense Account|Suspense bridge]]). The `backend/` demo server's LC elements DO compute charges, but on a separate, unrelated code path. See [[Charge Integration]] for the full boundary.
- 24 domain-level conflicts and 51 verification-flagged gaps were found and are preserved, not resolved by fiat, in [[Knowledge-Gaps]].
