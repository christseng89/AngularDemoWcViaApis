---
knowledge_id: Payment-Component-Overview
title: "Payment Component Overview"
domain: Payment
category: Overview
snapshot_date: 2026-08-22
tags:
  - payment
  - overview
---

# Payment Component Overview

The **Payment Component** is a shared, module-agnostic settlement layer for a bank's Trade Finance systems (Import LC, Export LC, Import/Export Bill Loans, Guarantees, Supply Chain Finance, and more). Instead of every trade-finance module implementing its own Dr/Cr posting, classification, and SWIFT-generation logic, each module submits one **Payment Instruction Confirm request** — a set of debit legs, a set of credit legs, a natural key, and (optionally) a bridge to an external Charge/Balance Component — and the Payment Component atomically: validates the legs balance exactly, classifies whether the transaction is "Payment-Component-related," assembles voucher descriptions, posts one GL Account Entry per leg, and generates any required SWIFT/ISO 20022 messages. See [[Payment-Flow-Index]] for the exact step order.

This is a **demo/reference implementation**, not the production banking core. Its business rules are explicitly traced back to a real legacy system's source functions wherever possible (see the `voucherDescription.ts`/`swiftMessages.ts` legacy-formula ports, and the 23-case business-case catalog in [[Payment Component Simulator UI]]) — 15 of 23 traced legacy Confirm functions are confirmed PASS users of an equivalent posting pattern, 4 are GAP (RPFM has its own parallel posting rail), 4 are N/A.

## The three parts of this repository

| Part | What it is | Role |
|---|---|---|
| `microservices/payment-component/` | Real TypeScript/Express microservice | **The actual Payment Component.** Owns classification, Dr/Cr balance validation, voucher assembly, GL posting, SWIFT generation, and the Suspense bridge. See [[Payment Architecture]]. |
| `src/app/` (Angular) | Payment Component Simulator + legacy LC web components | UI for driving the microservice through 23 catalogued business cases ([[Payment Component Simulator UI]]), plus a separate set of 9 vanilla-JS LC event elements (see [[Legacy LC Event Flows]]) that do **not** call the microservice at all. |
| `backend/` | Express "legacy Import/Export LC mock API" | A **demo-only, architecturally unrelated** backend serving fake currency/FX data and computing the 9 LC events' charge/settlement figures for the vanilla web components. See ARCH-RULE entries tagged `demo-backend` in [[Business-Rule-Index]]. |

## What the Payment Component deliberately does NOT do

- **Charge/commission/margin calculation.** Removed from this service in v1.6.0; owned entirely by an external Charge/Balance Component, reached only through the [[Suspense Account|Suspense bridge]]. See [[Charge Integration]].
- **Legacy RPFM-style ±0.01 balance tolerance.** The legacy per-side "≤ target total" check was replaced with an exact Dr = Cr equality check (V8, zero tolerance by default) — see the Accounting domain's `POSTING-RULE` entries and [[Knowledge-Gaps]] for the M-7 hardening history.
- **SWIFT transmission.** Messages are generated and persisted with status `PENDING`; no actual network transmission integration exists.
- **Idempotency across restarts.** The instruction store is in-memory (see ARCH-RULE entries under `api-validation`), so idempotent replay only works within one running process — a documented operational gap, not a business-rule gap.

## Where to go next

- [[Payment Architecture]] for the component diagram and how the three parts above actually talk (or don't talk) to each other.
- [[Payment-Flow-Index]] for the Confirm flow, Suspense bridge, and Angular preview/Confirm loop step-by-step.
- [[Business-Rule-Index]] for all 304 traceable rules; [[Knowledge-Gaps]] for the 89 items that didn't clear the evidence bar.
- [[Knowledge-Quality-Report]] for how this vault was built and self-scored.
