---
knowledge_id: Payment-Instruction-Data-Model
title: "Payment Instruction (Data Model)"
domain: Payment
category: Data Model
snapshot_date: 2026-08-22
tags:
  - payment
  - data-model
---

# Payment Instruction (Data Model)

Core types live in `microservices/payment-component/src/types.ts` (the server's own source of truth) and are independently, hand-maintained-mirrored in `src/app/payment-component/payment-component.types.ts` (the Angular client). See [[Payment Architecture]] for why this duplication exists and its sync risk.

## Enums

- **`OriginModule`** — which trade-finance module originated the request (IPLC, EPLC, IMCO, EXCO, GTEE, IWGT, RPFM, CFNC, SBLC, REIM, PYMT). Part of the idempotency natural key.
- **`AccountType`** — `CUSTOMER` \| `NOSTRO` \| `VOSTRO` \| `SUSPENSE` \| `INTERNAL`. See [[Account Types]] — note RTGS is a flag on NOSTRO, not its own value.
- **`AccountCategory`** — a UI-only display bucket, computed alongside voucher description assembly.
- **`SourceComponent`** / **`BalanceModule`** — provenance-only metadata on a `SuspenseEntry`, never used to trigger posting logic (see [[Suspense Account]]).

## Core interfaces

| Type | Key fields | Notes |
|---|---|---|
| `PaymentInstructionConfirmRequest` | `originModule`, `mainRef`, `sequence`, `debitLegs[]`, `creditLegs[]`, `transactionCurrency?`, `suspenseBridge?`, `dryRun?` | The Confirm request body. `creditLegs` may be empty only when `suspenseBridge` will contribute its own credit leg (v1.10.1). |
| `PaymentLegInput` | `accountNo`, `accountType`, `currency`, `amountTxCcy`, `amountAccountCcy?`, `drRate?`/`drBuyRate?`/`crBuyRate?`/`sellRate?`, `rtgsIndicator?`, `payAdviceMsgType?`, `payCoverMsgType?` | All monetary/rate fields are decimal strings — see [[Accounting Model]]. |
| `SuspenseEntry` | `amount`, `currency`, `crossRate?`, `sourceComponent?`, `balanceModule?` | One raw line item for the [[Suspense Account|Suspense bridge]]. |
| `SuspenseBridge` | `debitEntries?: SuspenseEntry[]`, `creditEntries?: SuspenseEntry[]` | Two independently-processed "sides" — see [[Suspense Bridge Expansion Flow]]. |
| `PaymentInstruction` | the full confirmed record: enriched legs, classification, accountEntries, swiftMessages, natural key, fingerprint | The persisted/returned shape. |
| `AccountEntry` | `accountNo`, `drCrIndicator`, `amount`, `currency`, `exchangeRate1?`, `exchangeRate2` (never populated) | One per leg — see [[Settlement]]. |
| `SwiftMessage` | message type, settled (32A) vs. instructed (33B) amount/currency, shared UETR | See [[SWIFT Messaging and Vouchers]]. |

## A field worth calling out on its own: `transactionCurrency`

Added in v1.10.0 as an **explicit, independent wire field** — deliberately not inferred from any leg's own currency. Before this fix, the server inferred transaction currency from `debitLegs[0].currency`, which silently broke whenever a side's legs were entirely in a currency other than the true transaction currency (e.g. a "Full pay in JPY" scenario). This is one of the clearest examples in the whole repository of a UI/business requirement ("switching a leg's currency must never change the displayed Transaction Currency") driving a server-side schema change rather than the reverse.

## Related knowledge

- [[Payment Instructions API]]
- [[Payment Architecture]]
- [[Account Types]]
- [[Business-Rule-Index]]
