---
knowledge_id: Source-to-Knowledge-Map
title: "Source to Knowledge Map"
domain: Payment
category: Traceability
snapshot_date: 2026-08-22
tags:
  - payment
  - traceability
  - source-map
---

# Source-to-Knowledge-Map

Maps each analyzed source/document file to the business-rule notes it produced. Use this when a source file changes: every rule listed for that file is a candidate for staleness review (see this repo's own CLAUDE.md standing rule of keeping docs in sync with code, which this vault adopts for itself too).

**Snapshot basis:** this repository has no `.git` history in the analyzed copy — there is no commit hash to pin to. The snapshot date above (2026-08-22) and each file's own last-modified timestamp (captured at staging time) are the only freshness signal available; see [[Knowledge-Gaps]] for this and other methodology caveats.

**Coverage:** 141 distinct source/document files are cited as evidence by at least one business rule, out of ~110 files analyzed across 18 extraction groups (some files — e.g. pure Angular boilerplate, node_modules-adjacent config — were read for context but produced no independently citable rule).

## Angular UI — LC web components (12 files)

| Source file | Rules generated |
|---|---|
| `src/app/web-components/export/lc-advise.element.ts` | [[CLASS-RULE-022]] |
| `src/app/web-components/export/lc-collection.element.ts` | [[CLASS-RULE-022]] |
| `src/app/web-components/export/lc-confirmed.element.ts` | [[CLASS-RULE-022]] |
| `src/app/web-components/export/lc-nego.element.ts` | [[CLASS-RULE-022]], [[CLASS-RULE-023]] |
| `src/app/web-components/export/lc-settlement.element.ts` | [[CLASS-RULE-022]] |
| `src/app/web-components/import/lc-issue.element.ts` | [[CLASS-RULE-023]], [[VALIDATION-RULE-030]] |
| `src/app/web-components/import/lc-settlement.element.ts` | [[CLASS-RULE-021]] |
| `src/app/web-components/import/lc-sight-payment.element.ts` | [[CLASS-RULE-021]] |
| `src/app/web-components/import/lc-sight-settlement.element.ts` | [[CLASS-RULE-021]] |
| `src/app/web-components/journal-entry.element.ts` | [[CLASS-RULE-020]], [[POSTING-RULE-029]], [[VALIDATION-RULE-030]] |
| `src/app/web-components/shared.spec.ts` | [[TEST-RULE-002]] |
| `src/app/web-components/shared.ts` | [[ARCH-RULE-022]], [[CLASS-RULE-020]], [[CLASS-RULE-023]], [[VALIDATION-RULE-030]] |

## Angular UI — Payment Component Simulator (14 files)

| Source file | Rules generated |
|---|---|
| `src/app/payment-component/business-case-fields.ts` | [[ARCH-RULE-014]], [[VALIDATION-RULE-017]] |
| `src/app/payment-component/business-case-registry.spec.ts` | [[ARCH-RULE-013]], [[CLASS-RULE-009]], [[CLASS-RULE-010]], [[CLASS-RULE-011]], [[CLASS-RULE-012]] |
| `src/app/payment-component/business-case-registry.ts` | [[CLASS-RULE-004]], [[CLASS-RULE-009]], [[CLASS-RULE-010]], [[CLASS-RULE-011]], [[CLASS-RULE-012]], [[TEST-RULE-001]], [[TEST-RULE-004]], [[VALIDATION-RULE-017]] |
| `src/app/payment-component/business-case-request.ts` | [[VALIDATION-RULE-018]], [[VALIDATION-RULE-019]] |
| `src/app/payment-component/business-case-runner.component.html` | [[API-RULE-010]], [[CLASS-RULE-015]], [[CLASS-RULE-016]] |
| `src/app/payment-component/business-case-runner.component.ts` | [[API-RULE-010]], [[ARCH-RULE-015]], [[ARCH-RULE-016]], [[CLASS-RULE-013]], [[CLASS-RULE-014]], [[CLASS-RULE-015]], [[CLASS-RULE-016]], [[POSTING-RULE-018]], [[POSTING-RULE-019]], [[TEST-RULE-005]], [[VALIDATION-RULE-020]], [[VALIDATION-RULE-021]] |
| `src/app/payment-component/business-case.model.ts` | [[ARCH-RULE-013]], [[CLASS-RULE-009]], [[CLASS-RULE-010]] |
| `src/app/payment-component/currency.service.ts` | [[POSTING-RULE-026]] |
| `src/app/payment-component/fx-rate.service.ts` | [[ARCH-RULE-018]] |
| `src/app/payment-component/leg-allocator.component.ts` | [[ARCH-RULE-017]], [[POSTING-RULE-021]], [[POSTING-RULE-022]], [[POSTING-RULE-024]], [[POSTING-RULE-025]], [[POSTING-RULE-040]], [[VALIDATION-RULE-022]], [[VALIDATION-RULE-023]], [[VALIDATION-RULE-024]], [[VALIDATION-RULE-025]] |
| `src/app/payment-component/payment-component-api.service.ts` | [[API-RULE-010]], [[API-RULE-011]], [[VALIDATION-RULE-026]], [[VALIDATION-RULE-027]] |
| `src/app/payment-component/payment-component.types.ts` | [[ARCH-RULE-019]], [[SUSPENSE-RULE-004]], [[SWIFT-RULE-007]], [[VALIDATION-RULE-009]], [[VALIDATION-RULE-027]], [[VALIDATION-RULE-028]] |
| `src/app/payment-component/response-viewer.component.ts` | [[ARCH-RULE-020]], [[CLASS-RULE-017]], [[CLASS-RULE-018]], [[CLASS-RULE-019]], [[POSTING-RULE-027]], [[POSTING-RULE-028]] |
| `src/app/payment-component/suspense-entries.component.ts` | [[ARCH-RULE-021]], [[VALIDATION-RULE-029]] |

## Demo backend (Express, fake FX/currency data) (3 files)

| Source file | Rules generated |
|---|---|
| `backend/data/currencies.js` | [[VALIDATION-RULE-032]] |
| `backend/server.js` | [[API-RULE-012]], [[ARCH-RULE-023]], [[CHARGE-RULE-004]], [[CHARGE-RULE-005]], [[CHARGE-RULE-006]], [[CHARGE-RULE-007]], [[CHARGE-RULE-008]], [[CHARGE-RULE-009]], [[CHARGE-RULE-010]], [[CHARGE-RULE-011]], [[FX-RULE-027]], [[POSTING-RULE-030]], [[POSTING-RULE-031]], [[VALIDATION-RULE-031]], [[VALIDATION-RULE-032]], [[VALIDATION-RULE-033]] |
| `backend/test/export-settlement.test.js` | [[VALIDATION-RULE-033]] |

## Existing FSD / expert review / manual / gap-analysis documents (10 files)

| Source file | Rules generated |
|---|---|
| `analysis/COMMON-PaymentComponent-Cross-Reference.md` | [[CLASS-RULE-025]], [[CLASS-RULE-026]] |
| `analysis/Payment_Component_Calculation_Validation.docx` | [[ARCH-RULE-042]] |
| `analysis__Payment-OAS-FSD-en.docx` | [[API-RULE-014]], [[CLASS-RULE-001]], [[FX-RULE-033]], [[POSTING-RULE-036]], [[POSTING-RULE-037]], [[SUSPENSE-RULE-017]], [[SUSPENSE-RULE-018]], [[SWIFT-RULE-002]], [[SWIFT-RULE-009]], [[SWIFT-RULE-011]], [[VALIDATION-RULE-007]], [[VALIDATION-RULE-008]], [[VALIDATION-RULE-009]], [[VALIDATION-RULE-015]], [[VALIDATION-RULE-016]], [[VALIDATION-RULE-035]], [[VALIDATION-RULE-038]] |
| `analysis__PaymentComponent-Microservice-FSD-zh.docx` | [[API-RULE-014]], [[CLASS-RULE-001]], [[SWIFT-RULE-003]], [[SWIFT-RULE-008]], [[SWIFT-RULE-009]], [[SWIFT-RULE-010]] |
| `analysis__Payment_Component_Calculation_Validation.docx` | [[FX-RULE-035]], [[FX-RULE-036]], [[SWIFT-RULE-003]], [[SWIFT-RULE-012]], [[VALIDATION-RULE-007]], [[VALIDATION-RULE-008]], [[VALIDATION-RULE-015]], [[VALIDATION-RULE-016]], [[VALIDATION-RULE-036]], [[VALIDATION-RULE-037]], [[VALIDATION-RULE-038]], [[VALIDATION-RULE-039]] |
| `analysis__Payment_Mapping_Functions.docx` | [[CLASS-RULE-001]], [[SWIFT-RULE-009]] |
| `analysis__Trade_Finance_Payment_Component_Architecture_v4-cn.docx` | [[CHARGE-RULE-012]], [[FX-RULE-034]], [[SUSPENSE-RULE-019]], [[SUSPENSE-RULE-020]] |
| `docs/RDD-oas-reference-event-model.md` | [[SWIFT-RULE-014]] |
| `docs/payment-component-expert-review.md` | [[ARCH-RULE-035]], [[ARCH-RULE-036]], [[ARCH-RULE-037]], [[ARCH-RULE-038]], [[ARCH-RULE-039]], [[SWIFT-RULE-012]], [[TEST-RULE-003]], [[VALIDATION-RULE-039]], [[VALIDATION-RULE-040]], [[VALIDATION-RULE-041]] |
| `docs__LC-Payment-WC-User-Manual-en.docx` | [[FX-RULE-042]], [[POSTING-RULE-044]], [[TEST-RULE-004]], [[TEST-RULE-005]] |

## Microservice — API/validation/store/infra (7 files)

| Source file | Rules generated |
|---|---|
| `microservices/payment-component/src/app.ts` | [[ARCH-RULE-011]], [[ARCH-RULE-012]], [[ARCH-RULE-038]], [[VALIDATION-RULE-013]] |
| `microservices/payment-component/src/errors.ts` | [[VALIDATION-RULE-013]] |
| `microservices/payment-component/src/money.ts` | [[ARCH-RULE-006]], [[POSTING-RULE-026]], [[POSTING-RULE-032]], [[POSTING-RULE-033]], [[POSTING-RULE-041]], [[VALIDATION-RULE-009]], [[VALIDATION-RULE-010]], [[VALIDATION-RULE-015]], [[VALIDATION-RULE-038]] |
| `microservices/payment-component/src/routes/paymentInstructions.ts` | [[API-RULE-002]], [[API-RULE-003]], [[API-RULE-004]], [[API-RULE-005]], [[API-RULE-006]], [[API-RULE-016]], [[API-RULE-017]] |
| `microservices/payment-component/src/store/paymentInstructionStore.ts` | [[ARCH-RULE-010]], [[ARCH-RULE-012]], [[VALIDATION-RULE-001]] |
| `microservices/payment-component/src/types.ts` | [[CLASS-RULE-004]], [[CLASS-RULE-024]], [[SWIFT-RULE-007]] |
| `microservices/payment-component/src/validation/requestSchema.ts` | [[API-RULE-003]], [[API-RULE-004]], [[API-RULE-019]], [[API-RULE-020]], [[VALIDATION-RULE-009]], [[VALIDATION-RULE-014]], [[VALIDATION-RULE-015]], [[VALIDATION-RULE-016]], [[VALIDATION-RULE-028]], [[VALIDATION-RULE-038]], [[VALIDATION-RULE-039]], [[VALIDATION-RULE-040]], [[VALIDATION-RULE-041]], [[VALIDATION-RULE-042]] |

## Microservice — domain logic (8 files)

| Source file | Rules generated |
|---|---|
| `microservices/payment-component/src/domain/accountEntries.ts` | [[ARCH-RULE-004]], [[ARCH-RULE-005]], [[SWIFT-RULE-007]] |
| `microservices/payment-component/src/domain/balanceValidation.ts` | [[VALIDATION-RULE-007]], [[VALIDATION-RULE-008]] |
| `microservices/payment-component/src/domain/classification.ts` | [[API-RULE-020]], [[CLASS-RULE-002]], [[CLASS-RULE-003]], [[CLASS-RULE-004]], [[CLASS-RULE-005]], [[CLASS-RULE-025]] |
| `microservices/payment-component/src/domain/classifyPreview.ts` | [[ARCH-RULE-002]], [[ARCH-RULE-003]], [[VALIDATION-RULE-005]], [[VALIDATION-RULE-006]], [[VALIDATION-RULE-027]] |
| `microservices/payment-component/src/domain/confirmPaymentInstruction.ts` | [[API-RULE-002]], [[API-RULE-008]], [[API-RULE-013]], [[API-RULE-014]], [[API-RULE-015]], [[ARCH-RULE-001]], [[ARCH-RULE-004]], [[ARCH-RULE-010]], [[ARCH-RULE-035]], [[CLASS-RULE-005]], [[CLASS-RULE-006]], [[POSTING-RULE-035]], [[VALIDATION-RULE-001]], [[VALIDATION-RULE-002]], [[VALIDATION-RULE-003]], [[VALIDATION-RULE-034]], [[VALIDATION-RULE-042]] |
| `microservices/payment-component/src/domain/suspenseBridge.ts` | [[ARCH-RULE-007]], [[ARCH-RULE-008]], [[FX-RULE-001]], [[FX-RULE-002]], [[POSTING-RULE-039]], [[VALIDATION-RULE-004]], [[VALIDATION-RULE-011]], [[VALIDATION-RULE-014]] |
| `microservices/payment-component/src/domain/swiftMessages.ts` | [[VALIDATION-RULE-012]] |
| `microservices/payment-component/src/domain/voucherDescription.ts` | [[API-RULE-001]], [[API-RULE-003]], [[ARCH-RULE-009]], [[CLASS-RULE-007]], [[CLASS-RULE-028]], [[VALIDATION-RULE-003]] |

## Microservice — tests (6 files)

| Source file | Rules generated |
|---|---|
| `microservices/payment-component/test/regression.ts` | [[API-RULE-007]], [[API-RULE-008]], [[API-RULE-009]], [[TEST-RULE-001]] |
| `microservices/payment-component/test/unit/domain/classification.test.ts` | [[CLASS-RULE-002]] |
| `microservices/payment-component/test/unit/domain/voucherDescription.test.ts` | [[API-RULE-001]] |
| `microservices/payment-component/test/unit/money.test.ts` | [[VALIDATION-RULE-009]] |
| `microservices/payment-component/test/unit/routes/paymentInstructions.test.ts` | [[API-RULE-002]], [[API-RULE-004]], [[API-RULE-005]], [[API-RULE-006]] |
| `microservices/payment-component/test/unit/validation/requestSchema.test.ts` | [[API-RULE-004]] |

## OpenAPI contracts (2 files)

| Source file | Rules generated |
|---|---|
| `analysis/Payment_component.yaml` | [[API-RULE-013]], [[API-RULE-014]], [[API-RULE-016]], [[API-RULE-017]], [[API-RULE-018]], [[ARCH-RULE-024]], [[ARCH-RULE-025]], [[CLASS-RULE-002]], [[CLASS-RULE-004]], [[CLASS-RULE-005]], [[CLASS-RULE-007]], [[CLASS-RULE-024]], [[POSTING-RULE-004]], [[POSTING-RULE-017]], [[POSTING-RULE-032]], [[POSTING-RULE-033]], [[SWIFT-RULE-002]], [[SWIFT-RULE-008]], [[SWIFT-RULE-010]], [[SWIFT-RULE-013]], [[VALIDATION-RULE-009]], [[VALIDATION-RULE-034]], [[VALIDATION-RULE-035]] |
| `analysis/payment-instructions-post.yaml` | [[API-RULE-013]], [[API-RULE-014]], [[API-RULE-018]], [[ARCH-RULE-024]], [[ARCH-RULE-025]], [[SWIFT-RULE-008]], [[VALIDATION-RULE-028]], [[VALIDATION-RULE-034]] |

## Root (README, CLAUDE.md, standalone test-case doc) (79 files)

| Source file | Rules generated |
|---|---|
| `.element.ts` | [[TEST-RULE-002]] |
| `/home/claude/payment-kb/converted/analysis__Payment-OAS-FSD-en.docx` | [[POSTING-RULE-035]] |
| `/home/claude/payment-kb/converted/analysis__PaymentComponent-Microservice-FSD-zh.docx` | [[POSTING-RULE-035]] |
| `/mnt/user-data/uploads/lc-payment-wc/analysis/Payment_component.yaml` | [[CLASS-RULE-001]] |
| `/mnt/user-data/uploads/lc-payment-wc/analysis/payment-instructions-post.yaml` | [[CLASS-RULE-001]] |
| `CLAUDE.md` | [[ARCH-RULE-004]], [[ARCH-RULE-022]], [[ARCH-RULE-024]], [[ARCH-RULE-036]], [[ARCH-RULE-043]], [[ARCH-RULE-044]], [[CLASS-RULE-019]], [[FX-RULE-043]], [[FX-RULE-044]], [[POSTING-RULE-039]], [[POSTING-RULE-040]], [[SUSPENSE-RULE-021]], [[SWIFT-RULE-014]], [[SWIFT-RULE-015]], [[VALIDATION-RULE-028]], [[VALIDATION-RULE-042]] |
| `Payment-Component-Suspense-FX-Test-Cases-zh.md` | [[FX-RULE-001]], [[FX-RULE-016]], [[FX-RULE-017]], [[FX-RULE-044]], [[FX-RULE-045]], [[SUSPENSE-RULE-021]], [[VALIDATION-RULE-042]], [[VALIDATION-RULE-043]] |
| `PaymentComponentProposedUseCases-EN.docx` | [[CLASS-RULE-027]], [[CLASS-RULE-028]], [[FX-RULE-041]], [[POSTING-RULE-045]], [[POSTING-RULE-046]], [[POSTING-RULE-047]] |
| `Payment_component.yaml` | [[FX-RULE-030]], [[FX-RULE-031]], [[SWIFT-RULE-008]] |
| `README.md` | [[ARCH-RULE-044]], [[TEST-RULE-002]], [[TEST-RULE-003]], [[VALIDATION-RULE-020]] |
| `RPFM-PaymentComponent-Gap-Analysis.md` | [[POSTING-RULE-038]] |
| `accountEntries.test.ts` | [[POSTING-RULE-005]] |
| `accountEntries.ts` | [[ARCH-RULE-020]], [[ARCH-RULE-039]], [[POSTING-RULE-036]] |
| `business-case-fields.spec.ts` | [[UI-RULE-001]], [[UI-RULE-002]], [[VALIDATION-RULE-017]] |
| `business-case-fields.ts` | [[UI-RULE-001]], [[UI-RULE-002]] |
| `business-case-registry.spec.ts` | [[VALIDATION-RULE-018]] |
| `business-case-registry.ts` | [[POSTING-RULE-038]], [[TEST-RULE-001]], [[TEST-RULE-004]] |
| `business-case-request.spec.ts` | [[SUSPENSE-RULE-007]], [[VALIDATION-RULE-019]] |
| `business-case-request.ts` | [[FX-RULE-019]], [[SUSPENSE-RULE-007]] |
| `business-case-runner.component.html` | [[TEST-RULE-005]] |
| `business-case-runner.component.spec.ts` | [[SUSPENSE-RULE-008]], [[SUSPENSE-RULE-009]], [[SUSPENSE-RULE-010]], [[SUSPENSE-RULE-011]], [[SUSPENSE-RULE-012]], [[SUSPENSE-RULE-013]], [[SUSPENSE-RULE-014]], [[VALIDATION-RULE-020]], [[VALIDATION-RULE-021]] |
| `business-case-runner.component.ts` | [[FX-RULE-019]], [[FX-RULE-020]], [[SUSPENSE-RULE-008]], [[SUSPENSE-RULE-009]], [[SUSPENSE-RULE-010]], [[SUSPENSE-RULE-011]], [[SUSPENSE-RULE-012]], [[SUSPENSE-RULE-013]], [[SUSPENSE-RULE-014]], [[TEST-RULE-005]], [[UI-RULE-003]], [[UI-RULE-004]], [[UI-RULE-022]] |
| `confirmPaymentInstruction.ts` | [[POSTING-RULE-019]], [[POSTING-RULE-042]], [[POSTING-RULE-047]] |
| `converted/PaymentComponentProposedUseCases-EN.docx` | [[API-RULE-020]] |
| `converted/analysis__Payment-OAS-FSD-en.docx` | [[API-RULE-015]], [[ARCH-RULE-026]], [[ARCH-RULE-027]], [[ARCH-RULE-028]], [[ARCH-RULE-029]], [[ARCH-RULE-031]], [[ARCH-RULE-034]], [[CLASS-RULE-002]], [[CLASS-RULE-003]], [[CLASS-RULE-005]] |
| `converted/analysis__PaymentComponent-Microservice-FSD-zh.docx` | [[ARCH-RULE-027]], [[ARCH-RULE-031]], [[CLASS-RULE-002]], [[CLASS-RULE-003]], [[CLASS-RULE-004]], [[CLASS-RULE-007]], [[CLASS-RULE-008]], [[CLASS-RULE-024]], [[CLASS-RULE-026]] |
| `converted/analysis__Payment_Component_Calculation_Validation.docx` | [[API-RULE-015]], [[API-RULE-019]], [[CLASS-RULE-002]], [[CLASS-RULE-025]] |
| `converted/analysis__Payment_Mapping_Functions.docx` | [[ARCH-RULE-030]], [[CLASS-RULE-008]] |
| `converted/analysis__Trade_Finance_Payment_Component_Architecture_v4-cn.docx` | [[ARCH-RULE-032]], [[ARCH-RULE-033]], [[ARCH-RULE-034]] |
| `converted/docs__LC-Payment-WC-User-Manual-en.docx` | [[ARCH-RULE-040]], [[ARCH-RULE-041]] |
| `currency.service.ts` | [[FX-RULE-027]] |
| `fx-rate.service.ts` | [[FX-RULE-028]], [[FX-RULE-029]] |
| `lc-advise.element.ts` | [[CHARGE-RULE-003]] |
| `lc-collection.element.ts` | [[CHARGE-RULE-003]], [[CHARGE-RULE-004]] |
| `lc-confirmed.element.ts` | [[CHARGE-RULE-005]] |
| `lc-issue.element.ts` | [[CHARGE-RULE-002]], [[CHARGE-RULE-003]], [[UI-RULE-021]] |
| `lc-nego.element.ts` | [[CHARGE-RULE-002]], [[CHARGE-RULE-003]], [[CHARGE-RULE-006]] |
| `lc-settlement.element.ts` | [[CHARGE-RULE-002]], [[CHARGE-RULE-004]], [[UI-RULE-021]] |
| `leg-allocator.component.html` | [[UI-RULE-006]], [[UI-RULE-012]] |
| `leg-allocator.component.spec.ts` | [[SUSPENSE-RULE-014]], [[VALIDATION-RULE-022]], [[VALIDATION-RULE-023]], [[VALIDATION-RULE-024]], [[VALIDATION-RULE-025]] |
| `leg-allocator.component.ts` | [[CLASS-RULE-004]], [[FX-RULE-021]], [[FX-RULE-022]], [[FX-RULE-023]], [[FX-RULE-024]], [[FX-RULE-025]], [[FX-RULE-026]], [[FX-RULE-042]], [[POSTING-RULE-020]], [[POSTING-RULE-023]], [[SUSPENSE-RULE-014]], [[UI-RULE-005]], [[UI-RULE-023]], [[VALIDATION-RULE-025]] |
| `microservices/payment-component/README.md` | [[SUSPENSE-RULE-021]] |
| `money.ts` | [[FX-RULE-004]], [[FX-RULE-005]], [[FX-RULE-006]], [[FX-RULE-008]], [[FX-RULE-036]], [[FX-RULE-037]] |
| `payment-component-api.service.spec.ts` | [[API-RULE-011]], [[VALIDATION-RULE-026]] |
| `payment-component-expert-review.md` | [[FX-RULE-037]], [[FX-RULE-038]], [[FX-RULE-039]], [[FX-RULE-040]], [[POSTING-RULE-042]], [[POSTING-RULE-043]] |
| `payment-component.types.ts` | [[FX-RULE-030]], [[FX-RULE-031]], [[SUSPENSE-RULE-015]] |
| `payment-instructions-post.yaml` | [[FX-RULE-032]], [[SWIFT-RULE-010]] |
| `requestSchema.ts` | [[FX-RULE-014]], [[FX-RULE-015]], [[FX-RULE-037]] |
| `response-viewer.component.spec.ts` | [[CLASS-RULE-017]], [[CLASS-RULE-018]], [[CLASS-RULE-019]], [[POSTING-RULE-028]] |
| `response-viewer.component.ts` | [[FX-RULE-023]], [[UI-RULE-013]], [[UI-RULE-014]], [[UI-RULE-015]], [[UI-RULE-016]], [[UI-RULE-017]], [[UI-RULE-018]], [[UI-RULE-022]] |
| `shared.spec.ts` | [[CHARGE-RULE-001]] |
| `shared.ts` | [[CHARGE-RULE-001]] |
| `spec.ts` | [[POSTING-RULE-018]], [[POSTING-RULE-023]] |
| `src/domain/accountEntries.ts` | [[POSTING-RULE-002]], [[POSTING-RULE-004]], [[POSTING-RULE-005]], [[POSTING-RULE-006]], [[POSTING-RULE-010]] |
| `src/domain/confirmPaymentInstruction.ts` | [[POSTING-RULE-001]], [[POSTING-RULE-002]], [[POSTING-RULE-003]], [[SUSPENSE-RULE-001]], [[SUSPENSE-RULE-002]], [[SWIFT-RULE-001]], [[SWIFT-RULE-013]], [[SWIFT-RULE-014]] |
| `src/domain/suspenseBridge.ts` | [[POSTING-RULE-011]], [[POSTING-RULE-012]], [[POSTING-RULE-034]], [[SUSPENSE-RULE-018]] |
| `src/domain/swiftMessages.ts` | [[SWIFT-RULE-002]], [[SWIFT-RULE-003]], [[SWIFT-RULE-004]], [[SWIFT-RULE-005]], [[SWIFT-RULE-006]], [[SWIFT-RULE-010]], [[SWIFT-RULE-011]] |
| `src/domain/voucherDescription.ts` | [[POSTING-RULE-013]], [[POSTING-RULE-014]], [[POSTING-RULE-015]] |
| `src/money.ts` | [[POSTING-RULE-007]], [[POSTING-RULE-008]], [[POSTING-RULE-009]], [[POSTING-RULE-010]] |
| `src/types.ts` | [[SUSPENSE-RULE-004]], [[SWIFT-RULE-015]] |
| `src/validation/requestSchema.ts` | [[POSTING-RULE-016]], [[SUSPENSE-RULE-002]], [[SUSPENSE-RULE-004]], [[SUSPENSE-RULE-018]] |
| `suspense-entries.component.html` | [[SUSPENSE-RULE-016]] |
| `suspense-entries.component.spec.ts` | [[VALIDATION-RULE-029]] |
| `suspense-entries.component.ts` | [[SUSPENSE-RULE-016]], [[UI-RULE-019]], [[UI-RULE-020]], [[UI-RULE-024]] |
| `suspenseBridge.test.ts` | [[SUSPENSE-RULE-003]], [[SUSPENSE-RULE-004]], [[SUSPENSE-RULE-005]], [[SUSPENSE-RULE-006]] |
| `suspenseBridge.ts` | [[ARCH-RULE-007]], [[FX-RULE-002]], [[FX-RULE-003]], [[FX-RULE-006]], [[FX-RULE-007]], [[FX-RULE-008]], [[FX-RULE-009]], [[FX-RULE-010]], [[FX-RULE-011]], [[FX-RULE-012]], [[FX-RULE-016]], [[FX-RULE-017]], [[FX-RULE-018]], [[FX-RULE-031]], [[FX-RULE-032]], [[FX-RULE-033]], [[FX-RULE-038]], [[FX-RULE-039]], [[FX-RULE-040]], [[FX-RULE-041]], [[FX-RULE-043]], [[POSTING-RULE-043]], [[POSTING-RULE-044]], [[SUSPENSE-RULE-003]], [[SUSPENSE-RULE-005]], [[SUSPENSE-RULE-006]] |
| `swiftMessages.ts` | [[FX-RULE-013]] |
| `test/curl-tests/requests/case1-suspense-fx-and-nostro-usd.js` | [[FX-RULE-016]], [[FX-RULE-018]] |
| `test/unit/domain/balanceValidation.test.ts` | [[VALIDATION-RULE-007]], [[VALIDATION-RULE-008]] |
| `test/unit/domain/classification.test.ts` | [[CLASS-RULE-003]], [[CLASS-RULE-004]] |
| `test/unit/domain/classifyPreview.test.ts` | [[VALIDATION-RULE-005]], [[VALIDATION-RULE-006]] |
| `test/unit/domain/confirmPaymentInstruction.test.ts` | [[CLASS-RULE-006]], [[FX-RULE-001]], [[FX-RULE-002]], [[FX-RULE-003]], [[POSTING-RULE-001]], [[POSTING-RULE-002]], [[SUSPENSE-RULE-001]], [[SUSPENSE-RULE-002]], [[SUSPENSE-RULE-018]], [[SWIFT-RULE-001]], [[SWIFT-RULE-002]], [[SWIFT-RULE-011]], [[VALIDATION-RULE-001]], [[VALIDATION-RULE-002]], [[VALIDATION-RULE-003]], [[VALIDATION-RULE-004]] |
| `test/unit/domain/suspenseBridge.test.ts` | [[VALIDATION-RULE-004]], [[VALIDATION-RULE-011]] |
| `test/unit/domain/swiftMessages.test.ts` | [[SWIFT-RULE-002]], [[SWIFT-RULE-003]], [[SWIFT-RULE-005]], [[SWIFT-RULE-006]], [[SWIFT-RULE-011]], [[VALIDATION-RULE-012]] |
| `test/unit/domain/voucherDescription.test.ts` | [[CLASS-RULE-007]] |
| `test/unit/money.test.ts` | [[FX-RULE-004]], [[FX-RULE-005]], [[FX-RULE-006]], [[VALIDATION-RULE-010]] |
| `test/unit/routes/paymentInstructions.test.ts` | [[SUSPENSE-RULE-004]] |
| `test/unit/validation/requestSchema.test.ts` | [[FX-RULE-014]], [[FX-RULE-015]], [[POSTING-RULE-016]], [[SUSPENSE-RULE-004]], [[VALIDATION-RULE-015]], [[VALIDATION-RULE-016]] |
| `voucherDescription.ts` | [[POSTING-RULE-037]], [[POSTING-RULE-046]] |

