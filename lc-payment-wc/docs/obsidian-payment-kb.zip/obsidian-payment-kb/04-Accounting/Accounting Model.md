---
knowledge_id: Accounting-Model
title: "Accounting Model"
domain: Payment
category: Domain Concept
snapshot_date: 2026-08-22
tags:
  - payment
  - domain-concept
  - accounting
---

# Accounting Model

The Payment Component's accounting model is deliberately narrow: it posts exactly one GL **Account Entry** per submitted leg (see [[Settlement]]), guarded by one balance rule, using one arithmetic library — nothing more. Charge/commission/liability posting is explicitly out of scope (see [[Charge Integration]]).

## V8 — the exact Dr = Cr balance rule

Before anything is posted, `validateDrCrBalance` checks that Σ debit `amountTxCcy` exactly equals Σ credit `amountTxCcy`, in the resolved transaction currency, across the **full expanded leg set** (including any [[Suspense Account|Suspense bridge]] legs). Default tolerance is zero for every `originModule`. This replaced a legacy rule — two independent per-side "≤ target total" checks with an explicit ±0.01 RPFM tolerance — that the current OAS request shape cannot even express (there is no single "target total" field to check each side against). The ±0.01 legacy slack is preserved as reference-only/opt-in, never the default. See `POSTING-RULE` entries tagged M-7 in [[Business-Rule-Index]].

## Decimal-only arithmetic

Every monetary/rate value on the wire is a **decimal string**, parsed and formatted exclusively through `money.ts`'s `decimal.js`-backed helpers — never a native JS float, anywhere in the posting path. Two dedicated guards exist specifically to protect V8's exactness:

- **Negative amounts are rejected (M-1).** Direction must come from which leg array (debit vs. credit) an entry is in, never from a signed amount — this prevents "gaming" the aggregate balance check with a negative figure that cancels out arithmetically but represents nonsense business intent.
- **A zero exchange rate is rejected (M-2).** A zero rate would silently zero-convert and drop what should be a real charge/suspense leg, with no error raised otherwise.

Currency-correct rounding is driven by an explicit **currency minor-units table** (`money.ts` `CURRENCY_MINOR_UNITS`) — e.g. USD rounds to 2dp, JPY to 0dp — never a hardcoded 2dp assumption. This table is **hand-duplicated** in the Angular Simulator's demo backend (`backend/data/currencies.json`); a documented sync risk is that divergence here can make a client-computed and a server-computed figure for "the same" quantity round to different minor-unit values and break V8 by exactly one minor unit. See [[Knowledge-Gaps]].

## Worked example — a foreign-currency leg's exchangeRate1 echo

A Settlement entry's `exchangeRate1` field is populated as a straight passthrough of whichever rate the leg itself carried — `drRate ?? drBuyRate` for a debit leg, `crBuyRate ?? sellRate` for a credit leg — never recomputed. `exchangeRate2` is deliberately never populated, since no OAS/wire source documents a second rate's meaning. This was a genuine gap closed by a hardening pass: a rate went in on the request and, before this fix, silently never came back out on the response.

## Related knowledge

- [[Settlement]]
- [[FX Processing]]
- [[Suspense Account]]
- [[Posting Direction Decision Table]]
- [[Business-Rule-Index]] — 47 rules tagged Accounting (`POSTING-RULE-*`)
