---
knowledge_id: Confirm-Payment-Instruction-Flow
title: "Confirm Payment Instruction Flow"
domain: Payment
category: Payment Flow
snapshot_date: 2026-08-22
tags:
  - payment
  - flow
---

# Confirm Payment Instruction Flow

The single most important flow in this repository: `POST /payment-instructions`, orchestrated by `confirmPaymentInstruction.ts`. Every other domain note ([[Payment Instruction Classification]], [[Accounting Model]], [[Suspense Account]], [[SWIFT Messaging and Vouchers]]) describes one step of this flow in depth — this note is the connective sequence.

```mermaid
flowchart TD
    A["POST /payment-instructions\n(debitLegs, creditLegs, natural key,\noptional suspenseBridge)"] --> B{"Step 0: Idempotency lookup\n(originModule, mainRef, sequence)"}
    B -->|"found, fingerprint matches"| B1["return existing instruction\ncreated:false, HTTP 200"]
    B -->|"found, fingerprint differs"| B2["409 IDEMPOTENCY_KEY_CONFLICT"]
    B -->|"not found, or dryRun"| C["Pre-Step-1 (v1.4.0):\nresolve transactionCurrency,\nexpand suspenseBridge into\nadditional Suspense/FX legs"]
    C --> D{"Step 1: V8 Dr/Cr balance\nvalidation (exact, per originModule)"}
    D -->|fail| D1["409 LEGS_UNBALANCED"]
    D -->|pass| E["Step 2: Classification\n(Payment Component ID Rule Rev.2)\ninformational only, never blocks"]
    E --> F["Step 3: Voucher description\nassembly (resolve prefix, enrichLegs)"]
    F -->|"missing prefix &\nno override"| F1["RequestValidationError"]
    F --> G["Step 4: Settlement Account Entry\ngeneration -- one entry per leg,\nunconditional"]
    G --> H{"Step 5: SWIFT cross-field\nvalidation + message generation"}
    H -->|"cross-field violation"| H1["BusinessValidationError"]
    H --> I{"dryRun?"}
    I -->|"true"| J["return computed instruction,\ncreated:false, NOT persisted"]
    I -->|"false"| K["persist via store.save\ncreated:true, HTTP 201"]
```

## Step-by-step, with the "why"

1. **Idempotency lookup (Step 0, FSD §6.1).** A canonical SHA-256 fingerprint of the validated payload is computed and compared against any existing instruction under the same natural key. Same key + same fingerprint → replay (200, no reprocessing). Same key + different fingerprint → 409. Skipped entirely for `dryRun` requests. See [[Request Validation]].
2. **Suspense bridge expansion (Pre-Step-1, v1.4.0 — not legacy-traced).** `transactionCurrency` is resolved (explicit field, falling back to `debitLegs[0].currency`), then `suspenseBridge.debitEntries`/`creditEntries` are expanded into additional Suspense and FX-pair legs, assembled into the final ordered leg arrays (Normal Debits → FX Debit → FX Credit → Normal Credits → Suspense Credit) **before** the balance check runs. See [[Suspense Account]].
3. **V8 balance validation (Step 1, §3).** Exact Dr = Cr equality across the full expanded leg set. See [[Accounting Model]].
4. **Classification (Step 2, §4).** The Payment Component Identification Rule XOR test — informational only. See [[Payment Instruction Classification]].
5. **Voucher description assembly (Step 3, §5).** Resolve the `{MODULE}{FuncCode}` prefix, then `enrichLegs()` each leg with its `accountDesc`. See [[SWIFT Messaging and Vouchers]].
6. **Settlement Account Entry generation (Step 4, §6.1).** One `SETTLEMENT`-type entry per leg, unconditionally (Charge/Liability streams were removed in v1.6.0). See [[Settlement]].
7. **SWIFT generation (Step 5, §7).** Cross-field validation, then one message per qualifying credit leg. See [[SWIFT Messaging and Vouchers]].
8. **Persistence.** Unless `dryRun`, the instruction is stored (201 semantics); `dryRun` always returns the freshly computed result without persisting.

## Related flows and knowledge

- [[Suspense Bridge Expansion Flow]] — Pre-Step-1 in detail
- [[Angular Preview and Confirm Loop]] — how the Simulator UI drives this endpoint
- [[Payment-Traceability-Matrix]]
- [[Business-Rule-Index]]
