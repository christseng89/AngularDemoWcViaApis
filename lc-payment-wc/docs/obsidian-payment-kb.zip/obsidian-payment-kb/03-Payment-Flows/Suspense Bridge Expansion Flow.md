---
knowledge_id: Suspense-Bridge-Expansion-Flow
title: "Suspense Bridge Expansion Flow"
domain: Payment
category: Payment Flow
snapshot_date: 2026-08-22
tags:
  - payment
  - flow
  - suspense
---

# Suspense Bridge Expansion Flow

Detail view of Pre-Step-1 in the [[Confirm Payment Instruction Flow]] — how `expandSuspenseBridge` (`microservices/payment-component/src/domain/suspenseBridge.ts`) turns raw Suspense entries into balanced ledger legs. See [[Suspense Account]] for the conceptual "why."

```mermaid
sequenceDiagram
    participant Caller
    participant Bridge as expandSuspenseBridge
    participant Bucket as groupByCurrency
    participant Leg as buildSuspenseBridgeLeg
    participant FX as buildFxPair
    participant V8 as validateDrCrBalance

    Caller->>Bridge: debitLegs, creditLegs,\nsuspenseBridge{debitEntries?, creditEntries?}
    Bridge->>Bucket: group debitEntries by currency
    Bridge->>Bucket: group creditEntries by currency
    loop each currency bucket
        Bucket->>Leg: build itemized Suspense leg(s)\n(always credit-direction)
        alt bucket currency == transactionCurrency
            Note over Leg: stop here -- no FX pair
        else foreign currency
            Leg->>FX: resolveBucketRate (must be consistent\nacross all entries in bucket)
            alt DEBIT bucket (v1.9.0)
                FX->>FX: net gross Suspense vs.\nmatching debitLegs (Decimal subtraction)
                Note over FX: exact match -> 0 pairs\npartial match -> 1 residual pair
            else CREDIT bucket (v1.8.0, unmodified)
                FX->>FX: always emit Suspense-anchored pair\n(full gross amount)
                FX->>FX: independently emit Leg pair\nif matching real credit leg exists\n(never netted against the first)
            end
        end
    end
    Bridge->>V8: merged { debit[], credit[] } + caller's own legs
    V8->>V8: Sigma debit amountTxCcy == Sigma credit amountTxCcy?
```

## The two buckets are processed independently

`debitEntries` and `creditEntries` are two separate "sides," each independently grouped by currency (`groupByCurrency`). A request can legitimately have both non-empty at once, but the interaction between a debit-side bucket and a credit-side bucket **sharing a common foreign currency with each other** (as opposed to with the caller's own legs) is untested — flagged as a genuine open question in [[Knowledge-Gaps]].

## Every FX pair is self-balancing by construction

Both legs of a generated FX Exchange pair always carry the *identical* `amountTxCcy` value — so this module's own additions can never themselves break the aggregate V8 check. What v1.9.0's netting and v1.8.0's independent-pair design specifically protect is **per-currency** balance, which V8 alone (an aggregate, transaction-currency-only check) cannot see.

## Related knowledge

- [[Suspense Account]]
- [[Confirm Payment Instruction Flow]]
- [[FX Processing]]
- [[Business-Rule-Index]] — `SUSPENSE-RULE-*`
