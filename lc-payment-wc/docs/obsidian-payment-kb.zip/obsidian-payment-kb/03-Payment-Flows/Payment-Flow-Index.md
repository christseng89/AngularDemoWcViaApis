---
knowledge_id: Payment-Flow-Index
title: "Payment Flow Index"
domain: Payment
category: Index
snapshot_date: 2026-08-22
tags:
  - payment
  - index
---

# Payment Flow Index

| Flow | What it covers |
|---|---|
| [[Confirm Payment Instruction Flow]] | The core `POST /payment-instructions` orchestration — idempotency, Suspense expansion, V8 balance, classification, voucher assembly, GL posting, SWIFT |
| [[Suspense Bridge Expansion Flow]] | Detail view of the Suspense-bridge Pre-Step-1: bucket-by-currency expansion and the debit/credit netting asymmetry |
| [[Angular Preview and Confirm Loop]] | How the Payment Component Simulator drives the Confirm flow from a user's click through debounced preview to a real Confirm |
| [[Legacy LC Event Flows]] | The 9 Import/Export LC web-component events, calling the separate demo backend, unrelated to the Payment Component microservice |

See [[Payment Architecture]] for how these flows relate to the repository's three-part structure, and [[Payment-Traceability-Matrix]] for how each flow step maps to a rule, an API field, and a test.
