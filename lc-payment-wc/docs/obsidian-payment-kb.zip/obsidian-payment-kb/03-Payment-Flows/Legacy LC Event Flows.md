---
knowledge_id: Legacy-LC-Event-Flows
title: "Legacy LC Event Flows"
domain: Payment
category: Payment Flow
snapshot_date: 2026-08-22
tags:
  - payment
  - flow
  - lc
---

# Legacy LC Event Flows

The 9 vanilla-JS LC web components (`src/app/web-components/{import,export}/`), each calling the **demo backend**'s own `/api/{module}/{event}/calc` — architecturally separate from the [[Confirm Payment Instruction Flow]] (see [[Payment Architecture]]). Each element owns one Import or Export LC business event.

```mermaid
flowchart TD
    subgraph Import["Import LC lifecycle"]
        A1["A1 Issue\nMargin + Commission + SWIFT Fee\n-> Dr Customer CA (TWD equiv.)"]
        A1 --> A2["A2 Settlement (Sight/Usance)\nNet CA = Bill + Corr Charges\n- Margin Released"]
        A1 --> A3["A3 Sight Payment / IBL Lodgement\nbooks (Bill - Margin) as IBL,\nfunds Nostro payment"]
        A3 --> A4["A4 Sight Settlement / IBL Repayment\nDr Customer CA / Cr IBL"]
    end
    subgraph Export["Export LC lifecycle"]
        B1["B1 Advise\nflat TWD commission"]
        B1 --> B2["B2 Confirmed (optional)\nper-quarter risk commission\non tolerance-adjusted LC Balance"]
        B1 --> B3["B3 Negotiation Payment\nNego Fee + usance discount\n(sight bills: no discount)"]
        B3 --> B4["B4 Settlement\nebl: clear vs. proceeds, FX G/L\ndirect: pay beneficiary directly"]
        B1 --> B5["B5 On Collection\n(alternative to B3->B4)\nNostro credited net of FBC"]
    end
```

## A2/A3 and B3→B4/B5 are alternative paths, not a fixed sequence

**A2 vs. A3+A4** are alternatives for how the bank settles an Import LC bill: A2 settles directly in one step; A3+A4 instead books the net exposure as an Import Bill Loan, funded partly by the margin held at A1, repaid later at A4. **B3→B4 vs. B5** are alternatives for the export side: B3→B4 negotiates/advances the bill then later clears it against actual proceeds (recognizing FX gain/loss on the EBL-held-TWD-vs-current-bill-TWD difference); B5 skips negotiation entirely and simply credits the beneficiary once correspondent proceeds physically arrive.

## Recurring patterns across all 9 events

- **Fee-currency choice re-triggers a real recalculation**, not just client-side reformatting, because it changes which leg is actually posted.
- **Foreign/correspondent bank charges** are either embedded into the main settlement leg or booked as a separate CA debit, depending on whether the customer's chosen fee currency matches the settlement currency.
- **Rate-based commissions** (Confirming, Negotiation) carry quarter-rounding and minimum-fee floors typical of trade-finance pricing — see [[Charge Integration]] for the specific `CHARGE-RULE-*` entries.
- **No unit tests exist for any of the 9 elements themselves** — see [[Testing Methodology and Coverage]] for what evidence tier this implies.

## Related knowledge

- [[Charge Integration]]
- [[Payment Architecture]]
- [[Payment Component Simulator UI]]
- [[Business-Rule-Index]] — `ARCH-RULE-*` / `CHARGE-RULE-*` entries sourced from `web-components-lc` and `demo-backend`
