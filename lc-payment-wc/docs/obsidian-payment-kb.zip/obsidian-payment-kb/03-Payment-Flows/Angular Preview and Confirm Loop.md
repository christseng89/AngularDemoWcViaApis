---
knowledge_id: Angular-Preview-and-Confirm-Loop
title: "Angular Preview and Confirm Loop"
domain: Payment
category: Payment Flow
snapshot_date: 2026-08-22
tags:
  - payment
  - flow
  - ui
---

# Angular Preview and Confirm Loop

How the [[Payment Component Simulator UI]] drives the [[Confirm Payment Instruction Flow]], end to end from a user's click to a persisted instruction.

```mermaid
flowchart TD
    A["User selects module,\nthen business case"] --> B["All prior per-case state reset;\nheaderFields rebuilt from registry"]
    B --> C{"Case classification?"}
    C -->|"PASS or GAP"| D["Open debounced (400ms) pipeline:\nmerge(form.valueChanges, legsChanged$)"]
    C -->|"N_A"| Z["Static citation card,\nno API calls at all"]
    D --> E["User fills header form,\noverrides Tx Currency/Amount,\nadds Suspense Debit/Credit entries"]
    E --> F["sideDefaults() recomputes each side's\nLeg #1 seed (Total +/- FX-converted\nSuspense adjustment, per-entry-rounded)"]
    F --> G["Two leg-allocator instances split/\nedit legs; emit legsChange/\nvalidChange/scaleErrorsChange"]
    G --> H{"H-2 guard:\nany amount over-precise\nfor its currency?"}
    H -->|"yes"| H1["Block preview AND Confirm;\nno server call"]
    H -->|"no"| I["400ms after last edit: runPreview()"]
    I --> J{"PASS or GAP?"}
    J -->|"PASS"| K["api.confirm(request, dryRun:true)"]
    J -->|"GAP"| L["api.classify(debitLegs, creditLegs)\n-- no suspenseBridge, no Confirm action"]
    K --> M["ResponseViewer shows classification,\nSettlement Vouchers, SWIFT (PASS only),\nFX Conversion Pair preview"]
    L --> M
    M --> N{"User clicks Confirm\n(PASS case only)"}
    N --> O["Re-validate H-2 guard;\nbuild same request, dryRun:false"]
    O --> P["POST -- persists new instruction,\nor replays existing one keyed by\n(originModule, mainRef, sequence)"]
```

## What makes this loop trustworthy rather than just convenient

- **The client never recalculates an accounting figure.** `ResponseViewerComponent` and `SuspenseEntriesComponent` are strictly presentation-layer — they filter, re-group, and reformat server-computed data. The one exception is a client-only "FX Conversion Pair" preview overlay, explicitly never sent to or received from the server, that exists purely to illustrate per-currency balance before a real Confirm call.
- **The H-2 precision guard blocks before any server round-trip.** Aggregating header, Suspense-entry, and leg-allocator over-precision checks client-side avoids a wasted call that the server would reject anyway with a 400.
- **Preview and Confirm reuse the exact same request-building code** (`buildConfirmRequest`), differing only in `dryRun`. This is what makes the live preview a genuinely faithful rehearsal of what Confirm will do, not an approximation.
- **A documented, deliberately-reverted attempt at optimization (v1.7.3→v1.7.4)** tried netting the Suspense adjustment against a live leg in the same currency client-side; this broke the server's own aggregate V8 check and was reverted — a caution against duplicating server-side balance logic on the client even when it looks like a harmless UX improvement.

## Related knowledge

- [[Confirm Payment Instruction Flow]]
- [[Payment Component Simulator UI]]
- [[Request Validation]] — the H-2 rule mirrored client-side here
- [[Business-Rule-Index]] — `UI-RULE-*`
