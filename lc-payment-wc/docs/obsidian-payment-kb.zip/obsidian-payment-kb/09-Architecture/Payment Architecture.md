---
knowledge_id: Payment-Architecture
title: "Payment Architecture"
domain: Payment
category: Architecture
snapshot_date: 2026-08-22
tags:
  - payment
  - architecture
---

# Payment Architecture

```mermaid
flowchart LR
    subgraph UI["Angular UI (src/app/)"]
        SIM["Payment Component Simulator\n(payment-component/)"]
        WC["9 legacy LC web components\n(web-components/)"]
    end
    subgraph SVC["microservices/payment-component/"]
        API["POST /payment-instructions"]
        DOM["classification, balanceValidation,\nsuspenseBridge, accountEntries,\nswiftMessages, voucherDescription"]
        STORE[("in-memory\ninstruction store")]
    end
    subgraph DEMO["backend/ (Express demo)"]
        CCY["/api/currencies, /api/fx/rates\n(fake demo data)"]
        LC["/api/{module}/{event}/calc\n(9 LC charge calculators)"]
    end
    SIM -- "dryRun preview / real Confirm\n(debitLegs, creditLegs, suspenseBridge)" --> API
    API --> DOM --> STORE
    SIM -. "currency master, FX rates" .-> CCY
    WC -- "charge/settlement calc" --> LC
    WC -.->|"NOT connected to"| API
```

## Three parts, two of which never talk to each other

- **`microservices/payment-component/`** — the real Payment Component. A TypeScript/Express microservice: `routes/paymentInstructions.ts` → `validation/requestSchema.ts` → `domain/confirmPaymentInstruction.ts` (the orchestrator) → `domain/{classification,balanceValidation,suspenseBridge,accountEntries,swiftMessages,voucherDescription}.ts` → `store/paymentInstructionStore.ts`. See [[Payment Component Overview]] and [[Confirm Payment Instruction Flow]].
- **Angular UI, Payment Component Simulator** (`src/app/payment-component/`) — the only UI that actually calls the microservice above. See [[Payment Component Simulator UI]].
- **Angular UI, legacy LC web components** (`src/app/web-components/`) and **the demo backend** (`backend/`) — a self-contained pair that computes Import/Export LC charges and settlement figures, entirely independent of the Payment Component microservice. No shared code, no shared wire contract, no calls between the two systems.

This separation is deliberate (see [[Charge Integration]] for the architectural reason charge calculation was never meant to live in the Payment Component), but it is also a common source of confusion when reading the repo for the first time — a rule or comment about "charges" almost always belongs to the `backend/`+`web-components/` pair, not the microservice.

## Two independently-maintained currency/FX sources

Both the microservice (`money.ts` `CURRENCY_MINOR_UNITS`) and the demo backend (`backend/data/currencies.json`) hand-maintain their own currency-decimals table; both the Angular Simulator's `payment-component.types.ts` and the microservice's own OAS-derived types are independently hand-maintained mirrors of each other. Neither pair is generated from a single source of truth — a documented sync-risk pattern that recurs across this repo (see `ARCH-RULE` entries and [[Knowledge-Gaps]]).

## Persistence and idempotency scope

The instruction store is **in-memory only** — idempotent replay (see [[Request Validation]]) works within one running process but not across a restart. There is no database in this repository.

## Related knowledge

- [[Payment Component Overview]]
- [[Payment Component Simulator UI]]
- [[Charge Integration]]
- [[Payment-Flow-Index]]
- [[Business-Rule-Index]] — 41 rules tagged Architecture (`ARCH-RULE-*`)
