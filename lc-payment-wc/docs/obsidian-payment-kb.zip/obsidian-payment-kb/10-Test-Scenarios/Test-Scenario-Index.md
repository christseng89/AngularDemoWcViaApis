---
knowledge_id: Test-Scenario-Index
title: "Test Scenario Index"
domain: Payment
category: Index
snapshot_date: 2026-08-22
tags:
  - payment
  - index
---

# Test Scenario Index

512 scenarios across 16 source areas. See [[Testing Methodology and Coverage]] for coverage caveats (notably: the 9 legacy LC web components have zero unit test coverage of their own).

| Area | Scenario count | Note |
|---|---|---|
| [[UI-Business-Case-Runner-Test-Scenarios]] | 76 | source group: `angular-runner` |
| [[UI-Leg-Allocator-Test-Scenarios]] | 67 | source group: `angular-leg-allocator` |
| [[API-Validation-and-Store-Test-Scenarios]] | 54 | source group: `api-validation` |
| [[Classification-and-Confirmation-Test-Scenarios]] | 53 | source group: `classification` |
| [[UI-Response-and-Suspense-Viewer-Test-Scenarios]] | 47 | source group: `angular-viewers` |
| [[Suspense-Bridge-Test-Scenarios]] | 35 | source group: `suspense` |
| [[Accounting-and-Money-Test-Scenarios]] | 31 | source group: `accounting-money` |
| [[SWIFT-and-Voucher-Test-Scenarios]] | 29 | source group: `swift-voucher` |
| [[UI-Currency-FX-API-Services-Test-Scenarios]] | 28 | source group: `angular-services` |
| [[UI-Business-Case-Model-Test-Scenarios]] | 24 | source group: `angular-business-case-core` |
| [[Regression-and-Smoke-Test-Scenarios]] | 19 | source group: `regression-scenarios` |
| [[FSD-Traced-Scenario-Evidence]] | 16 | source group: `fsd-architecture-docs` |
| [[Calculation-Validation-Worked-Scenarios]] | 11 | source group: `validation-gap-docs` |
| [[OpenAPI-Contract-Test-Scenarios]] | 10 | source group: `api-contracts` |
| [[Expert-Review-and-Manual-Worked-Scenarios]] | 8 | source group: `expert-reviews-manuals` |
| [[Demo-Backend-Test-Scenarios]] | 4 | source group: `demo-backend` |

See also: [[Payment-Traceability-Matrix]], [[Business-Rule-Index]].
