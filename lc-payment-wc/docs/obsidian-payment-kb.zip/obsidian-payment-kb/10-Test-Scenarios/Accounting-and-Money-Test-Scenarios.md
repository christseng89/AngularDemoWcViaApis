---
knowledge_id: Accounting-and-Money-Test-Scenarios
title: "Accounting & Money Test Scenarios"
domain: Payment
category: Test Scenarios
snapshot_date: 2026-08-22
tags:
  - payment
  - test-scenario
---

# Accounting & Money Test Scenarios

31 scenarios extracted from this area's test files. See [[Accounting Model]] for the business rules these scenarios prove, and [[Testing Methodology and Coverage]] for how this evidence tier was established.

| Scenario | Given | When | Then | Source |
|---|---|---|---|---|
| Settlement entry uses amountTxCcy when amountAccountCcy absent | a DEBIT leg with amountTxCcy='250' and no amountAccountCcy | buildSettlementEntries is called with side='DEBIT' | one entry is produced with drCrIndicator='D', amount='250', glAccount='ACC-1', description passed through — *Accounting:* Debit-side settlement posting to the leg's own account | `accountEntries.test.ts 'produces one D entry per debit leg using amountTxCcy when amountAccountCcy is absent'` |
| Credit side produces C entries | a leg on the credit side | buildSettlementEntries is called with side='CREDIT' | drCrIndicator is 'C' | `accountEntries.test.ts 'produces C entries for the credit side'` |
| amountAccountCcy overrides amountTxCcy | a leg with amountTxCcy='100' and amountAccountCcy='150' | buildSettlementEntries runs | the posted entry amount is '150', not '100' — *Accounting:* The account is debited/credited in its own settlement currency amount, not the transaction-currency-equivalent | `accountEntries.test.ts 'prefers amountAccountCcy over amountTxCcy when present'` |
| custId and referenceNumber carried through | a leg with partyId='PARTY-9' and accountNo='ACC-9' | buildSettlementEntries runs | entry.custId='PARTY-9', entry.referenceNumber='ACC-9' | `accountEntries.test.ts 'carries custId from partyId and referenceNumber from accountNo'` |
| multiple legs each produce their own entry | two debit legs with distinct accountNo 'A' and 'B' | buildSettlementEntries runs | 2 entries are returned | `accountEntries.test.ts 'maps one entry per leg for multiple legs'` |
| empty legs array yields empty entries | an empty legs array | buildSettlementEntries runs | returns [] | `accountEntries.test.ts 'returns an empty array for no legs'` |
| same-currency leg omits exchangeRate1 | a leg with no drRate/drBuyRate/crBuyRate/sellRate fields | buildSettlementEntries runs | entry.exchangeRate1 is undefined | `accountEntries.test.ts 'omits exchangeRate1 for a same-currency leg carrying no rate field'` |
| DEBIT leg echoes drBuyRate | a DEBIT leg with drBuyRate='1.083123' | buildSettlementEntries runs on side DEBIT | entry.exchangeRate1='1.083123' | `accountEntries.test.ts 'a DEBIT leg uses drBuyRate'` |
| DEBIT leg prefers drRate over drBuyRate | a DEBIT leg with drRate='1.100000' and drBuyRate='1.083123' | buildSettlementEntries runs | entry.exchangeRate1='1.100000' | `accountEntries.test.ts 'a DEBIT leg prefers drRate over drBuyRate when both are present'` |
| CREDIT leg echoes crBuyRate | a CREDIT leg with crBuyRate='149.082600' | buildSettlementEntries runs on side CREDIT | entry.exchangeRate1='149.082600' | `accountEntries.test.ts 'a CREDIT leg uses crBuyRate'` |
| CREDIT leg prefers crBuyRate over sellRate | a CREDIT leg with both crBuyRate and sellRate set | buildSettlementEntries runs | exchangeRate1 takes crBuyRate's value | `accountEntries.test.ts 'a CREDIT leg prefers crBuyRate over sellRate when both are present'` |
| side-mismatched rate field never leaks | a leg carrying only drBuyRate, submitted on side CREDIT | buildSettlementEntries runs | exchangeRate1 is undefined (crBuyRate/sellRate are what CREDIT reads, not drBuyRate) | `accountEntries.test.ts "a CREDIT leg's own drBuyRate is ignored (side-mismatched rate field never leaks across sides)"` |
| exchangeRate2 is never populated | a leg with drBuyRate set | buildSettlementEntries runs | entry.exchangeRate2 is undefined | `accountEntries.test.ts 'never populates exchangeRate2 — no second rate value exists on the wire to map to it'` |
| balanced legs pass V8 with zero difference | one debit leg of 100 and one credit leg of 100 | validateDrCrBalance runs with default tolerance | returns debitTotal='100', creditTotal='100', difference='0', no throw | `balanceValidation.test.ts 'passes and returns totals/difference when debit and credit totals match exactly'` |
| multiple legs per side are summed before comparison | debit legs [60,40] and credit leg [100] | validateDrCrBalance runs | debitTotal='100' (matches credit), no throw | `balanceValidation.test.ts 'sums multiple legs per side before comparing'` |
| unbalanced totals beyond default zero tolerance throw LEGS_UNBALANCED/409 | debit=100, credit=99.99, no explicit tolerance (defaults to 0) | validateDrCrBalance runs | throws BusinessValidationError code='LEGS_UNBALANCED', httpStatus=409, message contains both totals | `balanceValidation.test.ts 'throws BusinessValidationError with LEGS_UNBALANCED when totals differ beyond the default zero tolerance'` |
| difference exactly at explicit tolerance boundary passes | debit=100, credit=99.99, explicit tolerance='0.01' | validateDrCrBalance runs | does not throw; difference='0.01' | `balanceValidation.test.ts 'does not throw when the difference is exactly at the tolerance boundary'` |
| difference exceeding explicit tolerance still throws | debit=100, credit=99.98, explicit tolerance='0.01' | validateDrCrBalance runs | throws BusinessValidationError | `balanceValidation.test.ts 'throws when the difference exceeds the tolerance, even by a fraction'` |
| negative difference (credit exceeds debit) accepted within tolerance | debit=99.99, credit=100, tolerance=RPFM_BALANCE_TOLERANCE (0.01) | validateDrCrBalance runs | does not throw; difference='-0.01' | `balanceValidation.test.ts 'accepts a negative difference within tolerance (credit exceeds debit)'` |
| RPFM_BALANCE_TOLERANCE constant value check | the exported RPFM_BALANCE_TOLERANCE constant | inspected | is a Decimal instance equal to '0.01' | `balanceValidation.test.ts 'RPFM_BALANCE_TOLERANCE is 0.01'` |
| parseMonetaryAmount accepts integer, negative, and up-to-3dp amounts; rejects malformed/over-precise/empty strings | various wire strings: '100', '-100.50', '1.234', 'abc', '1.2345', '' | parseMonetaryAmount is called | first three parse correctly (toFixed '100','-100.5','1.234'); last three throw InvalidMonetaryAmountError | `money.test.ts 'parseMonetaryAmount' describe block` |
| parseExchangeRate rejects negative and over-precise rates | '-1.5' (negative, pattern has no sign) and '1.12345678901' (11 decimal places) | parseExchangeRate is called | both throw InvalidExchangeRateError | `money.test.ts 'parseExchangeRate' describe block` |
| formatMonetaryAmount rounding behavior | Decimal('12.5') with no scale; Decimal('12.345')/'12.344' at scale 2; Decimal('1000.6') at scale 0; an over-18-digit Decimal at scale 2 | formatMonetaryAmount is called | '12.5' unchanged; '12.35'/'12.34' (HALF_UP); '1001' (JPY-style); throws InvalidMonetaryAmountError for the too-large value | `money.test.ts 'formatMonetaryAmount' describe block` |
| formatExchangeRate boundary and sign checks | Decimal('1.5'); Decimal('1234567890123') (13 integer digits); Decimal('-1.5') | formatExchangeRate is called | '1.5' formats fine; the 13-digit and negative cases both throw InvalidExchangeRateError | `money.test.ts 'formatExchangeRate' describe block` |
| sumMonetaryAmounts avoids float drift and propagates parse errors | [] ; ['0.1','0.2'] ; ['10','not-a-number'] | sumMonetaryAmounts is called | 0 for empty; exactly '0.3' for 0.1+0.2 (not 0.30000000000000004); throws InvalidMonetaryAmountError for the malformed entry | `money.test.ts 'sumMonetaryAmounts' describe block` |
| convertTxCcyToAccountCcy multiplies amount by rate | amountTxCcy=100, rate=1.5 | convertTxCcyToAccountCcy is called | returns 150 | `money.test.ts 'convertTxCcyToAccountCcy' describe block` |
| minorUnitsForCurrency table and fallback | JPY/TWD/IDR; USD/EUR/AUD; XYZ (unlisted) | minorUnitsForCurrency is called | 0 for the zero-decimal currencies; 2 for the listed two-decimal currencies; 2 fallback for XYZ | `money.test.ts 'minorUnitsForCurrency' describe block` |
| knownMinorUnitsForCurrency distinguishes known vs unknown | USD/JPY/CNY (known); BHD/XYZ (not in table) | knownMinorUnitsForCurrency is called | returns 2/0/2 for the known set; returns undefined (not a fallback) for BHD and XYZ | `money.test.ts 'knownMinorUnitsForCurrency' describe block` |
| decimalPlaces counts literal fractional digits including trailing zeros | '100' , '100.5', '100.50', '1.234', '-99.9' | decimalPlaces is called | returns 0, 1, 2, 3, 1 respectively | `money.test.ts 'decimalPlaces' describe block` |
| isNegativeAmount treats -0/-0.00 as zero, not negative | '-100','-0.01' (negative); '0','-0','-0.00','100','0.50' (not negative) | isNegativeAmount is called | true for the first two; false for all of the second group | `money.test.ts 'isNegativeAmount' describe block` |
| isZeroRate detects any all-zero rate string; smallest positive rate is not zero | '0','0.0','0.0000000000','00' (zero); '1','0.0000000001','1.100000' (positive) | isZeroRate is called | true for the zero group; false for the positive group | `money.test.ts 'isZeroRate' describe block` |
