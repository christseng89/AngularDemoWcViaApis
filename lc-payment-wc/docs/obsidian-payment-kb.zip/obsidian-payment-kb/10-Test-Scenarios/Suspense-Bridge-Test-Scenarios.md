---
knowledge_id: Suspense-Bridge-Test-Scenarios
title: "Suspense Bridge Test Scenarios"
domain: Payment
category: Test Scenarios
snapshot_date: 2026-08-22
tags:
  - payment
  - test-scenario
---

# Suspense Bridge Test Scenarios

35 scenarios extracted from this area's test files. See [[Suspense Account]] for the business rules these scenarios prove, and [[Testing Methodology and Coverage]] for how this evidence tier was established.

| Scenario | Given | When | Then | Source |
|---|---|---|---|---|
| Same-currency Suspense entry passes through unchanged | entry {amount:'100.5', currency:'USD'}, transactionCurrency USD | buildSuspenseBridgeLeg('Suspense - Debit', entry, 'USD') | returns leg with amountTxCcy '100.5' verbatim, no amountAccountCcy/crBuyRate — *Accounting:* Suspense - Debit leg posted at original precision, no rounding *FX:* none — same currency | `suspenseBridge.test.ts:11-19` |
| Same-currency zero-amount entry returns null | entry {amount:'0', currency:'USD'}, transactionCurrency USD | buildSuspenseBridgeLeg is called | returns null — no leg generated | `suspenseBridge.test.ts:21-23` |
| Cross-currency entry converts via crossRate and sets amountAccountCcy/crBuyRate | entry {amount:'100', currency:'EUR', crossRate:'1.1'}, transactionCurrency USD | buildSuspenseBridgeLeg('Suspense - Credit', entry, 'USD') | amountTxCcy '110', amountAccountCcy '100', crBuyRate '1.1' — *FX:* EUR->USD conversion at 1.1 | `suspenseBridge.test.ts:25-35` |
| Cross-currency conversion rounds to USD 2dp ROUND_HALF_UP | amount 100 EUR × crossRate 1.234567 = 123.4567 | buildSuspenseBridgeLeg with transactionCurrency USD | amountTxCcy '123.46' | `suspenseBridge.test.ts:37-41` |
| Cross-currency conversion rounds to 0dp for JPY (exact integer) | amount 100 USD × crossRate 110.4 = 11040 exactly | buildSuspenseBridgeLeg with transactionCurrency JPY | amountTxCcy '11040' (no decimal point) | `suspenseBridge.test.ts:43-47` |
| Fractional cross-currency product rounds to 0dp for JPY, ROUND_HALF_UP | amount 10 USD × crossRate 110.46 = 1104.6 | buildSuspenseBridgeLeg with transactionCurrency JPY | amountTxCcy '1105' | `suspenseBridge.test.ts:49-53` |
| Cross-currency zero amount returns null even with valid crossRate | entry {amount:'0', currency:'EUR', crossRate:'1.1'}, transactionCurrency USD | buildSuspenseBridgeLeg is called | returns null | `suspenseBridge.test.ts:55-57` |
| Missing crossRate on a cross-currency entry throws | entry {amount:'100', currency:'EUR'} (no crossRate), transactionCurrency USD | buildSuspenseBridgeLeg is called | throws RequestValidationError | `suspenseBridge.test.ts:59-63` |
| buildFxPair returns empty when ownCcyAmount is zero | ownCcyAmount = Decimal(0) | buildFxPair is called | returns {debit:[], credit:[]} | `suspenseBridge.test.ts:67-69` |
| buildFxPair CREDIT direction places legs correctly | sourceDirection CREDIT, EUR/USD pair, amounts 17/18.7, rate 1.1 | buildFxPair is called | debit=[Other-Ccy-site EUR leg with drBuyRate], credit=[Trx-Ccy-site USD leg with crBuyRate] | `suspenseBridge.test.ts:71-79` |
| buildFxPair DEBIT direction places legs correctly | sourceDirection DEBIT, EUR/USD pair, amounts 3/3.3, rate 1.1 | buildFxPair is called | credit=[Other-Ccy-site EUR leg with crBuyRate], debit=[Trx-Ccy-site USD leg with drBuyRate] | `suspenseBridge.test.ts:81-89` |
| trxCcyAmount reused verbatim, never re-derived | ownCcyAmount 100, trxCcyAmount 999.99 (not 100×1.1) | buildFxPair is called with rate 1.1 | credit leg amountTxCcy is '999.99', not '110' | `suspenseBridge.test.ts:91-94` |
| Other-Ccy-site amount rounds to the foreign currency's own minor units (JPY 0dp) | currency JPY, ownCcyAmount 9000 | buildFxPair is called | debit leg amountAccountCcy '9000' | `suspenseBridge.test.ts:96-99` |
| Trx-Ccy-site amount rounds to the transaction currency's own minor units | trxCcyAmount 18.666, transactionCurrency USD | buildFxPair is called | credit leg amountTxCcy '18.67' (ROUND_HALF_UP) | `suspenseBridge.test.ts:101-104` |
| crossRate string passed through verbatim as crBuyRate/drBuyRate | rateStr '1.10000001' | buildFxPair is called | credit leg crBuyRate is '1.10000001' unchanged | `suspenseBridge.test.ts:106-109` |
| accountSuffix appended to both generated account names | accountSuffix ' - Suspense' | buildFxPair is called | debit accountNo 'FX Exchange USD - Suspense', credit accountNo 'FX Exchange EUR - Suspense' | `suspenseBridge.test.ts:111-115` |
| Undefined bridge produces no legs | bridge = undefined | expandSuspenseBridge is called | returns {debit:[], credit:[]} | `suspenseBridge.test.ts:119-121` |
| Empty bridge (both lists absent) produces no legs | bridge = {} | expandSuspenseBridge is called | returns {debit:[], credit:[]} | `suspenseBridge.test.ts:123-125` |
| Same-currency entries with no matching legs land as their own credit legs | debitEntries [10 USD], creditEntries [20 USD], transactionCurrency USD | expandSuspenseBridge is called | credit = [Suspense-Debit 10, Suspense-Credit 20], debit = [] | `suspenseBridge.test.ts:127-139` |
| Cross-currency entry with no matching real leg produces only its own Suspense-suffixed FX pair | debitEntries [100 EUR, crossRate 1.1], no debitLegs, transactionCurrency USD | expandSuspenseBridge is called | credit = [Suspense-Debit EUR 100/110, FX Exchange EUR - Suspense 110], debit = [FX Exchange USD - Suspense EUR 100] | `suspenseBridge.test.ts:141-150` |
| Multiple same-list entries stay itemized, not merged | creditEntries [10 USD, 20 USD] | expandSuspenseBridge is called | credit has 2 separate legs with amountTxCcy ['10','20'] | `suspenseBridge.test.ts:152-159` |
| Zero-amount entry silently skipped | debitEntries [0 USD] | expandSuspenseBridge is called | debit=[], credit=[] | `suspenseBridge.test.ts:161-165` |
| sourceComponent-tagged entry expands identically to untagged | debitEntries [{amount:'10', currency:'USD', sourceComponent:'BALANCE', balanceModule:'IBL'}] | expandSuspenseBridge is called | credit = [{accountNo:'Suspense - Debit', ..., amountTxCcy:'10'}], tag has no effect on output shape | `suspenseBridge.test.ts:167-173` |
| v1.9.0: real debit leg exceeding Suspense nets to a Leg-anchored residual pair | debitEntries [17 EUR, crossRate 1.1], debitLegs [EUR leg amountTxCcy 18.18, amountAccountCcy 20] | expandSuspenseBridge is called | Suspense leg posts at 18.7/17; diff = 17-20 = -3 -> Leg-anchored (DEBIT) pair sized to 3 EUR / 0.52 USD, unsuffixed 'FX Exchange EUR'/'FX Exchange USD' | `suspenseBridge.test.ts:176-190` |
| v1.9.0: exact-match real debit leg skips the FX pair entirely | debitEntries [17 EUR, crossRate 1.1], debitLegs [EUR leg amountTxCcy 18.7, amountAccountCcy 17] | expandSuspenseBridge is called | debit=[], credit=[Suspense-Debit only] — no FX pair generated (diff=0) | `suspenseBridge.test.ts:192-202` |
| v1.9.0: multiple Suspense entries stay itemized while the net FX pair uses the combined diff | debitEntries [12 EUR, 5 EUR, both crossRate 1.1], debitLegs [EUR leg amountTxCcy 18.18, amountAccountCcy 20] | expandSuspenseBridge is called | Suspense legs itemized ['12','5']; diff pair = 3 EUR (20-17)/0.52 USD | `suspenseBridge.test.ts:204-216` |
| v1.9.0: a leg in a different currency does not net against the bucket | debitEntries [17 EUR, crossRate 1.1], debitLegs [GBP leg 100/100] | expandSuspenseBridge is called | only full-gross Suspense-anchored pair 'FX Exchange USD - Suspense' generates — no unsuffixed leg pair | `suspenseBridge.test.ts:218-225` |
| v1.9.0: native-amount fallback to amountTxCcy when amountAccountCcy is absent | debitEntries [17 EUR, crossRate 1.1], debitLegs [EUR leg amountTxCcy 20 only, no amountAccountCcy] | expandSuspenseBridge is called | legsOwnCcy falls back to amountTxCcy(20); diff pair amountAccountCcy '3', amountTxCcy '1.3' | `suspenseBridge.test.ts:227-237` |
| v1.9.0: zero-amount entry inside a foreign bucket is skipped, sibling and net pair still post | debitEntries [0 EUR crossRate 1.1, 17 EUR crossRate 1.1], debitLegs [EUR leg 18.18/20] | expandSuspenseBridge is called | only 1 Suspense-Debit leg posts; Leg-anchored diff pair (17-20=-3) still generates | `suspenseBridge.test.ts:239-247` |
| v1.9.0: mismatched crossRate within a currency bucket throws | debitEntries [10 EUR crossRate 1.1, 5 EUR crossRate 1.2] | expandSuspenseBridge is called | throws RequestValidationError | `suspenseBridge.test.ts:249-256` |
| v1.8.0 CREDIT side: reviewer-confirmed EUR100+EUR100 — two independent pairs, full V8 balance holds | creditEntries [200 EUR, crossRate 1.083077], creditLegs [EUR leg amountTxCcy 108.31, amountAccountCcy 100] | expandSuspenseBridge is called and combined with CUST-ACC(10000 DEBIT) and NOSTRO-ACC2(9675.07 CREDIT) | generates a Suspense-anchored pair (200/216.62, suffixed) and an independent Leg pair (100/108.31, unsuffixed) — not netted; Σdebit amountTxCcy === Σcredit amountTxCcy over the full leg set | `suspenseBridge.test.ts:260-284` |
| v1.8.0 CREDIT side: no matching leg generates only the Suspense pair | creditEntries [17 EUR, crossRate 1.1], no creditLegs | expandSuspenseBridge is called | credit=[Suspense-Credit 17/18.7, FX Exchange EUR - Suspense 18.7], debit=[FX Exchange USD - Suspense 17] | `suspenseBridge.test.ts:286-295` |
| v1.8.0 CREDIT side: debitLegs-side leg never affects a creditEntries bucket (side independence) | creditEntries [17 EUR, crossRate 1.1], debitLegs [EUR leg 18.18/20] (irrelevant), no creditLegs | expandSuspenseBridge is called | credit accountNo list = ['Suspense - Credit', 'FX Exchange EUR - Suspense'] — no unsuffixed leg pair | `suspenseBridge.test.ts:297-305` |
| v1.8.0 CREDIT side: multiple real credit legs sum verbatim for the leg pair | creditEntries [17 EUR, crossRate 1.1], creditLegs [EUR 10.00/11, EUR 8.18/9] | expandSuspenseBridge is called | leg pair amountTxCcy = '18.18' (10.00+8.18 verbatim, not re-derived from (11+9)×rate) | `suspenseBridge.test.ts:307-316` |
| Partial-match debitEntries bucket nets unconditionally, no request flag involved | debitEntries [200 EUR, crossRate 1.2], debitLegs [EUR leg amountTxCcy 180, amountAccountCcy 150] | expandSuspenseBridge is called | Suspense-Debit leg always lands CREDIT (never flips to debit); diff-sized residual pair 'FX Exchange EUR - Suspense' amountTxCcy '60' (200 gross - 150 matched = 50 EUR / 60 USD) | `suspenseBridge.test.ts:319-331` |
