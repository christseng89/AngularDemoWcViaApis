---
knowledge_id: API-Validation-and-Store-Test-Scenarios
title: "API, Validation & Store Test Scenarios"
domain: Payment
category: Test Scenarios
snapshot_date: 2026-08-22
tags:
  - payment
  - test-scenario
---

# API, Validation & Store Test Scenarios

54 scenarios extracted from this area's test files. See [[Request Validation]] for the business rules these scenarios prove, and [[Testing Methodology and Coverage]] for how this evidence tier was established.

| Scenario | Given | When | Then | Source |
|---|---|---|---|---|
| New natural key returns 201 | No prior instruction exists for (IPLC, REF-ROUTE-1, 1) | POST /payment-instructions with a valid body | 201, instructionId defined, classification.paymentComponentRelated true | `test/unit/routes/paymentInstructions.test.ts` |
| Idempotent replay returns 200 with same id | A confirmed instruction already exists at a natural key | The identical body is POSTed again | 200, instructionId equals the first response's instructionId | `test/unit/routes/paymentInstructions.test.ts` |
| Conflicting replay at same natural key is rejected | A confirmed instruction exists at a natural key | The same natural key is POSTed with different leg amounts | 409, code IDEMPOTENCY_KEY_CONFLICT | `test/unit/routes/paymentInstructions.test.ts` |
| dryRun always 200 even for a new key | A never-before-used natural key (mainRef REF-DRY-RUN) | POST with dryRun:true | 200 (not 201) | `test/unit/routes/paymentInstructions.test.ts` |
| Empty debitLegs is a 400 | A body otherwise valid | debitLegs is set to [] | 400, code REQUEST_VALIDATION_FAILED | `test/unit/routes/paymentInstructions.test.ts` |
| Unbalanced legs is a 409 | debitLegs total 100, creditLegs total 1 (mismatched) | POST /payment-instructions | 409, code LEGS_UNBALANCED | `test/unit/routes/paymentInstructions.test.ts` |
| suspenseBridge.debitEntries expands into a Suspense - Debit leg | debitLegs pre-adjusted to include the bridge amount (110 = 100 + 10) | POST with suspenseBridge.debitEntries=[{amount:'10', currency:'USD'}] | 201, response creditLegs includes an accountNo 'Suspense - Debit' leg | `test/unit/routes/paymentInstructions.test.ts` |
| suspenseBridge entry without caller pre-adjustment is unbalanced | debitLegs NOT adjusted for the bridge amount | POST with the same suspenseBridge.debitEntries | 409 (LEGS_UNBALANCED) | `test/unit/routes/paymentInstructions.test.ts` |
| sourceComponent-tagged bridge entry produces only a SETTLEMENT accountEntry | suspenseBridge.debitEntries=[{amount:'10', currency:'USD', sourceComponent:'BALANCE', balanceModule:'IBL'}] | POST /payment-instructions | 201, every accountEntries[].voucherType === 'SETTLEMENT' | `test/unit/routes/paymentInstructions.test.ts` |
| classify endpoint returns classification and balance | Balanced IDR legs (500/500), NOSTRO vs CUSTOMER | POST /payment-instructions/classify | 200, classification.paymentComponentRelated true, balance.balanced true | `test/unit/routes/paymentInstructions.test.ts` |
| classify endpoint includes SETTLEMENT entries for both legs | Two balanced legs | POST /payment-instructions/classify | accountEntries has length 2, all voucherType SETTLEMENT, description mentions 'no Payment Component voucher code prefix' | `test/unit/routes/paymentInstructions.test.ts` |
| classify endpoint rejects empty debitLegs | debitLegs: [] | POST /payment-instructions/classify | 400 | `test/unit/routes/paymentInstructions.test.ts` |
| GET list with no query returns all | Two instructions confirmed (IPLC/REF-A, EPLC/REF-B) | GET /payment-instructions | Array of length 2 | `test/unit/routes/paymentInstructions.test.ts` |
| GET list filters by originModule | Two instructions across different origin modules | GET /payment-instructions?originModule=IPLC | Only instruction a returned | `test/unit/routes/paymentInstructions.test.ts` |
| GET list filters by mainRef | Two instructions with different mainRef | GET /payment-instructions?mainRef=REF-B | Only instruction b returned | `test/unit/routes/paymentInstructions.test.ts` |
| GET list ignores an unrecognized originModule value | Two instructions exist | GET /payment-instructions?originModule=NOT_REAL | Both instructions returned (filter not applied) | `test/unit/routes/paymentInstructions.test.ts` |
| GET by id returns the full instruction | An instruction was confirmed | GET /payment-instructions/:id with the real id | 200, instructionId matches | `test/unit/routes/paymentInstructions.test.ts` |
| GET by id 404s for unknown id | No instruction with that id | GET /payment-instructions/does-not-exist | 404, code NOT_FOUND | `test/unit/routes/paymentInstructions.test.ts` |
| GET account-entries returns array | A confirmed instruction | GET .../account-entries | 200, array with length > 0 | `test/unit/routes/paymentInstructions.test.ts` |
| GET account-entries 404s for unknown id | No such instruction | GET .../account-entries | 404 | `test/unit/routes/paymentInstructions.test.ts` |
| GET swift-messages returns generated messages | A credit leg with payAdviceMsgType MT103 | GET .../swift-messages after confirming | 200, array length 1 | `test/unit/routes/paymentInstructions.test.ts` |
| GET swift-messages 404s for unknown id | No such instruction | GET .../swift-messages | 404 | `test/unit/routes/paymentInstructions.test.ts` |
| healthz returns ok | App created | GET /healthz | 200 {status:'ok'} | `test/unit/app.test.ts` |
| Empty POST body triggers 400 via central handler | Body {} | POST /payment-instructions | 400, code REQUEST_VALIDATION_FAILED | `test/unit/app.test.ts` |
| Non-ApiError thrown deep in the stack becomes a generic 500 | A store whose find() throws a plain Error('unexpected database outage') | POST /payment-instructions | 500, body {code:'INTERNAL_ERROR', message:'Unexpected server error'}, console.error called | `test/unit/app.test.ts` |
| App defaults to a fresh in-memory store | createApp() called with no store argument | GET /payment-instructions | 200, empty array | `test/unit/app.test.ts` |
| RequestValidationError shape | new RequestValidationError('bad request body') | toBody() called | httpStatus 400, code REQUEST_VALIDATION_FAILED, body matches | `test/unit/errors.test.ts` |
| BusinessValidationError carries a caller-supplied code | new BusinessValidationError('LEGS_UNBALANCED', 'legs do not balance') | toBody() called | httpStatus 409, code LEGS_UNBALANCED | `test/unit/errors.test.ts` |
| BusinessValidationError code varies per instance | new BusinessValidationError('SWIFT_ADV_COV_MISMATCH', 'mismatch') | code read | 'SWIFT_ADV_COV_MISMATCH' | `test/unit/errors.test.ts` |
| NotFoundError shape | new NotFoundError('no such instruction') | toBody() called | httpStatus 404, code NOT_FOUND | `test/unit/errors.test.ts` |
| Store find() before any save | A fresh store | find('IPLC','REF-1',1) | undefined | `test/unit/store/paymentInstructionStore.test.ts` |
| Store save then find by natural key | An instruction saved at (IPLC,REF-1,1) | find('IPLC','REF-1',1) | Returns the exact saved object | `test/unit/store/paymentInstructionStore.test.ts` |
| findFingerprint returns saved fingerprint | save(instr, 'abc123') | findFingerprint at the same key | 'abc123' | `test/unit/store/paymentInstructionStore.test.ts` |
| findFingerprint undefined without one | save(instr) with no fingerprint argument | findFingerprint at that key | undefined (while find() still returns the instruction) | `test/unit/store/paymentInstructionStore.test.ts` |
| findById works independently of natural key | An instruction saved | findById(its instructionId) vs findById('missing') | Returns the instruction / undefined respectively | `test/unit/store/paymentInstructionStore.test.ts` |
| Natural key requires exact match on all three fields | An instruction saved at (IPLC, REF-1, 1) | find() called with a different originModule, mainRef, or sequence | undefined in each case | `test/unit/store/paymentInstructionStore.test.ts` |
| search with no filter returns everything | 3 instructions saved across modules/refs | search({}) | All 3 returned | `test/unit/store/paymentInstructionStore.test.ts` |
| search filters by originModule / mainRef / both / neither-match | 3 instructions with varying originModule/mainRef | search() called with various filter combinations | Correct subset (or empty array) returned | `test/unit/store/paymentInstructionStore.test.ts` |
| Valid confirm body parses and types correctly | A minimal valid PaymentInstructionConfirmRequest | validateConfirmRequest() | Returns typed result with originModule/debitLegs preserved | `test/unit/validation/requestSchema.test.ts` |
| Optional fields accepted when valid | tenorType, tenorStartDate, maturityDate, payInstrFlag all supplied validly | validateConfirmRequest() | No throw, payInstrFlag echoed | `test/unit/validation/requestSchema.test.ts` |
| Missing required field throws | mainRef omitted | validateConfirmRequest() | Throws RequestValidationError | `test/unit/validation/requestSchema.test.ts` |
| Invalid accountType enum throws | accountType: 'BOGUS' | validateConfirmRequest() | Throws RequestValidationError | `test/unit/validation/requestSchema.test.ts` |
| Empty debitLegs blames debitLegs specifically | debitLegs: [] | validateConfirmRequest() | Message starts with 'debitLegs: debitLegs must contain at least 1 item' | `test/unit/validation/requestSchema.test.ts` |
| Empty creditLegs (no bridge) blames creditLegs specifically | creditLegs: [] with no suspenseBridge | validateConfirmRequest() | Message starts with 'creditLegs: creditLegs must contain at least 1 item' | `test/unit/validation/requestSchema.test.ts` |
| Multiple simultaneous violations are all reported | mainRef undefined AND sequence not a number | validateConfirmRequest() | Message contains both 'mainRef' and 'sequence', semicolon-joined (>1 part) | `test/unit/validation/requestSchema.test.ts` |
| Root-level type error uses '(root)' path | body is the string 'not-an-object' | validateConfirmRequest() | Message contains '(root)' | `test/unit/validation/requestSchema.test.ts` |
| Valid suspenseBridge with both entry lists accepted | debitEntries and creditEntries both well-formed | validateConfirmRequest() | No throw, debitEntries length 1 in the result | `test/unit/validation/requestSchema.test.ts` |
| suspenseBridge omitted is undefined in result | No suspenseBridge field | validateConfirmRequest() | result.suspenseBridge is undefined | `test/unit/validation/requestSchema.test.ts` |
| suspenseBridge malformed amount/crossRate throws | amount 'nope' or crossRate 'bad' | validateConfirmRequest() | Throws RequestValidationError | `test/unit/validation/requestSchema.test.ts` |
| sourceComponent/balanceModule enums accepted when valid, rejected when bogus | sourceComponent BALANCE+balanceModule IBL/EBL, or CHARGE with no balanceModule; vs BOGUS values | validateConfirmRequest() | Valid combos pass through typed; bogus enum values throw | `test/unit/validation/requestSchema.test.ts` |
| classify: minimal valid body parses | debitLegs and creditLegs each with one leg, no balanceTolerance | validateClassifyRequest() | debitLegs length 1, balanceTolerance undefined | `test/unit/validation/requestSchema.test.ts` |
| classify: balanceTolerance accepted when nonnegative, rejected when negative | balanceTolerance 0.5 vs -1 | validateClassifyRequest() | 0.5 accepted and echoed; -1 throws RequestValidationError | `test/unit/validation/requestSchema.test.ts` |
| classify: missing debitLegs throws | Body has only creditLegs | validateClassifyRequest() | Throws RequestValidationError | `test/unit/validation/requestSchema.test.ts` |
| classify: root-level type error uses '(root)' path | body is 'not-an-object' | validateClassifyRequest() | Message contains '(root)' | `test/unit/validation/requestSchema.test.ts` |
