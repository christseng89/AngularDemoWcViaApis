---
knowledge_id: Testing-Methodology-and-Coverage
title: "Testing Methodology and Coverage"
domain: Payment
category: Test Methodology
snapshot_date: 2026-08-22
tags:
  - payment
  - testing
---

# Testing Methodology and Coverage

## Coverage floor

Both the microservice (`microservices/payment-component/`) and the Angular app enforce a **90% coverage floor** (statements/branches/functions/lines), gated in CI. The legacy Import/Export LC mock API (`backend/`) requires passing tests but currently enforces no coverage floor. See this repo's own `CLAUDE.md` standing rule: run every test surface a change could plausibly touch, never lower a floor to make a change easier.

## Two independent Jest configs — never cross them

The Angular app's own Jest config and the microservice's own Jest config are separate and must not be mixed — a standing project rule, included here as `TEST-RULE-*` evidence of process discipline rather than a domain business rule.

## What actually has test coverage, and what doesn't

- **Microservice domain logic** (`classification.ts`, `suspenseBridge.ts`, `accountEntries.ts`, `balanceValidation.ts`, `swiftMessages.ts`, `voucherDescription.ts`, `money.ts`, validation, routes, store) — thoroughly tested with concrete worked numeric examples; this is the strongest evidence tier in [[Business-Rule-Index]].
- **Angular Payment Component Simulator** — thoroughly tested, including the leg-allocator's "waterfall" rebalancing rules (see [[Payment Component Simulator UI]]).
- **The 9 legacy LC web components** (`src/app/web-components/{export,import}/*.element.ts`) — **no unit tests at all**. Only `shared.ts`'s pure helper functions (`round`, `fmt`, `escapeHtml`, `ddaAcctsByCcy`, `chargeAmt`, `groupChargesByCcy`) are covered, via `shared.spec.ts`. Test coverage explicitly **excludes** the 9 elements themselves and all `.html` templates from collection — meaning the charge-calculation business rules documented in [[Charge Integration]] rest on implementation code and inline comments, not executable assertions. Treat `CHARGE-RULE-*` entries sourced from this area with correspondingly more caution than a rule backed by a passing test.

## Regression and curl-based scenario evidence

`microservices/payment-component/test/regression.ts` replays 6 FSD-verified classification scenarios, a V8 balance-validation worked example, two voucher-description worked examples, and a full HTTP smoke test (idempotency, dryRun, classify-preview, RTGS-vs-NOSTRO). Two curl-based request fixtures (`test/curl-tests/requests/case1`, `case2`) exercise the [[Suspense Account|Suspense bridge]]'s FX-pair generation end to end, including the v1.9.0 debit-side netting rule and its deliberate non-application on the credit side. See [[Test-Scenario-Index]] for curated scenario write-ups.

## Related knowledge

- [[Payment Component Simulator UI]]
- [[Payment-Traceability-Matrix]]
- [[Business-Rule-Index]] — 5 rules tagged TestScenario (`TEST-RULE-*`)
