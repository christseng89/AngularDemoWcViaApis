---
knowledge_id: UI-Business-Case-Model-Test-Scenarios
title: "UI Business Case Model Test Scenarios"
domain: Payment
category: Test Scenarios
snapshot_date: 2026-08-22
tags:
  - payment
  - test-scenario
---

# UI Business Case Model Test Scenarios

24 scenarios extracted from this area's test files. See [[Payment Component Simulator UI]] for the business rules these scenarios prove, and [[Testing Methodology and Coverage]] for how this evidence tier was established.

| Scenario | Given | When | Then | Source |
|---|---|---|---|---|
| buildHeaderFields returns [] for GAP verdict | a BusinessCaseConfig with verdict 'GAP' | buildHeaderFields(config) is called | the result equals [] | `business-case-fields.spec.ts 'returns [] for a non-PASS verdict'` |
| buildHeaderFields returns [] for N_A verdict | a BusinessCaseConfig with verdict 'N_A' | buildHeaderFields(config) is called | the result equals [] | `business-case-fields.spec.ts 'returns [] for a non-PASS verdict'` |
| PASS case header row built with correct defaults | a PASS config with module 'IPLC', id 'pay-accept', no dualPrefixOptions | buildHeaderFields(config) is called | exactly one field group is returned; unitCode default 'HQ', mainRef default 'IPLC-pay-accept-0001', sequence default 1 | `business-case-fields.spec.ts 'builds the unitCode/mainRef/sequence row for a PASS case, with mainRef defaulted from module+id'` |
| voucherPrefix select added when dualPrefixOptions is set | a PASS config with module 'EPLC' and two dualPrefixOptions entries | buildHeaderFields(config) is called | a 'voucherPrefix' select field is present, type 'select', defaultValue equal to the first option's value, props.options equal to config.dualPrefixOptions, and props.description contains the config's citation text | `business-case-fields.spec.ts 'adds a voucherPrefix select, defaulted to the first option, when dualPrefixOptions is set'` |
| registry has exactly 15 PASS + 4 GAP + 4 N_A = 23 cases | the BUSINESS_CASES array | filtered by verdict | 15 PASS, 4 GAP, 4 N_A, 23 total | `business-case-registry.spec.ts 'has 15 PASS (all legacy-traced) + 4 GAP + 4 N_A cases (23 total)'` |
| every business case id is unique | BUSINESS_CASES | ids are collected into a Set | the Set size equals the array length (no duplicate ids) | `business-case-registry.spec.ts 'every case has a unique id'` |
| every PASS case resolves a voucher prefix via sourceFunctionCode xor dualPrefixOptions | every PASS-verdict case in BUSINESS_CASES | checked for sourceFunctionCode or dualPrefixOptions presence | at least one of the two is set for every PASS case | `business-case-registry.spec.ts 'every PASS case can resolve a voucher prefix'` |
| every PASS/GAP case has exactly one DEBIT and one CREDIT leg | every case with verdict !== 'N_A' | leg sides are inspected | the sides array contains both 'DEBIT' and 'CREDIT' and legs.length === 2 | `business-case-registry.spec.ts 'every PASS/GAP case has exactly one DEBIT and one CREDIT leg'` |
| every N_A case has no legs and a populated moduleStats | every case with verdict === 'N_A' | legs and moduleStats are inspected | legs equals [] and moduleStats is truthy (non-empty) | `business-case-registry.spec.ts 'every N_A case has no legs and a populated moduleStats summary'` |
| all GAP cases belong to module RPFM | every case with verdict === 'GAP' | module is inspected | module equals 'RPFM' for all of them | `business-case-registry.spec.ts 'all 4 GAP cases belong to RPFM'` |
| RTGS is never a selectable AccountType | every leg of every case in BUSINESS_CASES | leg.accountTypeOptions is inspected | the array never contains 'RTGS' | `business-case-registry.spec.ts 'no leg offers RTGS as a selectable AccountType'` |
| every RTGS-flagged leg defaults to accountType NOSTRO | every leg with defaultRtgsIndicator truthy | defaultAccountType is inspected | it equals 'NOSTRO' | `business-case-registry.spec.ts 'every RTGS-flagged leg defaults to accountType NOSTRO'` |
| every leg has a positive default amount and 3-letter currency code | every leg of every case | defaultAmountTxCcy and defaultCurrency are checked | Number(defaultAmountTxCcy) > 0 and defaultCurrency matches /^[A-Z]{3}$/ | `business-case-registry.spec.ts 'every leg has a positive default amount and a 3-letter currency code'` |
| MODULE_GROUPS covers all 11 modules in the documented order | MODULE_GROUPS | module values are mapped | equals ['IPLC','EPLC','IMCO','EXCO','GTEE','IWGT','RPFM','CFNC','SBLC','REIM','PYMT'] | `business-case-registry.spec.ts 'covers all 11 modules in the documented order'` |
| every module group has a non-empty label | MODULE_GROUPS | moduleLabel is inspected per group | moduleLabel is truthy for every group | `business-case-registry.spec.ts 'every group has a non-empty label'` |
| MODULE_GROUPS is an exact partition of BUSINESS_CASES | MODULE_GROUPS flattened by cases | compared against BUSINESS_CASES | same length, same set of ids (none dropped/duplicated), and every case's module matches its group's module | `business-case-registry.spec.ts 'is an exact partition of BUSINESS_CASES'` |
| buildConfirmRequest assembles header/module/legs from inputs | a PASS config, a base model, debitLegs, creditLegs, transactionCurrency 'USD' | buildConfirmRequest is called | req.originModule='IPLC', req.mainRef='IPLC-test-0001', req.sequence=1, req.unitCode='HQ', req.debitLegs===debitLegs, req.creditLegs===creditLegs | `business-case-request.spec.ts 'assembles header fields, module, and legs from the model/config/legs inputs'` |
| model.sequence is coerced to a number | model.sequence = '3' (string) | buildConfirmRequest is called | req.sequence === 3 (number) | `business-case-request.spec.ts 'coerces model.sequence to a number'` |
| sourceFunctionCode used when no dual-prefix choice | config.sourceFunctionCode='PayAccept', no dualPrefixOptions | buildConfirmRequest is called | req.sourceFunctionCode==='PayAccept', req.voucherCodePrefixOverride is undefined | `business-case-request.spec.ts 'uses config.sourceFunctionCode when there is no dual-prefix choice'` |
| model.voucherPrefix used, not config.sourceFunctionCode, when dualPrefixOptions is set | config has dualPrefixOptions and sourceFunctionCode='PayAccept'; model.voucherPrefix='EPLC03NULLNULLNULL' | buildConfirmRequest is called | req.sourceFunctionCode is undefined, req.voucherCodePrefixOverride==='EPLC03NULLNULLNULL' | `business-case-request.spec.ts 'uses model.voucherPrefix (not config.sourceFunctionCode) when dualPrefixOptions is set'` |
| transactionCurrency sent explicitly | debitLegs/creditLegs in USD, transactionCurrency param 'USD' | buildConfirmRequest is called | req.transactionCurrency==='USD' | `business-case-request.spec.ts 'is sent explicitly, independent of any leg currency'` |
| transactionCurrency can diverge from every leg's own currency (Full pay in JPY) | debitLegs all denominated in JPY, transactionCurrency param 'USD' | buildConfirmRequest is called | req.transactionCurrency==='USD' while req.debitLegs[0].currency==='JPY' — *FX:* Confirms the client never re-infers transaction currency from a leg's settlement currency, avoiding the pre-v1.10.0 server bug where a fully-foreign-currency debit side broke H-2 currency-scale validation. | `business-case-request.spec.ts 'can diverge from every leg's own currency — e.g. Full pay in JPY against a USD transaction'` |
| suspenseBridge omitted from request when not supplied | buildConfirmRequest called without a suspenseBridge argument | the request is built | req.suspenseBridge is undefined | `business-case-request.spec.ts 'is omitted from the request when not supplied'` |
| suspenseBridge included verbatim when supplied | a SuspenseBridge object with debitEntries=[{amount:'10',currency:'USD',sourceComponent:'CHARGE'}] | buildConfirmRequest is called with that object as the 6th argument | req.suspenseBridge is the exact same object reference | `business-case-request.spec.ts 'is included verbatim when supplied'` |
