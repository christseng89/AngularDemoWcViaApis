---
knowledge_id: FX-Processing
title: "FX Processing"
domain: Payment
category: Domain Concept
snapshot_date: 2026-08-22
tags:
  - payment
  - domain-concept
  - fx
---

# FX Processing

FX processing exists to answer one question wherever it comes up: when a leg's own currency differs from the deal's **transaction currency**, how does the system keep the Settlement Voucher balanced not just in aggregate (V8, see [[Accounting Model]]) but **currency-by-currency**? The answer is always the same shape — a **self-balancing FX Exchange pair**, two `INTERNAL`-type legs (one denominated in the foreign currency, one in the transaction currency) carrying the *identical* transaction-currency amount — but the sizing rule for that pair differs by where the foreign-currency exposure came from.

## WHEN FX processing triggers

- A caller's own leg has a settlement currency different from `transactionCurrency` — the leg-allocator UI computes and previews the pair client-side (`debitFxPairs`/`creditFxPairs` in [[Payment Component Simulator UI]]); the pair is not sent to or received from the server.
- A [[Suspense Account|Suspense bridge]] entry's currency differs from `transactionCurrency` — the server itself generates the pair, following the debit-side-nets / credit-side-never-nets asymmetry documented in [[Suspense Account]].

## WHY the implementation determines FX is required — the core design constraint

Every FX pair amount is **reused verbatim** from an already-computed, already-rounded figure — never re-derived by combining two amounts and converting once. This is a deliberate fix for a documented v1.7.x rounding-drift bug: "round-per-line, then combine" and "combine, then round once" can legitimately land a minor unit apart for the same real-world amounts, and the system had been silently producing the second (wrong, undocumented) answer. `resolveBucketRate` additionally enforces that every entry sharing a currency within one Suspense bucket resolves to the *same* cross-rate — a mismatch is treated as a caller-side data error, not a legitimate multi-rate scenario within one request.

## Worked example — v1.9.0 debit-side netting

EUR debit leg: `amountTxCcy=18`, `amountAccountCcy=20`. Suspense `debitEntries` EUR 17 (crossRate 1.1). Diff = 17 − 20 = −3 (account-ccy terms, i.e. the real leg exceeds the Suspense amount) → a **Leg-anchored** residual pair only, sized to the shortfall, not the full gross Suspense amount. A second worked case where the leg (15.45/17) exactly matches the Suspense gross (17) produces **no FX pair at all** — "Same Currency + Same Amount → Direct Settlement → No FX Pair," the reviewer-confirmed rule that motivated v1.9.0 in the first place (see `SUSPENSE-RULE` entries).

## Rounding discipline

Cross-currency conversion always rounds to the **transaction currency's** own minor-unit scale (`minorUnitsForCurrency`), confirmed for both USD (2dp) and JPY (0dp), with `ROUND_HALF_UP` throughout the Suspense/FX modules. See [[Accounting Model]] for the parallel currency-minor-units discipline in ordinary Settlement posting.

## Related knowledge

- [[Suspense Account]]
- [[Accounting Model]]
- [[Payment Component Simulator UI]] — the client-side FX Conversion Pair preview
- [[FX Trigger Decision Table]]
- [[Business-Rule-Index]] — 45 rules tagged FX (`FX-RULE-*`)
