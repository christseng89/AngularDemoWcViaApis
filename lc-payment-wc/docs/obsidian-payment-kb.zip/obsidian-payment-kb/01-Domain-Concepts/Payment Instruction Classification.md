---
knowledge_id: Payment-Instruction-Classification
title: "Payment Instruction Classification"
domain: Payment
category: Domain Concept
snapshot_date: 2026-08-22
tags:
  - payment
  - domain-concept
  - classification
---

# Payment Instruction Classification

Classification answers one question: **"is this transaction Payment-Component-related?"** — implemented as the **Payment Component Identification Rule (Rev. 2)**, an FSD §4-traced XOR test. It is computed on every Confirm request (Step 2 of the [[Confirm Payment Instruction Flow]]) and is purely **informational** — the result is returned in the response but never blocks posting, never changes which legs get settled, and is not part of the balance check.

## The rule

For each of CUSTOMER, NOSTRO, and VOSTRO independently, compute whether that account type appears on the debit side XOR the credit side (i.e. exactly one side, not both, not neither):

```
customerXor = has(debitTypes, CUSTOMER) xor has(creditTypes, CUSTOMER)
nostroXor   = has(debitTypes, NOSTRO)   xor has(creditTypes, NOSTRO)
vostroXor   = has(debitTypes, VOSTRO)   xor has(creditTypes, VOSTRO)
paymentComponentRelated = customerXor OR nostroXor OR vostroXor
```

Any one term firing is sufficient. SUSPENSE and INTERNAL never participate — see [[Account Types]]. This is the same rule the 23-case business-case catalog in [[Payment Component Simulator UI]] traces against 11 legacy trade-finance modules (15 PASS, 4 GAP, 4 N/A).

```mermaid
flowchart TD
    A[debitLegs / creditLegs] --> B{CUSTOMER on\nexactly one side?}
    A --> C{NOSTRO on\nexactly one side?}
    A --> D{VOSTRO on\nexactly one side?}
    B -->|yes| E[paymentComponentRelated = true]
    C -->|yes| E
    D -->|yes| E
    B -->|no| F{any term true?}
    C -->|no| F
    D -->|no| F
    F -->|no| G[paymentComponentRelated = false]
```

## Why an XOR, not a simpler membership test?

A type appearing on **both** sides (e.g. two CUSTOMER legs, one debit one credit) does not fire — that pattern represents an internal reallocation between two of the bank's own account holders, not a payment leaving/entering the Payment-Component-relevant boundary. A type appearing on **neither** side obviously doesn't fire either. Only a genuine one-sided crossing counts.

## Related knowledge

- [[Account Types]]
- [[Confirm Payment Instruction Flow]]
- [[Payment Component Simulator UI]]
- [[Classification XOR Decision Table]] (worked truth table)
- [[Business-Rule-Index]] — 27 rules tagged Classification (`CLASS-RULE-*`)
