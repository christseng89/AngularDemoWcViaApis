---
knowledge_id: Settlement
title: "Settlement"
domain: Payment
category: Domain Concept
snapshot_date: 2026-08-22
tags:
  - payment
  - domain-concept
  - settlement
---

# Settlement

**Settlement** is the unconditional posting of one GL **Account Entry** per submitted leg — the Payment Component's Step 4 of the [[Confirm Payment Instruction Flow]] (`buildSettlementEntries`). Every debit leg becomes one `SETTLEMENT`-type entry with `drCrIndicator='D'`; every credit leg becomes one with `drCrIndicator='C'`. This happens for every request, independent of the [[Payment Instruction Classification|classification]] result — classification never gates settlement.

## What a Settlement Voucher contains

Each posted entry carries: the leg's own account number and currency, the amount (preferring the leg's own account-currency amount over the transaction-currency amount, parsed/formatted exclusively through `decimal.js` — see [[Accounting Model]]), the assembled voucher description code (see [[SWIFT Messaging and Vouchers]]), and — since a later hardening pass — an echoed-back `exchangeRate1` sourced straight from whichever rate field the leg itself carried (`drRate`/`drBuyRate` for debit, `crBuyRate`/`sellRate` for credit), never recomputed.

## Before settlement can happen: the balance gate

Settlement only runs after **V8**, the exact Dr = Cr balance check in transaction currency, passes (Step 1 of the Confirm flow). V8 replaced a legacy per-side "≤ target total" check with ±0.01 tolerance; the current default tolerance is zero. See the Accounting domain's `POSTING-RULE` entries in [[Business-Rule-Index]] for the full hardening history (tagged M-7), and [[Knowledge-Gaps]] for the still-open question of whether any `originModule` legitimately needs the old tolerance restored.

## What Settlement is deliberately NOT

Prior to v1.6.0 this service also generated **Charge Voucher** and **Liability Voucher** streams from the same request. Both were removed entirely — charge/liability posting now belongs to an external Charge/Balance Component, connected only through the [[Suspense Account|Suspense bridge]]. A Settlement Voucher today is Settlement-only.

## Related knowledge

- [[Accounting Model]]
- [[Suspense Account]]
- [[FX Processing]]
- [[Confirm Payment Instruction Flow]]
- [[Business-Rule-Index]]
