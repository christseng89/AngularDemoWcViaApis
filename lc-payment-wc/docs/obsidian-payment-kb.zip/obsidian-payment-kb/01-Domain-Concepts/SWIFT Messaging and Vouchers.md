---
knowledge_id: SWIFT-Messaging-and-Vouchers
title: "SWIFT Messaging and Vouchers"
domain: Payment
category: Domain Concept
snapshot_date: 2026-08-22
tags:
  - payment
  - domain-concept
  - swift
---

# SWIFT Messaging and Vouchers

Two closely related but distinct pieces of Confirm-flow logic, both server-derived from the confirmed legs but neither itself a GL posting:

## Voucher description assembly

`voucherDescription.ts` builds each leg's `accountDesc` — a fixed per-function **prefix** (resolved from `sourceFunctionCode` or a direct override; missing both throws a `RequestValidationError`) plus a single **TypeChar** keyed off the leg's own [[Account Types|account type]], with a special override when `rtgsIndicator` is set on a NOSTRO leg. Both the prefix and TypeChar formulas are ported directly from legacy source (see [[Legacy Baseline Traceability]]). This step also computes a UI-only `accountCategory` bucket. It produces a descriptive string attached to a leg — never an accounting entry itself.

## SWIFT / ISO 20022 message generation

`swiftMessages.ts` generates one SWIFT-style message (MT103/PACS008/MT202/MT202COV/PACS009COV) per **credit** leg that carries a recognized message-type field (`payAdviceMsgType`/`payCoverMsgType`). Two business rules matter most here:

- **Cross-field validation.** A COV-style cover message must be paired with a compatible advice type — `validateSwiftCrossField` throws before message generation if this is violated (e.g. a cover message type without any advice type set).
- **32A vs. 33B decoupling.** The settled amount/currency (32A) and the instructed amount/currency (33B) are correctly differentiated for a cross-currency credit leg, using `transactionCurrency` as the instructed currency — this was a genuine defect found by the expert review (32A/33B not decoupled) and closed by a later hardening pass (tagged H-3, alongside a shared SWIFT gpi UETR linking a leg's own advice and cover message pair).

Messages are generated and persisted with status `PENDING` only — **no actual transmission integration exists**, so SWIFT status is never observed as anything else. This is an operational gap, not a business-rule gap; see [[Knowledge-Gaps]].

## Related knowledge

- [[Payment Instruction Classification]]
- [[Account Types]]
- [[Confirm Payment Instruction Flow]]
- [[Business-Rule-Index]] — 15 rules tagged SWIFT (`SWIFT-RULE-*`)
