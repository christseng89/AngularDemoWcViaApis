---
knowledge_id: Suspense-Account
title: "Suspense Account"
domain: Payment
category: Domain Concept
snapshot_date: 2026-08-22
tags:
  - payment
  - domain-concept
  - suspense
---

# Suspense Account

The **Suspense bridge** is how the [[Payment Component Overview|Payment Component]] stays financially connected to an external **Charge/Balance Component** without ever calculating or posting a single charge line itself (see [[Charge Integration]] for that boundary). A caller submits raw Suspense amounts — `suspenseBridge.debitEntries` / `creditEntries`, each with an amount, currency, and (if foreign) a cross-rate — and `expandSuspenseBridge` (`microservices/payment-component/src/domain/suspenseBridge.ts`) turns them into real, balanced ledger legs before the [[Accounting Model|V8 balance check]] runs.

## What gets generated

Every Suspense entry becomes its own itemized leg — account type `SUSPENSE`, account number `'Suspense - Debit'` or `'Suspense - Credit'` — and, critically, **always lands in the credit-direction output array regardless of which input list it came from**. Where an entry's currency differs from the deal's transaction currency, one or more self-balancing **FX Exchange pair** legs (account type `INTERNAL`) are generated alongside it, so the Settlement Voucher balances not just in aggregate but currency-by-currency. See `SUSPENSE-RULE-*` entries in [[Business-Rule-Index]] for the full itemized rule set.

```mermaid
flowchart TD
    A[suspenseBridge.debitEntries /\ncreditEntries] --> B[group by currency]
    B --> C{bucket currency ==\ntransaction currency?}
    C -->|yes| D[Suspense leg only,\nno FX pair]
    C -->|no| E{DEBIT bucket?}
    E -->|yes, v1.9.0| F[net gross Suspense vs.\nmatching debitLegs\n-> at most one residual FX pair]
    E -->|no, CREDIT bucket, v1.8.0| G[always emit a Suspense-anchored pair;\nindependently emit a Leg pair if a\nmatching real credit leg exists\n-- never netted against each other]
    F --> H[merged into full leg set]
    G --> H
    D --> H
    H --> I[V8 balance validation]
```

## The asymmetry that matters most

The debit side and credit side are handled **deliberately differently** (v1.9.0), and this is the single most load-bearing design decision in the Suspense domain:

- **Debit-side bucket:** the Suspense leg lands CREDIT while a matching real debit leg is DEBIT — opposite placement, i.e. "the same money" funding the bridge from two directions. Same-currency-same-amount nets to **zero pairs**; a partial match nets to **one residual pair**.
- **Credit-side bucket:** a matching real credit leg is the SAME direction as the generated Suspense leg (both CREDIT) — an independent exposure, not the same money. Netting these would silently break per-currency balance while staying aggregate-safe, so they are **never netted**: up to two independent pairs are generated instead.

This distinction was reached after three documented design iterations (v1.7.0/1 → v1.8.0 → v1.9.0), each fixing a specific rounding or decorative-posting defect — see the Suspense domain's rules and [[Knowledge-Gaps]] for the two still-open items (untested debit+credit-same-currency interaction; README staleness describing the superseded v1.7.x mechanism).

## A hard rule worth internalizing

**Suspense bridge expansion happens BEFORE the balance check runs**, not after. A caller that submits a `debitEntries` amount without pre-adjusting its own real `debitLegs` total by the same amount gets a 409 `LEGS_UNBALANCED` — the bridge does not "absorb" an imbalance, it only converts an already-planned-for amount into real legs. See `SUSPENSE-RULE-001` for the exact evidence.

## Related knowledge

- [[Charge Integration]] — the component boundary this bridge exists to cross
- [[FX Processing]] — how the FX Exchange pairs this module generates fit the broader FX picture
- [[Accounting Model]] — the V8 balance check this module's output must satisfy
- [[Suspense Bucket Routing Decision Table]]
- [[Business-Rule-Index]] — 21 rules tagged Suspense (`SUSPENSE-RULE-*`)
