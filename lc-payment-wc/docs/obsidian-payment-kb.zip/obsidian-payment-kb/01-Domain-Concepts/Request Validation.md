---
knowledge_id: Request-Validation
title: "Request Validation"
domain: Payment
category: Domain Concept
snapshot_date: 2026-08-22
tags:
  - payment
  - domain-concept
  - validation
---

# Request Validation

Validation in this service is deliberately **layered**, and the layering itself is a business rule: schema-shape violations and business-balance violations get different HTTP semantics, so a caller can distinguish "you sent me something malformed" from "what you sent me is internally inconsistent."

## The two layers

1. **Schema-shape validation (Zod, `requestSchema.ts`) → HTTP 400.** Missing required fields, bad enum values, malformed decimal strings, and a handful of business-adjacent-but-still-structural rules: amounts can never be negative (**M-1** — direction must come from which leg array an entry is in, never from a signed amount, closing a way to game the [[Accounting Model|V8 balance check]]), exchange rates can never be zero (**M-2**), and every amount field is gated by that currency's own decimal precision sourced from a Currency-API master (**H-2**) — an unknown currency is skipped rather than assumed 2dp.
2. **Business-rule validation (domain layer) → HTTP 409.** Unbalanced legs (`LEGS_UNBALANCED`), an idempotency-key/payload mismatch (`IDEMPOTENCY_KEY_CONFLICT`), a SWIFT cross-field violation, and similar — these are structurally valid requests that violate a business invariant.

`creditLegs` may legitimately be empty specifically when a [[Suspense Account|Suspense bridge]] will contribute its own credit-side leg (v1.10.1) — `debitLegs` keeps an unconditional non-empty requirement, since the bridge never generates a debit-direction leg.

## Idempotency

Every Confirm request is uniquely identified by a **natural key** — `(originModule, mainRef, sequence)`, not a generated id. A payload-fingerprint check (**C-2**, SHA-256 of the canonicalized validated request) distinguishes a genuine replay (same key, same payload → HTTP 200, no reprocessing) from a same-key-different-payload conflict (→ 409 `IDEMPOTENCY_KEY_CONFLICT`). The instruction store is in-memory, so this idempotency guarantee holds only within one running process — a documented operational limitation, not a business-rule gap.

## Related knowledge

- [[Accounting Model]]
- [[Payment Instructions API]]
- [[Confirm Payment Instruction Flow]]
- [[Business-Rule-Index]] — 43 rules tagged Validation (`VALIDATION-RULE-*`)
