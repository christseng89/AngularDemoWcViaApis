---
knowledge_id: Legacy-Baseline-Traceability
title: "Legacy Baseline Traceability"
domain: Payment
category: Domain Concept
snapshot_date: 2026-08-22
tags:
  - payment
  - domain-concept
  - traceability
---

# Legacy Baseline Traceability

A distinctive feature of this repository: nearly every business rule is deliberately traced back to a **named legacy source function or FSD section**, rather than being freshly invented for the demo. This traceability discipline recurs across multiple unrelated parts of the codebase and is worth understanding as its own concept, since it explains why so many rules in [[Business-Rule-Index]] cite a legacy function name in their evidence.

## Where this shows up

- **Voucher description and SWIFT generation** (`voucherDescription.ts`, `swiftMessages.ts`) are explicit ports of legacy formulas (e.g. `SYF_*_CAL_PAYMENT_AC_DESC`, `SYM_IMCO_SetPaymentVchDesc`) — see [[SWIFT Messaging and Vouchers]].
- **The demo backend's currency master** (`backend/server.js`) traces its endpoint shape in comments to the legacy **STAN** core-banking system's Currency Master function group (`grp_G49082300152.xml`, `InquireCurrency F05030701358`) — while explicitly flagging that the actual response shape was invented for the demo since STAN's own screen has no bespoke field list to trace.
- **The 23-case business-case catalog** (`business-case-registry.ts`) traces each simulated scenario to a specific legacy Confirm function, tagged PASS/GAP/N_A by a dedicated Mapping Functions verification report.
- **The RPFM gap analysis** distinguishes "RPFM doesn't call the Payment Component" from "money isn't tracked at all" — RPFM has its own parallel `VCH`-template posting rail, complete for only 1 of 4 traced legacy business events.

## Why this matters

Traceability-to-legacy is the primary way this vault's extraction agents could tell **CONFIRMED** business logic from **invented demo filler**. Where a rule's evidence is "the code does X" but no legacy trace exists, that gap is called out explicitly (e.g. the demo backend's FX rates are labeled fake/invented, not sourced from a real rate feed) rather than silently treated as equally authoritative. See [[Knowledge-Gaps]] for the specific items where a legacy trace was expected but not found (e.g. `drRate`/`crBuyRate`/`sellRate`'s exact selection logic, `payInstrFlag` reachability).

## Related knowledge

- [[Payment Component Overview]]
- [[Payment Component Simulator UI]]
- [[Source-to-Knowledge-Map]]
- [[Knowledge-Gaps]]
