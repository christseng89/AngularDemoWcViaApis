---
knowledge_id: Account-Types
title: "Account Types"
domain: Payment
category: Domain Concept
snapshot_date: 2026-08-22
tags:
  - payment
  - domain-concept
  - classification
---

# Account Types

Every leg in a Payment Instruction carries one `accountType`, drawn from a fixed enum: **CUSTOMER**, **NOSTRO**, **VOSTRO**, **SUSPENSE**, or **INTERNAL**. Account type drives two independent things: the [[Payment Instruction Classification|classification]] XOR test, and the account-type-keyed character used in [[SWIFT Messaging and Vouchers|voucher description assembly]].

## RTGS is not a 6th account type

RTGS settlement is modeled as a **flag on a NOSTRO leg** (`rtgsIndicator: true`), not a distinct account type — a deliberate schema-evolution decision. An earlier FSD version (v1.1.0/v1.2.0) modeled RTGS as its own `AccountType` enum value; this was superseded, and the two FSD versions disagreeing about it is recorded as a CONFLICT rule (see `CLASS-RULE` entries tagged CONFLICT in [[Business-Rule-Index]] and the corresponding entry in [[Knowledge-Gaps]]). A leg's own `accountDesc` voucher code still gets a special `R` override when `rtgsIndicator` is set, even though the type itself is `NOSTRO`.

## SUSPENSE and INTERNAL never drive classification

Only CUSTOMER, NOSTRO, and VOSTRO participate in the [[Payment Instruction Classification]] XOR terms. A request built entirely of SUSPENSE and/or INTERNAL legs is never flagged `paymentComponentRelated` — confirmed directly by test (`classify('id-5', [SUSPENSE], [INTERNAL])` → all XOR flags false). SUSPENSE legs are how the [[Suspense Account|Suspense bridge]] and its FX Exchange pairs are always posted; INTERNAL legs are how the FX Exchange pair's own two sides are posted (both self-balancing legs of an FX pair are `accountType: INTERNAL`).

## Related knowledge

- [[Payment Instruction Classification]]
- [[Suspense Account]]
- [[SWIFT Messaging and Vouchers]]
- [[Classification XOR Decision Table]]
- [[Business-Rule-Index]]
