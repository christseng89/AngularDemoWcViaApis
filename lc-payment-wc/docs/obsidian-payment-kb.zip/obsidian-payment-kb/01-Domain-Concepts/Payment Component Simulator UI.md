---
knowledge_id: Payment-Component-Simulator-UI
title: "Payment Component Simulator UI"
domain: Payment
category: Domain Concept
snapshot_date: 2026-08-22
tags:
  - payment
  - domain-concept
  - ui
---

# Payment Component Simulator UI

The **Payment Component Simulator** (`src/app/payment-component/`) is the Angular application a BA or developer uses to drive the [[Payment Component Overview|Payment Component]] microservice through 23 catalogued, legacy-source-traced business cases spanning 11 trade-finance modules (IPLC, EPLC, IMCO, EXCO, GTEE, IWGT, RPFM, CFNC, SBLC, REIM, PYMT) — 15 tagged `PASS` (confirmed Payment Component users), 4 `GAP` (RPFM, which has its own parallel posting rail — see [[Knowledge-Gaps]]), 4 `N/A` (confirmed non-users, shown as a static citation card with no API calls at all).

## The moving parts

`BusinessCaseRunnerComponent` is the orchestrator: it owns the header form, an override-capable Transaction Currency/Total Amount pair, two repeatable Suspense Debit/Credit entry lists (feeding the [[Suspense Account|Suspense bridge]]), two `LegAllocatorComponent` instances (one per side) that split a case's protected total across multiple legs using a percentage-or-amount "waterfall" rebalancing model, and a single debounced (400ms) live-preview pipeline that calls a `dryRun` Confirm for PASS cases or a classify-only preview for GAP cases. `ResponseViewerComponent` and `SuspenseEntriesComponent` are presentation-only — they never recompute an accounting figure themselves, only re-group and reformat what the server already balanced. See [[Payment-Flow-Index]] for the full click-by-click flow.

## Why this matters as a domain concept, not just UI plumbing

The leg-allocator's "waterfall" rules, the H-2 client-side amount-precision guard, and the per-currency Suspense-bucket rounding fix (v1.13.1) all encode genuine banking calculation discipline (B-Tree-style: whichever field the user actually typed is authoritative, never re-derived from its own rounded counterpart) — not incidental frontend logic. 24 rules tagged `UI` in [[Business-Rule-Index]] document this in detail.

## A separate, unrelated UI: the legacy LC web components

`src/app/web-components/` implements 9 framework-free Custom Elements for Import/Export LC events (Issue, Settlement, Sight Payment/Settlement, Advise, Confirmed, Negotiation, Settlement, Collection). These call the **demo backend** (`backend/server.js`), never the Payment Component microservice — there is no `debitLegs`/`creditLegs`/`suspenseBridge` wiring anywhere in that file set. See [[Payment Architecture]] for why these two UIs are architecturally distinct, and [[Charge Integration]] for what these components actually compute.

## Related knowledge

- [[Payment Instruction Classification]]
- [[Suspense Account]]
- [[Payment Architecture]]
- [[Test-Scenario-Index]]
- [[Business-Rule-Index]] — 24 rules tagged UI (`UI-RULE-*`)
