---
knowledge_id: Payment
title: "Payment"
domain: Payment
category: Domain Concept
snapshot_date: 2026-08-22
tags:
  - payment
  - domain-concept
---

# Payment

In this system, a **Payment** is not a standalone object — it is the act of submitting a **Payment Instruction Confirm request** to the [[Payment Component Overview|Payment Component]]: a natural key (originModule, mainRef, sequence), a list of debit legs, a list of credit legs, and optionally a bridge to an external Charge/Balance Component. Submitting the same natural key twice is a **replay**, not a new payment (HTTP 200, not 201) — see the API domain's rules in [[Business-Rule-Index]] and [[Payment Instructions API]].

## The shape of a payment

Every leg (debit or credit) carries: an account number, an account type (`CUSTOMER`, `NOSTRO`, `VOSTRO`, `SUSPENSE`, or `INTERNAL` — see [[Account Types]]), a currency, an amount in transaction currency (`amountTxCcy`), and optionally an amount in the account's own currency plus an exchange rate, when the leg's settlement currency differs from the deal's transaction currency. See [[Payment Instruction (Data Model)]] for the full field list.

A payment is only "complete" once it clears every step of the [[Confirm Payment Instruction Flow]]: balance validation, classification, voucher assembly, GL posting, and (conditionally) SWIFT generation — all five happen atomically in one request/response, never as separate calls.

## What a payment is NOT, in this system

- It is not gated by [[Payment Instruction Classification]] — classification is informational only and never blocks posting.
- It is not where charge/commission is calculated — see [[Charge Integration]] for that boundary.
- It is not necessarily denominated entirely in one currency — see [[FX Processing]] and [[Suspense Account]] for how multi-currency legs and Suspense-bridge entries are reconciled to exact per-currency balance.

## Related knowledge

- [[Settlement]] — what happens to a payment once it's confirmed
- [[Payment Instruction Classification]]
- [[Account Types]]
- [[Payment-Flow-Index]]
- [[Business-Rule-Index]]
