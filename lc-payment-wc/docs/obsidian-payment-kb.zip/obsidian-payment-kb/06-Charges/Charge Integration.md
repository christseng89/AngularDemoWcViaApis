---
knowledge_id: Charge-Integration
title: "Charge Integration"
domain: Payment
category: Domain Concept
snapshot_date: 2026-08-22
tags:
  - payment
  - domain-concept
  - charges
---

# Charge Integration

This is the single most important architectural boundary in the repository, and it is easy to get backwards: **the Payment Component microservice never calculates or posts a charge, commission, or margin line.** All of that belongs to a separate, external **Charge/Balance Component**, and the two are connected only through the [[Suspense Account|Suspense bridge]]'s `'Suspense - Credit'` clearing account. This is not a documented aspiration — the §6.2 Charge Voucher and §6.3 Liability Voucher generation streams were physically removed from this service in v1.6.0 specifically to enforce it.

## The two-component pattern (worked example: LC Issue)

```
Charge Component (its own books)
Dr  Suspense - Credit
    Cr  Margin
    Cr  Commission
    Cr  Charge 1
    Cr  Charge 2

Payment Component (this service — funding/settlement only)
Dr  Customer A/C
    Cr  Suspense - Credit

Combined visible effect once both components have posted:
Dr  Customer A/C
    Cr  Margin
    Cr  Commission
    Cr  Charge 1
    Cr  Charge 2
```

`Suspense - Credit` nets to zero once both sides post — it is a clearing/bridge account, not a resting balance. The wire shape for this pattern is `creditLegs: []` (no real credit leg needed) plus `suspenseBridge.creditEntries` supplying the offsetting leg — a pattern that initially 400'd (the schema required `creditLegs.min(1)` unconditionally) until a fix (v1.10.1) recognized that a non-empty `suspenseBridge` always contributes its own credit-direction leg. See `CHARGE-RULE` entries in [[Business-Rule-Index]].

## Where actual charge calculation DOES happen in this repo

Confusingly, the **demo backend** (`backend/server.js`) — a separate, architecturally unrelated Express server — genuinely does compute trade-finance charges (margin, commission, SWIFT fee, foreign/correspondent bank charges, FX gain/loss) for the 9 legacy LC web components ([[Payment Component Simulator UI]]). These computations are real and rule-rich (quarter-rounded confirming commission, 360-day negotiation-discount convention, pledge-account exclusion, embedded-vs-separate FBC posting) but feed a completely different code path with no `debitLegs`/`creditLegs`/`suspenseBridge` wiring to the actual Payment Component. See [[Payment Architecture]] for why these were built as two separate systems, and the `CHARGE-RULE` entries sourced from the `demo-backend` and `web-components-lc` extraction groups for the specific pricing rules (e.g. "Export Negotiation discount interest applies only to usance bills, never sight," "no bank commission is charged at Import Sight Payment utilization").

## What is NOT wired up

`lc-issue-angular/`-style charge-calculation demos and the `backend/server.js` LC elements have **no integration** with the Payment Component microservice — they only compute the charge amount, never post any GL/Suspense entries against it. A proposed unified Charge Settlement Policy (INDIVIDUAL/SUM_BY_CURRENCY/SUM_ALL/HYBRID) exists only as a documented proposal, not an implementation.

## Related knowledge

- [[Suspense Account]]
- [[Payment Architecture]]
- [[Payment Component Simulator UI]]
- [[Business-Rule-Index]] — 12 rules tagged Charges (`CHARGE-RULE-*`)
